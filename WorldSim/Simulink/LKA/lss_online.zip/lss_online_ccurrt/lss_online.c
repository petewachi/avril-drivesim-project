/*
 * lss_online.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "lss_online".
 *
 * Model version              : 17.27
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Fri Feb  2 00:03:37 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "lss_online.h"
#include "rtwtypes.h"
#include "lss_online_private.h"
#include <string.h>
#include <math.h>
#include "rt_nonfinite.h"
#include "lss_online_capi.h"
#include "zero_crossing_types.h"
#define lss_online_period              (0.02)
#ifdef __cplusplus

extern "C"
{

#endif

  int checkMetaDataType(uint8_T slDataID, short cvtDataId);

#ifdef __cplusplus

}

#endif

#ifdef __cplusplus

extern "C"
{

#endif

  int checkMetaDataType(uint8_T slDataID, short cvtDataId);

#ifdef __cplusplus

}

#endif

void *pVI_DriveSim_Inputs_ECAT_BECKH_ANA3;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_chassis_velocities_longitudinal;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_driver_demands_steering;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_ECAT_BECKH_DIG4;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Outputs_Vicrt_Status;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_ECAT_BECKH_ANA4;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_Steering_System_DriveSim_Steering_Feedback_Torque;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_Wheel_Spindle_Steer_L1;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_Wheel_Spindle_Steer_R1;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_chassis_accelerations_lateral;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_chassis_accelerations_longitudinal;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_driver_demands_brake;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_driver_demands_throttle;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_ECAT_BECKH_DIG3;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_transmission_gear;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_Control_VICRT_UPSHIFT_REQ;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Inputs_Driver_Demands_str_swa;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Inputs_steer_assist_torque;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_Control_VICRT_DOWNSHIFT_REQ;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LDW_LDW_On;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LDW_LDW_On_Left;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LDW_LDW_On_Pulse;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LDW_LDW_On_Right;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LDW_LDW_Ready;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LDW_LDW_Steering_Torque;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LDW_LDW_White;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LKA_LKA_AEB_Sound;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LKA_LKA_On_Display;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LKA_LKA_On_Left;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LKA_LKA_On_Pulse;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LKA_LKA_On_Right;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LKA_LKA_Ready;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LKA_LKA_Steer_Angle;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_LKA_LKA_Steer_Mode;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_Control_VICRT_RESTART_REQ;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_Control_VICRT_RESTORE_REQ;
       // see model_private.h for rtwvariable declaration for modelvariables.txt

/* Block signals (default storage) */
B_lss_online_T lss_online_B;

/* Block states (default storage) */
DW_lss_online_T lss_online_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_lss_online_T lss_online_PrevZCX;

/* Real-time model */
static RT_MODEL_lss_online_T lss_online_M_;
RT_MODEL_lss_online_T *const lss_online_M = &lss_online_M_;
static void rate_monotonic_scheduler(void);
time_T rt_SimUpdateDiscreteEvents(
  int_T rtmNumSampTimes, void *rtmTimingData, int_T *rtmSampleHitPtr, int_T
  *rtmPerTaskSampleHits )
{
  rtmSampleHitPtr[1] = rtmStepTask(lss_online_M, 1);
  rtmSampleHitPtr[2] = rtmStepTask(lss_online_M, 2);
  rtmSampleHitPtr[3] = rtmStepTask(lss_online_M, 3);
  UNUSED_PARAMETER(rtmNumSampTimes);
  UNUSED_PARAMETER(rtmTimingData);
  UNUSED_PARAMETER(rtmPerTaskSampleHits);
  return(-1);
}

/*
 *         This function updates active task flag for each subrate
 *         and rate transition flags for tasks that exchange data.
 *         The function assumes rate-monotonic multitasking scheduler.
 *         The function must be called at model base rate so that
 *         the generated code self-manages all its subrates and rate
 *         transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* To ensure a deterministic data transfer between two rates,
   * data is transferred at the priority of a fast task and the frequency
   * of the slow task.  The following flags indicate when the data transfer
   * happens.  That is, a rate interaction flag is set true when both rates
   * will run, and false otherwise.
   */

  /* tid 1 shares data with slower tid rates: 2, 3 */
  if (lss_online_M->Timing.TaskCounters.TID[1] == 0) {
    lss_online_M->Timing.RateInteraction.TID1_2 =
      (lss_online_M->Timing.TaskCounters.TID[2] == 0);

    /* update PerTaskSampleHits matrix for non-inline sfcn */
    lss_online_M->Timing.perTaskSampleHits[6] =
      lss_online_M->Timing.RateInteraction.TID1_2;
    lss_online_M->Timing.RateInteraction.TID1_3 =
      (lss_online_M->Timing.TaskCounters.TID[3] == 0);

    /* update PerTaskSampleHits matrix for non-inline sfcn */
    lss_online_M->Timing.perTaskSampleHits[7] =
      lss_online_M->Timing.RateInteraction.TID1_3;
  }

  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (lss_online_M->Timing.TaskCounters.TID[2])++;
  if ((lss_online_M->Timing.TaskCounters.TID[2]) > 9) {/* Sample time: [0.01s, 0.0s] */
    lss_online_M->Timing.TaskCounters.TID[2] = 0;
  }

  (lss_online_M->Timing.TaskCounters.TID[3])++;
  if ((lss_online_M->Timing.TaskCounters.TID[3]) > 19) {/* Sample time: [0.02s, 0.0s] */
    lss_online_M->Timing.TaskCounters.TID[3] = 0;
  }
}

/*
 * Output and update for atomic system:
 *    '<S139>/manipulation_of_objects'
 *    '<S139>/manipulation_of_objects1'
 */
void lss_online_manipulation_of_objects(const real_T
  rtu_complete_obstacles_matrix[100], real_T rtu_detected_objects,
  B_manipulation_of_objects_lss_online_T *localB)
{
  int32_T c;
  int32_T i;
  int32_T i_0;
  int32_T tmp;
  memcpy(&localB->filtered_matrix[0], &rtu_complete_obstacles_matrix[0], 100U *
         sizeof(real_T));

  /* MATLAB Function 'OUTPUT/WorldSim_Sensor_Outputs/manipulation_of_objects': '<S144>:1' */
  /* '<S144>:1:7' */
  /* '<S144>:1:5' */
  if (rtu_detected_objects + 1.0 > 10.0) {
    c = -1;
    i = -1;
  } else {
    c = (int32_T)(rtu_detected_objects + 1.0) - 2;
    i = 9;
  }

  /* '<S144>:1:7' */
  tmp = i - c;
  for (i = 0; i < tmp; i++) {
    for (i_0 = 0; i_0 < 10; i_0++) {
      localB->filtered_matrix[i_0 + 10 * ((c + i) + 1)] = 0.0;
    }
  }
}

real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else {
    real_T tmp;
    real_T tmp_0;
    tmp = fabs(u0);
    tmp_0 = fabs(u1);
    if (rtIsInf(u1)) {
      if (tmp == 1.0) {
        y = 1.0;
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > floor(u1))) {
      y = (rtNaN);
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

/* Model output function for TID0 */
static void lss_online_output0(void)   /* Sample time: [0.0s, 0.0s] */
{
  real_T Product;
  real_T deltaT;
  real_T riseValLimit;
  real_T rtb_DiscreteFilter1;
  real_T rtb_Product3;
  real_T rtb_PulseGenerator;
  boolean_T rtb_Compare_l;
  boolean_T rtb_Compare_lj;
  boolean_T rtb_Compare_pf;
  boolean_T rtb_LogicalOperator1;
  ZCEventType zcEvent;

  {                                    /* Sample time: [0.0s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* S-Function (simwbC_RTDBIn): '<S6>/VI_DriveSim.Inputs.ECAT.BECKH.ANA3' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S6>/VI_DriveSim.Inputs.ECAT.BECKH.ANA3 */
  lss_online_B.VI_DriveSimInputsECATBECKHANA3 = *(real_T *)
    pVI_DriveSim_Inputs_ECAT_BECKH_ANA3;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.chassis_velocities.longitudinal' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.chassis_velocities.longitudinal */
  lss_online_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal = *(real_T *)
    pVI_CarRealTime_Outputs_chassis_velocities_longitudinal;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.driver_demands.steering' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.driver_demands.steering */
  lss_online_B.VI_CarRealTimeOutputsdriver_demandssteering = *(real_T *)
    pVI_CarRealTime_Outputs_driver_demands_steering;

#endif

  /* S-Function (simwbC_RTDBIn): '<S6>/VI_DriveSim.Inputs.ECAT.BECKH.DIG4' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S6>/VI_DriveSim.Inputs.ECAT.BECKH.DIG4 */
  lss_online_B.VI_DriveSimInputsECATBECKHDIG4 = *(real_T *)
    pVI_DriveSim_Inputs_ECAT_BECKH_DIG4;

#endif

  /* S-Function (simwbC_RTDBIn): '<S6>/VI_DriveSim.Outputs.Vicrt.Status' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S6>/VI_DriveSim.Outputs.Vicrt.Status */
  lss_online_B.VI_DriveSimOutputsVicrtStatus = *(real_T *)
    pVI_DriveSim_Outputs_Vicrt_Status;

#endif

  /* S-Function (simwbC_RTDBIn): '<S6>/VI_DriveSim.Inputs.ECAT.BECKH.ANA1' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S6>/VI_DriveSim.Inputs.ECAT.BECKH.ANA1 */
  lss_online_B.VI_DriveSimInputsECATBECKHANA1 = *(real_T *)
    pVI_DriveSim_Inputs_ECAT_BECKH_ANA4;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque */
  lss_online_B.VI_CarRealTimeOutputsSteering_SystemDriveSim_Steering_Feedback_Torque
    = *(real_T *)
    pVI_CarRealTime_Outputs_Steering_System_DriveSim_Steering_Feedback_Torque;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1 */
  lss_online_B.VI_CarRealTimeOutputsWheelSpindle_SteerL1 = *(real_T *)
    pVI_CarRealTime_Outputs_Wheel_Spindle_Steer_L1;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1 */
  lss_online_B.VI_CarRealTimeOutputsWheelSpindle_SteerR1 = *(real_T *)
    pVI_CarRealTime_Outputs_Wheel_Spindle_Steer_R1;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.chassis_accelerations.lateral' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.chassis_accelerations.lateral */
  lss_online_B.VI_CarRealTimeOutputschassis_accelerationslateral = *(real_T *)
    pVI_CarRealTime_Outputs_chassis_accelerations_lateral;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.chassis_accelerations.longitudinal' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.chassis_accelerations.longitudinal */
  lss_online_B.VI_CarRealTimeOutputschassis_accelerationslongitudinal = *(real_T
    *)pVI_CarRealTime_Outputs_chassis_accelerations_longitudinal;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.driver_demands.brake' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.driver_demands.brake */
  lss_online_B.VI_CarRealTimeOutputsdriver_demandsbrake = *(real_T *)
    pVI_CarRealTime_Outputs_driver_demands_brake;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.driver_demands.throttle' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.driver_demands.throttle */
  lss_online_B.VI_CarRealTimeOutputsdriver_demandsthrottle = *(real_T *)
    pVI_CarRealTime_Outputs_driver_demands_throttle;

#endif

  /* S-Function (simwbC_RTDBIn): '<S6>/VI_DriveSim.Inputs.ECAT.BECKH.DIG3' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S6>/VI_DriveSim.Inputs.ECAT.BECKH.DIG3 */
  lss_online_B.VI_DriveSimInputsECATBECKHDIG3 = *(real_T *)
    pVI_DriveSim_Inputs_ECAT_BECKH_DIG3;

#endif

  /* S-Function (simwbC_RTDBIn): '<S6>/VI_CarRealTime.Outputs.transmission.gear' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S6>/VI_CarRealTime.Outputs.transmission.gear */
  lss_online_B.VI_CarRealTimeOutputstransmissiongear = *(real_T *)
    pVI_CarRealTime_Outputs_transmission_gear;

#endif

  /* DataTypeConversion: '<S6>/Data Type Conversion6' incorporates:
   *  Constant: '<S165>/Constant'
   *  Constant: '<S167>/Constant'
   *  Product: '<S6>/Product5'
   *  RelationalOperator: '<S165>/Compare'
   *  RelationalOperator: '<S167>/Compare'
   */
  lss_online_B.DataTypeConversion6 =
    (lss_online_B.VI_DriveSimInputsECATBECKHANA3 >=
     lss_online_P.shift_paddle_threshold1_const) *
    (lss_online_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal <
     lss_online_P.gear_change_max_speed_up_const);

  /* RelationalOperator: '<S78>/Compare' incorporates:
   *  Constant: '<S4>/Constant'
   *  Constant: '<S78>/Constant'
   */
  lss_online_B.Compare = (lss_online_P.Constant_Value_dk ==
    lss_online_P.Constant_Value_d);

  /* UnitDelay: '<S163>/Delay Input1' */
  lss_online_B.Uk1 = lss_online_DW.DelayInput1_DSTATE;

  /* Memory: '<S6>/Memory1' */
  lss_online_B.Memory1 = lss_online_DW.Memory1_PreviousInput;

  /* Memory: '<S6>/Memory' */
  lss_online_B.Memory_a = lss_online_DW.Memory_PreviousInput_b;

  /* Switch: '<S6>/Switch' incorporates:
   *  RelationalOperator: '<S163>/FixPt Relational Operator'
   */
  if (lss_online_B.VI_DriveSimInputsECATBECKHDIG4 > lss_online_B.Uk1) {
    /* Switch: '<S6>/Switch' incorporates:
     *  RelationalOperator: '<S6>/Relational Operator'
     */
    lss_online_B.ACCoutputs = !lss_online_B.Memory1;
  } else {
    /* Switch: '<S6>/Switch' */
    lss_online_B.ACCoutputs = lss_online_B.Memory_a;
  }

  /* End of Switch: '<S6>/Switch' */

  /* Product: '<S4>/Product3' incorporates:
   *  Constant: '<S4>/LKA_Activity_Flag'
   *  DataTypeConversion: '<S6>/Data Type Conversion9'
   */
  rtb_Product3 = (real_T)lss_online_B.Compare * lss_online_P.LKA_Activity_Flag *
    (real_T)lss_online_B.ACCoutputs;

  /* RelationalOperator: '<S72>/Compare' incorporates:
   *  Constant: '<S72>/Constant'
   */
  rtb_Compare_lj = (lss_online_B.VI_DriveSimOutputsVicrtStatus ==
                    lss_online_P.CompareToConstant1_const);

  /* RateTransition: '<S4>/Rate Transition2' incorporates:
   *  RateTransition: '<S4>/Rate Transition1'
   */
  if (lss_online_M->Timing.RateInteraction.TID1_3) {
    /* RateTransition: '<S4>/Rate Transition2' */
    lss_online_B.RateTransition2[0] = lss_online_DW.RateTransition2_Buffer0[0];
    lss_online_B.RateTransition2[1] = lss_online_DW.RateTransition2_Buffer0[1];

    /* RateTransition: '<S4>/Rate Transition1' */
    lss_online_B.RateTransition1[0] = lss_online_DW.RateTransition1_Buffer0[0];
    lss_online_B.RateTransition1[1] = lss_online_DW.RateTransition1_Buffer0[1];
  }

  /* End of RateTransition: '<S4>/Rate Transition2' */

  /* Logic: '<S4>/Logical Operator4' incorporates:
   *  Constant: '<S76>/Constant'
   *  RelationalOperator: '<S76>/Compare'
   */
  lss_online_B.LogicalOperator4 = ((lss_online_B.RateTransition2[0] <
    lss_online_P.LKA_Lane_Gap_dydt_Activate) || (lss_online_B.RateTransition2[1]
    < lss_online_P.LKA_Lane_Gap_dydt_Activate));

  /* MultiPortSwitch: '<S83>/Multiport Switch' incorporates:
   *  Constant: '<S83>/ADAS_Control_Mode'
   *  Constant: '<S83>/LKA_Lane_Gap_Activate'
   *  Constant: '<S83>/LKA_Lane_Gap_Activate2'
   */
  switch ((int32_T)lss_online_P.ADAS_Control_Mode) {
   case 1:
    rtb_DiscreteFilter1 = lss_online_P.LKA_Lane_Gap_Activate[0];
    break;

   case 2:
    rtb_DiscreteFilter1 = lss_online_P.LKA_Lane_Gap_Activate[1];
    break;

   default:
    rtb_DiscreteFilter1 = lss_online_P.LKA_Lane_Gap_Activate[0];
    break;
  }

  /* End of MultiPortSwitch: '<S83>/Multiport Switch' */

  /* RelationalOperator: '<S83>/Relational Operator' */
  lss_online_B.RelationalOperator[0] = (lss_online_B.RateTransition1[0] <
    rtb_DiscreteFilter1);
  lss_online_B.RelationalOperator[1] = (lss_online_B.RateTransition1[1] <
    rtb_DiscreteFilter1);

  /* Logic: '<S4>/Logical Operator' */
  lss_online_B.LogicalOperator = (lss_online_B.RelationalOperator[0] ||
    lss_online_B.RelationalOperator[1]);

  /* RelationalOperator: '<S77>/Compare' incorporates:
   *  Constant: '<S77>/Constant'
   */
  rtb_Compare_l =
    (lss_online_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal >=
     lss_online_P.LKA_Min_Speed);

  /* RelationalOperator: '<S74>/Compare' incorporates:
   *  Constant: '<S74>/Constant'
   *  Memory: '<S4>/Memory2'
   */
  lss_online_B.Compare_c = (lss_online_DW.Memory2_PreviousInput !=
    lss_online_P.CompareToConstant3_const);

  /* RelationalOperator: '<S75>/Compare' incorporates:
   *  Constant: '<S4>/Constant'
   *  Constant: '<S75>/Constant'
   */
  lss_online_B.Compare_k = (lss_online_P.Constant_Value_dk !=
    lss_online_P.CompareToConstant4_const);

  /* Logic: '<S4>/Logical Operator1' */
  rtb_LogicalOperator1 = ((rtb_Product3 != 0.0) && rtb_Compare_lj &&
    lss_online_B.LogicalOperator4 && lss_online_B.LogicalOperator &&
    rtb_Compare_l && lss_online_B.Compare_c && lss_online_B.Compare_k);

  /* RateTransition: '<S4>/Rate Transition5' */
  if (lss_online_M->Timing.RateInteraction.TID1_3) {
    /* RateTransition: '<S4>/Rate Transition5' */
    lss_online_B.toggle = lss_online_DW.RateTransition5_Buffer0;
  }

  /* End of RateTransition: '<S4>/Rate Transition5' */

  /* Memory: '<S4>/Memory' */
  lss_online_B.Memory = lss_online_DW.Memory_PreviousInput;

  /* Switch: '<S4>/Switch1' incorporates:
   *  DataTypeConversion: '<S4>/Data Type Conversion'
   */
  if ((real_T)rtb_LogicalOperator1 > lss_online_P.Switch1_Threshold) {
    /* Switch: '<S4>/Switch1' */
    lss_online_B.LKA_on = rtb_LogicalOperator1;
  } else {
    /* Switch: '<S4>/Switch1' incorporates:
     *  Product: '<S4>/Product'
     */
    lss_online_B.LKA_on = (real_T)lss_online_B.toggle * rtb_Product3 * (real_T)
      rtb_Compare_lj * (real_T)lss_online_B.Compare_k * lss_online_B.Memory;
  }

  /* End of Switch: '<S4>/Switch1' */

  /* RateLimiter: '<S8>/Rate Limiter1' */
  if (lss_online_DW.LastMajorTime == (rtInf)) {
    /* RateLimiter: '<S8>/Rate Limiter1' */
    lss_online_B.RateLimiter1 = lss_online_B.LKA_on;
  } else {
    deltaT = lss_online_M->Timing.t[0] - lss_online_DW.LastMajorTime;
    riseValLimit = deltaT * lss_online_P.AP_Transition_Rate;
    rtb_PulseGenerator = lss_online_B.LKA_on - lss_online_DW.PrevY;
    if (rtb_PulseGenerator > riseValLimit) {
      /* RateLimiter: '<S8>/Rate Limiter1' */
      lss_online_B.RateLimiter1 = lss_online_DW.PrevY + riseValLimit;
    } else {
      deltaT *= -lss_online_P.AP_Transition_Rate;
      if (rtb_PulseGenerator < deltaT) {
        /* RateLimiter: '<S8>/Rate Limiter1' */
        lss_online_B.RateLimiter1 = lss_online_DW.PrevY + deltaT;
      } else {
        /* RateLimiter: '<S8>/Rate Limiter1' */
        lss_online_B.RateLimiter1 = lss_online_B.LKA_on;
      }
    }
  }

  /* End of RateLimiter: '<S8>/Rate Limiter1' */

  /* RateTransition generated from: '<S147>/Sum' */
  if (lss_online_M->Timing.RateInteraction.TID1_2) {
    /* RateTransition generated from: '<S147>/Sum' */
    lss_online_B.TmpRTBAtSumOutport1 = lss_online_DW.TmpRTBAtSumOutport1_Buffer0;
  }

  /* End of RateTransition generated from: '<S147>/Sum' */

  /* DiscretePulseGenerator: '<S147>/Pulse Generator' */
  rtb_PulseGenerator = (lss_online_DW.clockTickCounter <
                        lss_online_P.PulseGenerator_Duty) &&
    (lss_online_DW.clockTickCounter >= 0) ? lss_online_P.PulseGenerator_Amp :
    0.0;
  if (lss_online_DW.clockTickCounter >= lss_online_P.PulseGenerator_Period - 1.0)
  {
    lss_online_DW.clockTickCounter = 0;
  } else {
    lss_online_DW.clockTickCounter++;
  }

  /* End of DiscretePulseGenerator: '<S147>/Pulse Generator' */

  /* Outputs for Triggered SubSystem: '<S147>/derivation_speed' incorporates:
   *  TriggerPort: '<S152>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &lss_online_PrevZCX.derivation_speed_Trig_ZCE,
                     (rtb_PulseGenerator));
  if (zcEvent != NO_ZCEVENT) {
    uint32_T derivation_speed_ELAPS_T_tmp_tmp;
    uint32_T elapseT_H;
    uint32_T elapseT_H_tmp;
    derivation_speed_ELAPS_T_tmp_tmp = lss_online_M->Timing.clockTick1;
    lss_online_DW.derivation_speed_ELAPS_T[0] = derivation_speed_ELAPS_T_tmp_tmp
      - lss_online_DW.derivation_speed_PREV_T[0];
    elapseT_H_tmp = lss_online_M->Timing.clockTickH1;
    elapseT_H = elapseT_H_tmp - lss_online_DW.derivation_speed_PREV_T[1];
    if (lss_online_DW.derivation_speed_PREV_T[0] >
        derivation_speed_ELAPS_T_tmp_tmp) {
      elapseT_H--;
    }

    lss_online_DW.derivation_speed_ELAPS_T[1] = elapseT_H;
    lss_online_DW.derivation_speed_PREV_T[0] = derivation_speed_ELAPS_T_tmp_tmp;
    lss_online_DW.derivation_speed_PREV_T[1] = elapseT_H_tmp;

    /* Gain: '<S42>/Integral Gain' incorporates:
     *  SampleTimeMath: '<S153>/TSamp'
     *
     * About '<S153>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    lss_online_B.IntegralGain = lss_online_B.TmpRTBAtSumOutport1 / (((real_T)
      lss_online_DW.derivation_speed_ELAPS_T[0] * 0.001 + (real_T)
      lss_online_DW.derivation_speed_ELAPS_T[1] * 4.294967296E+6) *
      lss_online_P.TSamp_WtEt);

    /* Gain: '<S152>/Gain' incorporates:
     *  Sum: '<S153>/Diff'
     *  UnitDelay: '<S153>/UD'
     */
    lss_online_B.Gain = (lss_online_B.IntegralGain - lss_online_DW.UD_DSTATE_l) *
      lss_online_P.Gain_Gain_f;

    /* Update for UnitDelay: '<S153>/UD' */
    lss_online_DW.UD_DSTATE_l = lss_online_B.IntegralGain;
  }

  /* End of Outputs for SubSystem: '<S147>/derivation_speed' */

  /* DiscreteFilter: '<S147>/filtering' */
  lss_online_DW.filtering_tmp = ((lss_online_B.Gain -
    lss_online_DW.filtering_states[0] * lss_online_P.filtering_DenCoef[1]) -
    lss_online_DW.filtering_states[1] * lss_online_P.filtering_DenCoef[2]) /
    lss_online_P.filtering_DenCoef[0];

  /* Sum: '<S8>/Sum' incorporates:
   *  Constant: '<S8>/prescribed_approaching_speed'
   *  DiscreteFilter: '<S147>/filtering'
   */
  rtb_DiscreteFilter1 = lss_online_P.variant_approaching_speed[(int32_T)
    lss_online_P.index_variant_approaching_speed - 1] -
    ((lss_online_P.filtering_NumCoef[0] * lss_online_DW.filtering_tmp +
      lss_online_DW.filtering_states[0] * lss_online_P.filtering_NumCoef[1]) +
     lss_online_DW.filtering_states[1] * lss_online_P.filtering_NumCoef[2]);

  /* Sum: '<S54>/Sum' incorporates:
   *  DiscreteIntegrator: '<S45>/Integrator'
   *  Gain: '<S50>/Proportional Gain'
   */
  lss_online_B.Sum = lss_online_P.PIDController_P * rtb_DiscreteFilter1 +
    lss_online_DW.Integrator_DSTATE;

  /* RateTransition: '<S4>/Rate Transition3' */
  if (lss_online_M->Timing.RateInteraction.TID1_3) {
    /* RateTransition: '<S4>/Rate Transition3' */
    lss_online_B.RateTransition3 = lss_online_DW.RateTransition3_Buffer0;
  }

  /* End of RateTransition: '<S4>/Rate Transition3' */

  /* DiscreteFilter: '<S4>/Discrete Filter' */
  lss_online_DW.DiscreteFilter_tmp = ((lss_online_B.RateTransition3 -
    lss_online_DW.DiscreteFilter_states[0] *
    lss_online_P.DiscreteFilter_DenCoef[1]) -
    lss_online_DW.DiscreteFilter_states[1] *
    lss_online_P.DiscreteFilter_DenCoef[2]) /
    lss_online_P.DiscreteFilter_DenCoef[0];

  /* DiscreteFilter: '<S4>/Discrete Filter' */
  lss_online_B.DiscreteFilter = (lss_online_P.DiscreteFilter_NumCoef[0] *
    lss_online_DW.DiscreteFilter_tmp + lss_online_DW.DiscreteFilter_states[0] *
    lss_online_P.DiscreteFilter_NumCoef[1]) +
    lss_online_DW.DiscreteFilter_states[1] *
    lss_online_P.DiscreteFilter_NumCoef[2];

  /* RelationalOperator: '<S10>/Compare' incorporates:
   *  Constant: '<S10>/Constant'
   */
  lss_online_B.Compare_a = (lss_online_B.DiscreteFilter ==
    lss_online_P.CompareToConstant1_const_h);

  /* Product: '<S8>/Product' incorporates:
   *  Clock: '<S8>/Clock'
   *  Constant: '<S9>/Constant'
   *  RelationalOperator: '<S9>/Compare'
   */
  Product = (real_T)(lss_online_M->Timing.t[0] >=
                     lss_online_P.CompareToConstant_const) * lss_online_B.Sum *
    (real_T)lss_online_B.Compare_a;

  /* RateLimiter: '<S8>/Rate Limiter' */
  if (lss_online_DW.LastMajorTime_g == (rtInf)) {
    /* RateLimiter: '<S8>/Rate Limiter' */
    lss_online_B.RateLimiter = Product;
  } else {
    deltaT = lss_online_M->Timing.t[0] - lss_online_DW.LastMajorTime_g;
    riseValLimit = deltaT * lss_online_P.RateLimiter_RisingLim;
    rtb_PulseGenerator = Product - lss_online_DW.PrevY_b;
    if (rtb_PulseGenerator > riseValLimit) {
      /* RateLimiter: '<S8>/Rate Limiter' */
      lss_online_B.RateLimiter = lss_online_DW.PrevY_b + riseValLimit;
    } else {
      deltaT *= lss_online_P.RateLimiter_FallingLim;
      if (rtb_PulseGenerator < deltaT) {
        /* RateLimiter: '<S8>/Rate Limiter' */
        lss_online_B.RateLimiter = lss_online_DW.PrevY_b + deltaT;
      } else {
        /* RateLimiter: '<S8>/Rate Limiter' */
        lss_online_B.RateLimiter = Product;
      }
    }
  }

  /* End of RateLimiter: '<S8>/Rate Limiter' */

  /* Sum: '<S8>/Add' incorporates:
   *  Constant: '<S8>/Constant2'
   *  Gain: '<S8>/Neg_driver_str_gain'
   *  Product: '<S8>/Product2'
   *  Product: '<S8>/Product3'
   *  Sum: '<S8>/Subtract1'
   *  Sum: '<S8>/Sum1'
   */
  lss_online_B.Add = lss_online_P.Neg_driver_str_gain_Gain *
    lss_online_B.VI_CarRealTimeOutputsdriver_demandssteering *
    (lss_online_P.Constant2_Value - lss_online_B.RateLimiter1) +
    (lss_online_B.RateLimiter - lss_online_B.DiscreteFilter) *
    lss_online_B.RateLimiter1;

  /* RateTransition: '<S3>/Rate Transition2' incorporates:
   *  RateTransition: '<S3>/Rate Transition1'
   */
  if (lss_online_M->Timing.RateInteraction.TID1_3) {
    /* RateTransition: '<S3>/Rate Transition2' */
    lss_online_B.RateTransition2_b[0] = lss_online_DW.RateTransition2_Buffer0_a
      [0];
    lss_online_B.RateTransition2_b[1] = lss_online_DW.RateTransition2_Buffer0_a
      [1];

    /* RateTransition: '<S3>/Rate Transition1' */
    lss_online_B.RateTransition1_m[0] = lss_online_DW.RateTransition1_Buffer0_o
      [0];
    lss_online_B.RateTransition1_m[1] = lss_online_DW.RateTransition1_Buffer0_o
      [1];
  }

  /* End of RateTransition: '<S3>/Rate Transition2' */

  /* Logic: '<S3>/Logical Operator4' incorporates:
   *  Constant: '<S67>/Constant'
   *  RelationalOperator: '<S67>/Compare'
   */
  lss_online_B.LogicalOperator4_o = ((lss_online_B.RateTransition2_b[0] <
    lss_online_P.LDW_LaneGap_dydt_Warning) || (lss_online_B.RateTransition2_b[1]
    < lss_online_P.LDW_LaneGap_dydt_Warning));

  /* MultiPortSwitch: '<S70>/Multiport Switch' incorporates:
   *  Constant: '<S70>/ADAS_Control_Mode'
   *  Constant: '<S70>/LDW_LaneGap_Warning'
   *  Constant: '<S70>/LDW_LaneGap_Warning1'
   */
  switch ((int32_T)lss_online_P.ADAS_Control_Mode) {
   case 1:
    rtb_PulseGenerator = lss_online_P.LDW_LaneGap_Warning[0];
    break;

   case 2:
    rtb_PulseGenerator = lss_online_P.LDW_LaneGap_Warning[1];
    break;

   default:
    rtb_PulseGenerator = lss_online_P.LDW_LaneGap_Warning[0];
    break;
  }

  /* End of MultiPortSwitch: '<S70>/Multiport Switch' */

  /* RelationalOperator: '<S70>/Relational Operator' */
  lss_online_B.RelationalOperator_h[0] = (lss_online_B.RateTransition1_m[0] <
    rtb_PulseGenerator);
  lss_online_B.RelationalOperator_h[1] = (lss_online_B.RateTransition1_m[1] <
    rtb_PulseGenerator);

  /* Logic: '<S3>/Logical Operator' */
  lss_online_B.LogicalOperator_c = (lss_online_B.RelationalOperator_h[0] ||
    lss_online_B.RelationalOperator_h[1]);

  /* RelationalOperator: '<S68>/Compare' incorporates:
   *  Constant: '<S68>/Constant'
   */
  rtb_Compare_lj =
    (lss_online_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal >=
     lss_online_P.LDW_Min_Speed);

  /* RelationalOperator: '<S66>/Compare' incorporates:
   *  Constant: '<S3>/Constant'
   *  Constant: '<S66>/Constant'
   */
  lss_online_B.Compare_j = (lss_online_P.Constant_Value_h ==
    lss_online_P.Constant_Value);

  /* Product: '<S3>/Product' incorporates:
   *  Constant: '<S3>/LDW_Activity_Flag'
   *  DataTypeConversion: '<S6>/Data Type Conversion9'
   */
  Product = (real_T)lss_online_B.Compare_j * lss_online_P.LDW_Activity_Flag *
    (real_T)lss_online_B.ACCoutputs;

  /* RelationalOperator: '<S65>/Compare' incorporates:
   *  Constant: '<S3>/Constant'
   *  Constant: '<S65>/Constant'
   */
  lss_online_B.Compare_k3 = (lss_online_P.Constant_Value_h !=
    lss_online_P.CompareToConstant4_const_h);

  /* RelationalOperator: '<S64>/Compare' incorporates:
   *  Constant: '<S64>/Constant'
   *  Memory: '<S3>/Memory2'
   */
  lss_online_B.Compare_jt = (lss_online_DW.Memory2_PreviousInput_b !=
    lss_online_P.CompareToConstant3_const_l);

  /* Logic: '<S3>/Logical Operator1' incorporates:
   *  Constant: '<S62>/Constant'
   *  RelationalOperator: '<S62>/Compare'
   */
  rtb_Compare_pf = ((lss_online_B.VI_DriveSimOutputsVicrtStatus ==
                     lss_online_P.CompareToConstant1_const_o) &&
                    lss_online_B.LogicalOperator4_o &&
                    lss_online_B.LogicalOperator_c && rtb_Compare_lj && (Product
    != 0.0) && lss_online_B.Compare_k3 && lss_online_B.Compare_jt);

  /* DataTypeConversion: '<S3>/Data Type Conversion' */
  lss_online_B.DataTypeConversion = rtb_Compare_pf;

  /* Product: '<S3>/Product1' incorporates:
   *  Sin: '<S3>/LDW_Steer_Vibration'
   */
  lss_online_B.Product1 = (sin(lss_online_P.LDW_Steer_Vibration_Freq * 2.0 *
    3.1415926535897931 * lss_online_M->Timing.t[0] +
    lss_online_P.LDW_Steer_Vibration_Phase) *
    lss_online_P.LDW_Steer_Vibration_Amplitude +
    lss_online_P.LDW_Steer_Vibration_Bias) * lss_online_B.DataTypeConversion;

  /* DataTypeConversion: '<S6>/Data Type Conversion4' incorporates:
   *  Constant: '<S164>/Constant'
   *  Constant: '<S166>/Constant'
   *  Product: '<S6>/Product3'
   *  RelationalOperator: '<S164>/Compare'
   *  RelationalOperator: '<S166>/Compare'
   */
  lss_online_B.DataTypeConversion4 =
    (lss_online_B.VI_DriveSimInputsECATBECKHANA1 >=
     lss_online_P.shift_paddle_threshold_const) *
    (lss_online_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal <
     lss_online_P.gear_change_max_speed_down_const);

  /* DiscretePulseGenerator: '<S3>/Pulse Generator' */
  lss_online_B.PulseGenerator = (lss_online_DW.clockTickCounter_c <
    lss_online_P.PulseGenerator_Duty_c) && (lss_online_DW.clockTickCounter_c >=
    0) ? lss_online_P.PulseGenerator_Amp_l : 0.0;

  /* DiscretePulseGenerator: '<S3>/Pulse Generator' */
  if (lss_online_DW.clockTickCounter_c >= lss_online_P.PulseGenerator_Period_c -
      1.0) {
    lss_online_DW.clockTickCounter_c = 0;
  } else {
    lss_online_DW.clockTickCounter_c++;
  }

  /* Product: '<S3>/Product2' */
  lss_online_B.Product2 = lss_online_B.DataTypeConversion *
    lss_online_B.PulseGenerator;

  /* Sum: '<S4>/Sum' incorporates:
   *  Constant: '<S4>/Constant'
   */
  lss_online_B.Sum_c = lss_online_B.LKA_on + lss_online_P.Constant_Value_dk;

  /* DataTypeConversion: '<S3>/Data Type Conversion3' incorporates:
   *  Logic: '<S3>/Logical Operator3'
   */
  lss_online_B.DataTypeConversion3[0] = (rtb_Compare_pf &&
    lss_online_B.RelationalOperator_h[0]);

  /* DataTypeConversion: '<S4>/Data Type Conversion3' incorporates:
   *  Logic: '<S4>/Logical Operator3'
   */
  lss_online_B.DataTypeConversion3_h[0] = (rtb_LogicalOperator1 &&
    lss_online_B.RelationalOperator[0]);

  /* DataTypeConversion: '<S3>/Data Type Conversion3' incorporates:
   *  Logic: '<S3>/Logical Operator3'
   */
  lss_online_B.DataTypeConversion3[1] = (rtb_Compare_pf &&
    lss_online_B.RelationalOperator_h[1]);

  /* DataTypeConversion: '<S4>/Data Type Conversion3' incorporates:
   *  Logic: '<S4>/Logical Operator3'
   */
  lss_online_B.DataTypeConversion3_h[1] = (rtb_LogicalOperator1 &&
    lss_online_B.RelationalOperator[1]);

  /* Logic: '<S3>/Logical Operator2' */
  rtb_Compare_pf = ((Product != 0.0) && rtb_Compare_lj);

  /* DataTypeConversion: '<S3>/Data Type Conversion2' incorporates:
   *  Logic: '<S3>/Logical Operator5'
   */
  lss_online_B.DataTypeConversion2 = (rtb_Compare_pf && lss_online_B.Compare_k3 &&
    lss_online_B.Compare_jt);

  /* DataTypeConversion: '<S3>/Data Type Conversion1' */
  lss_online_B.DataTypeConversion1 = rtb_Compare_pf;

  /* DiscretePulseGenerator: '<S4>/Pulse Generator' */
  lss_online_B.PulseGenerator_j = (lss_online_DW.clockTickCounter_f <
    lss_online_P.PulseGenerator_Duty_h) && (lss_online_DW.clockTickCounter_f >=
    0) ? lss_online_P.PulseGenerator_Amp_k : 0.0;

  /* DiscretePulseGenerator: '<S4>/Pulse Generator' */
  if (lss_online_DW.clockTickCounter_f >= lss_online_P.PulseGenerator_Period_o -
      1.0) {
    lss_online_DW.clockTickCounter_f = 0;
  } else {
    lss_online_DW.clockTickCounter_f++;
  }

  /* Product: '<S4>/Product2' */
  lss_online_B.Product2_f = lss_online_B.LKA_on * lss_online_B.PulseGenerator_j;

  /* DataTypeConversion: '<S4>/Data Type Conversion2' incorporates:
   *  Logic: '<S4>/Logical Operator2'
   *  Logic: '<S4>/Logical Operator6'
   */
  lss_online_B.DataTypeConversion2_o = (lss_online_B.Compare_k &&
    lss_online_B.Compare_c && ((rtb_Product3 != 0.0) && rtb_Compare_l));

  /* Gain: '<S42>/Integral Gain' */
  lss_online_B.IntegralGain = lss_online_P.PIDController_I * rtb_DiscreteFilter1;

  /* DiscreteFilter: '<S147>/Discrete Filter' */
  lss_online_DW.DiscreteFilter_tmp_g = ((lss_online_B.TmpRTBAtSumOutport1 -
    lss_online_DW.DiscreteFilter_states_m[0] *
    lss_online_P.DiscreteFilter_DenCoef_d[1]) -
    lss_online_DW.DiscreteFilter_states_m[1] *
    lss_online_P.DiscreteFilter_DenCoef_d[2]) /
    lss_online_P.DiscreteFilter_DenCoef_d[0];
  rtb_PulseGenerator = (lss_online_P.DiscreteFilter_NumCoef_l[0] *
                        lss_online_DW.DiscreteFilter_tmp_g +
                        lss_online_DW.DiscreteFilter_states_m[0] *
                        lss_online_P.DiscreteFilter_NumCoef_l[1]) +
    lss_online_DW.DiscreteFilter_states_m[1] *
    lss_online_P.DiscreteFilter_NumCoef_l[2];

  /* RateTransition generated from: '<S147>/Discrete Filter1' */
  if (lss_online_M->Timing.RateInteraction.TID1_2) {
    /* RateTransition generated from: '<S147>/Discrete Filter1' */
    lss_online_B.TmpRTBAtDiscreteFilter1Inport1 =
      lss_online_DW.TmpRTBAtDiscreteFilter1Inport1_Buffer0;
  }

  /* End of RateTransition generated from: '<S147>/Discrete Filter1' */

  /* DiscreteFilter: '<S147>/Discrete Filter1' */
  lss_online_DW.DiscreteFilter1_tmp =
    ((lss_online_B.TmpRTBAtDiscreteFilter1Inport1 -
      lss_online_DW.DiscreteFilter1_states[0] *
      lss_online_P.DiscreteFilter1_DenCoef[1]) -
     lss_online_DW.DiscreteFilter1_states[1] *
     lss_online_P.DiscreteFilter1_DenCoef[2]) /
    lss_online_P.DiscreteFilter1_DenCoef[0];
  rtb_DiscreteFilter1 = (lss_online_P.DiscreteFilter1_NumCoef[0] *
    lss_online_DW.DiscreteFilter1_tmp + lss_online_DW.DiscreteFilter1_states[0] *
    lss_online_P.DiscreteFilter1_NumCoef[1]) +
    lss_online_DW.DiscreteFilter1_states[1] *
    lss_online_P.DiscreteFilter1_NumCoef[2];

  /* RateTransition: '<S3>/Rate Transition' */
  if (lss_online_M->Timing.RateInteraction.TID1_3) {
    lss_online_DW.RateTransition_Buffer[0] = rtb_PulseGenerator;
    lss_online_DW.RateTransition_Buffer[1] = rtb_DiscreteFilter1;

    /* RateTransition: '<S4>/Rate Transition' */
    lss_online_DW.RateTransition_Buffer_g[0] = rtb_PulseGenerator;
    lss_online_DW.RateTransition_Buffer_g[1] = rtb_DiscreteFilter1;

    /* RateTransition: '<S4>/Rate Transition4' */
    lss_online_DW.RateTransition4_Buffer = lss_online_B.LKA_on;

    /* RateTransition: '<S4>/Rate Transition6' */
    lss_online_DW.RateTransition6_Buffer = lss_online_B.LKA_on;
  }

  /* End of RateTransition: '<S3>/Rate Transition' */

  /* Product: '<S6>/Product' incorporates:
   *  Constant: '<S160>/Constant'
   *  DataTypeConversion: '<S6>/Data Type Conversion'
   *  RelationalOperator: '<S160>/Compare'
   */
  lss_online_B.Product_f = lss_online_B.VI_DriveSimInputsECATBECKHDIG4 *
    lss_online_B.VI_DriveSimInputsECATBECKHDIG3 * (real_T)
    (lss_online_B.VI_DriveSimOutputsVicrtStatus !=
     lss_online_P.CompareToConstant_const_i);

  /* Product: '<S6>/Product1' incorporates:
   *  Constant: '<S161>/Constant'
   *  RelationalOperator: '<S161>/Compare'
   */
  lss_online_B.Product1_i = (real_T)(lss_online_B.VI_DriveSimInputsECATBECKHDIG4
    != lss_online_P.CompareToConstant1_const_a) *
    lss_online_B.VI_DriveSimInputsECATBECKHDIG3;

  /* S-Function (simwbC_RTDBOut): '<Root>/VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ */
  *(real_T *)pVI_DriveSim_Inputs_Control_VICRT_UPSHIFT_REQ =
    lss_online_B.DataTypeConversion6;

#endif

  /* S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.Driver_Demands.str_swa' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Inputs.Driver_Demands.str_swa */
  *(real_T *)pVI_CarRealTime_Inputs_Driver_Demands_str_swa = lss_online_B.Add;

#endif

  /* S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.steer_assist.torque' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Inputs.steer_assist.torque */
  *(real_T *)pVI_CarRealTime_Inputs_steer_assist_torque = lss_online_B.Product1;

#endif

  /* S-Function (simwbC_RTDBOut): '<Root>/VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ */
  *(real_T *)pVI_DriveSim_Inputs_Control_VICRT_DOWNSHIFT_REQ =
    lss_online_B.DataTypeConversion4;

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_On' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LDW.LDW_On */
  *(real_T *)pADAS_Outputs_LDW_LDW_On = lss_online_B.DataTypeConversion;

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_On_Left' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LDW.LDW_On_Left */
  *(real_T *)pADAS_Outputs_LDW_LDW_On_Left = lss_online_B.DataTypeConversion3[0];

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_On_Pulse' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LDW.LDW_On_Pulse */
  *(real_T *)pADAS_Outputs_LDW_LDW_On_Pulse = lss_online_B.Product2;

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_On_Right' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LDW.LDW_On_Right */
  *(real_T *)pADAS_Outputs_LDW_LDW_On_Right = lss_online_B.DataTypeConversion3[1];

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_Ready' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LDW.LDW_Ready */
  *(real_T *)pADAS_Outputs_LDW_LDW_Ready = lss_online_B.DataTypeConversion2;

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_Steering_Torque' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LDW.LDW_Steering_Torque */
  *(real_T *)pADAS_Outputs_LDW_LDW_Steering_Torque = lss_online_B.Product1;

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_White' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LDW.LDW_White */
  *(real_T *)pADAS_Outputs_LDW_LDW_White = lss_online_B.DataTypeConversion1;

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_AEB_Sound' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LKA.LKA_AEB_Sound */
  *(real_T *)pADAS_Outputs_LKA_LKA_AEB_Sound = lss_online_B.Sum_c;

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_On_Display' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LKA.LKA_On_Display */
  *(real_T *)pADAS_Outputs_LKA_LKA_On_Display = lss_online_B.LKA_on;

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_On_Left' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LKA.LKA_On_Left */
  *(real_T *)pADAS_Outputs_LKA_LKA_On_Left = lss_online_B.DataTypeConversion3_h
    [0];

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_On_Pulse' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LKA.LKA_On_Pulse */
  *(real_T *)pADAS_Outputs_LKA_LKA_On_Pulse = lss_online_B.Product2_f;

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_On_Right' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LKA.LKA_On_Right */
  *(real_T *)pADAS_Outputs_LKA_LKA_On_Right =
    lss_online_B.DataTypeConversion3_h[1];

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_Ready' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LKA.LKA_Ready */
  *(real_T *)pADAS_Outputs_LKA_LKA_Ready = lss_online_B.DataTypeConversion2_o;

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_Steer_Angle' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LKA.LKA_Steer_Angle */
  *(real_T *)pADAS_Outputs_LKA_LKA_Steer_Angle = lss_online_B.DiscreteFilter;

#endif

  /* S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_Steer_Mode' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S1>/ADAS.Outputs.LKA.LKA_Steer_Mode */
  *(real_T *)pADAS_Outputs_LKA_LKA_Steer_Mode = lss_online_B.LKA_on;

#endif

  /* S-Function (simwbC_RTDBOut): '<S6>/VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S6>/VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ */
  *(real_T *)pVI_DriveSim_Inputs_Control_VICRT_RESTART_REQ =
    lss_online_B.Product_f;

#endif

  /* S-Function (simwbC_RTDBOut): '<S6>/VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S6>/VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ */
  *(real_T *)pVI_DriveSim_Inputs_Control_VICRT_RESTORE_REQ =
    lss_online_B.Product1_i;

#endif

}

/* Model update function for TID0 */
static void lss_online_update0(void)   /* Sample time: [0.0s, 0.0s] */
{
  real_T LastMajorTime_tmp;

  /* Update for UnitDelay: '<S163>/Delay Input1' */
  lss_online_DW.DelayInput1_DSTATE = lss_online_B.VI_DriveSimInputsECATBECKHDIG4;

  /* Update for Memory: '<S6>/Memory1' */
  lss_online_DW.Memory1_PreviousInput = lss_online_B.Memory_a;

  /* Update for Memory: '<S6>/Memory' */
  lss_online_DW.Memory_PreviousInput_b = lss_online_B.ACCoutputs;

  /* Update for Memory: '<S4>/Memory2' incorporates:
   *  Constant: '<S4>/Constant'
   */
  lss_online_DW.Memory2_PreviousInput = lss_online_P.Constant_Value_dk;

  /* Update for Memory: '<S4>/Memory' */
  lss_online_DW.Memory_PreviousInput = lss_online_B.LKA_on;

  /* Update for RateLimiter: '<S8>/Rate Limiter1' incorporates:
   *  RateLimiter: '<S8>/Rate Limiter'
   */
  lss_online_DW.PrevY = lss_online_B.RateLimiter1;
  LastMajorTime_tmp = lss_online_M->Timing.t[0];
  lss_online_DW.LastMajorTime = LastMajorTime_tmp;

  /* Update for DiscreteFilter: '<S147>/filtering' */
  lss_online_DW.filtering_states[1] = lss_online_DW.filtering_states[0];
  lss_online_DW.filtering_states[0] = lss_online_DW.filtering_tmp;

  /* Update for DiscreteIntegrator: '<S45>/Integrator' */
  lss_online_DW.Integrator_DSTATE += lss_online_P.Integrator_gainval *
    lss_online_B.IntegralGain;

  /* Update for DiscreteFilter: '<S4>/Discrete Filter' */
  lss_online_DW.DiscreteFilter_states[1] = lss_online_DW.DiscreteFilter_states[0];
  lss_online_DW.DiscreteFilter_states[0] = lss_online_DW.DiscreteFilter_tmp;

  /* Update for RateLimiter: '<S8>/Rate Limiter' */
  lss_online_DW.PrevY_b = lss_online_B.RateLimiter;
  lss_online_DW.LastMajorTime_g = LastMajorTime_tmp;

  /* Update for Memory: '<S3>/Memory2' incorporates:
   *  Constant: '<S3>/Constant'
   */
  lss_online_DW.Memory2_PreviousInput_b = lss_online_P.Constant_Value_h;

  /* Update for DiscreteFilter: '<S147>/Discrete Filter' */
  lss_online_DW.DiscreteFilter_states_m[1] =
    lss_online_DW.DiscreteFilter_states_m[0];
  lss_online_DW.DiscreteFilter_states_m[0] = lss_online_DW.DiscreteFilter_tmp_g;

  /* Update for DiscreteFilter: '<S147>/Discrete Filter1' */
  lss_online_DW.DiscreteFilter1_states[1] =
    lss_online_DW.DiscreteFilter1_states[0];
  lss_online_DW.DiscreteFilter1_states[0] = lss_online_DW.DiscreteFilter1_tmp;

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++lss_online_M->Timing.clockTick0)) {
    ++lss_online_M->Timing.clockTickH0;
  }

  lss_online_M->Timing.t[0] = lss_online_M->Timing.clockTick0 *
    lss_online_M->Timing.stepSize0 + lss_online_M->Timing.clockTickH0 *
    lss_online_M->Timing.stepSize0 * 4294967296.0;

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick1"
   * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick1 and the high bits
   * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++lss_online_M->Timing.clockTick1)) {
    ++lss_online_M->Timing.clockTickH1;
  }

  lss_online_M->Timing.t[1] = lss_online_M->Timing.clockTick1 *
    lss_online_M->Timing.stepSize1 + lss_online_M->Timing.clockTickH1 *
    lss_online_M->Timing.stepSize1 * 4294967296.0;
}

/* Model output function for TID2 */
static void lss_online_output2(void)   /* Sample time: [0.01s, 0.0s] */
{
  real_T rtb_Sum1_l;
  real_T rtb_Sum_c;

  /* S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S139>/VI_WorldSim_Sensor_VirtualCamera' */
  /* MATLAB Function 'OUTPUT/WorldSim_Sensor_Outputs/Subsystem/multiagent radar  SimpleRadar_... are single double representing id, yaw, range, power_db, range_rate, yaw_rate, status/MATLAB Function1': '<S154>:1' */
  /* '<S154>:1:3' */
  /* '<S154>:1:4' */
  /* '<S154>:1:5' */
  /* '<S154>:1:6' */
  /* '<S154>:1:7' */
  /* '<S154>:1:8' */
  /* '<S154>:1:9' */

  /* Level2 S-Function Block: '<S139>/VI_WorldSim_Sensor_VirtualCamera' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = lss_online_M->childSfunctions[0];
    sfcnOutputs(rts,2);
  }

  /* MATLAB Function: '<S139>/manipulation_of_objects' */
  lss_online_manipulation_of_objects(lss_online_B.matrix_obstacles,
    lss_online_B.valid_matrix_obstacles,
    &lss_online_B.sf_manipulation_of_objects);

  /* S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S139>/VI_WorldSim_Sensor_VirtualCamera1' */
  /* MATLAB Function 'OUTPUT/WorldSim_Sensor_Outputs/Subsystem/obstacle detection /MATLAB Function2': '<S156>:1' */
  /* '<S156>:1:4' */
  /* '<S156>:1:5' */
  /* '<S156>:1:6' */
  /* '<S156>:1:7' */
  /* '<S156>:1:8' */
  /* '<S156>:1:9' */
  /* '<S156>:1:10' */
  /* '<S156>:1:11' */
  /* '<S156>:1:12' */
  /* '<S156>:1:13' */
  /* MATLAB Function 'OUTPUT/WorldSim_Sensor_Outputs/Subsystem/obstacle detection /MATLAB Function': '<S155>:1' */
  /* '<S155>:1:6' */
  /* '<S155>:1:7' */

  /* Level2 S-Function Block: '<S139>/VI_WorldSim_Sensor_VirtualCamera1' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = lss_online_M->childSfunctions[1];
    sfcnOutputs(rts,2);
  }

  /* MATLAB Function: '<S139>/manipulation_of_objects1' */
  lss_online_manipulation_of_objects(lss_online_B.matrix_obstacles_e,
    lss_online_B.valid_matrix_obstacles_d,
    &lss_online_B.sf_manipulation_of_objects1);

  /* Sum: '<S147>/Sum' incorporates:
   *  Constant: '<S143>/Semitrack'
   *  MATLAB Function: '<S139>/MATLAB Function'
   *  S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  /* MATLAB Function 'OUTPUT/WorldSim_Sensor_Outputs/Subsystem/bsd setection from ostacle recognition/MATLAB Function3': '<S151>:1' */
  /* '<S151>:1:7' */
  /* '<S151>:1:2' */
  /* '<S151>:1:3' */
  /* '<S151>:1:7' */
  /* '<S151>:1:10' */
  /* '<S151>:1:11' */
  /* MATLAB Function 'OUTPUT/WorldSim_Sensor_Outputs/MATLAB Function': '<S141>:1' */
  /* '<S141>:1:3' */
  /* '<S141>:1:4' */
  rtb_Sum_c = lss_online_B.lanecoefficients2x4[0] - lss_online_P.vehicle_width /
    2.0;

  /* Sum: '<S147>/Sum1' incorporates:
   *  Constant: '<S143>/Semitrack'
   *  Gain: '<S147>/Gain2'
   *  MATLAB Function: '<S139>/MATLAB Function'
   *  S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  rtb_Sum1_l = lss_online_P.Gain2_Gain * lss_online_B.lanecoefficients2x4[1] -
    lss_online_P.vehicle_width / 2.0;

  /* RateTransition generated from: '<S147>/Discrete Filter1' */
  lss_online_DW.TmpRTBAtDiscreteFilter1Inport1_Buffer0 = rtb_Sum1_l;

  /* RateTransition generated from: '<S147>/Sum' */
  lss_online_DW.TmpRTBAtSumOutport1_Buffer0 = rtb_Sum_c;

  /* S-Function (VI_WorldSim_State_Manager_mex): '<S139>/VI_WorldSim_State_Manager' */

  /* Level2 S-Function Block: '<S139>/VI_WorldSim_State_Manager' (VI_WorldSim_State_Manager_mex) */
  {
    SimStruct *rts = lss_online_M->childSfunctions[2];
    sfcnOutputs(rts,2);
  }
}

/* Model update function for TID2 */
static void lss_online_update2(void)   /* Sample time: [0.01s, 0.0s] */
{
  /* Update for S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S139>/VI_WorldSim_Sensor_VirtualCamera' */
  /* Level2 S-Function Block: '<S139>/VI_WorldSim_Sensor_VirtualCamera' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = lss_online_M->childSfunctions[0];
    sfcnUpdate(rts,2);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Update for S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S139>/VI_WorldSim_Sensor_VirtualCamera1' */
  /* Level2 S-Function Block: '<S139>/VI_WorldSim_Sensor_VirtualCamera1' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = lss_online_M->childSfunctions[1];
    sfcnUpdate(rts,2);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Update for S-Function (VI_WorldSim_State_Manager_mex): '<S139>/VI_WorldSim_State_Manager' */
  /* Level2 S-Function Block: '<S139>/VI_WorldSim_State_Manager' (VI_WorldSim_State_Manager_mex) */
  {
    SimStruct *rts = lss_online_M->childSfunctions[2];
    sfcnUpdate(rts,2);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Update absolute time */
  /* The "clockTick2" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick2"
   * and "Timing.stepSize2". Size of "clockTick2" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick2 and the high bits
   * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++lss_online_M->Timing.clockTick2)) {
    ++lss_online_M->Timing.clockTickH2;
  }

  lss_online_M->Timing.t[2] = lss_online_M->Timing.clockTick2 *
    lss_online_M->Timing.stepSize2 + lss_online_M->Timing.clockTickH2 *
    lss_online_M->Timing.stepSize2 * 4294967296.0;
}

/* Model output function for TID3 */
static void lss_online_output3(void)   /* Sample time: [0.02s, 0.0s] */
{
  /* local block i/o variables */
  real_T rtb_Sum_g;
  real_T rtb_Abs[2];
  real_T rtb_RateTransition[2];
  real_T rtb_LKA_Dyn_Rate_Limiter_Gain;
  real_T rtb_MultiportSwitch_idx_1;
  real_T rtb_MultiportSwitch_idx_2;
  real_T rtb_PProdOut;
  real_T rtb_SumofElements;
  boolean_T rtb_off;

  /* SampleTimeMath: '<S69>/TSamp' incorporates:
   *  RateTransition: '<S3>/Rate Transition'
   *
   * About '<S69>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  lss_online_B.TSamp[0] = lss_online_DW.RateTransition_Buffer[0] *
    lss_online_P.TSamp_WtEt_b;

  /* Abs: '<S3>/Abs' incorporates:
   *  Sum: '<S69>/Diff'
   *  UnitDelay: '<S69>/UD'
   */
  rtb_Abs[0] = fabs(lss_online_B.TSamp[0] - lss_online_DW.UD_DSTATE[0]);

  /* RateTransition: '<S3>/Rate Transition1' incorporates:
   *  RateTransition: '<S3>/Rate Transition'
   */
  lss_online_DW.RateTransition1_Buffer0_o[0] =
    lss_online_DW.RateTransition_Buffer[0];

  /* SampleTimeMath: '<S69>/TSamp' incorporates:
   *  RateTransition: '<S3>/Rate Transition'
   *
   * About '<S69>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  lss_online_B.TSamp[1] = lss_online_DW.RateTransition_Buffer[1] *
    lss_online_P.TSamp_WtEt_b;

  /* Abs: '<S3>/Abs' incorporates:
   *  Sum: '<S69>/Diff'
   *  UnitDelay: '<S69>/UD'
   */
  rtb_Abs[1] = fabs(lss_online_B.TSamp[1] - lss_online_DW.UD_DSTATE[1]);

  /* RateTransition: '<S3>/Rate Transition1' incorporates:
   *  RateTransition: '<S3>/Rate Transition'
   */
  lss_online_DW.RateTransition1_Buffer0_o[1] =
    lss_online_DW.RateTransition_Buffer[1];

  /* RateTransition: '<S3>/Rate Transition2' */
  lss_online_DW.RateTransition2_Buffer0_a[0] = rtb_Abs[0];
  lss_online_DW.RateTransition2_Buffer0_a[1] = rtb_Abs[1];

  /* SampleTimeMath: '<S79>/TSamp' incorporates:
   *  RateTransition: '<S4>/Rate Transition'
   *
   * About '<S79>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  lss_online_B.TSamp_h[0] = lss_online_DW.RateTransition_Buffer_g[0] *
    lss_online_P.TSamp_WtEt_i;

  /* Abs: '<S4>/Abs' incorporates:
   *  Sum: '<S79>/Diff'
   *  UnitDelay: '<S79>/UD'
   */
  rtb_Abs[0] = fabs(lss_online_B.TSamp_h[0] - lss_online_DW.UD_DSTATE_e[0]);

  /* RateTransition: '<S4>/Rate Transition' */
  rtb_RateTransition[0] = lss_online_DW.RateTransition_Buffer_g[0];

  /* SampleTimeMath: '<S79>/TSamp' incorporates:
   *  RateTransition: '<S4>/Rate Transition'
   *
   * About '<S79>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  lss_online_B.TSamp_h[1] = lss_online_DW.RateTransition_Buffer_g[1] *
    lss_online_P.TSamp_WtEt_i;

  /* Abs: '<S4>/Abs' incorporates:
   *  Sum: '<S79>/Diff'
   *  UnitDelay: '<S79>/UD'
   */
  rtb_Abs[1] = fabs(lss_online_B.TSamp_h[1] - lss_online_DW.UD_DSTATE_e[1]);

  /* RateTransition: '<S4>/Rate Transition' */
  rtb_RateTransition[1] = lss_online_DW.RateTransition_Buffer_g[1];

  /* Sum: '<S4>/Subtract' incorporates:
   *  Gain: '<S4>/Gain1'
   *  Sum: '<S4>/Sum of Elements'
   */
  rtb_PProdOut = (rtb_RateTransition[0] + rtb_RateTransition[1]) *
    lss_online_P.Gain1_Gain - rtb_RateTransition[0];

  /* Saturate: '<S4>/Saturation' */
  if (rtb_PProdOut > lss_online_P.LKA_Error_Max) {
    rtb_PProdOut = lss_online_P.LKA_Error_Max;
  } else if (rtb_PProdOut < -lss_online_P.LKA_Error_Max) {
    rtb_PProdOut = -lss_online_P.LKA_Error_Max;
  }

  /* End of Saturate: '<S4>/Saturation' */

  /* SampleTimeMath: '<S80>/TSamp'
   *
   * About '<S80>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  lss_online_B.TSamp_m = rtb_PProdOut * lss_online_P.TSamp_WtEt_k;

  /* Sum: '<S80>/Diff' incorporates:
   *  UnitDelay: '<S80>/UD'
   */
  rtb_LKA_Dyn_Rate_Limiter_Gain = lss_online_B.TSamp_m -
    lss_online_DW.UD_DSTATE_k;

  /* Abs: '<S4>/Abs1' */
  rtb_SumofElements = fabs(rtb_LKA_Dyn_Rate_Limiter_Gain);

  /* SampleTimeMath: '<S81>/TSamp'
   *
   * About '<S81>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  lss_online_B.TSamp_g = rtb_LKA_Dyn_Rate_Limiter_Gain *
    lss_online_P.TSamp_WtEt_h;

  /* MultiPortSwitch: '<S82>/Multiport Switch' incorporates:
   *  Constant: '<S82>/ADAS_Control_Mode'
   *  Constant: '<S82>/LKA_D(1)'
   *  Constant: '<S82>/LKA_D(1)1'
   *  Constant: '<S82>/LKA_I(1)'
   *  Constant: '<S82>/LKA_I(1)1'
   *  Constant: '<S82>/LKA_P(1)'
   *  Constant: '<S82>/LKA_P(1)1'
   */
  switch ((int32_T)lss_online_P.ADAS_Control_Mode) {
   case 1:
    rtb_LKA_Dyn_Rate_Limiter_Gain = lss_online_P.LKA_P[0];
    rtb_MultiportSwitch_idx_1 = lss_online_P.LKA_I[0];
    rtb_MultiportSwitch_idx_2 = lss_online_P.LKA_D[0];
    break;

   case 2:
    rtb_LKA_Dyn_Rate_Limiter_Gain = lss_online_P.LKA_P[1];
    rtb_MultiportSwitch_idx_1 = lss_online_P.LKA_I[1];
    rtb_MultiportSwitch_idx_2 = lss_online_P.LKA_D[1];
    break;

   default:
    rtb_LKA_Dyn_Rate_Limiter_Gain = lss_online_P.LKA_P[0];
    rtb_MultiportSwitch_idx_1 = lss_online_P.LKA_I[0];
    rtb_MultiportSwitch_idx_2 = lss_online_P.LKA_D[0];
    break;
  }

  /* End of MultiPortSwitch: '<S82>/Multiport Switch' */

  /* SampleTimeMath: '<S115>/Tsamp' incorporates:
   *  Product: '<S112>/DProd Out'
   *
   * About '<S115>/Tsamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  lss_online_B.Tsamp = rtb_PProdOut * rtb_MultiportSwitch_idx_2 *
    lss_online_P.Tsamp_WtEt;

  /* RateTransition: '<S4>/Rate Transition4' */
  lss_online_B.RateTransition4 = lss_online_DW.RateTransition4_Buffer;

  /* Delay: '<S113>/UD' */
  if (rt_ZCFcn(ANY_ZERO_CROSSING,&lss_online_PrevZCX.UD_Reset_ZCE,
               (lss_online_B.RateTransition4)) != NO_ZCEVENT) {
    lss_online_DW.UD_DSTATE_g =
      lss_online_P.DiscretePIDController_DifferentiatorICPrevScaledInput;
  }

  /* Product: '<S117>/IProd Out' */
  lss_online_B.IProdOut = rtb_PProdOut * rtb_MultiportSwitch_idx_1;

  /* DiscreteIntegrator: '<S120>/Integrator' */
  if (((lss_online_B.RateTransition4 > 0.0) &&
       (lss_online_DW.Integrator_PrevResetState <= 0)) ||
      ((lss_online_B.RateTransition4 <= 0.0) &&
       (lss_online_DW.Integrator_PrevResetState == 1))) {
    lss_online_DW.Integrator_DSTATE_g =
      lss_online_P.DiscretePIDController_InitialConditionForIntegrator;
  }

  /* Sum: '<S129>/Sum' incorporates:
   *  Delay: '<S113>/UD'
   *  DiscreteIntegrator: '<S120>/Integrator'
   *  Product: '<S125>/PProd Out'
   *  Sum: '<S113>/Diff'
   */
  rtb_Sum_g = (rtb_PProdOut * rtb_LKA_Dyn_Rate_Limiter_Gain +
               lss_online_DW.Integrator_DSTATE_g) + (lss_online_B.Tsamp -
    lss_online_DW.UD_DSTATE_g);

  /* Gain: '<S4>/LKA_Dyn_Rate_Limiter_Gain' incorporates:
   *  Abs: '<S4>/Abs2'
   *  Sum: '<S81>/Diff'
   *  UnitDelay: '<S81>/UD'
   */
  rtb_LKA_Dyn_Rate_Limiter_Gain = fabs(lss_online_B.TSamp_g -
    lss_online_DW.UD_DSTATE_o) * lss_online_P.LKA_Dyn_Rate_Limiter_Gain;

  /* Math: '<S4>/Math Function1' incorporates:
   *  Constant: '<S4>/LKA_Dyn_Rate_Limiter_Power'
   */
  if ((rtb_LKA_Dyn_Rate_Limiter_Gain < 0.0) &&
      (lss_online_P.LKA_Dyn_Rate_Limiter_Power > floor
       (lss_online_P.LKA_Dyn_Rate_Limiter_Power))) {
    rtb_LKA_Dyn_Rate_Limiter_Gain = -rt_powd_snf(-rtb_LKA_Dyn_Rate_Limiter_Gain,
      lss_online_P.LKA_Dyn_Rate_Limiter_Power);
  } else {
    rtb_LKA_Dyn_Rate_Limiter_Gain = rt_powd_snf(rtb_LKA_Dyn_Rate_Limiter_Gain,
      lss_online_P.LKA_Dyn_Rate_Limiter_Power);
  }

  /* End of Math: '<S4>/Math Function1' */

  /* MATLAB Function: '<S4>/MATLAB Function' */
  /* MATLAB Function 'LKA/MATLAB Function': '<S84>:1' */
  if (rtb_LKA_Dyn_Rate_Limiter_Gain == 0.0) {
    /* '<S84>:1:3' */
    /* '<S84>:1:4' */
    rtb_LKA_Dyn_Rate_Limiter_Gain = 1.0E-6;
  } else {
    /* '<S84>:1:6' */
  }

  /* End of MATLAB Function: '<S4>/MATLAB Function' */

  /* Product: '<S4>/Reciprocal' */
  rtb_LKA_Dyn_Rate_Limiter_Gain = 1.0 / rtb_LKA_Dyn_Rate_Limiter_Gain;

  /* Logic: '<S4>/Logical Operator5' incorporates:
   *  Abs: '<S4>/Abs3'
   *  Constant: '<S71>/Constant'
   *  Constant: '<S73>/Constant'
   *  RelationalOperator: '<S71>/Compare'
   *  RelationalOperator: '<S73>/Compare'
   */
  rtb_off = ((!(rtb_SumofElements < lss_online_P.LKA_Error_dydt_Off)) || (!(fabs
    (rtb_PProdOut) < lss_online_P.LKA_Error_Off)));

  /* Product: '<S85>/delta rise limit' incorporates:
   *  SampleTimeMath: '<S85>/sample time'
   *
   * About '<S85>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_SumofElements = rtb_LKA_Dyn_Rate_Limiter_Gain *
    lss_online_P.sampletime_WtEt;

  /* Sum: '<S85>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S85>/Delay Input2'
   */
  rtb_PProdOut = rtb_Sum_g - lss_online_DW.DelayInput2_DSTATE;

  /* Switch: '<S137>/Switch2' incorporates:
   *  RelationalOperator: '<S137>/LowerRelop1'
   */
  if (!(rtb_PProdOut > rtb_SumofElements)) {
    /* Product: '<S85>/delta fall limit' incorporates:
     *  Gain: '<S4>/Gain'
     *  SampleTimeMath: '<S85>/sample time'
     *
     * About '<S85>/sample time':
     *  y = K where K = ( w * Ts )
     */
    rtb_SumofElements = lss_online_P.Gain_Gain * rtb_LKA_Dyn_Rate_Limiter_Gain *
      lss_online_P.sampletime_WtEt;

    /* Switch: '<S137>/Switch' incorporates:
     *  RelationalOperator: '<S137>/UpperRelop'
     */
    if (!(rtb_PProdOut < rtb_SumofElements)) {
      rtb_SumofElements = rtb_PProdOut;
    }

    /* End of Switch: '<S137>/Switch' */
  }

  /* End of Switch: '<S137>/Switch2' */

  /* Sum: '<S85>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S85>/Delay Input2'
   */
  lss_online_B.DifferenceInputs2 = rtb_SumofElements +
    lss_online_DW.DelayInput2_DSTATE;

  /* Product: '<S4>/Product1' incorporates:
   *  RateTransition: '<S4>/Rate Transition6'
   */
  rtb_SumofElements = lss_online_B.DifferenceInputs2 *
    lss_online_DW.RateTransition6_Buffer;

  /* RateLimiter: '<S4>/Rate Limiter' */
  rtb_PProdOut = rtb_SumofElements - lss_online_DW.PrevY_i;
  if (rtb_PProdOut > lss_online_P.LKA_Steer_Rate_Max_radps * lss_online_period)
  {
    rtb_SumofElements = lss_online_P.LKA_Steer_Rate_Max_radps *
      lss_online_period + lss_online_DW.PrevY_i;
  } else {
    rtb_LKA_Dyn_Rate_Limiter_Gain = -lss_online_P.LKA_Steer_Rate_Max_radps *
      lss_online_period;
    if (rtb_PProdOut < rtb_LKA_Dyn_Rate_Limiter_Gain) {
      rtb_SumofElements = rtb_LKA_Dyn_Rate_Limiter_Gain + lss_online_DW.PrevY_i;
    }
  }

  lss_online_DW.PrevY_i = rtb_SumofElements;

  /* End of RateLimiter: '<S4>/Rate Limiter' */

  /* RateTransition: '<S4>/Rate Transition1' */
  lss_online_DW.RateTransition1_Buffer0[0] = rtb_RateTransition[0];
  lss_online_DW.RateTransition1_Buffer0[1] = rtb_RateTransition[1];

  /* RateTransition: '<S4>/Rate Transition2' */
  lss_online_DW.RateTransition2_Buffer0[0] = rtb_Abs[0];
  lss_online_DW.RateTransition2_Buffer0[1] = rtb_Abs[1];

  /* RateTransition: '<S4>/Rate Transition3' */
  lss_online_DW.RateTransition3_Buffer0 = rtb_SumofElements;

  /* RateTransition: '<S4>/Rate Transition5' */
  lss_online_DW.RateTransition5_Buffer0 = rtb_off;
}

/* Model update function for TID3 */
static void lss_online_update3(void)   /* Sample time: [0.02s, 0.0s] */
{
  /* Update for UnitDelay: '<S69>/UD' */
  lss_online_DW.UD_DSTATE[0] = lss_online_B.TSamp[0];

  /* Update for UnitDelay: '<S79>/UD' */
  lss_online_DW.UD_DSTATE_e[0] = lss_online_B.TSamp_h[0];

  /* Update for UnitDelay: '<S69>/UD' */
  lss_online_DW.UD_DSTATE[1] = lss_online_B.TSamp[1];

  /* Update for UnitDelay: '<S79>/UD' */
  lss_online_DW.UD_DSTATE_e[1] = lss_online_B.TSamp_h[1];

  /* Update for UnitDelay: '<S80>/UD' */
  lss_online_DW.UD_DSTATE_k = lss_online_B.TSamp_m;

  /* Update for UnitDelay: '<S81>/UD' */
  lss_online_DW.UD_DSTATE_o = lss_online_B.TSamp_g;

  /* Update for Delay: '<S113>/UD' */
  lss_online_DW.UD_DSTATE_g = lss_online_B.Tsamp;

  /* Update for DiscreteIntegrator: '<S120>/Integrator' */
  lss_online_DW.Integrator_DSTATE_g += lss_online_P.Integrator_gainval_o *
    lss_online_B.IProdOut;
  if (lss_online_B.RateTransition4 > 0.0) {
    lss_online_DW.Integrator_PrevResetState = 1;
  } else if (lss_online_B.RateTransition4 < 0.0) {
    lss_online_DW.Integrator_PrevResetState = -1;
  } else if (lss_online_B.RateTransition4 == 0.0) {
    lss_online_DW.Integrator_PrevResetState = 0;
  } else {
    lss_online_DW.Integrator_PrevResetState = 2;
  }

  /* End of Update for DiscreteIntegrator: '<S120>/Integrator' */

  /* Update for UnitDelay: '<S85>/Delay Input2' */
  lss_online_DW.DelayInput2_DSTATE = lss_online_B.DifferenceInputs2;

  /* Update absolute time */
  /* The "clockTick3" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick3"
   * and "Timing.stepSize3". Size of "clockTick3" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick3 and the high bits
   * Timing.clockTickH3. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++lss_online_M->Timing.clockTick3)) {
    ++lss_online_M->Timing.clockTickH3;
  }

  lss_online_M->Timing.t[3] = lss_online_M->Timing.clockTick3 *
    lss_online_M->Timing.stepSize3 + lss_online_M->Timing.clockTickH3 *
    lss_online_M->Timing.stepSize3 * 4294967296.0;
}

/* Use this function only if you need to maintain compatibility with an existing static main program. */
static void lss_online_output(int_T tid)
{
  switch (tid) {
   case 0 :
    lss_online_output0();
    break;

   case 2 :
    lss_online_output2();
    break;

   case 3 :
    lss_online_output3();
    break;

   default :
    /* do nothing */
    break;
  }
}

/* Use this function only if you need to maintain compatibility with an existing static main program. */
static void lss_online_update(int_T tid)
{
  switch (tid) {
   case 0 :
    lss_online_update0();
    break;

   case 2 :
    lss_online_update2();
    break;

   case 3 :
    lss_online_update3();
    break;

   default :
    /* do nothing */
    break;
  }
}

/* Model initialize function */
static void lss_online_initialize(void)
{
  /* Start for S-Function (simwbC_RTDBIn): '<S6>/VI_DriveSim.Inputs.ECAT.BECKH.ANA3' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.ECAT.BECKH.ANA3",&pItem) < 0)
    {
      fprintf(stderr,
              "MDL:  input var VI_DriveSim.Inputs.ECAT.BECKH.ANA3 not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.ANA3 not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_DriveSim.Inputs.ECAT.BECKH.ANA3 datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.ANA3 datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_DriveSim_Inputs_ECAT_BECKH_ANA3 = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.chassis_velocities.longitudinal' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress(
         "VI_CarRealTime.Outputs.chassis_velocities.longitudinal",&pItem) < 0) {
      fprintf(stderr,
              "MDL:  input var VI_CarRealTime.Outputs.chassis_velocities.longitudinal not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.chassis_velocities.longitudinal not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_CarRealTime.Outputs.chassis_velocities.longitudinal datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.chassis_velocities.longitudinal datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_CarRealTime_Outputs_chassis_velocities_longitudinal = &pCVT
      [pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.driver_demands.steering' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_CarRealTime.Outputs.driver_demands.steering",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL:  input var VI_CarRealTime.Outputs.driver_demands.steering not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.driver_demands.steering not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_CarRealTime.Outputs.driver_demands.steering datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.driver_demands.steering datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_CarRealTime_Outputs_driver_demands_steering = &pCVT
      [pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<S6>/VI_DriveSim.Inputs.ECAT.BECKH.DIG4' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.ECAT.BECKH.DIG4",&pItem) < 0)
    {
      fprintf(stderr,
              "MDL:  input var VI_DriveSim.Inputs.ECAT.BECKH.DIG4 not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.DIG4 not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_DriveSim.Inputs.ECAT.BECKH.DIG4 datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.DIG4 datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_DriveSim_Inputs_ECAT_BECKH_DIG4 = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<S6>/VI_DriveSim.Outputs.Vicrt.Status' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_DriveSim.Outputs.Vicrt.Status",&pItem) < 0)
    {
      fprintf(stderr,
              "MDL:  input var VI_DriveSim.Outputs.Vicrt.Status not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_DriveSim.Outputs.Vicrt.Status not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_DriveSim.Outputs.Vicrt.Status datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_DriveSim.Outputs.Vicrt.Status datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_DriveSim_Outputs_Vicrt_Status = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<S6>/VI_DriveSim.Inputs.ECAT.BECKH.ANA1' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.ECAT.BECKH.ANA4",&pItem) < 0)
    {
      fprintf(stderr,
              "MDL:  input var VI_DriveSim.Inputs.ECAT.BECKH.ANA4 not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.ANA4 not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_DriveSim.Inputs.ECAT.BECKH.ANA4 datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.ANA4 datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_DriveSim_Inputs_ECAT_BECKH_ANA4 = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress(
         "VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL:  input var VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_CarRealTime_Outputs_Steering_System_DriveSim_Steering_Feedback_Torque =
      &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL:  input var VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1 not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1 not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1 datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1 datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_CarRealTime_Outputs_Wheel_Spindle_Steer_L1 = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL:  input var VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1 not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1 not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1 datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1 datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_CarRealTime_Outputs_Wheel_Spindle_Steer_R1 = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.chassis_accelerations.lateral' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress(
         "VI_CarRealTime.Outputs.chassis_accelerations.lateral",&pItem) < 0) {
      fprintf(stderr,
              "MDL:  input var VI_CarRealTime.Outputs.chassis_accelerations.lateral not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.chassis_accelerations.lateral not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_CarRealTime.Outputs.chassis_accelerations.lateral datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.chassis_accelerations.lateral datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_CarRealTime_Outputs_chassis_accelerations_lateral = &pCVT
      [pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.chassis_accelerations.longitudinal' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress(
         "VI_CarRealTime.Outputs.chassis_accelerations.longitudinal",&pItem) < 0)
    {
      fprintf(stderr,
              "MDL:  input var VI_CarRealTime.Outputs.chassis_accelerations.longitudinal not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.chassis_accelerations.longitudinal not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_CarRealTime.Outputs.chassis_accelerations.longitudinal datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.chassis_accelerations.longitudinal datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_CarRealTime_Outputs_chassis_accelerations_longitudinal = &pCVT
      [pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.driver_demands.brake' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_CarRealTime.Outputs.driver_demands.brake",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL:  input var VI_CarRealTime.Outputs.driver_demands.brake not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.driver_demands.brake not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_CarRealTime.Outputs.driver_demands.brake datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.driver_demands.brake datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_CarRealTime_Outputs_driver_demands_brake = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.driver_demands.throttle' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_CarRealTime.Outputs.driver_demands.throttle",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL:  input var VI_CarRealTime.Outputs.driver_demands.throttle not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.driver_demands.throttle not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_CarRealTime.Outputs.driver_demands.throttle datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.driver_demands.throttle datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_CarRealTime_Outputs_driver_demands_throttle = &pCVT
      [pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<S6>/VI_DriveSim.Inputs.ECAT.BECKH.DIG3' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.ECAT.BECKH.DIG3",&pItem) < 0)
    {
      fprintf(stderr,
              "MDL:  input var VI_DriveSim.Inputs.ECAT.BECKH.DIG3 not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.DIG3 not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_DriveSim.Inputs.ECAT.BECKH.DIG3 datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.DIG3 datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_DriveSim_Inputs_ECAT_BECKH_DIG3 = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBIn): '<S6>/VI_CarRealTime.Outputs.transmission.gear' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_CarRealTime.Outputs.transmission.gear",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL:  input var VI_CarRealTime.Outputs.transmission.gear not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.transmission.gear not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_CarRealTime.Outputs.transmission.gear datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL input variable: VI_CarRealTime.Outputs.transmission.gear datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_CarRealTime_Outputs_transmission_gear = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for RateTransition: '<S4>/Rate Transition2' */
  lss_online_B.RateTransition2[0] =
    lss_online_P.RateTransition2_InitialCondition;

  /* Start for RateTransition: '<S4>/Rate Transition1' */
  lss_online_B.RateTransition1[0] =
    lss_online_P.RateTransition1_InitialCondition;

  /* Start for RateTransition: '<S4>/Rate Transition2' */
  lss_online_B.RateTransition2[1] =
    lss_online_P.RateTransition2_InitialCondition;

  /* Start for RateTransition: '<S4>/Rate Transition1' */
  lss_online_B.RateTransition1[1] =
    lss_online_P.RateTransition1_InitialCondition;

  /* Start for RateTransition: '<S4>/Rate Transition5' */
  lss_online_B.toggle = lss_online_P.RateTransition5_InitialCondition;

  /* Start for RateTransition generated from: '<S147>/Sum' */
  lss_online_B.TmpRTBAtSumOutport1 =
    lss_online_P.TmpRTBAtSumOutport1_InitialCondition;

  /* Start for DiscretePulseGenerator: '<S147>/Pulse Generator' */
  lss_online_DW.clockTickCounter = 0;

  /* Start for RateTransition: '<S4>/Rate Transition3' */
  lss_online_B.RateTransition3 = lss_online_P.RateTransition3_InitialCondition;

  /* Start for RateTransition: '<S3>/Rate Transition2' */
  lss_online_B.RateTransition2_b[0] =
    lss_online_P.RateTransition2_InitialCondition_j;

  /* Start for RateTransition: '<S3>/Rate Transition1' */
  lss_online_B.RateTransition1_m[0] =
    lss_online_P.RateTransition1_InitialCondition_i;

  /* Start for RateTransition: '<S3>/Rate Transition2' */
  lss_online_B.RateTransition2_b[1] =
    lss_online_P.RateTransition2_InitialCondition_j;

  /* Start for RateTransition: '<S3>/Rate Transition1' */
  lss_online_B.RateTransition1_m[1] =
    lss_online_P.RateTransition1_InitialCondition_i;

  /* Start for DiscretePulseGenerator: '<S3>/Pulse Generator' */
  lss_online_DW.clockTickCounter_c = 0;

  /* Start for DiscretePulseGenerator: '<S4>/Pulse Generator' */
  lss_online_DW.clockTickCounter_f = 0;

  /* Start for RateTransition generated from: '<S147>/Discrete Filter1' */
  lss_online_B.TmpRTBAtDiscreteFilter1Inport1 =
    lss_online_P.TmpRTBAtDiscreteFilter1Inport1_InitialCondition;

  /* Start for S-Function (simwbC_RTDBOut): '<Root>/VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_DriveSim_Inputs_Control_VICRT_UPSHIFT_REQ = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.Driver_Demands.str_swa' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_CarRealTime.Inputs.Driver_Demands.str_swa",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var VI_CarRealTime.Inputs.Driver_Demands.str_swa not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: VI_CarRealTime.Inputs.Driver_Demands.str_swa not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_CarRealTime.Inputs.Driver_Demands.str_swa datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: VI_CarRealTime.Inputs.Driver_Demands.str_swa datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_CarRealTime_Inputs_Driver_Demands_str_swa = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.steer_assist.torque' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_CarRealTime.Inputs.steer_assist.torque",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var VI_CarRealTime.Inputs.steer_assist.torque not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: VI_CarRealTime.Inputs.steer_assist.torque not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_CarRealTime.Inputs.steer_assist.torque datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: VI_CarRealTime.Inputs.steer_assist.torque datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_CarRealTime_Inputs_steer_assist_torque = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<Root>/VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_DriveSim_Inputs_Control_VICRT_DOWNSHIFT_REQ = &pCVT
      [pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_On' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LDW.LDW_On",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LDW.LDW_On not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_On not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LDW.LDW_On datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_On datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LDW_LDW_On = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_On_Left' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LDW.LDW_On_Left",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LDW.LDW_On_Left not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_On_Left not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LDW.LDW_On_Left datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_On_Left datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LDW_LDW_On_Left = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_On_Pulse' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LDW.LDW_On_Pulse",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LDW.LDW_On_Pulse not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_On_Pulse not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LDW.LDW_On_Pulse datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_On_Pulse datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LDW_LDW_On_Pulse = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_On_Right' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LDW.LDW_On_Right",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LDW.LDW_On_Right not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_On_Right not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LDW.LDW_On_Right datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_On_Right datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LDW_LDW_On_Right = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_Ready' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LDW.LDW_Ready",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LDW.LDW_Ready not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_Ready not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LDW.LDW_Ready datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_Ready datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LDW_LDW_Ready = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_Steering_Torque' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LDW.LDW_Steering_Torque",&pItem) <
        0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LDW.LDW_Steering_Torque not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_Steering_Torque not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LDW.LDW_Steering_Torque datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_Steering_Torque datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LDW_LDW_Steering_Torque = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LDW.LDW_White' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LDW.LDW_White",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LDW.LDW_White not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_White not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LDW.LDW_White datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LDW.LDW_White datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LDW_LDW_White = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_AEB_Sound' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LKA.LKA_AEB_Sound",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LKA.LKA_AEB_Sound not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_AEB_Sound not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LKA.LKA_AEB_Sound datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_AEB_Sound datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LKA_LKA_AEB_Sound = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_On_Display' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LKA.LKA_On_Display",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LKA.LKA_On_Display not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_On_Display not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LKA.LKA_On_Display datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_On_Display datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LKA_LKA_On_Display = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_On_Left' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LKA.LKA_On_Left",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LKA.LKA_On_Left not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_On_Left not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LKA.LKA_On_Left datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_On_Left datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LKA_LKA_On_Left = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_On_Pulse' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LKA.LKA_On_Pulse",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LKA.LKA_On_Pulse not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_On_Pulse not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LKA.LKA_On_Pulse datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_On_Pulse datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LKA_LKA_On_Pulse = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_On_Right' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LKA.LKA_On_Right",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LKA.LKA_On_Right not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_On_Right not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LKA.LKA_On_Right datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_On_Right datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LKA_LKA_On_Right = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_Ready' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LKA.LKA_Ready",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LKA.LKA_Ready not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_Ready not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LKA.LKA_Ready datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_Ready datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LKA_LKA_Ready = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_Steer_Angle' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LKA.LKA_Steer_Angle",&pItem) < 0)
    {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LKA.LKA_Steer_Angle not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_Steer_Angle not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LKA.LKA_Steer_Angle datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_Steer_Angle datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LKA_LKA_Steer_Angle = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S1>/ADAS.Outputs.LKA.LKA_Steer_Mode' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("ADAS.Outputs.LKA.LKA_Steer_Mode",&pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var ADAS.Outputs.LKA.LKA_Steer_Mode not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_Steer_Mode not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var ADAS.Outputs.LKA.LKA_Steer_Mode datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: ADAS.Outputs.LKA.LKA_Steer_Mode datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pADAS_Outputs_LKA_LKA_Steer_Mode = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S6>/VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_DriveSim_Inputs_Control_VICRT_RESTART_REQ = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (simwbC_RTDBOut): '<S6>/VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ' */
#ifdef GENSIMWBCODE

  {
    RTDBItem *pItem;
    if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ",
         &pItem) < 0) {
      fprintf(stderr,
              "MDL: string input var VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ not found!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ not found !");
      ccurSched_initFailed();
      exit(1);
    }

#if 0

    if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
      fprintf(stderr,
              "MDL: var VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ datatype in model is inconsistent with RTDB.!\n");
      ccurLog_printf(defaultLogger,LOG_CRITICAL,
                     "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ datatype inconsistent with RTDB !");
      ccurSched_initFailed();
      exit(1);
    }

#endif

    pVI_DriveSim_Inputs_Control_VICRT_RESTORE_REQ = &pCVT[pItem->meta.cvtOffset];
  }

#endif

  /* Start for S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S139>/VI_WorldSim_Sensor_VirtualCamera' */
  /* Level2 S-Function Block: '<S139>/VI_WorldSim_Sensor_VirtualCamera' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = lss_online_M->childSfunctions[0];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S139>/VI_WorldSim_Sensor_VirtualCamera1' */
  /* Level2 S-Function Block: '<S139>/VI_WorldSim_Sensor_VirtualCamera1' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = lss_online_M->childSfunctions[1];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (VI_WorldSim_State_Manager_mex): '<S139>/VI_WorldSim_State_Manager' */
  /* Level2 S-Function Block: '<S139>/VI_WorldSim_State_Manager' (VI_WorldSim_State_Manager_mex) */
  {
    SimStruct *rts = lss_online_M->childSfunctions[2];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  lss_online_PrevZCX.UD_Reset_ZCE = UNINITIALIZED_ZCSIG;
  lss_online_PrevZCX.derivation_speed_Trig_ZCE = UNINITIALIZED_ZCSIG;

  /* InitializeConditions for UnitDelay: '<S163>/Delay Input1' */
  lss_online_DW.DelayInput1_DSTATE = lss_online_P.DetectIncrease_vinit;

  /* InitializeConditions for Memory: '<S6>/Memory1' */
  lss_online_DW.Memory1_PreviousInput = lss_online_P.Memory1_InitialCondition;

  /* InitializeConditions for Memory: '<S6>/Memory' */
  lss_online_DW.Memory_PreviousInput_b = lss_online_P.Memory_InitialCondition_o;

  /* InitializeConditions for RateTransition: '<S4>/Rate Transition2' */
  lss_online_DW.RateTransition2_Buffer0[0] =
    lss_online_P.RateTransition2_InitialCondition;
  lss_online_DW.RateTransition2_Buffer0[1] =
    lss_online_P.RateTransition2_InitialCondition;

  /* InitializeConditions for RateTransition: '<S4>/Rate Transition1' */
  lss_online_DW.RateTransition1_Buffer0[0] =
    lss_online_P.RateTransition1_InitialCondition;
  lss_online_DW.RateTransition1_Buffer0[1] =
    lss_online_P.RateTransition1_InitialCondition;

  /* InitializeConditions for Memory: '<S4>/Memory2' */
  lss_online_DW.Memory2_PreviousInput = lss_online_P.Memory2_InitialCondition;

  /* InitializeConditions for RateTransition: '<S4>/Rate Transition5' */
  lss_online_DW.RateTransition5_Buffer0 =
    lss_online_P.RateTransition5_InitialCondition;

  /* InitializeConditions for Memory: '<S4>/Memory' */
  lss_online_DW.Memory_PreviousInput = lss_online_P.Memory_InitialCondition;

  /* InitializeConditions for RateLimiter: '<S8>/Rate Limiter1' */
  lss_online_DW.LastMajorTime = (rtInf);

  /* InitializeConditions for RateTransition generated from: '<S147>/Sum' */
  lss_online_DW.TmpRTBAtSumOutport1_Buffer0 =
    lss_online_P.TmpRTBAtSumOutport1_InitialCondition;

  /* InitializeConditions for DiscreteFilter: '<S147>/filtering' */
  lss_online_DW.filtering_states[0] = lss_online_P.filtering_InitialStates;
  lss_online_DW.filtering_states[1] = lss_online_P.filtering_InitialStates;

  /* InitializeConditions for DiscreteIntegrator: '<S45>/Integrator' */
  lss_online_DW.Integrator_DSTATE =
    lss_online_P.PIDController_InitialConditionForIntegrator;

  /* InitializeConditions for RateTransition: '<S4>/Rate Transition3' */
  lss_online_DW.RateTransition3_Buffer0 =
    lss_online_P.RateTransition3_InitialCondition;

  /* InitializeConditions for RateLimiter: '<S8>/Rate Limiter' */
  lss_online_DW.LastMajorTime_g = (rtInf);

  /* InitializeConditions for DiscreteFilter: '<S4>/Discrete Filter' */
  lss_online_DW.DiscreteFilter_states[0] =
    lss_online_P.DiscreteFilter_InitialStates;

  /* InitializeConditions for RateTransition: '<S3>/Rate Transition2' */
  lss_online_DW.RateTransition2_Buffer0_a[0] =
    lss_online_P.RateTransition2_InitialCondition_j;

  /* InitializeConditions for DiscreteFilter: '<S4>/Discrete Filter' */
  lss_online_DW.DiscreteFilter_states[1] =
    lss_online_P.DiscreteFilter_InitialStates;

  /* InitializeConditions for RateTransition: '<S3>/Rate Transition2' */
  lss_online_DW.RateTransition2_Buffer0_a[1] =
    lss_online_P.RateTransition2_InitialCondition_j;

  /* InitializeConditions for RateTransition: '<S3>/Rate Transition1' */
  lss_online_DW.RateTransition1_Buffer0_o[0] =
    lss_online_P.RateTransition1_InitialCondition_i;
  lss_online_DW.RateTransition1_Buffer0_o[1] =
    lss_online_P.RateTransition1_InitialCondition_i;

  /* InitializeConditions for Memory: '<S3>/Memory2' */
  lss_online_DW.Memory2_PreviousInput_b =
    lss_online_P.Memory2_InitialCondition_h;

  /* InitializeConditions for DiscreteFilter: '<S147>/Discrete Filter' */
  lss_online_DW.DiscreteFilter_states_m[0] =
    lss_online_P.DiscreteFilter_InitialStates_g;
  lss_online_DW.DiscreteFilter_states_m[1] =
    lss_online_P.DiscreteFilter_InitialStates_g;

  /* InitializeConditions for RateTransition generated from: '<S147>/Discrete Filter1' */
  lss_online_DW.TmpRTBAtDiscreteFilter1Inport1_Buffer0 =
    lss_online_P.TmpRTBAtDiscreteFilter1Inport1_InitialCondition;

  /* InitializeConditions for DiscreteFilter: '<S147>/Discrete Filter1' */
  lss_online_DW.DiscreteFilter1_states[0] =
    lss_online_P.DiscreteFilter1_InitialStates;

  /* InitializeConditions for UnitDelay: '<S69>/UD' */
  lss_online_DW.UD_DSTATE[0] =
    lss_online_P.DiscreteDerivative_ICPrevScaledInput_k;

  /* InitializeConditions for UnitDelay: '<S79>/UD' */
  lss_online_DW.UD_DSTATE_e[0] =
    lss_online_P.DiscreteDerivative_ICPrevScaledInput_i;

  /* InitializeConditions for DiscreteFilter: '<S147>/Discrete Filter1' */
  lss_online_DW.DiscreteFilter1_states[1] =
    lss_online_P.DiscreteFilter1_InitialStates;

  /* InitializeConditions for UnitDelay: '<S69>/UD' */
  lss_online_DW.UD_DSTATE[1] =
    lss_online_P.DiscreteDerivative_ICPrevScaledInput_k;

  /* InitializeConditions for UnitDelay: '<S79>/UD' */
  lss_online_DW.UD_DSTATE_e[1] =
    lss_online_P.DiscreteDerivative_ICPrevScaledInput_i;

  /* InitializeConditions for UnitDelay: '<S80>/UD' */
  lss_online_DW.UD_DSTATE_k = lss_online_P.DiscreteDerivative1_ICPrevScaledInput;

  /* InitializeConditions for UnitDelay: '<S81>/UD' */
  lss_online_DW.UD_DSTATE_o = lss_online_P.DiscreteDerivative2_ICPrevScaledInput;

  /* InitializeConditions for Delay: '<S113>/UD' */
  lss_online_DW.UD_DSTATE_g =
    lss_online_P.DiscretePIDController_DifferentiatorICPrevScaledInput;

  /* InitializeConditions for DiscreteIntegrator: '<S120>/Integrator' */
  lss_online_DW.Integrator_DSTATE_g =
    lss_online_P.DiscretePIDController_InitialConditionForIntegrator;
  lss_online_DW.Integrator_PrevResetState = 2;

  /* InitializeConditions for UnitDelay: '<S85>/Delay Input2' */
  lss_online_DW.DelayInput2_DSTATE = lss_online_P.DelayInput2_InitialCondition;

  /* InitializeConditions for RateLimiter: '<S4>/Rate Limiter' */
  lss_online_DW.PrevY_i = lss_online_P.RateLimiter_IC;

  /* SystemInitialize for Triggered SubSystem: '<S147>/derivation_speed' */
  lss_online_DW.derivation_speed_PREV_T[0] = lss_online_M->Timing.clockTick1;
  lss_online_DW.derivation_speed_PREV_T[1] = lss_online_M->Timing.clockTickH1;

  /* InitializeConditions for UnitDelay: '<S153>/UD' */
  lss_online_DW.UD_DSTATE_l = lss_online_P.DiscreteDerivative_ICPrevScaledInput;

  /* End of SystemInitialize for SubSystem: '<S147>/derivation_speed' */
}

/* Model terminate function */
static void lss_online_terminate(void)
{
  /* Terminate for S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S139>/VI_WorldSim_Sensor_VirtualCamera' */
  /* Level2 S-Function Block: '<S139>/VI_WorldSim_Sensor_VirtualCamera' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = lss_online_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S139>/VI_WorldSim_Sensor_VirtualCamera1' */
  /* Level2 S-Function Block: '<S139>/VI_WorldSim_Sensor_VirtualCamera1' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = lss_online_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (VI_WorldSim_State_Manager_mex): '<S139>/VI_WorldSim_State_Manager' */
  /* Level2 S-Function Block: '<S139>/VI_WorldSim_State_Manager' (VI_WorldSim_State_Manager_mex) */
  {
    SimStruct *rts = lss_online_M->childSfunctions[2];
    sfcnTerminate(rts);
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  if (tid == 1)
    tid = 0;
  lss_online_output(tid);
}

void MdlUpdate(int_T tid)
{
  if (tid == 1)
    tid = 0;
  lss_online_update(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  lss_online_initialize();
}

void MdlTerminate(void)
{
  lss_online_terminate();
}

/* Registration function */
RT_MODEL_lss_online_T *lss_online(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  lss_online_P.RateLimiter_FallingLim = rtMinusInf;

  /* initialize real-time model */
  (void) memset((void *)lss_online_M, 0,
                sizeof(RT_MODEL_lss_online_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&lss_online_M->solverInfo,
                          &lss_online_M->Timing.simTimeStep);
    rtsiSetTPtr(&lss_online_M->solverInfo, &rtmGetTPtr(lss_online_M));
    rtsiSetStepSizePtr(&lss_online_M->solverInfo,
                       &lss_online_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&lss_online_M->solverInfo, (&rtmGetErrorStatus
      (lss_online_M)));
    rtsiSetRTModelPtr(&lss_online_M->solverInfo, lss_online_M);
  }

  rtsiSetSimTimeStep(&lss_online_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&lss_online_M->solverInfo,"FixedStepDiscrete");
  lss_online_M->solverInfoPtr = (&lss_online_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = lss_online_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    mdlTsMap[2] = 2;
    mdlTsMap[3] = 3;

    /* polyspace +2 MISRA2012:D4.1 [Justified:Low] "lss_online_M points to
       static memory which is guaranteed to be non-NULL" */
    lss_online_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    lss_online_M->Timing.sampleTimes = (&lss_online_M->Timing.sampleTimesArray[0]);
    lss_online_M->Timing.offsetTimes = (&lss_online_M->Timing.offsetTimesArray[0]);

    /* task periods */
    lss_online_M->Timing.sampleTimes[0] = (0.0);
    lss_online_M->Timing.sampleTimes[1] = (0.001);
    lss_online_M->Timing.sampleTimes[2] = (0.01);
    lss_online_M->Timing.sampleTimes[3] = (0.02);

    /* task offsets */
    lss_online_M->Timing.offsetTimes[0] = (0.0);
    lss_online_M->Timing.offsetTimes[1] = (0.0);
    lss_online_M->Timing.offsetTimes[2] = (0.0);
    lss_online_M->Timing.offsetTimes[3] = (0.0);
  }

  rtmSetTPtr(lss_online_M, &lss_online_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = lss_online_M->Timing.sampleHitArray;
    int_T *mdlPerTaskSampleHits = lss_online_M->Timing.perTaskSampleHitsArray;
    lss_online_M->Timing.perTaskSampleHits = (&mdlPerTaskSampleHits[0]);
    mdlSampleHits[0] = 1;
    lss_online_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(lss_online_M, -1);
  lss_online_M->Timing.stepSize0 = 0.001;
  lss_online_M->Timing.stepSize1 = 0.001;
  lss_online_M->Timing.stepSize2 = 0.01;
  lss_online_M->Timing.stepSize3 = 0.02;
  lss_online_M->solverInfoPtr = (&lss_online_M->solverInfo);
  lss_online_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&lss_online_M->solverInfo, 0.001);
  rtsiSetSolverMode(&lss_online_M->solverInfo, SOLVER_MODE_MULTITASKING);

  /* block I/O */
  lss_online_M->blockIO = ((void *) &lss_online_B);
  (void) memset(((void *) &lss_online_B), 0,
                sizeof(B_lss_online_T));

  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      lss_online_B.lanecoefficients2x4[i] = 0.0;
    }

    for (i = 0; i < 610; i++) {
      lss_online_B.matrix_lanes_points[i] = 0.0;
    }

    for (i = 0; i < 100; i++) {
      lss_online_B.matrix_obstacles[i] = 0.0;
    }

    for (i = 0; i < 100; i++) {
      lss_online_B.matrix_objects[i] = 0.0;
    }

    for (i = 0; i < 8; i++) {
      lss_online_B.lanecoefficients2x4_l[i] = 0.0;
    }

    for (i = 0; i < 610; i++) {
      lss_online_B.matrix_lanes_points_f[i] = 0.0;
    }

    for (i = 0; i < 100; i++) {
      lss_online_B.matrix_obstacles_e[i] = 0.0;
    }

    for (i = 0; i < 100; i++) {
      lss_online_B.matrix_objects_a[i] = 0.0;
    }

    for (i = 0; i < 9; i++) {
      lss_online_B.VI_WorldSim_State_Manager_o4[i] = 0.0;
    }

    for (i = 0; i < 100; i++) {
      lss_online_B.sf_manipulation_of_objects1.filtered_matrix[i] = 0.0;
    }

    for (i = 0; i < 100; i++) {
      lss_online_B.sf_manipulation_of_objects.filtered_matrix[i] = 0.0;
    }

    lss_online_B.VI_DriveSimInputsECATBECKHANA3 = 0.0;
    lss_online_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal = 0.0;
    lss_online_B.VI_CarRealTimeOutputsdriver_demandssteering = 0.0;
    lss_online_B.VI_DriveSimInputsECATBECKHDIG4 = 0.0;
    lss_online_B.VI_DriveSimOutputsVicrtStatus = 0.0;
    lss_online_B.VI_DriveSimInputsECATBECKHANA1 = 0.0;
    lss_online_B.VI_CarRealTimeOutputsSteering_SystemDriveSim_Steering_Feedback_Torque
      = 0.0;
    lss_online_B.VI_CarRealTimeOutputsWheelSpindle_SteerL1 = 0.0;
    lss_online_B.VI_CarRealTimeOutputsWheelSpindle_SteerR1 = 0.0;
    lss_online_B.VI_CarRealTimeOutputschassis_accelerationslateral = 0.0;
    lss_online_B.VI_CarRealTimeOutputschassis_accelerationslongitudinal = 0.0;
    lss_online_B.VI_CarRealTimeOutputsdriver_demandsbrake = 0.0;
    lss_online_B.VI_CarRealTimeOutputsdriver_demandsthrottle = 0.0;
    lss_online_B.VI_DriveSimInputsECATBECKHDIG3 = 0.0;
    lss_online_B.VI_CarRealTimeOutputstransmissiongear = 0.0;
    lss_online_B.DataTypeConversion6 = 0.0;
    lss_online_B.Uk1 = 0.0;
    lss_online_B.RateTransition2[0] = 0.0;
    lss_online_B.RateTransition2[1] = 0.0;
    lss_online_B.RateTransition1[0] = 0.0;
    lss_online_B.RateTransition1[1] = 0.0;
    lss_online_B.Memory = 0.0;
    lss_online_B.LKA_on = 0.0;
    lss_online_B.RateLimiter1 = 0.0;
    lss_online_B.TmpRTBAtSumOutport1 = 0.0;
    lss_online_B.Sum = 0.0;
    lss_online_B.RateTransition3 = 0.0;
    lss_online_B.DiscreteFilter = 0.0;
    lss_online_B.RateLimiter = 0.0;
    lss_online_B.Add = 0.0;
    lss_online_B.RateTransition2_b[0] = 0.0;
    lss_online_B.RateTransition2_b[1] = 0.0;
    lss_online_B.RateTransition1_m[0] = 0.0;
    lss_online_B.RateTransition1_m[1] = 0.0;
    lss_online_B.DataTypeConversion = 0.0;
    lss_online_B.Product1 = 0.0;
    lss_online_B.DataTypeConversion4 = 0.0;
    lss_online_B.DataTypeConversion3[0] = 0.0;
    lss_online_B.DataTypeConversion3[1] = 0.0;
    lss_online_B.PulseGenerator = 0.0;
    lss_online_B.Product2 = 0.0;
    lss_online_B.DataTypeConversion2 = 0.0;
    lss_online_B.DataTypeConversion1 = 0.0;
    lss_online_B.Sum_c = 0.0;
    lss_online_B.DataTypeConversion3_h[0] = 0.0;
    lss_online_B.DataTypeConversion3_h[1] = 0.0;
    lss_online_B.PulseGenerator_j = 0.0;
    lss_online_B.Product2_f = 0.0;
    lss_online_B.DataTypeConversion2_o = 0.0;
    lss_online_B.TmpRTBAtDiscreteFilter1Inport1 = 0.0;
    lss_online_B.Product_f = 0.0;
    lss_online_B.Product1_i = 0.0;
    lss_online_B.messagecount[0] = 0.0;
    lss_online_B.messagecount[1] = 0.0;
    lss_online_B.valid_matrix_lanes_points = 0.0;
    lss_online_B.valid_matrix_obstacles = 0.0;
    lss_online_B.valid_matrix_objects = 0.0;
    lss_online_B.messagecount_m[0] = 0.0;
    lss_online_B.messagecount_m[1] = 0.0;
    lss_online_B.valid_matrix_lanes_points_f = 0.0;
    lss_online_B.valid_matrix_obstacles_d = 0.0;
    lss_online_B.valid_matrix_objects_o = 0.0;
    lss_online_B.collisionmsginfo[0] = 0.0;
    lss_online_B.collisionmsginfo[1] = 0.0;
    lss_online_B.VI_WorldSim_State_Manager_o2[0] = 0.0;
    lss_online_B.VI_WorldSim_State_Manager_o2[1] = 0.0;
    lss_online_B.VI_WorldSim_State_Manager_o2[2] = 0.0;
    lss_online_B.VI_WorldSim_State_Manager_o3 = 0.0;
    lss_online_B.TSamp[0] = 0.0;
    lss_online_B.TSamp[1] = 0.0;
    lss_online_B.TSamp_h[0] = 0.0;
    lss_online_B.TSamp_h[1] = 0.0;
    lss_online_B.TSamp_m = 0.0;
    lss_online_B.TSamp_g = 0.0;
    lss_online_B.Tsamp = 0.0;
    lss_online_B.RateTransition4 = 0.0;
    lss_online_B.IProdOut = 0.0;
    lss_online_B.DifferenceInputs2 = 0.0;
    lss_online_B.Gain = 0.0;
    lss_online_B.IntegralGain = 0.0;
  }

  /* parameters */
  lss_online_M->defaultParam = ((real_T *)&lss_online_P);

  /* states (dwork) */
  lss_online_M->dwork = ((void *) &lss_online_DW);
  (void) memset((void *)&lss_online_DW, 0,
                sizeof(DW_lss_online_T));
  lss_online_DW.DelayInput1_DSTATE = 0.0;
  lss_online_DW.filtering_states[0] = 0.0;
  lss_online_DW.filtering_states[1] = 0.0;
  lss_online_DW.Integrator_DSTATE = 0.0;
  lss_online_DW.DiscreteFilter_states[0] = 0.0;
  lss_online_DW.DiscreteFilter_states[1] = 0.0;
  lss_online_DW.DiscreteFilter_states_m[0] = 0.0;
  lss_online_DW.DiscreteFilter_states_m[1] = 0.0;
  lss_online_DW.DiscreteFilter1_states[0] = 0.0;
  lss_online_DW.DiscreteFilter1_states[1] = 0.0;
  lss_online_DW.UD_DSTATE[0] = 0.0;
  lss_online_DW.UD_DSTATE[1] = 0.0;
  lss_online_DW.UD_DSTATE_e[0] = 0.0;
  lss_online_DW.UD_DSTATE_e[1] = 0.0;
  lss_online_DW.UD_DSTATE_k = 0.0;
  lss_online_DW.UD_DSTATE_o = 0.0;
  lss_online_DW.UD_DSTATE_g = 0.0;
  lss_online_DW.Integrator_DSTATE_g = 0.0;
  lss_online_DW.DelayInput2_DSTATE = 0.0;
  lss_online_DW.UD_DSTATE_l = 0.0;
  lss_online_DW.RateTransition2_Buffer0[0] = 0.0;
  lss_online_DW.RateTransition2_Buffer0[1] = 0.0;
  lss_online_DW.RateTransition1_Buffer0[0] = 0.0;
  lss_online_DW.RateTransition1_Buffer0[1] = 0.0;
  lss_online_DW.Memory2_PreviousInput = 0.0;
  lss_online_DW.Memory_PreviousInput = 0.0;
  lss_online_DW.PrevY = 0.0;
  lss_online_DW.LastMajorTime = 0.0;
  lss_online_DW.TmpRTBAtSumOutport1_Buffer0 = 0.0;
  lss_online_DW.filtering_tmp = 0.0;
  lss_online_DW.RateTransition3_Buffer0 = 0.0;
  lss_online_DW.DiscreteFilter_tmp = 0.0;
  lss_online_DW.PrevY_b = 0.0;
  lss_online_DW.LastMajorTime_g = 0.0;
  lss_online_DW.RateTransition2_Buffer0_a[0] = 0.0;
  lss_online_DW.RateTransition2_Buffer0_a[1] = 0.0;
  lss_online_DW.RateTransition1_Buffer0_o[0] = 0.0;
  lss_online_DW.RateTransition1_Buffer0_o[1] = 0.0;
  lss_online_DW.Memory2_PreviousInput_b = 0.0;
  lss_online_DW.DiscreteFilter_tmp_g = 0.0;
  lss_online_DW.TmpRTBAtDiscreteFilter1Inport1_Buffer0 = 0.0;
  lss_online_DW.DiscreteFilter1_tmp = 0.0;
  lss_online_DW.RateTransition_Buffer[0] = 0.0;
  lss_online_DW.RateTransition_Buffer[1] = 0.0;
  lss_online_DW.RateTransition_Buffer_g[0] = 0.0;
  lss_online_DW.RateTransition_Buffer_g[1] = 0.0;
  lss_online_DW.RateTransition4_Buffer = 0.0;
  lss_online_DW.RateTransition6_Buffer = 0.0;
  lss_online_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK2 = 0.0;
  lss_online_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK3 = 0.0;
  lss_online_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK4 = 0.0;
  lss_online_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK2 = 0.0;
  lss_online_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK3 = 0.0;
  lss_online_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK4 = 0.0;
  lss_online_DW.VI_WorldSim_State_Manager_DWORK2 = 0.0;
  lss_online_DW.VI_WorldSim_State_Manager_DWORK3 = 0.0;
  lss_online_DW.VI_WorldSim_State_Manager_DWORK4 = 0.0;
  lss_online_DW.PrevY_i = 0.0;

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  lss_online_InitializeDataMapInfo();

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &lss_online_M->NonInlinedSFcns.sfcnInfo;
    lss_online_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(lss_online_M)));
    lss_online_M->Sizes.numSampTimes = (4);
    rtssSetNumRootSampTimesPtr(sfcnInfo, &lss_online_M->Sizes.numSampTimes);
    lss_online_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr(lss_online_M)[0]);
    lss_online_M->NonInlinedSFcns.taskTimePtrs[1] = &(rtmGetTPtr(lss_online_M)[1]);
    lss_online_M->NonInlinedSFcns.taskTimePtrs[2] = &(rtmGetTPtr(lss_online_M)[2]);
    lss_online_M->NonInlinedSFcns.taskTimePtrs[3] = &(rtmGetTPtr(lss_online_M)[3]);
    rtssSetTPtrPtr(sfcnInfo,lss_online_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(lss_online_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(lss_online_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput(lss_online_M));
    rtssSetStepSizePtr(sfcnInfo, &lss_online_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(lss_online_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo, &lss_online_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo, &lss_online_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &lss_online_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo, &lss_online_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &lss_online_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &lss_online_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &lss_online_M->solverInfoPtr);
  }

  lss_online_M->Sizes.numSFcns = (3);

  /* register each child */
  {
    (void) memset((void *)&lss_online_M->NonInlinedSFcns.childSFunctions[0], 0,
                  3*sizeof(SimStruct));
    lss_online_M->childSfunctions =
      (&lss_online_M->NonInlinedSFcns.childSFunctionPtrs[0]);
    lss_online_M->childSfunctions[0] =
      (&lss_online_M->NonInlinedSFcns.childSFunctions[0]);
    lss_online_M->childSfunctions[1] =
      (&lss_online_M->NonInlinedSFcns.childSFunctions[1]);
    lss_online_M->childSfunctions[2] =
      (&lss_online_M->NonInlinedSFcns.childSFunctions[2]);

    /* Level2 S-Function Block: lss_online/<S139>/VI_WorldSim_Sensor_VirtualCamera (VI_WorldSim_Sensor_VirtualCamera_mex) */
    {
      SimStruct *rts = lss_online_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = lss_online_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = lss_online_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = lss_online_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &lss_online_M->NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &lss_online_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, lss_online_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &lss_online_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &lss_online_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &lss_online_M->NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &lss_online_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &lss_online_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &lss_online_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        ssSetPortInfoForOutputs(rts,
          &lss_online_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 8);
        _ssSetPortInfo2ForOutputUnits(rts,
          &lss_online_M->NonInlinedSFcns.Sfcn0.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        ssSetOutputPortUnit(rts, 5, 0);
        ssSetOutputPortUnit(rts, 6, 0);
        ssSetOutputPortUnit(rts, 7, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &lss_online_M->NonInlinedSFcns.Sfcn0.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 5, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 6, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 7, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((real_T *) lss_online_B.messagecount));
        }

        /* port 1 */
        {
          int_T *dimensions = (int_T *)
            &lss_online_M->NonInlinedSFcns.Sfcn0.oDims1;
          dimensions[0] = 2;
          dimensions[1] = 4;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 1, dimensions);
          _ssSetOutputPortNumDimensions(rts, 1, 2);
          ssSetOutputPortWidthAsInt(rts, 1, 8);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            lss_online_B.lanecoefficients2x4));
        }

        /* port 2 */
        {
          int_T *dimensions = (int_T *)
            &lss_online_M->NonInlinedSFcns.Sfcn0.oDims2;
          dimensions[0] = 10;
          dimensions[1] = 61;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 2, dimensions);
          _ssSetOutputPortNumDimensions(rts, 2, 2);
          ssSetOutputPortWidthAsInt(rts, 2, 610);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            lss_online_B.matrix_lanes_points));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidthAsInt(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((real_T *)
            &lss_online_B.valid_matrix_lanes_points));
        }

        /* port 4 */
        {
          int_T *dimensions = (int_T *)
            &lss_online_M->NonInlinedSFcns.Sfcn0.oDims4;
          dimensions[0] = 10;
          dimensions[1] = 10;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 4, dimensions);
          _ssSetOutputPortNumDimensions(rts, 4, 2);
          ssSetOutputPortWidthAsInt(rts, 4, 100);
          ssSetOutputPortSignal(rts, 4, ((real_T *)
            lss_online_B.matrix_obstacles));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidthAsInt(rts, 5, 1);
          ssSetOutputPortSignal(rts, 5, ((real_T *)
            &lss_online_B.valid_matrix_obstacles));
        }

        /* port 6 */
        {
          int_T *dimensions = (int_T *)
            &lss_online_M->NonInlinedSFcns.Sfcn0.oDims6;
          dimensions[0] = 10;
          dimensions[1] = 10;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 6, dimensions);
          _ssSetOutputPortNumDimensions(rts, 6, 2);
          ssSetOutputPortWidthAsInt(rts, 6, 100);
          ssSetOutputPortSignal(rts, 6, ((real_T *) lss_online_B.matrix_objects));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidthAsInt(rts, 7, 1);
          ssSetOutputPortSignal(rts, 7, ((real_T *)
            &lss_online_B.valid_matrix_objects));
        }
      }

      /* path info */
      ssSetModelName(rts, "VI_WorldSim_Sensor_VirtualCamera");
      ssSetPath(rts,
                "lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera");
      ssSetRTModel(rts,lss_online_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &lss_online_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P7_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &lss_online_DW.VI_WorldSim_Sensor_VirtualCamera_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &lss_online_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &lss_online_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 5);

        /* DWORK1 */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &lss_online_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK1);

        /* DWORK2 */
        ssSetDWorkWidthAsInt(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1,
                   &lss_online_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK2);

        /* DWORK3 */
        ssSetDWorkWidthAsInt(rts, 2, 1);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2,
                   &lss_online_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK3);

        /* DWORK4 */
        ssSetDWorkWidthAsInt(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3,
                   &lss_online_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK4);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &lss_online_DW.VI_WorldSim_Sensor_VirtualCamera_PWORK);
      }

      /* registration */
      VI_WorldSim_Sensor_VirtualCamera_mex(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 0);
      _ssSetOutputPortConnected(rts, 3, 0);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 0);
      _ssSetOutputPortConnected(rts, 7, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: lss_online/<S139>/VI_WorldSim_Sensor_VirtualCamera1 (VI_WorldSim_Sensor_VirtualCamera_mex) */
    {
      SimStruct *rts = lss_online_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod = lss_online_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset = lss_online_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = lss_online_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &lss_online_M->NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &lss_online_M->NonInlinedSFcns.inputOutputPortInfo2[1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, lss_online_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &lss_online_M->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &lss_online_M->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &lss_online_M->NonInlinedSFcns.methods4[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &lss_online_M->NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &lss_online_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &lss_online_M->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        ssSetPortInfoForOutputs(rts,
          &lss_online_M->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 8);
        _ssSetPortInfo2ForOutputUnits(rts,
          &lss_online_M->NonInlinedSFcns.Sfcn1.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        ssSetOutputPortUnit(rts, 5, 0);
        ssSetOutputPortUnit(rts, 6, 0);
        ssSetOutputPortUnit(rts, 7, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &lss_online_M->NonInlinedSFcns.Sfcn1.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 5, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 6, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 7, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((real_T *) lss_online_B.messagecount_m));
        }

        /* port 1 */
        {
          int_T *dimensions = (int_T *)
            &lss_online_M->NonInlinedSFcns.Sfcn1.oDims1;
          dimensions[0] = 2;
          dimensions[1] = 4;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 1, dimensions);
          _ssSetOutputPortNumDimensions(rts, 1, 2);
          ssSetOutputPortWidthAsInt(rts, 1, 8);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            lss_online_B.lanecoefficients2x4_l));
        }

        /* port 2 */
        {
          int_T *dimensions = (int_T *)
            &lss_online_M->NonInlinedSFcns.Sfcn1.oDims2;
          dimensions[0] = 10;
          dimensions[1] = 61;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 2, dimensions);
          _ssSetOutputPortNumDimensions(rts, 2, 2);
          ssSetOutputPortWidthAsInt(rts, 2, 610);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            lss_online_B.matrix_lanes_points_f));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidthAsInt(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((real_T *)
            &lss_online_B.valid_matrix_lanes_points_f));
        }

        /* port 4 */
        {
          int_T *dimensions = (int_T *)
            &lss_online_M->NonInlinedSFcns.Sfcn1.oDims4;
          dimensions[0] = 10;
          dimensions[1] = 10;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 4, dimensions);
          _ssSetOutputPortNumDimensions(rts, 4, 2);
          ssSetOutputPortWidthAsInt(rts, 4, 100);
          ssSetOutputPortSignal(rts, 4, ((real_T *)
            lss_online_B.matrix_obstacles_e));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidthAsInt(rts, 5, 1);
          ssSetOutputPortSignal(rts, 5, ((real_T *)
            &lss_online_B.valid_matrix_obstacles_d));
        }

        /* port 6 */
        {
          int_T *dimensions = (int_T *)
            &lss_online_M->NonInlinedSFcns.Sfcn1.oDims6;
          dimensions[0] = 10;
          dimensions[1] = 10;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 6, dimensions);
          _ssSetOutputPortNumDimensions(rts, 6, 2);
          ssSetOutputPortWidthAsInt(rts, 6, 100);
          ssSetOutputPortSignal(rts, 6, ((real_T *)
            lss_online_B.matrix_objects_a));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidthAsInt(rts, 7, 1);
          ssSetOutputPortSignal(rts, 7, ((real_T *)
            &lss_online_B.valid_matrix_objects_o));
        }
      }

      /* path info */
      ssSetModelName(rts, "VI_WorldSim_Sensor_VirtualCamera1");
      ssSetPath(rts,
                "lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1");
      ssSetRTModel(rts,lss_online_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &lss_online_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P7_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &lss_online_DW.VI_WorldSim_Sensor_VirtualCamera1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &lss_online_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &lss_online_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 5);

        /* DWORK1 */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &lss_online_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK1);

        /* DWORK2 */
        ssSetDWorkWidthAsInt(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1,
                   &lss_online_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK2);

        /* DWORK3 */
        ssSetDWorkWidthAsInt(rts, 2, 1);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2,
                   &lss_online_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK3);

        /* DWORK4 */
        ssSetDWorkWidthAsInt(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3,
                   &lss_online_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK4);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4,
                   &lss_online_DW.VI_WorldSim_Sensor_VirtualCamera1_PWORK);
      }

      /* registration */
      VI_WorldSim_Sensor_VirtualCamera_mex(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 0);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 0);
      _ssSetOutputPortConnected(rts, 3, 0);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 0);
      _ssSetOutputPortConnected(rts, 7, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: lss_online/<S139>/VI_WorldSim_State_Manager (VI_WorldSim_State_Manager_mex) */
    {
      SimStruct *rts = lss_online_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod = lss_online_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset = lss_online_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = lss_online_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &lss_online_M->NonInlinedSFcns.blkInfo2[2]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &lss_online_M->NonInlinedSFcns.inputOutputPortInfo2[2]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, lss_online_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &lss_online_M->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &lss_online_M->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &lss_online_M->NonInlinedSFcns.methods4[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &lss_online_M->NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &lss_online_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &lss_online_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        ssSetPortInfoForOutputs(rts,
          &lss_online_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 4);
        _ssSetPortInfo2ForOutputUnits(rts,
          &lss_online_M->NonInlinedSFcns.Sfcn2.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &lss_online_M->NonInlinedSFcns.Sfcn2.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            lss_online_B.collisionmsginfo));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 3);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            lss_online_B.VI_WorldSim_State_Manager_o2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidthAsInt(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            &lss_online_B.VI_WorldSim_State_Manager_o3));
        }

        /* port 3 */
        {
          int_T *dimensions = (int_T *)
            &lss_online_M->NonInlinedSFcns.Sfcn2.oDims3;
          dimensions[0] = 3;
          dimensions[1] = 3;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 3, dimensions);
          _ssSetOutputPortNumDimensions(rts, 3, 2);
          ssSetOutputPortWidthAsInt(rts, 3, 9);
          ssSetOutputPortSignal(rts, 3, ((real_T *)
            lss_online_B.VI_WorldSim_State_Manager_o4));
        }
      }

      /* path info */
      ssSetModelName(rts, "VI_WorldSim_State_Manager");
      ssSetPath(rts,
                "lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_State_Manager");
      ssSetRTModel(rts,lss_online_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &lss_online_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 4);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       lss_online_P.VI_WorldSim_State_Manager_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       lss_online_P.VI_WorldSim_State_Manager_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       lss_online_P.VI_WorldSim_State_Manager_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       lss_online_P.VI_WorldSim_State_Manager_P4_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &lss_online_DW.VI_WorldSim_State_Manager_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &lss_online_M->NonInlinedSFcns.Sfcn2.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &lss_online_M->NonInlinedSFcns.Sfcn2.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 5);

        /* DWORK1 */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &lss_online_DW.VI_WorldSim_State_Manager_DWORK1);

        /* DWORK2 */
        ssSetDWorkWidthAsInt(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &lss_online_DW.VI_WorldSim_State_Manager_DWORK2);

        /* DWORK3 */
        ssSetDWorkWidthAsInt(rts, 2, 1);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &lss_online_DW.VI_WorldSim_State_Manager_DWORK3);

        /* DWORK4 */
        ssSetDWorkWidthAsInt(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &lss_online_DW.VI_WorldSim_State_Manager_DWORK4);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &lss_online_DW.VI_WorldSim_State_Manager_PWORK);
      }

      /* registration */
      VI_WorldSim_State_Manager_mex(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 0);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);

      /* Update the BufferDstPort flags for each input port */
    }
  }

  /* Initialize Sizes */
  lss_online_M->Sizes.numContStates = (0);/* Number of continuous states */
  lss_online_M->Sizes.numY = (0);      /* Number of model outputs */
  lss_online_M->Sizes.numU = (0);      /* Number of model inputs */
  lss_online_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  lss_online_M->Sizes.numSampTimes = (4);/* Number of sample times */
  lss_online_M->Sizes.numBlocks = (268);/* Number of blocks */
  lss_online_M->Sizes.numBlockIO = (96);/* Number of block outputs */
  lss_online_M->Sizes.numBlockPrms = (699);/* Sum of parameter "widths" */
  return lss_online_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
