/*
 * lss_online_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "lss_online".
 *
 * Model version              : 17.27
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Fri Feb  2 00:03:37 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "lss_online.h"

/* Block parameters (default storage) */
P_lss_online_T lss_online_P = {
  /* Variable: ADAS_Control_Mode
   * Referenced by:
   *   '<S70>/ADAS_Control_Mode'
   *   '<S82>/ADAS_Control_Mode'
   *   '<S83>/ADAS_Control_Mode'
   */
  1.0,

  /* Variable: AP_Transition_Rate
   * Referenced by: '<S8>/Rate Limiter1'
   */
  0.8,

  /* Variable: LDW_Activity_Flag
   * Referenced by: '<S3>/LDW_Activity_Flag'
   */
  1.0,

  /* Variable: LDW_LaneGap_Warning
   * Referenced by:
   *   '<S70>/LDW_LaneGap_Warning'
   *   '<S70>/LDW_LaneGap_Warning1'
   */
  { 0.5, 0.25 },

  /* Variable: LDW_LaneGap_dydt_Warning
   * Referenced by: '<S67>/Constant'
   */
  50.0,

  /* Variable: LDW_Min_Speed
   * Referenced by: '<S68>/Constant'
   */
  60.0,

  /* Variable: LDW_Steer_Vibration_Amplitude
   * Referenced by: '<S3>/LDW_Steer_Vibration'
   */
  5.0,

  /* Variable: LDW_Steer_Vibration_Freq
   * Referenced by: '<S3>/LDW_Steer_Vibration'
   */
  25.0,

  /* Variable: LKA_Activity_Flag
   * Referenced by: '<S4>/LKA_Activity_Flag'
   */
  1.0,

  /* Variable: LKA_D
   * Referenced by:
   *   '<S82>/LKA_D(1)'
   *   '<S82>/LKA_D(1)1'
   */
  { 0.2, 0.3 },

  /* Variable: LKA_Dyn_Rate_Limiter_Gain
   * Referenced by: '<S4>/LKA_Dyn_Rate_Limiter_Gain'
   */
  0.1,

  /* Variable: LKA_Dyn_Rate_Limiter_Power
   * Referenced by: '<S4>/LKA_Dyn_Rate_Limiter_Power'
   */
  10.0,

  /* Variable: LKA_Error_Max
   * Referenced by: '<S4>/Saturation'
   */
  3.0,

  /* Variable: LKA_Error_Off
   * Referenced by: '<S73>/Constant'
   */
  0.5,

  /* Variable: LKA_Error_dydt_Off
   * Referenced by: '<S71>/Constant'
   */
  1.0,

  /* Variable: LKA_I
   * Referenced by:
   *   '<S82>/LKA_I(1)'
   *   '<S82>/LKA_I(1)1'
   */
  { 0.025, 0.05 },

  /* Variable: LKA_Lane_Gap_Activate
   * Referenced by:
   *   '<S83>/LKA_Lane_Gap_Activate'
   *   '<S83>/LKA_Lane_Gap_Activate2'
   */
  { -0.05, 0.125 },

  /* Variable: LKA_Lane_Gap_dydt_Activate
   * Referenced by: '<S76>/Constant'
   */
  50.0,

  /* Variable: LKA_Min_Speed
   * Referenced by: '<S77>/Constant'
   */
  50.0,

  /* Variable: LKA_P
   * Referenced by:
   *   '<S82>/LKA_P(1)'
   *   '<S82>/LKA_P(1)1'
   */
  { 0.1, 0.2 },

  /* Variable: LKA_Steer_Rate_Max_radps
   * Referenced by: '<S4>/Rate Limiter'
   */
  1.0,

  /* Variable: index_variant_approaching_speed
   * Referenced by: '<S8>/prescribed_approaching_speed'
   */
  3.0,

  /* Variable: variant_approaching_speed
   * Referenced by: '<S8>/prescribed_approaching_speed'
   */
  { 0.2, 0.3, 0.4, 0.5, 0.6 },

  /* Variable: vehicle_width
   * Referenced by: '<S143>/Semitrack'
   */
  2.05,

  /* Mask Parameter: DiscretePIDController_DifferentiatorICPrevScaledInput
   * Referenced by: '<S113>/UD'
   */
  0.0,

  /* Mask Parameter: PIDController_I
   * Referenced by: '<S42>/Integral Gain'
   */
  -0.002,

  /* Mask Parameter: DiscreteDerivative_ICPrevScaledInput
   * Referenced by: '<S153>/UD'
   */
  0.0,

  /* Mask Parameter: DiscreteDerivative_ICPrevScaledInput_k
   * Referenced by: '<S69>/UD'
   */
  0.0,

  /* Mask Parameter: DiscreteDerivative_ICPrevScaledInput_i
   * Referenced by: '<S79>/UD'
   */
  0.0,

  /* Mask Parameter: DiscreteDerivative1_ICPrevScaledInput
   * Referenced by: '<S80>/UD'
   */
  0.0,

  /* Mask Parameter: DiscreteDerivative2_ICPrevScaledInput
   * Referenced by: '<S81>/UD'
   */
  0.0,

  /* Mask Parameter: PIDController_InitialConditionForIntegrator
   * Referenced by: '<S45>/Integrator'
   */
  0.0,

  /* Mask Parameter: DiscretePIDController_InitialConditionForIntegrator
   * Referenced by: '<S120>/Integrator'
   */
  0.0,

  /* Mask Parameter: PIDController_P
   * Referenced by: '<S50>/Proportional Gain'
   */
  0.4,

  /* Mask Parameter: shift_paddle_threshold1_const
   * Referenced by: '<S167>/Constant'
   */
  0.5,

  /* Mask Parameter: gear_change_max_speed_up_const
   * Referenced by: '<S165>/Constant'
   */
  5.0,

  /* Mask Parameter: CompareToConstant1_const
   * Referenced by: '<S72>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant3_const
   * Referenced by: '<S74>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant4_const
   * Referenced by: '<S75>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant_const
   * Referenced by: '<S9>/Constant'
   */
  1.5,

  /* Mask Parameter: CompareToConstant1_const_h
   * Referenced by: '<S10>/Constant'
   */
  0.0,

  /* Mask Parameter: CompareToConstant1_const_o
   * Referenced by: '<S62>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant4_const_h
   * Referenced by: '<S65>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant3_const_l
   * Referenced by: '<S64>/Constant'
   */
  1.0,

  /* Mask Parameter: shift_paddle_threshold_const
   * Referenced by: '<S166>/Constant'
   */
  0.5,

  /* Mask Parameter: gear_change_max_speed_down_const
   * Referenced by: '<S164>/Constant'
   */
  5.0,

  /* Mask Parameter: CompareToConstant_const_i
   * Referenced by: '<S160>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant1_const_a
   * Referenced by: '<S161>/Constant'
   */
  1.0,

  /* Mask Parameter: DetectIncrease_vinit
   * Referenced by: '<S163>/Delay Input1'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S4>/Gain'
   */
  -1.0,

  /* Computed Parameter: TSamp_WtEt
   * Referenced by: '<S153>/TSamp'
   */
  1.0,

  /* Expression: -1
   * Referenced by: '<S152>/Gain'
   */
  -1.0,

  /* Expression: 0
   * Referenced by: '<S66>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S78>/Constant'
   */
  0.0,

  /* Expression: -1.5
   * Referenced by: '<S8>/Neg_driver_str_gain'
   */
  -1.5,

  /* Expression: 1
   * Referenced by: '<S8>/Constant2'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S4>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S4>/Rate Transition2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S4>/Rate Transition1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S4>/Memory2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S4>/Memory'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S4>/Switch1'
   */
  0.0,

  /* Expression: 0
   * Referenced by:
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S147>/Pulse Generator'
   */
  1.0,

  /* Computed Parameter: PulseGenerator_Period
   * Referenced by: '<S147>/Pulse Generator'
   */
  20.0,

  /* Computed Parameter: PulseGenerator_Duty
   * Referenced by: '<S147>/Pulse Generator'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S147>/Pulse Generator'
   */
  0.0,

  /* Expression: [butter_b]
   * Referenced by: '<S147>/filtering'
   */
  { 9.825916820482009E-6, 1.9651833640964018E-5, 9.825916820482009E-6 },

  /* Expression: [butter_a]
   * Referenced by: '<S147>/filtering'
   */
  { 1.0, -1.9911142922016536, 0.99115359586893548 },

  /* Expression: 0
   * Referenced by: '<S147>/filtering'
   */
  0.0,

  /* Computed Parameter: Integrator_gainval
   * Referenced by: '<S45>/Integrator'
   */
  0.001,

  /* Expression: 0
   * Referenced by: '<S4>/Rate Transition3'
   */
  0.0,

  /* Expression: [butter_b_lka_out]
   * Referenced by: '<S4>/Discrete Filter'
   */
  { 0.020083365564211246, 0.040166731128422492, 0.020083365564211246 },

  /* Expression: [butter_a_lka_out]
   * Referenced by: '<S4>/Discrete Filter'
   */
  { 1.0, -1.5610180758007179, 0.641351538057563 },

  /* Expression: 0
   * Referenced by: '<S4>/Discrete Filter'
   */
  0.0,

  /* Expression: 0.75
   * Referenced by: '<S8>/Rate Limiter'
   */
  0.75,

  /* Expression: -inf
   * Referenced by: '<S8>/Rate Limiter'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S3>/LDW_Steer_Vibration'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S3>/LDW_Steer_Vibration'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S3>/Rate Transition2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S3>/Rate Transition1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S3>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S3>/Memory2'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S3>/Pulse Generator'
   */
  1.0,

  /* Computed Parameter: PulseGenerator_Period_c
   * Referenced by: '<S3>/Pulse Generator'
   */
  200.0,

  /* Computed Parameter: PulseGenerator_Duty_c
   * Referenced by: '<S3>/Pulse Generator'
   */
  100.0,

  /* Expression: 0
   * Referenced by: '<S3>/Pulse Generator'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S4>/Pulse Generator'
   */
  1.0,

  /* Computed Parameter: PulseGenerator_Period_o
   * Referenced by: '<S4>/Pulse Generator'
   */
  200.0,

  /* Computed Parameter: PulseGenerator_Duty_h
   * Referenced by: '<S4>/Pulse Generator'
   */
  100.0,

  /* Expression: 0
   * Referenced by: '<S4>/Pulse Generator'
   */
  0.0,

  /* Expression: [butter_b]
   * Referenced by: '<S147>/Discrete Filter'
   */
  { 9.825916820482009E-6, 1.9651833640964018E-5, 9.825916820482009E-6 },

  /* Expression: [butter_a]
   * Referenced by: '<S147>/Discrete Filter'
   */
  { 1.0, -1.9911142922016536, 0.99115359586893548 },

  /* Expression: 0
   * Referenced by: '<S147>/Discrete Filter'
   */
  0.0,

  /* Expression: 0
   * Referenced by:
   */
  0.0,

  /* Expression: [butter_b]
   * Referenced by: '<S147>/Discrete Filter1'
   */
  { 9.825916820482009E-6, 1.9651833640964018E-5, 9.825916820482009E-6 },

  /* Expression: [butter_a]
   * Referenced by: '<S147>/Discrete Filter1'
   */
  { 1.0, -1.9911142922016536, 0.99115359586893548 },

  /* Expression: 0
   * Referenced by: '<S147>/Discrete Filter1'
   */
  0.0,

  /* Expression: zeros(64,7)
   * Referenced by: '<S139>/Constant'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P1_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 9.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P1
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 49.0, 50.0, 55.0, 46.0, 48.0, 46.0, 48.0, 46.0, 49.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P2_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 1.0 },

  /* Expression: worldsim_endpoint_port
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  8080.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P3_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 3.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P3
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 101.0, 103.0, 111.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P4_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 16.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P4
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 70.0, 114.0, 111.0, 110.0, 116.0, 95.0, 86.0, 105.0, 114.0, 116.0, 117.0,
    97.0, 108.0, 67.0, 97.0, 109.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P5_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 1.0 },

  /* Expression: max_lanes
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  10.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P6_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 1.0 },

  /* Expression: max_obstacles
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  10.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P7_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 1.0 },

  /* Expression: worldsim_verbose
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera'
   */
  0.0,

  /* Expression: 0.5
   * Referenced by: '<S149>/Gain'
   */
  0.5,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P1_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 9.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P1
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 49.0, 50.0, 55.0, 46.0, 48.0, 46.0, 48.0, 46.0, 49.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P2_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 1.0 },

  /* Expression: worldsim_endpoint_port
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  8080.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P3_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 3.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P3
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 101.0, 103.0, 111.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P4_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 15.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P4
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 82.0, 101.0, 97.0, 114.0, 95.0, 86.0, 105.0, 114.0, 116.0, 117.0, 97.0,
    108.0, 67.0, 97.0, 109.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P5_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 1.0 },

  /* Expression: max_lanes
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  10.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P6_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 1.0 },

  /* Expression: max_obstacles
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  10.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P7_Size
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 1.0 },

  /* Expression: worldsim_verbose
   * Referenced by: '<S139>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S147>/Gain2'
   */
  -1.0,

  /* Computed Parameter: VI_WorldSim_State_Manager_P1_Size
   * Referenced by: '<S139>/VI_WorldSim_State_Manager'
   */
  { 1.0, 9.0 },

  /* Computed Parameter: VI_WorldSim_State_Manager_P1
   * Referenced by: '<S139>/VI_WorldSim_State_Manager'
   */
  { 49.0, 50.0, 55.0, 46.0, 48.0, 46.0, 48.0, 46.0, 49.0 },

  /* Computed Parameter: VI_WorldSim_State_Manager_P2_Size
   * Referenced by: '<S139>/VI_WorldSim_State_Manager'
   */
  { 1.0, 1.0 },

  /* Expression: worldsim_endpoint_port
   * Referenced by: '<S139>/VI_WorldSim_State_Manager'
   */
  8080.0,

  /* Computed Parameter: VI_WorldSim_State_Manager_P3_Size
   * Referenced by: '<S139>/VI_WorldSim_State_Manager'
   */
  { 1.0, 3.0 },

  /* Computed Parameter: VI_WorldSim_State_Manager_P3
   * Referenced by: '<S139>/VI_WorldSim_State_Manager'
   */
  { 101.0, 103.0, 111.0 },

  /* Computed Parameter: VI_WorldSim_State_Manager_P4_Size
   * Referenced by: '<S139>/VI_WorldSim_State_Manager'
   */
  { 1.0, 1.0 },

  /* Expression: worldsim_verbose
   * Referenced by: '<S139>/VI_WorldSim_State_Manager'
   */
  0.0,

  /* Computed Parameter: TSamp_WtEt_b
   * Referenced by: '<S69>/TSamp'
   */
  50.0,

  /* Computed Parameter: TSamp_WtEt_i
   * Referenced by: '<S79>/TSamp'
   */
  50.0,

  /* Expression: 0.5
   * Referenced by: '<S4>/Gain1'
   */
  0.5,

  /* Computed Parameter: TSamp_WtEt_k
   * Referenced by: '<S80>/TSamp'
   */
  50.0,

  /* Computed Parameter: TSamp_WtEt_h
   * Referenced by: '<S81>/TSamp'
   */
  50.0,

  /* Computed Parameter: Tsamp_WtEt
   * Referenced by: '<S115>/Tsamp'
   */
  50.0,

  /* Computed Parameter: Integrator_gainval_o
   * Referenced by: '<S120>/Integrator'
   */
  0.02,

  /* Computed Parameter: sampletime_WtEt
   * Referenced by: '<S85>/sample time'
   */
  0.02,

  /* Expression: 0
   * Referenced by: '<S85>/Delay Input2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S4>/Rate Limiter'
   */
  0.0,

  /* Computed Parameter: Memory1_InitialCondition
   * Referenced by: '<S6>/Memory1'
   */
  false,

  /* Computed Parameter: Memory_InitialCondition_o
   * Referenced by: '<S6>/Memory'
   */
  false,

  /* Computed Parameter: RateTransition5_InitialCondition
   * Referenced by: '<S4>/Rate Transition5'
   */
  false
};
