/*
 * lss_online_capi.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "lss_online".
 *
 * Model version              : 17.27
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Fri Feb  2 00:03:37 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "lss_online_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#ifndef SS_UINT64
#define SS_UINT64                      17
#endif

#ifndef SS_INT64
#define SS_INT64                       18
#endif

#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "lss_online.h"
#include "lss_online_capi.h"
#include "lss_online_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               ((NULL))
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

static const rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 0, TARGET_STRING("lss_online/LDW/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 1, TARGET_STRING("lss_online/LDW/Compare To Constant3"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 2, TARGET_STRING("lss_online/LDW/Compare To Constant4"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 3, TARGET_STRING("lss_online/LDW/Discrete Derivative"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 4, TARGET_STRING("lss_online/LDW/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 5, TARGET_STRING("lss_online/LDW/Pulse Generator"),
    TARGET_STRING("Amplitude"), 0, 0, 0 },

  { 6, TARGET_STRING("lss_online/LDW/Pulse Generator"),
    TARGET_STRING("Period"), 0, 0, 0 },

  { 7, TARGET_STRING("lss_online/LDW/Pulse Generator"),
    TARGET_STRING("PulseWidth"), 0, 0, 0 },

  { 8, TARGET_STRING("lss_online/LDW/Pulse Generator"),
    TARGET_STRING("PhaseDelay"), 0, 0, 0 },

  { 9, TARGET_STRING("lss_online/LDW/Memory2"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 10, TARGET_STRING("lss_online/LDW/Rate Transition1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 11, TARGET_STRING("lss_online/LDW/Rate Transition2"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 12, TARGET_STRING("lss_online/LDW/LDW_Steer_Vibration"),
    TARGET_STRING("Bias"), 0, 0, 0 },

  { 13, TARGET_STRING("lss_online/LDW/LDW_Steer_Vibration"),
    TARGET_STRING("Phase"), 0, 0, 0 },

  { 14, TARGET_STRING("lss_online/LKA/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 15, TARGET_STRING("lss_online/LKA/Compare To Constant3"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 16, TARGET_STRING("lss_online/LKA/Compare To Constant4"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 17, TARGET_STRING("lss_online/LKA/Discrete Derivative"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 18, TARGET_STRING("lss_online/LKA/Discrete Derivative1"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 19, TARGET_STRING("lss_online/LKA/Discrete Derivative2"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 20, TARGET_STRING("lss_online/LKA/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 21, TARGET_STRING("lss_online/LKA/Pulse Generator"),
    TARGET_STRING("Amplitude"), 0, 0, 0 },

  { 22, TARGET_STRING("lss_online/LKA/Pulse Generator"),
    TARGET_STRING("Period"), 0, 0, 0 },

  { 23, TARGET_STRING("lss_online/LKA/Pulse Generator"),
    TARGET_STRING("PulseWidth"), 0, 0, 0 },

  { 24, TARGET_STRING("lss_online/LKA/Pulse Generator"),
    TARGET_STRING("PhaseDelay"), 0, 0, 0 },

  { 25, TARGET_STRING("lss_online/LKA/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 26, TARGET_STRING("lss_online/LKA/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 27, TARGET_STRING("lss_online/LKA/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 28, TARGET_STRING("lss_online/LKA/Memory2"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 29, TARGET_STRING("lss_online/LKA/Rate Transition1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 30, TARGET_STRING("lss_online/LKA/Rate Transition2"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 31, TARGET_STRING("lss_online/LKA/Rate Transition3"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 32, TARGET_STRING("lss_online/LKA/Rate Transition5"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 33, TARGET_STRING("lss_online/LKA/Rate Limiter"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 34, TARGET_STRING("lss_online/LKA/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 35, TARGET_STRING("lss_online/LKA/Discrete Filter"),
    TARGET_STRING("Numerator"), 0, 1, 0 },

  { 36, TARGET_STRING("lss_online/LKA/Discrete Filter"),
    TARGET_STRING("Denominator"), 0, 1, 0 },

  { 37, TARGET_STRING("lss_online/LKA/Discrete Filter"),
    TARGET_STRING("InitialStates"), 0, 0, 0 },

  { 38, TARGET_STRING("lss_online/SteeringButtonsMap/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 39, TARGET_STRING("lss_online/SteeringButtonsMap/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 40, TARGET_STRING("lss_online/SteeringButtonsMap/Detect Increase"),
    TARGET_STRING("vinit"), 0, 0, 0 },

  { 41, TARGET_STRING("lss_online/SteeringButtonsMap/gear_change_max_speed_down"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 42, TARGET_STRING("lss_online/SteeringButtonsMap/gear_change_max_speed_up"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 43, TARGET_STRING("lss_online/SteeringButtonsMap/shift_paddle_threshold"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 44, TARGET_STRING("lss_online/SteeringButtonsMap/shift_paddle_threshold1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 45, TARGET_STRING("lss_online/SteeringButtonsMap/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 46, TARGET_STRING("lss_online/SteeringButtonsMap/Memory1"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 47, TARGET_STRING("lss_online/INPUT/finalizing controls inputs/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 48, TARGET_STRING("lss_online/INPUT/finalizing controls inputs/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 49, TARGET_STRING("lss_online/INPUT/finalizing controls inputs/PID Controller"),
    TARGET_STRING("P"), 0, 0, 0 },

  { 50, TARGET_STRING("lss_online/INPUT/finalizing controls inputs/PID Controller"),
    TARGET_STRING("I"), 0, 0, 0 },

  { 51, TARGET_STRING("lss_online/INPUT/finalizing controls inputs/PID Controller"),
    TARGET_STRING("InitialConditionForIntegrator"), 0, 0, 0 },

  { 52, TARGET_STRING("lss_online/INPUT/finalizing controls inputs/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 53, TARGET_STRING("lss_online/INPUT/finalizing controls inputs/Neg_driver_str_gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 54, TARGET_STRING("lss_online/INPUT/finalizing controls inputs/Rate Limiter"),
    TARGET_STRING("RisingSlewLimit"), 0, 0, 0 },

  { 55, TARGET_STRING("lss_online/INPUT/finalizing controls inputs/Rate Limiter"),
    TARGET_STRING("FallingSlewLimit"), 0, 0, 0 },

  { 56, TARGET_STRING("lss_online/LDW/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 57, TARGET_STRING("lss_online/LDW/Discrete Derivative/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 58, TARGET_STRING("lss_online/LKA/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 59, TARGET_STRING("lss_online/LKA/Discrete Derivative/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 60, TARGET_STRING("lss_online/LKA/Discrete Derivative1/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 61, TARGET_STRING("lss_online/LKA/Discrete Derivative2/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 62, TARGET_STRING("lss_online/LKA/Discrete PID Controller/Discrete PID Controller"),
    TARGET_STRING("InitialConditionForIntegrator"), 0, 0, 0 },

  { 63, TARGET_STRING("lss_online/LKA/Discrete PID Controller/Discrete PID Controller"),
    TARGET_STRING("DifferentiatorICPrevScaledInput"), 0, 0, 0 },

  { 64, TARGET_STRING("lss_online/LKA/Rate Limiter Dynamic/Delay Input2"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 65, TARGET_STRING("lss_online/LKA/Rate Limiter Dynamic/sample time"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 66, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Constant"),
    TARGET_STRING("Value"), 0, 2, 0 },

  { 67, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P1"), 0, 3, 0 },

  { 68, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P2"), 0, 0, 0 },

  { 69, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P3"), 0, 1, 0 },

  { 70, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P4"), 0, 4, 0 },

  { 71, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P5"), 0, 0, 0 },

  { 72, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P6"), 0, 0, 0 },

  { 73, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P7"), 0, 0, 0 },

  { 74, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P1"), 0, 3, 0 },

  { 75, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P2"), 0, 0, 0 },

  { 76, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P3"), 0, 1, 0 },

  { 77, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P4"), 0, 5, 0 },

  { 78, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P5"), 0, 0, 0 },

  { 79, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P6"), 0, 0, 0 },

  { 80, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P7"), 0, 0, 0 },

  { 81, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_State_Manager"),
    TARGET_STRING("P1"), 0, 3, 0 },

  { 82, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_State_Manager"),
    TARGET_STRING("P2"), 0, 0, 0 },

  { 83, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_State_Manager"),
    TARGET_STRING("P3"), 0, 1, 0 },

  { 84, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_State_Manager"),
    TARGET_STRING("P4"), 0, 0, 0 },

  { 85, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Pulse Generator"),
    TARGET_STRING("Amplitude"), 0, 0, 0 },

  { 86, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Pulse Generator"),
    TARGET_STRING("Period"), 0, 0, 0 },

  { 87, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Pulse Generator"),
    TARGET_STRING("PulseWidth"), 0, 0, 0 },

  { 88, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Pulse Generator"),
    TARGET_STRING("PhaseDelay"), 0, 0, 0 },

  { 89, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Gain2"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 90, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Discrete Filter"),
    TARGET_STRING("Numerator"), 0, 1, 0 },

  { 91, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Discrete Filter"),
    TARGET_STRING("Denominator"), 0, 1, 0 },

  { 92, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Discrete Filter"),
    TARGET_STRING("InitialStates"), 0, 0, 0 },

  { 93, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Discrete Filter1"),
    TARGET_STRING("Numerator"), 0, 1, 0 },

  { 94, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Discrete Filter1"),
    TARGET_STRING("Denominator"), 0, 1, 0 },

  { 95, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Discrete Filter1"),
    TARGET_STRING("InitialStates"), 0, 0, 0 },

  { 96, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/filtering"),
    TARGET_STRING("Numerator"), 0, 1, 0 },

  { 97, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/filtering"),
    TARGET_STRING("Denominator"), 0, 1, 0 },

  { 98, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/filtering"),
    TARGET_STRING("InitialStates"), 0, 0, 0 },

  { 99, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/obstacle detection /Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 100, TARGET_STRING("lss_online/INPUT/finalizing controls inputs/PID Controller/Integrator/Discrete/Integrator"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 101, TARGET_STRING("lss_online/LKA/Discrete PID Controller/Discrete PID Controller/Integrator/Discrete/Integrator"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 102, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/derivation_speed/Discrete Derivative"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 103, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/derivation_speed/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 104, TARGET_STRING("lss_online/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/derivation_speed/Discrete Derivative/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 105, TARGET_STRING("lss_online/LKA/Discrete PID Controller/Discrete PID Controller/Filter/Differentiator/Tsamp/Internal Ts/Tsamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Tunable variable parameters */
static const rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 106, TARGET_STRING("ADAS_Control_Mode"), 0, 0, 0 },

  { 107, TARGET_STRING("AP_Transition_Rate"), 0, 0, 0 },

  { 108, TARGET_STRING("LDW_Activity_Flag"), 0, 0, 0 },

  { 109, TARGET_STRING("LDW_LaneGap_Warning"), 0, 6, 0 },

  { 110, TARGET_STRING("LDW_LaneGap_dydt_Warning"), 0, 0, 0 },

  { 111, TARGET_STRING("LDW_Min_Speed"), 0, 0, 0 },

  { 112, TARGET_STRING("LDW_Steer_Vibration_Amplitude"), 0, 0, 0 },

  { 113, TARGET_STRING("LDW_Steer_Vibration_Freq"), 0, 0, 0 },

  { 114, TARGET_STRING("LKA_Activity_Flag"), 0, 0, 0 },

  { 115, TARGET_STRING("LKA_D"), 0, 6, 0 },

  { 116, TARGET_STRING("LKA_Dyn_Rate_Limiter_Gain"), 0, 0, 0 },

  { 117, TARGET_STRING("LKA_Dyn_Rate_Limiter_Power"), 0, 0, 0 },

  { 118, TARGET_STRING("LKA_Error_Max"), 0, 0, 0 },

  { 119, TARGET_STRING("LKA_Error_Off"), 0, 0, 0 },

  { 120, TARGET_STRING("LKA_Error_dydt_Off"), 0, 0, 0 },

  { 121, TARGET_STRING("LKA_I"), 0, 6, 0 },

  { 122, TARGET_STRING("LKA_Lane_Gap_Activate"), 0, 6, 0 },

  { 123, TARGET_STRING("LKA_Lane_Gap_dydt_Activate"), 0, 0, 0 },

  { 124, TARGET_STRING("LKA_Min_Speed"), 0, 0, 0 },

  { 125, TARGET_STRING("LKA_P"), 0, 6, 0 },

  { 126, TARGET_STRING("LKA_Steer_Rate_Max_radps"), 0, 0, 0 },

  { 127, TARGET_STRING("index_variant_approaching_speed"), 0, 0, 0 },

  { 128, TARGET_STRING("variant_approaching_speed"), 0, 7, 0 },

  { 129, TARGET_STRING("vehicle_width"), 0, 0, 0 },

  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Declare Data Addresses statically */
static void* rtDataAddrMap[] = {
  &lss_online_P.CompareToConstant1_const_o,/* 0: Mask Parameter */
  &lss_online_P.CompareToConstant3_const_l,/* 1: Mask Parameter */
  &lss_online_P.CompareToConstant4_const_h,/* 2: Mask Parameter */
  &lss_online_P.DiscreteDerivative_ICPrevScaledInput_k,/* 3: Mask Parameter */
  &lss_online_P.Constant_Value_h,      /* 4: Block Parameter */
  &lss_online_P.PulseGenerator_Amp_l,  /* 5: Block Parameter */
  &lss_online_P.PulseGenerator_Period_c,/* 6: Block Parameter */
  &lss_online_P.PulseGenerator_Duty_c, /* 7: Block Parameter */
  &lss_online_P.PulseGenerator_PhaseDelay_p,/* 8: Block Parameter */
  &lss_online_P.Memory2_InitialCondition_h,/* 9: Block Parameter */
  &lss_online_P.RateTransition1_InitialCondition_i,/* 10: Block Parameter */
  &lss_online_P.RateTransition2_InitialCondition_j,/* 11: Block Parameter */
  &lss_online_P.LDW_Steer_Vibration_Bias,/* 12: Block Parameter */
  &lss_online_P.LDW_Steer_Vibration_Phase,/* 13: Block Parameter */
  &lss_online_P.CompareToConstant1_const,/* 14: Mask Parameter */
  &lss_online_P.CompareToConstant3_const,/* 15: Mask Parameter */
  &lss_online_P.CompareToConstant4_const,/* 16: Mask Parameter */
  &lss_online_P.DiscreteDerivative_ICPrevScaledInput_i,/* 17: Mask Parameter */
  &lss_online_P.DiscreteDerivative1_ICPrevScaledInput,/* 18: Mask Parameter */
  &lss_online_P.DiscreteDerivative2_ICPrevScaledInput,/* 19: Mask Parameter */
  &lss_online_P.Constant_Value_dk,     /* 20: Block Parameter */
  &lss_online_P.PulseGenerator_Amp_k,  /* 21: Block Parameter */
  &lss_online_P.PulseGenerator_Period_o,/* 22: Block Parameter */
  &lss_online_P.PulseGenerator_Duty_h, /* 23: Block Parameter */
  &lss_online_P.PulseGenerator_PhaseDelay_l,/* 24: Block Parameter */
  &lss_online_P.Gain_Gain,             /* 25: Block Parameter */
  &lss_online_P.Gain1_Gain,            /* 26: Block Parameter */
  &lss_online_P.Memory_InitialCondition,/* 27: Block Parameter */
  &lss_online_P.Memory2_InitialCondition,/* 28: Block Parameter */
  &lss_online_P.RateTransition1_InitialCondition,/* 29: Block Parameter */
  &lss_online_P.RateTransition2_InitialCondition,/* 30: Block Parameter */
  &lss_online_P.RateTransition3_InitialCondition,/* 31: Block Parameter */
  &lss_online_P.RateTransition5_InitialCondition,/* 32: Block Parameter */
  &lss_online_P.RateLimiter_IC,        /* 33: Block Parameter */
  &lss_online_P.Switch1_Threshold,     /* 34: Block Parameter */
  &lss_online_P.DiscreteFilter_NumCoef[0],/* 35: Block Parameter */
  &lss_online_P.DiscreteFilter_DenCoef[0],/* 36: Block Parameter */
  &lss_online_P.DiscreteFilter_InitialStates,/* 37: Block Parameter */
  &lss_online_P.CompareToConstant_const_i,/* 38: Mask Parameter */
  &lss_online_P.CompareToConstant1_const_a,/* 39: Mask Parameter */
  &lss_online_P.DetectIncrease_vinit,  /* 40: Mask Parameter */
  &lss_online_P.gear_change_max_speed_down_const,/* 41: Mask Parameter */
  &lss_online_P.gear_change_max_speed_up_const,/* 42: Mask Parameter */
  &lss_online_P.shift_paddle_threshold_const,/* 43: Mask Parameter */
  &lss_online_P.shift_paddle_threshold1_const,/* 44: Mask Parameter */
  &lss_online_P.Memory_InitialCondition_o,/* 45: Block Parameter */
  &lss_online_P.Memory1_InitialCondition,/* 46: Block Parameter */
  &lss_online_P.CompareToConstant_const,/* 47: Mask Parameter */
  &lss_online_P.CompareToConstant1_const_h,/* 48: Mask Parameter */
  &lss_online_P.PIDController_P,       /* 49: Mask Parameter */
  &lss_online_P.PIDController_I,       /* 50: Mask Parameter */
  &lss_online_P.PIDController_InitialConditionForIntegrator,/* 51: Mask Parameter */
  &lss_online_P.Constant2_Value,       /* 52: Block Parameter */
  &lss_online_P.Neg_driver_str_gain_Gain,/* 53: Block Parameter */
  &lss_online_P.RateLimiter_RisingLim, /* 54: Block Parameter */
  &lss_online_P.RateLimiter_FallingLim,/* 55: Block Parameter */
  &lss_online_P.Constant_Value,        /* 56: Block Parameter */
  &lss_online_P.TSamp_WtEt_b,          /* 57: Block Parameter */
  &lss_online_P.Constant_Value_d,      /* 58: Block Parameter */
  &lss_online_P.TSamp_WtEt_i,          /* 59: Block Parameter */
  &lss_online_P.TSamp_WtEt_k,          /* 60: Block Parameter */
  &lss_online_P.TSamp_WtEt_h,          /* 61: Block Parameter */
  &lss_online_P.DiscretePIDController_InitialConditionForIntegrator,/* 62: Mask Parameter */
  &lss_online_P.DiscretePIDController_DifferentiatorICPrevScaledInput,/* 63: Mask Parameter */
  &lss_online_P.DelayInput2_InitialCondition,/* 64: Block Parameter */
  &lss_online_P.sampletime_WtEt,       /* 65: Block Parameter */
  &lss_online_P.Constant_Value_l[0],   /* 66: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P1[0],/* 67: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P2,/* 68: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P3[0],/* 69: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P4[0],/* 70: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P5,/* 71: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P6,/* 72: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera_P7,/* 73: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P1[0],/* 74: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P2,/* 75: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P3[0],/* 76: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P4[0],/* 77: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P5,/* 78: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P6,/* 79: Block Parameter */
  &lss_online_P.VI_WorldSim_Sensor_VirtualCamera1_P7,/* 80: Block Parameter */
  &lss_online_P.VI_WorldSim_State_Manager_P1[0],/* 81: Block Parameter */
  &lss_online_P.VI_WorldSim_State_Manager_P2,/* 82: Block Parameter */
  &lss_online_P.VI_WorldSim_State_Manager_P3[0],/* 83: Block Parameter */
  &lss_online_P.VI_WorldSim_State_Manager_P4,/* 84: Block Parameter */
  &lss_online_P.PulseGenerator_Amp,    /* 85: Block Parameter */
  &lss_online_P.PulseGenerator_Period, /* 86: Block Parameter */
  &lss_online_P.PulseGenerator_Duty,   /* 87: Block Parameter */
  &lss_online_P.PulseGenerator_PhaseDelay,/* 88: Block Parameter */
  &lss_online_P.Gain2_Gain,            /* 89: Block Parameter */
  &lss_online_P.DiscreteFilter_NumCoef_l[0],/* 90: Block Parameter */
  &lss_online_P.DiscreteFilter_DenCoef_d[0],/* 91: Block Parameter */
  &lss_online_P.DiscreteFilter_InitialStates_g,/* 92: Block Parameter */
  &lss_online_P.DiscreteFilter1_NumCoef[0],/* 93: Block Parameter */
  &lss_online_P.DiscreteFilter1_DenCoef[0],/* 94: Block Parameter */
  &lss_online_P.DiscreteFilter1_InitialStates,/* 95: Block Parameter */
  &lss_online_P.filtering_NumCoef[0],  /* 96: Block Parameter */
  &lss_online_P.filtering_DenCoef[0],  /* 97: Block Parameter */
  &lss_online_P.filtering_InitialStates,/* 98: Block Parameter */
  &lss_online_P.Gain_Gain_j,           /* 99: Block Parameter */
  &lss_online_P.Integrator_gainval,    /* 100: Block Parameter */
  &lss_online_P.Integrator_gainval_o,  /* 101: Block Parameter */
  &lss_online_P.DiscreteDerivative_ICPrevScaledInput,/* 102: Mask Parameter */
  &lss_online_P.Gain_Gain_f,           /* 103: Block Parameter */
  &lss_online_P.TSamp_WtEt,            /* 104: Block Parameter */
  &lss_online_P.Tsamp_WtEt,            /* 105: Block Parameter */
  &lss_online_P.ADAS_Control_Mode,     /* 106: Model Parameter */
  &lss_online_P.AP_Transition_Rate,    /* 107: Model Parameter */
  &lss_online_P.LDW_Activity_Flag,     /* 108: Model Parameter */
  &lss_online_P.LDW_LaneGap_Warning[0],/* 109: Model Parameter */
  &lss_online_P.LDW_LaneGap_dydt_Warning,/* 110: Model Parameter */
  &lss_online_P.LDW_Min_Speed,         /* 111: Model Parameter */
  &lss_online_P.LDW_Steer_Vibration_Amplitude,/* 112: Model Parameter */
  &lss_online_P.LDW_Steer_Vibration_Freq,/* 113: Model Parameter */
  &lss_online_P.LKA_Activity_Flag,     /* 114: Model Parameter */
  &lss_online_P.LKA_D[0],              /* 115: Model Parameter */
  &lss_online_P.LKA_Dyn_Rate_Limiter_Gain,/* 116: Model Parameter */
  &lss_online_P.LKA_Dyn_Rate_Limiter_Power,/* 117: Model Parameter */
  &lss_online_P.LKA_Error_Max,         /* 118: Model Parameter */
  &lss_online_P.LKA_Error_Off,         /* 119: Model Parameter */
  &lss_online_P.LKA_Error_dydt_Off,    /* 120: Model Parameter */
  &lss_online_P.LKA_I[0],              /* 121: Model Parameter */
  &lss_online_P.LKA_Lane_Gap_Activate[0],/* 122: Model Parameter */
  &lss_online_P.LKA_Lane_Gap_dydt_Activate,/* 123: Model Parameter */
  &lss_online_P.LKA_Min_Speed,         /* 124: Model Parameter */
  &lss_online_P.LKA_P[0],              /* 125: Model Parameter */
  &lss_online_P.LKA_Steer_Rate_Max_radps,/* 126: Model Parameter */
  &lss_online_P.index_variant_approaching_speed,/* 127: Model Parameter */
  &lss_online_P.variant_approaching_speed[0],/* 128: Model Parameter */
  &lss_online_P.vehicle_width,         /* 129: Model Parameter */
};

/* Declare Data Run-Time Dimension Buffer Addresses statically */
static int32_T* rtVarDimsAddrMap[] = {
  (NULL)
};

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), (uint8_T)SS_DOUBLE, 0, 0, 0 },

  { "unsigned char", "boolean_T", 0, 0, sizeof(boolean_T), (uint8_T)SS_BOOLEAN,
    0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static const rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 },

  { rtwCAPI_VECTOR, 2, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 },

  { rtwCAPI_VECTOR, 8, 2, 0 },

  { rtwCAPI_VECTOR, 10, 2, 0 },

  { rtwCAPI_VECTOR, 12, 2, 0 },

  { rtwCAPI_VECTOR, 14, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static const uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1,                                   /* 1 */
  1,                                   /* 2 */
  3,                                   /* 3 */
  64,                                  /* 4 */
  7,                                   /* 5 */
  1,                                   /* 6 */
  9,                                   /* 7 */
  1,                                   /* 8 */
  16,                                  /* 9 */
  1,                                   /* 10 */
  15,                                  /* 11 */
  1,                                   /* 12 */
  2,                                   /* 13 */
  1,                                   /* 14 */
  5                                    /* 15 */
};

/* Fixed Point Map */
static const rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, (boolean_T)0 },
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static const rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  {
    (NULL), (NULL), 0, 0
  }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { (NULL), 0,
    (NULL), 0,
    (NULL), 0 },

  { rtBlockParameters, 106,
    rtModelParameters, 24 },

  { (NULL), 0 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 2804961027U,
    301693264U,
    3072178169U,
    1529712945U },
  (NULL), 0,
  (boolean_T)0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  lss_online_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void lss_online_InitializeDataMapInfo(void)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(lss_online_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(lss_online_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(lss_online_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetDataAddressMap(lss_online_M->DataMapInfo.mmi, rtDataAddrMap);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetVarDimsAddressMap(lss_online_M->DataMapInfo.mmi, rtVarDimsAddrMap);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(lss_online_M->DataMapInfo.mmi, (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(lss_online_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetChildMMIArrayLen(lss_online_M->DataMapInfo.mmi, 0);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C"
{

#endif

  void lss_online_host_InitializeDataMapInfo(lss_online_host_DataMapInfo_T
    *dataMap, const char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, (NULL));

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, (NULL));

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, (NULL));

    /* Set reference to submodels */
    rtwCAPI_SetChildMMIArray(dataMap->mmi, (NULL));
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 0);
  }

#ifdef __cplusplus

}

#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: lss_online_capi.c */
