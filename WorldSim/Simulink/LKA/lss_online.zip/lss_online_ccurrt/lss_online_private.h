/*
 * lss_online_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "lss_online".
 *
 * Model version              : 17.27
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Fri Feb  2 00:03:37 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_lss_online_private_h_
#define RTW_HEADER_lss_online_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#include "lss_online.h"
#include "lss_online_types.h"
#ifdef GENSIMWBCODE
#ifndef CCURSIM_INCLUDES
#define CCURSIM_INCLUDES
#include <stdio.h>
#include <stdlib.h>
#define __need_timespec
#include <time.h>
#include <string.h>
#include <stddef.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/time.h>
#include <schedutils.h>
#include <rtdbutils.h>
#include <logger.h>
#include <simerrors.h>
#include "ccur_rtdb.h"

extern int defaultLogger;

#endif

/* Between SimWB 2018.1-0 and 2020.1-2, pointers for RTDB variables were declared in model_private.h.
   In SimWB 2020.2-0, pointer declarations were moved to model.c[pp]? to avoid multiple declarations. */
#endif

#ifdef GENSIMWBCODE
#ifndef CCURSIM_INCLUDES
#define CCURSIM_INCLUDES
#include <stdio.h>
#include <stdlib.h>
#define __need_timespec
#include <time.h>
#include <string.h>
#include <stddef.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/time.h>
#include <schedutils.h>
#include <rtdbutils.h>
#include <logger.h>
#include <simerrors.h>
#include "ccur_rtdb.h"

extern int defaultLogger;

#endif

/* Between SimWB 2018.1-0 and 2020.1-2, pointers for RTDB variables were declared in model_private.h.
   In SimWB 2020.2-0, pointer declarations were moved to model.c[pp]? to avoid multiple declarations. */
#endif

//RTWVAR: input=VI_DriveSim.Inputs.ECAT.BECKH.ANA3(1)
//RTWVAR: input=VI_CarRealTime.Outputs.chassis_velocities.longitudinal(1)
//RTWVAR: input=VI_CarRealTime.Outputs.driver_demands.steering(1)
//RTWVAR: input=VI_DriveSim.Inputs.ECAT.BECKH.DIG4(1)
//RTWVAR: input=VI_DriveSim.Outputs.Vicrt.Status(1)
//RTWVAR: input=VI_DriveSim.Inputs.ECAT.BECKH.ANA4(1)
//RTWVAR: input=VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque(1)
//RTWVAR: input=VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1(1)
//RTWVAR: input=VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1(1)
//RTWVAR: input=VI_CarRealTime.Outputs.chassis_accelerations.lateral(1)
//RTWVAR: input=VI_CarRealTime.Outputs.chassis_accelerations.longitudinal(1)
//RTWVAR: input=VI_CarRealTime.Outputs.driver_demands.brake(1)
//RTWVAR: input=VI_CarRealTime.Outputs.driver_demands.throttle(1)
//RTWVAR: input=VI_DriveSim.Inputs.ECAT.BECKH.DIG3(1)
//RTWVAR: input=VI_CarRealTime.Outputs.transmission.gear(1)
//RTWVAR: output=VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ(1)
//RTWVAR: output=VI_CarRealTime.Inputs.Driver_Demands.str_swa(1)
//RTWVAR: output=VI_CarRealTime.Inputs.steer_assist.torque(1)
//RTWVAR: output=VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ(1)
//RTWVAR: output=ADAS.Outputs.LDW.LDW_On(1)
//RTWVAR: output=ADAS.Outputs.LDW.LDW_On_Left(1)
//RTWVAR: output=ADAS.Outputs.LDW.LDW_On_Pulse(1)
//RTWVAR: output=ADAS.Outputs.LDW.LDW_On_Right(1)
//RTWVAR: output=ADAS.Outputs.LDW.LDW_Ready(1)
//RTWVAR: output=ADAS.Outputs.LDW.LDW_Steering_Torque(1)
//RTWVAR: output=ADAS.Outputs.LDW.LDW_White(1)
//RTWVAR: output=ADAS.Outputs.LKA.LKA_AEB_Sound(1)
//RTWVAR: output=ADAS.Outputs.LKA.LKA_On_Display(1)
//RTWVAR: output=ADAS.Outputs.LKA.LKA_On_Left(1)
//RTWVAR: output=ADAS.Outputs.LKA.LKA_On_Pulse(1)
//RTWVAR: output=ADAS.Outputs.LKA.LKA_On_Right(1)
//RTWVAR: output=ADAS.Outputs.LKA.LKA_Ready(1)
//RTWVAR: output=ADAS.Outputs.LKA.LKA_Steer_Angle(1)
//RTWVAR: output=ADAS.Outputs.LKA.LKA_Steer_Mode(1)
//RTWVAR: output=VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ(1)
//RTWVAR: output=VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ(1)
extern real_T rt_powd_snf(real_T u0, real_T u1);
extern void VI_WorldSim_Sensor_VirtualCamera_mex(SimStruct *rts);
extern void VI_WorldSim_State_Manager_mex(SimStruct *rts);
extern void lss_online_manipulation_of_objects(const real_T
  rtu_complete_obstacles_matrix[100], real_T rtu_detected_objects,
  B_manipulation_of_objects_lss_online_T *localB);

#endif                                 /* RTW_HEADER_lss_online_private_h_ */
