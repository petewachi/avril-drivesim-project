/*
 * lss_online_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "lss_online".
 *
 * Model version              : 17.27
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Fri Feb  2 00:03:37 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_lss_online_types_h_
#define RTW_HEADER_lss_online_types_h_
#ifndef SS_UINT64
#define SS_UINT64                      17
#endif

#ifndef SS_INT64
#define SS_INT64                       18
#endif

/* Parameters (default storage) */
typedef struct P_lss_online_T_ P_lss_online_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_lss_online_T RT_MODEL_lss_online_T;

#endif                                 /* RTW_HEADER_lss_online_types_h_ */
