// @File      : VI_WorldSim_Sensor_VirtualCamera_mex.cpp
// @Contact   : info@vi-grade.com
// @License   : PROPRIETARY/CONFIDENTIAL (https://www.vi-grade.com/license.txt)
// @Copyright : (c) 2006-2023, VI-grade GmbH, Darmstadt, Germany, All Rights Reserved
// ----------------------------------------------------------------------------------

#define S_FUNCTION_NAME VI_WorldSim_Sensor_VirtualCamera_mex
#define S_FUNCTION_LEVEL 2

#include "WorldSimInterface.h"
#include <string>

#include "simstruc.h"

#define IS_PARAM_DOUBLE(pVal) (mxIsNumeric(pVal) && !mxIsLogical(pVal) && !mxIsEmpty(pVal) && !mxIsSparse(pVal) && !mxIsComplex(pVal) && mxIsDouble(pVal))

enum VirtualCameraMexParameters { eEndPointIP, eEndPointPort, eVehicleName, eSensorName, eMaxLanes, eMaxObstacles, eVerbose, eParamsNum };

enum VirtualCameraDWork { eDWorkVerbose, eDWorkSensorStep, eDWorkSeqNo, eDWorkSeqNoOld, eDWorkNum };

#define MDL_CHECK_PARAMETERS
static void mdlCheckParameters(SimStruct* S) {
#ifndef __WORLDSIM_FOR_DRIVESIM__
    std::string endpoint_ip_ = mxGetClassName(ssGetSFcnParam(S, eEndPointIP));
    if (endpoint_ip_ != "char") {
        ssSetErrorStatus(S, "S-function expects as first parameter a char array as valid ip endpoint.\n (e.g. '127.0.0.1', not \"127.0.0.1\")\n");
        return;
    }

    const mxArray* endpoint_port_ = ssGetSFcnParam(S, eEndPointPort);
    if (!IS_PARAM_DOUBLE(endpoint_port_)) {
        ssSetErrorStatus(S, "S-function expects as second parameter a double scalar as valid port endpoint.\n");
        return;
    }

    std::string car_name_ = mxGetClassName(ssGetSFcnParam(S, eVehicleName));
    if (car_name_ != "char") {
        ssSetErrorStatus(S, "S-function expects as third parameter a char array as valid vehicle name.\n (e.g. 'ego', not \"ego\")\n");
        return;
    }

    std::string sensor_name_ = mxGetClassName(ssGetSFcnParam(S, eSensorName));
    if (sensor_name_ != "char") {
        ssSetErrorStatus(S, "S-function expects as fourth parameter a char array as valid sensor name.\n (e.g. 'CameraFront', not \"CameraFront\")\n");
        return;
    }

    const mxArray* max_size = ssGetSFcnParam(S, eMaxObstacles);
    if (!IS_PARAM_DOUBLE(max_size)) {
        ssSetErrorStatus(S, "S-function expects as fifth parameter a double scalar.\n");
        return;
    }

    const mxArray* max_lanes = ssGetSFcnParam(S, eMaxLanes);
    if (!IS_PARAM_DOUBLE(max_lanes)) {
        ssSetErrorStatus(S, "S-function expects as sixth parameter a double scalar.\n");
        return;
    }
#endif
}

static void mdlInitializeSizes(SimStruct* S) {
    ssSetNumSFcnParams(S, eParamsNum);
    if (ssGetNumSFcnParams(S) == ssGetSFcnParamsCount(S)) {
        mdlCheckParameters(S);
        if (ssGetErrorStatus(S) != NULL) {
            return;
        }
    } else {
        return;
    }

    // Parameter mismatch will be reported by Simulink
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        return;
    }

    /* Allow signal dimensions greater than 2 */
    ssAllowSignalsWithMoreThan2D(S);

    /* Set number of input and output ports */
    if (!ssSetNumInputPorts(S, 0)) return;
    if (!ssSetNumOutputPorts(S, 8)) return;

    int max_lanes = (int)*mxGetPr(ssGetSFcnParam(S, eMaxLanes));
    int max_dimsize = (int)*mxGetPr(ssGetSFcnParam(S, eMaxObstacles));

    ssSetOutputPortMatrixDimensions(S, 1, 2, CUBIC_COEFFICIENTS);
    ssSetOutputPortMatrixDimensions(S, 2, max_lanes, (MAX_LANE_POINTS * 3) + 1);
    ssSetOutputPortWidth(S, 3, 1);
    ssSetOutputPortMatrixDimensions(S, 4, VIRTUAL_CAMERA_OBSTACLES_DATA, max_dimsize);
    ssSetOutputPortWidth(S, 5, 1);
    ssSetOutputPortMatrixDimensions(S, 6, VIRTUAL_CAMERA_OBSTACLES_DATA, max_dimsize);
    ssSetOutputPortWidth(S, 7, 1);
    ssSetOutputPortWidth(S, 0, 2);

    ssSetOutputPortDimensionsMode(S, 0, FIXED_DIMS_MODE);
    ssSetOutputPortDimensionsMode(S, 1, FIXED_DIMS_MODE);
    ssSetOutputPortDimensionsMode(S, 2, FIXED_DIMS_MODE);
    ssSetOutputPortDimensionsMode(S, 3, FIXED_DIMS_MODE);
    ssSetOutputPortDimensionsMode(S, 4, FIXED_DIMS_MODE);
    ssSetOutputPortDimensionsMode(S, 5, FIXED_DIMS_MODE);
    ssSetOutputPortDimensionsMode(S, 6, FIXED_DIMS_MODE);
    ssSetOutputPortDimensionsMode(S, 7, FIXED_DIMS_MODE);

    ssSetOutputPortDataType(S, 0, SS_DOUBLE);
    ssSetOutputPortDataType(S, 1, SS_DOUBLE);
    ssSetOutputPortDataType(S, 2, SS_DOUBLE);
    ssSetOutputPortDataType(S, 3, SS_DOUBLE);
    ssSetOutputPortDataType(S, 4, SS_DOUBLE);
    ssSetOutputPortDataType(S, 5, SS_DOUBLE);
    ssSetOutputPortDataType(S, 6, SS_DOUBLE);
    ssSetOutputPortDataType(S, 7, SS_DOUBLE);

    ssSetNumSampleTimes(S, 1);
    ssSetNumRWork(S, 0);
    ssSetNumIWork(S, 0);
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);
    ssSetNumPWork(S, 1);
    ssSetNumDWork(S, eDWorkNum);

    ssSetDWorkWidth(S, eDWorkVerbose, 1);
    ssSetDWorkDataType(S, eDWorkVerbose, SS_BOOLEAN);
    ssSetDWorkWidth(S, eDWorkSensorStep, 1);
    ssSetDWorkDataType(S, eDWorkSensorStep, SS_DOUBLE);
    ssSetDWorkWidth(S, eDWorkSeqNo, 1);
    ssSetDWorkDataType(S, eDWorkSeqNo, SS_DOUBLE);
    ssSetDWorkWidth(S, eDWorkSeqNoOld, 1);
    ssSetDWorkDataType(S, eDWorkSeqNoOld, SS_DOUBLE);

    ssSetOptions(S, SS_OPTION_EXCEPTION_FREE_CODE);
}

static void mdlInitializeSampleTimes(SimStruct* S) {
    ssSetSampleTime(S, 0, 1.0 / WORLDSIM_UPDATE_FREQUENCY);
    ssSetOffsetTime(S, 0, 0.0);
    ssSetModelReferenceSampleTimeDefaultInheritance(S);
}

#define MDL_START
static void mdlStart(SimStruct* S) {
    char endpointIp[MAX_ENDPOINT_LENGTH];
    int endpointPort;

#ifdef __WORLDSIM_FOR_DRIVESIM__
    retrieveDriveSimEndPoint(endpointIp, endpointPort);
#else
    const mxArray* param_0 = ssGetSFcnParam(S, eEndPointIP);
    int param_0_len = mxGetN(param_0) + 1;
    char * p_0 = (char*)mxCalloc(param_0_len, sizeof(char));
    mxGetString(param_0, p_0, param_0_len);
    strncpy(endpointIp, p_0, MAX_ENDPOINT_LENGTH);
    mxFree(p_0);

    endpointPort = (int)*mxGetPr(ssGetSFcnParam(S, eEndPointPort));
#endif

    const mxArray* param_2 = ssGetSFcnParam(S, eVehicleName);
    int param_2_len = mxGetN(param_2) + 1;
    char* car_name = (char*)mxCalloc(param_2_len, sizeof(char));
    mxGetString(param_2, car_name, param_2_len);
    
    const mxArray* param_3 = ssGetSFcnParam(S, eSensorName);
    int param_3_len = mxGetN(param_3) + 1;
    char* sensor_name = (char*)mxCalloc(param_3_len, sizeof(char));
    mxGetString(param_3, sensor_name, param_3_len);

    bool* verbose = (bool*)ssGetDWork(S, eDWorkVerbose);
    const double* verbosity = 0;
    verbosity = mxGetPr(ssGetSFcnParam(S, eVerbose));
    if (verbosity)
        verbose[0] = *verbosity > 0 ? true : false;
    else
        verbose[0] = true;

    bool drivesim = false;

#ifdef __WORLDSIM_FOR_DRIVESIM__
    drivesim = true;
#endif

    int updated = 0;
    int rate;

    char msg[2048];
    sprintf(msg, "Init sensor '%s' of vehicle '%s'\n", sensor_name, car_name);
    sensorLog(msg, 1);  

    ssGetPWork(S)[0] = sensorReceiverCreate(endpointIp, endpointPort, car_name, updated, "");
    if (!updated) {
        msg[0] = '\0';
        sprintf(msg, "VirtualCamera Sensor: Invalid Scenario data. Please make sure a scenario is loaded in VI-WorldSim!\n");
        sensorLog(msg, 3);
        ssSetErrorStatus(S, msg);
        return;
    }

    mxFree(car_name);
    void** PWork = ssGetPWork(S);

    if (!buildVirtualCameraSensor(PWork[0], sensor_name, verbose[0], drivesim)) {
        msg[0] = '\0';
        sprintf(msg, "Can't find sensor '%s'\n", sensor_name);
        sensorLog(msg, 3);
        ssSetErrorStatus(S, msg);
        return;
    }

    if (!getVirtualCameraUpdateRate(PWork[0], sensor_name, rate)) {
        msg[0] = '\0';
        sprintf(msg, "Failure in reading '%s' update rate\n", sensor_name);
        sensorLog(msg, 3);
        ssSetErrorStatus(S, msg);
        return;
    }
    mxFree(sensor_name);
    
    double* sensor_step = (double*)ssGetDWork(S, eDWorkSensorStep);
    sensor_step[0] = 1.0 / rate;

    double* seq_no = (double*)ssGetDWork(S, eDWorkSeqNo);
    seq_no[0] = 0;

    double* seq_no_old = (double*)ssGetDWork(S, eDWorkSeqNoOld);
    seq_no_old[0] = 0;
}

static void mdlOutputs(SimStruct* S, int_T tid) {
    real_T* y0 = ssGetOutputPortRealSignal(S, 0);
    real_T* y1 = ssGetOutputPortRealSignal(S, 1);
    real_T* y2 = ssGetOutputPortRealSignal(S, 2);
    real_T* y3 = ssGetOutputPortRealSignal(S, 3);
    real_T* y4 = ssGetOutputPortRealSignal(S, 4);
    real_T* y5 = ssGetOutputPortRealSignal(S, 5);
    real_T* y6 = ssGetOutputPortRealSignal(S, 6);
    real_T* y7 = ssGetOutputPortRealSignal(S, 7);

    bool* verbose = (bool*)ssGetDWork(S, eDWorkVerbose);
    double* sensor_step = (double*)ssGetDWork(S, eDWorkSensorStep);
    double* seq_no = (double*)ssGetDWork(S, eDWorkSeqNo);
    double* seq_no_old = (double*)ssGetDWork(S, eDWorkSeqNoOld);

    int max_lanes = (int)*mxGetPr(ssGetSFcnParam(S, eMaxLanes));
    int max_num_obstacles = (int)*mxGetPr(ssGetSFcnParam(S, eMaxObstacles));
    int out_lanes = 0;
    int out_obstacles = 0;
    int out_map_objects = 0;

    double sim_time = ssGetT(S);

    void** PWork = ssGetPWork(S);
    void* virtual_camera_msg;

    int msg_size = getVirtualCameraMsg(PWork[0], virtual_camera_msg, sensor_step[0], seq_no[0], seq_no_old[0], sim_time);

    if (msg_size > 0) {
        getVirtualCameraData(PWork[0], virtual_camera_msg, verbose[0], y1, y2, y3, y4, y5, y6, y7, y0, max_num_obstacles, max_lanes, msg_size);
    }
    seq_no[0] = seq_no_old[0];    
}

#define MDL_UPDATE
#if defined MDL_UPDATE
static void mdlUpdate(SimStruct* S, int_T tid) {
      UNUSED_ARG(tid);
}
#endif

static void mdlTerminate(SimStruct* S) {
    void** PWork = ssGetPWork(S);
    sensorReceiverDestructor(PWork[0]);
}

#ifdef MATLAB_MEX_FILE
#include "simulink.c"
#else
#include "cg_sfun.h"
#endif