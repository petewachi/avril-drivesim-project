/*
 * auto_pilot_upl_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "auto_pilot_upl".
 *
 * Model version              : 17.110
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Thu Feb  1 00:30:37 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_auto_pilot_upl_types_h_
#define RTW_HEADER_auto_pilot_upl_types_h_
#ifndef SS_UINT64
#define SS_UINT64                      18
#endif

#ifndef SS_INT64
#define SS_INT64                       19
#endif

/* Parameters (default storage) */
typedef struct P_auto_pilot_upl_T_ P_auto_pilot_upl_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_auto_pilot_upl_T RT_MODEL_auto_pilot_upl_T;

#endif                                 /* RTW_HEADER_auto_pilot_upl_types_h_ */
