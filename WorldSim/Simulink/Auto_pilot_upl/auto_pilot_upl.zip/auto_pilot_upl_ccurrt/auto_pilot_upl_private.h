/*
 * auto_pilot_upl_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "auto_pilot_upl".
 *
 * Model version              : 17.110
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Thu Feb  1 00:30:37 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_auto_pilot_upl_private_h_
#define RTW_HEADER_auto_pilot_upl_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#include "auto_pilot_upl.h"
#include "auto_pilot_upl_types.h"
#ifdef GENSIMWBCODE
#ifndef CCURSIM_INCLUDES
#define CCURSIM_INCLUDES
#include <stdio.h>
#include <stdlib.h>
#define __need_timespec
#include <time.h>
#include <string.h>
#include <stddef.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/time.h>
#include <schedutils.h>
#include <rtdbutils.h>
#include <logger.h>
#include <simerrors.h>
#include "ccur_rtdb.h"

extern int defaultLogger;

#endif

/* Between SimWB 2018.1-0 and 2020.1-2, pointers for RTDB variables were declared in model_private.h.
   In SimWB 2020.2-0, pointer declarations were moved to model.c[pp]? to avoid multiple declarations. */
#endif

#ifdef GENSIMWBCODE
#ifndef CCURSIM_INCLUDES
#define CCURSIM_INCLUDES
#include <stdio.h>
#include <stdlib.h>
#define __need_timespec
#include <time.h>
#include <string.h>
#include <stddef.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/time.h>
#include <schedutils.h>
#include <rtdbutils.h>
#include <logger.h>
#include <simerrors.h>
#include "ccur_rtdb.h"

extern int defaultLogger;

#endif

/* Between SimWB 2018.1-0 and 2020.1-2, pointers for RTDB variables were declared in model_private.h.
   In SimWB 2020.2-0, pointer declarations were moved to model.c[pp]? to avoid multiple declarations. */
#endif

#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFU) ) || ( SCHAR_MAX != (0x7F) )
#error Code was generated for compiler with different sized uchar/char. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized ushort/short. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( UINT_MAX != (0xFFFFFFFFU) ) || ( INT_MAX != (0x7FFFFFFF) )
#error Code was generated for compiler with different sized uint/int. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

/* Skipping ulong/long check: insufficient preprocessor integer range. */

//RTWVAR: input=VI_DriveSim.Inputs.ECAT.BECKH.ANA3(1)
//RTWVAR: input=VI_CarRealTime.Outputs.transmission.gear(1)
//RTWVAR: input=VI_DriveSim.Inputs.ECAT.BECKH.ANA4(1)
//RTWVAR: input=VI_DriveSim.Inputs.ECAT.BECKH.DIG4(1)
//RTWVAR: input=VI_CarRealTime.Outputs.chassis_velocities.longitudinal(1)
//RTWVAR: input=VI_DriveSim.Outputs.Vicrt.Status(1)
//RTWVAR: input=VI_CarRealTime.Outputs.driver_demands.brake(1)
//RTWVAR: input=VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1(1)
//RTWVAR: input=VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1(1)
//RTWVAR: input=VI_CarRealTime.Outputs.driver_demands.throttle(1)
//RTWVAR: input=VI_CarRealTime.Outputs.driver_demands.steering(1)
//RTWVAR: input=VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque(1)
//RTWVAR: input=VI_CarRealTime.Outputs.chassis_accelerations.lateral(1)
//RTWVAR: input=VI_CarRealTime.Outputs.chassis_accelerations.longitudinal(1)
//RTWVAR: input=VI_DriveSim.Inputs.ECAT.BECKH.DIG3(1)
//RTWVAR: output=VI_CarRealTime.Inputs.Driver_Demands.brake(1)
//RTWVAR: output=VI_CarRealTime.Inputs.Driver_Demands.throttle(1)
//RTWVAR: output=VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ(1)
//RTWVAR: output=VI_CarRealTime.Inputs.Driver_Demands.str_swa(1)
//RTWVAR: output=VI_CarRealTime.Inputs.steer_assist.torque(1)
//RTWVAR: output=VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ(1)
//RTWVAR: output=VI_CarRealTime.Inputs.Driver_Demands.target_speed(1)
//RTWVAR: output=ADAS.Outputs.ACC.ACC_On(1)
//RTWVAR: output=ADAS.Outputs.ACC.ACC_On_Display(1)
//RTWVAR: output=ADAS.Outputs.ACC.ACC_Ready(1)
//RTWVAR: output=ADAS.Outputs.ACC.ACC_Ready_Display(1)
//RTWVAR: output=ADAS.Outputs.ACC.ACC_Speed_Target_Display(1)
//RTWVAR: output=ADAS.Outputs.ACC.ACC_Target_Id_Display(1)
//RTWVAR: output=ADAS.Outputs.ACC.ACC_Target_Speed(1)
//RTWVAR: output=ADAS.Outputs.AEB.AEB_BrakeDemand(1)
//RTWVAR: output=ADAS.Outputs.AEB.AEB_On(1)
//RTWVAR: output=ADAS.Outputs.AEB.AEB_Output_Active(1)
//RTWVAR: output=ADAS.Outputs.AEB.AEB_Ready(1)
//RTWVAR: output=ADAS.Outputs.AEB.AEB_Target_Id_Display(1)
//RTWVAR: output=ADAS.Outputs.AEB.AEB_TimeToCollision(1)
//RTWVAR: output=ADAS.Outputs.AP.AP_On(1)
//RTWVAR: output=ADAS.Outputs.AP.AP_Ready(1)
//RTWVAR: output=ADAS.Outputs.Generic.ADAS_Error(1)
//RTWVAR: output=ADAS.Outputs.AEB.AEB_TimeToCollision_Threshold(1)
//RTWVAR: output=WorldSim.ego.Sensors.Lane_detector.LeftLane.Crossed(1)
//RTWVAR: output=WorldSim.ego.Sensors.Lane_detector.LeftLane.Distance(1)
//RTWVAR: output=WorldSim.ego.Sensors.Lane_detector.RightLane.Crossed(1)
//RTWVAR: output=WorldSim.ego.Sensors.Lane_detector.RightLane.Distance(1)
//RTWVAR: output=WorldSim.ego.Sensors.Front_VirtualCam.obstacleData(1)
//RTWVAR: output=VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ(1)
//RTWVAR: output=VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ(1)
//RTWVAR: output=WorldSim.ego.Sensors.Collision.Count(1)
extern real_T rt_powd_snf(real_T u0, real_T u1);
extern void VI_WorldSim_Sensor_VirtualCamera_mex(SimStruct *rts);
extern void VI_WorldSim_State_Manager_mex(SimStruct *rts);
extern void auto_pilot_upl_MATLABFunction(const real_T rtu_u[10],
  B_MATLABFunction_auto_pilot_upl_T *localB);
extern void auto_pilot_upl_manipulation_of_objects(const real_T
  rtu_complete_obstacles_matrix[100], real_T rtu_detected_objects,
  B_manipulation_of_objects_auto_pilot_upl_T *localB);

/* private model entry point functions */
extern void auto_pilot_upl_derivatives(void);

#endif                                /* RTW_HEADER_auto_pilot_upl_private_h_ */
