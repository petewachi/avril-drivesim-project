/*
 * auto_pilot_upl_capi.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "auto_pilot_upl".
 *
 * Model version              : 17.110
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Thu Feb  1 00:30:37 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "auto_pilot_upl_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#ifndef SS_UINT64
#define SS_UINT64                      18
#endif

#ifndef SS_INT64
#define SS_INT64                       19
#endif

#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "auto_pilot_upl.h"
#include "auto_pilot_upl_capi.h"
#include "auto_pilot_upl_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               ((NULL))
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

static const rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 0, TARGET_STRING("auto_pilot_upl/SteeringButtonsMap/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 1, TARGET_STRING("auto_pilot_upl/SteeringButtonsMap/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 2, TARGET_STRING("auto_pilot_upl/SteeringButtonsMap/Compare To Constant2"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 3, TARGET_STRING("auto_pilot_upl/SteeringButtonsMap/gear_change_max_speed_down"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 4, TARGET_STRING("auto_pilot_upl/SteeringButtonsMap/gear_change_max_speed_up"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 5, TARGET_STRING("auto_pilot_upl/SteeringButtonsMap/shift_paddle_threshold"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 6, TARGET_STRING("auto_pilot_upl/SteeringButtonsMap/shift_paddle_threshold1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 7, TARGET_STRING("auto_pilot_upl/ACC/ACC_Inputs/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 8, TARGET_STRING("auto_pilot_upl/ACC/ACC_Inputs/Detect Increase"),
    TARGET_STRING("vinit"), 1, 0, 0 },

  { 9, TARGET_STRING("auto_pilot_upl/ACC/ACC_Inputs/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 10, TARGET_STRING("auto_pilot_upl/ACC/ACC_Inputs/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 11, TARGET_STRING("auto_pilot_upl/ACC/ACC_Inputs/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 12, TARGET_STRING("auto_pilot_upl/ACC/ACC_Outputs/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 13, TARGET_STRING("auto_pilot_upl/ACC/ACC_Outputs/Rate Limiter"),
    TARGET_STRING("RisingSlewLimit"), 0, 0, 0 },

  { 14, TARGET_STRING("auto_pilot_upl/ACC/ACC_Outputs/Rate Limiter"),
    TARGET_STRING("FallingSlewLimit"), 0, 0, 0 },

  { 15, TARGET_STRING("auto_pilot_upl/ACC/ACC_Outputs/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 16, TARGET_STRING("auto_pilot_upl/AEB/AEB_Inputs/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 17, TARGET_STRING("auto_pilot_upl/AEB/AEB_Inputs/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 18, TARGET_STRING("auto_pilot_upl/AEB/AEB_Inputs/Gain2"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 19, TARGET_STRING("auto_pilot_upl/AEB/AEB_Inputs/Gain3"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 20, TARGET_STRING("auto_pilot_upl/AEB/AEB_Inputs/Gain4"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 21, TARGET_STRING("auto_pilot_upl/AEB/AEB_Inputs/Gain5"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 22, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/AEB_Approaching_Speed_Threshold"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 23, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 24, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 25, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Detect Change"),
    TARGET_STRING("vinit"), 0, 0, 0 },

  { 26, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 27, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 28, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 29, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Constant3"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 30, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Pulse Generator"),
    TARGET_STRING("Amplitude"), 0, 0, 0 },

  { 31, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Pulse Generator"),
    TARGET_STRING("Period"), 0, 0, 0 },

  { 32, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Pulse Generator"),
    TARGET_STRING("PulseWidth"), 0, 0, 0 },

  { 33, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Pulse Generator"),
    TARGET_STRING("PhaseDelay"), 0, 0, 0 },

  { 34, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 35, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Rate Transition5"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 36, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Rate Transition6"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 37, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Rate Transition7"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 38, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Rate Limiter"),
    TARGET_STRING("RisingSlewLimit"), 0, 0, 0 },

  { 39, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Rate Limiter"),
    TARGET_STRING("FallingSlewLimit"), 0, 0, 0 },

  { 40, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Rate Limiter1"),
    TARGET_STRING("RisingSlewLimit"), 0, 0, 0 },

  { 41, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Rate Limiter1"),
    TARGET_STRING("FallingSlewLimit"), 0, 0, 0 },

  { 42, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Rate Limiter1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 43, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 44, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 45, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 46, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Delay"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 47, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Delay1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 48, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/filtering"),
    TARGET_STRING("Numerator"), 0, 1, 0 },

  { 49, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/filtering"),
    TARGET_STRING("Denominator"), 0, 1, 0 },

  { 50, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/filtering"),
    TARGET_STRING("InitialStates"), 0, 0, 0 },

  { 51, TARGET_STRING("auto_pilot_upl/AEB/AEB_Outputs/Pulse Generator"),
    TARGET_STRING("Amplitude"), 0, 0, 0 },

  { 52, TARGET_STRING("auto_pilot_upl/AEB/AEB_Outputs/Pulse Generator"),
    TARGET_STRING("Period"), 0, 0, 0 },

  { 53, TARGET_STRING("auto_pilot_upl/AEB/AEB_Outputs/Pulse Generator"),
    TARGET_STRING("PulseWidth"), 0, 0, 0 },

  { 54, TARGET_STRING("auto_pilot_upl/AEB/AEB_Outputs/Pulse Generator"),
    TARGET_STRING("PhaseDelay"), 0, 0, 0 },

  { 55, TARGET_STRING("auto_pilot_upl/AEB/AEB_Outputs/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 56, TARGET_STRING("auto_pilot_upl/AEB/AEB_Outputs/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 57, TARGET_STRING("auto_pilot_upl/AP/AP_Inputs/Gain4"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 58, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 59, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Compare To Constant4"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 60, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Compare To Constant5"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 61, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Compare To Constant6"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 62, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Compare To Constant8"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 63, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Compare To Constant9"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 64, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Discrete Derivative"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 65, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Discrete Derivative1"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 66, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 67, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 68, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 69, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Gain2"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 70, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Gain3"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 71, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Gain4"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 72, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Integrator"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 73, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Integrator1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 74, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 75, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Memory1"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 76, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Memory2"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 77, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Rate Transition5"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 78, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Rate Transition8"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 79, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Rate Limiter"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 80, TARGET_STRING("auto_pilot_upl/INPUT/Inputs for CRT/ACC_Output_Brake_Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 81, TARGET_STRING("auto_pilot_upl/INPUT/Inputs for CRT/AEB_Output_Brake_Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 82, TARGET_STRING("auto_pilot_upl/OUTPUT/VI-CarRealTime_Outputs/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 83, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Constant"),
    TARGET_STRING("Value"), 0, 2, 0 },

  { 84, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 85, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P1"), 0, 3, 0 },

  { 86, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P2"), 0, 0, 0 },

  { 87, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P3"), 0, 1, 0 },

  { 88, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P4"), 0, 4, 0 },

  { 89, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P5"), 0, 0, 0 },

  { 90, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P6"), 0, 0, 0 },

  { 91, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera"),
    TARGET_STRING("P7"), 0, 0, 0 },

  { 92, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P1"), 0, 3, 0 },

  { 93, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P2"), 0, 0, 0 },

  { 94, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P3"), 0, 1, 0 },

  { 95, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P4"), 0, 5, 0 },

  { 96, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P5"), 0, 0, 0 },

  { 97, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P6"), 0, 0, 0 },

  { 98, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1"),
    TARGET_STRING("P7"), 0, 0, 0 },

  { 99, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_State_Manager"),
    TARGET_STRING("P1"), 0, 3, 0 },

  { 100, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_State_Manager"),
    TARGET_STRING("P2"), 0, 0, 0 },

  { 101, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_State_Manager"),
    TARGET_STRING("P3"), 0, 1, 0 },

  { 102, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_State_Manager"),
    TARGET_STRING("P4"), 0, 0, 0 },

  { 103, TARGET_STRING("auto_pilot_upl/OUTPUT/rough data reporting/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 104, TARGET_STRING("auto_pilot_upl/OUTPUT/rough data reporting/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 105, TARGET_STRING("auto_pilot_upl/ACC/ACC_Inputs/ADAS_map/Detect Decrease"),
    TARGET_STRING("vinit"), 0, 0, 0 },

  { 106, TARGET_STRING("auto_pilot_upl/ACC/ACC_Inputs/ADAS_map/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 107, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID"),
    TARGET_STRING("Kb"), 0, 0, 0 },

  { 108, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Detect Increase"),
    TARGET_STRING("vinit"), 0, 0, 0 },

  { 109, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Detect Increase1"),
    TARGET_STRING("vinit"), 0, 0, 0 },

  { 110, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1"),
    TARGET_STRING("InitialConditionForIntegrator"), 0, 0, 0 },

  { 111, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1"),
    TARGET_STRING("Kb"), 0, 0, 0 },

  { 112, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order10"),
    TARGET_STRING("PoleZ"), 0, 0, 0 },

  { 113, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order10"),
    TARGET_STRING("ICPrevOutput"), 0, 0, 0 },

  { 114, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order11"),
    TARGET_STRING("PoleZ"), 0, 0, 0 },

  { 115, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order11"),
    TARGET_STRING("ICPrevOutput"), 0, 0, 0 },

  { 116, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order4"),
    TARGET_STRING("PoleZ"), 0, 0, 0 },

  { 117, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order4"),
    TARGET_STRING("ICPrevOutput"), 0, 0, 0 },

  { 118, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order5"),
    TARGET_STRING("PoleZ"), 0, 0, 0 },

  { 119, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order5"),
    TARGET_STRING("ICPrevOutput"), 0, 0, 0 },

  { 120, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order6"),
    TARGET_STRING("PoleZ"), 0, 0, 0 },

  { 121, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order6"),
    TARGET_STRING("ICPrevOutput"), 0, 0, 0 },

  { 122, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order7"),
    TARGET_STRING("PoleZ"), 0, 0, 0 },

  { 123, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order7"),
    TARGET_STRING("ICPrevOutput"), 0, 0, 0 },

  { 124, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order8"),
    TARGET_STRING("PoleZ"), 0, 0, 0 },

  { 125, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order8"),
    TARGET_STRING("ICPrevOutput"), 0, 0, 0 },

  { 126, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order9"),
    TARGET_STRING("PoleZ"), 0, 0, 0 },

  { 127, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order9"),
    TARGET_STRING("ICPrevOutput"), 0, 0, 0 },

  { 128, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 129, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_Brake_Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 130, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_Brake_Gain2"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 131, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 132, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Memory1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 133, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Memory2"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 134, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Saturation1"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 135, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Saturation1"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 136, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Saturation2"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 137, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Saturation2"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 138, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Saturation3"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 139, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Saturation3"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 140, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Saturation4"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 141, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Saturation4"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 142, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Saturation8"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 143, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Saturation8"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 144, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Saturation9"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 145, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Saturation9"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 146, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Target_Distance_Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 147, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 148, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 149, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Constant2"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 150, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Constant3"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 151, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Constant4"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 152, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Detect Increase"),
    TARGET_STRING("vinit"), 1, 0, 0 },

  { 153, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Detect Increase1"),
    TARGET_STRING("vinit"), 0, 0, 0 },

  { 154, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 155, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 156, TARGET_STRING("auto_pilot_upl/ACC/ACC_Outputs/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 157, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/AEB_Trigger/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 158, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/AEB_Trigger/Delay"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 159, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/AEB_Trigger/Delay1"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 160, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/AEB_Trigger/Delay2"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 161, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 162, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Compare To Zero1/Constant"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 163, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Compare To Zero2/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 164, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Compare To Zero3/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 165, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Distance_To_Collision_computation/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 166, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/derivation_speed/Discrete Derivative"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 167, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/derivation_speed/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 168, TARGET_STRING("auto_pilot_upl/AEB/AEB_Outputs/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 169, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 170, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Discrete Derivative/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 171, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Discrete Derivative1/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 172, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 173, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Rate Limiter Dynamic/Delay Input2"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 174, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Rate Limiter Dynamic/sample time"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 175, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_Speed_Distance_Gain/Detect Increase"),
    TARGET_STRING("vinit"), 0, 0, 0 },

  { 176, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_Speed_Distance_Gain/Detect Increase1"),
    TARGET_STRING("vinit"), 0, 0, 0 },

  { 177, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_Speed_Distance_Gain/Gain"),
    TARGET_STRING("Gain"), 2, 0, 1 },

  { 178, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_Speed_Distance_Gain/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 179, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_Speed_Distance_Gain/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 180, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 181, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID"),
    TARGET_STRING("InitialConditionForIntegrator"), 0, 0, 0 },

  { 182, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID"),
    TARGET_STRING("DifferentiatorICPrevScaledInput"), 0, 0, 0 },

  { 183, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID"),
    TARGET_STRING("Kb"), 0, 0, 0 },

  { 184, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 185, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 186, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Zero3/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 187, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_ClosestTargetDistance/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 188, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_ClosestTargetId/Compare To Constant"),
    TARGET_STRING("const"), 1, 0, 0 },

  { 189, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_ClosestTargetId/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 190, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_ClosestTargetId/Compare To Constant2"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 191, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_ClosestTargetId/Compare To Constant3"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 192, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_ClosestTargetId/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 193, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_InCurvedLane_mux/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 194, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_InCurvedLane_mux/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 195, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Collision_Identifier_mux   /Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 196, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Collision_Identifier_mux   /Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 197, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Collision_Identifier_mux   /Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 198, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_X_TimeToCollision_mux/Discrete Derivative"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 199, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_X_TimeToCollision_mux/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 200, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_X_TimeToCollision_mux/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 201, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_X_TimeToCollision_mux/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 202, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Discrete Derivative1"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 203, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Discrete Derivative2"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 204, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Lane_Left_Edge_Y_Distance"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 205, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Lane_Right_Edge_Y_Distance"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 206, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 207, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Gain2"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 208, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 209, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 210, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Saturation1"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 211, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Saturation1"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 212, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/derivation_speed/Discrete Derivative/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 213, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Pulse Generator"),
    TARGET_STRING("Amplitude"), 0, 0, 0 },

  { 214, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Pulse Generator"),
    TARGET_STRING("Period"), 0, 0, 0 },

  { 215, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Pulse Generator"),
    TARGET_STRING("PulseWidth"), 0, 0, 0 },

  { 216, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Pulse Generator"),
    TARGET_STRING("PhaseDelay"), 0, 0, 0 },

  { 217, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Gain2"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 218, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Discrete Filter"),
    TARGET_STRING("Numerator"), 0, 1, 0 },

  { 219, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Discrete Filter"),
    TARGET_STRING("Denominator"), 0, 1, 0 },

  { 220, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Discrete Filter"),
    TARGET_STRING("InitialStates"), 0, 0, 0 },

  { 221, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Discrete Filter1"),
    TARGET_STRING("Numerator"), 0, 1, 0 },

  { 222, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Discrete Filter1"),
    TARGET_STRING("Denominator"), 0, 1, 0 },

  { 223, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/Discrete Filter1"),
    TARGET_STRING("InitialStates"), 0, 0, 0 },

  { 224, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/multiagent radar  SimpleRadar_... are single double representing id, yaw, range, power_db, range_rate, yaw_rate, status/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 225, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/multiagent radar  SimpleRadar_... are single double representing id, yaw, range, power_db, range_rate, yaw_rate, status/Constant2"),
    TARGET_STRING("Value"), 0, 3, 0 },

  { 226, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/multiagent radar  SimpleRadar_... are single double representing id, yaw, range, power_db, range_rate, yaw_rate, status/Constant3"),
    TARGET_STRING("Value"), 0, 3, 0 },

  { 227, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/multiagent radar  SimpleRadar_... are single double representing id, yaw, range, power_db, range_rate, yaw_rate, status/Constant4"),
    TARGET_STRING("Value"), 0, 3, 0 },

  { 228, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/multiagent radar  SimpleRadar_... are single double representing id, yaw, range, power_db, range_rate, yaw_rate, status/Constant5"),
    TARGET_STRING("Value"), 0, 3, 0 },

  { 229, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/multiagent radar  SimpleRadar_... are single double representing id, yaw, range, power_db, range_rate, yaw_rate, status/Constant6"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 230, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/multiagent radar  SimpleRadar_... are single double representing id, yaw, range, power_db, range_rate, yaw_rate, status/Constant7"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 231, TARGET_STRING("auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/obstacle detection /Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 232, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_X_TimeToCollision_mux/Discrete Derivative/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 233, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Discrete Derivative1/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 234, TARGET_STRING("auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Discrete Derivative2/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 235, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Integrator/Discrete/Integrator"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 236, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Integrator/Discrete/Integrator"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 237, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Integrator/Discrete/Integrator"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 238, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Integrator/Discrete/Integrator"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 239, TARGET_STRING("auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Filter/Differentiator/Tsamp/Internal Ts/Tsamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 240, TARGET_STRING("auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Filter/Differentiator/Tsamp/Internal Ts/Tsamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Tunable variable parameters */
static const rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 241, TARGET_STRING("ACC_Adaptive_P"), 0, 6, 0 },

  { 242, TARGET_STRING("ACC_Classic_I"), 0, 0, 0 },

  { 243, TARGET_STRING("ACC_Classic_P"), 0, 0, 0 },

  { 244, TARGET_STRING("ACC_MaxBrake"), 0, 0, 0 },

  { 245, TARGET_STRING("ACC_MaxThrottle"), 0, 0, 0 },

  { 246, TARGET_STRING("ACC_Module_Activity_Flag"), 0, 0, 0 },

  { 247, TARGET_STRING("ACC_Ready_Speed"), 0, 0, 0 },

  { 248, TARGET_STRING("ACC_SensorMaxDistance"), 0, 0, 0 },

  { 249, TARGET_STRING("ACC_Speed_Distance_Gain"), 0, 7, 0 },

  { 250, TARGET_STRING("ACC_Speed_Distance_control"), 0, 0, 0 },

  { 251, TARGET_STRING("ADAS_Control_Mode"), 0, 0, 0 },

  { 252, TARGET_STRING("AEB_Distance_To_Collision_Brake"), 0, 0, 0 },

  { 253, TARGET_STRING("AEB_Gain"), 0, 6, 0 },

  { 254, TARGET_STRING("AEB_Gain_set"), 0, 0, 0 },

  { 255, TARGET_STRING("AEB_Gain_set_mult"), 0, 0, 0 },

  { 256, TARGET_STRING("AEB_Max_Decel"), 0, 6, 0 },

  { 257, TARGET_STRING("AEB_Max_Speed"), 0, 0, 0 },

  { 258, TARGET_STRING("AEB_Min_Distance_at_Stop"), 0, 0, 0 },

  { 259, TARGET_STRING("AEB_Module_Activity_Flag"), 0, 0, 0 },

  { 260, TARGET_STRING("AEB_Pedestrian_type"), 0, 0, 0 },

  { 261, TARGET_STRING("AEB_Steer_Max"), 0, 0, 0 },

  { 262, TARGET_STRING("AP_Activity_Flag"), 0, 0, 0 },

  { 263, TARGET_STRING("AP_D"), 0, 6, 0 },

  { 264, TARGET_STRING("AP_Dyn_Rate_Limiter_Gain"), 0, 0, 0 },

  { 265, TARGET_STRING("AP_Dyn_Rate_Limiter_Power"), 0, 0, 0 },

  { 266, TARGET_STRING("AP_Error_Max"), 0, 0, 0 },

  { 267, TARGET_STRING("AP_I"), 0, 6, 0 },

  { 268, TARGET_STRING("AP_Max_Error_dydt_Disable"), 0, 0, 0 },

  { 269, TARGET_STRING("AP_On_Request_Time"), 0, 0, 0 },

  { 270, TARGET_STRING("AP_P"), 0, 6, 0 },

  { 271, TARGET_STRING("AP_Steer_Error_Max"), 0, 0, 0 },

  { 272, TARGET_STRING("AP_Steer_Rate_Max_radps"), 0, 0, 0 },

  { 273, TARGET_STRING("AP_Transition_Rate"), 0, 0, 0 },

  { 274, TARGET_STRING("Lane_Width"), 0, 0, 0 },

  { 275, TARGET_STRING("No_Target_Display_Value"), 0, 0, 0 },

  { 276, TARGET_STRING("radar_source"), 0, 0, 0 },

  { 277, TARGET_STRING("vehicle_width"), 0, 0, 0 },

  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Declare Data Addresses statically */
static void* rtDataAddrMap[] = {
  &auto_pilot_upl_P.CompareToConstant_const_g,/* 0: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant1_const_bt,/* 1: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant2_const,/* 2: Mask Parameter */
  &auto_pilot_upl_P.gear_change_max_speed_down_const,/* 3: Mask Parameter */
  &auto_pilot_upl_P.gear_change_max_speed_up_const,/* 4: Mask Parameter */
  &auto_pilot_upl_P.shift_paddle_threshold_const,/* 5: Mask Parameter */
  &auto_pilot_upl_P.shift_paddle_threshold1_const,/* 6: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant_const,/* 7: Mask Parameter */
  &auto_pilot_upl_P.DetectIncrease_vinit_ao,/* 8: Mask Parameter */
  &auto_pilot_upl_P.Constant_Value_p,  /* 9: Block Parameter */
  &auto_pilot_upl_P.Constant1_Value,   /* 10: Block Parameter */
  &auto_pilot_upl_P.Gain1_Gain,        /* 11: Block Parameter */
  &auto_pilot_upl_P.Gain_Gain,         /* 12: Block Parameter */
  &auto_pilot_upl_P.RateLimiter_RisingLim_p,/* 13: Block Parameter */
  &auto_pilot_upl_P.RateLimiter_FallingLim_f,/* 14: Block Parameter */
  &auto_pilot_upl_P.Switch_Threshold_c,/* 15: Block Parameter */
  &auto_pilot_upl_P.Gain_Gain_nj,      /* 16: Block Parameter */
  &auto_pilot_upl_P.Gain1_Gain_m,      /* 17: Block Parameter */
  &auto_pilot_upl_P.Gain2_Gain_k,      /* 18: Block Parameter */
  &auto_pilot_upl_P.Gain3_Gain,        /* 19: Block Parameter */
  &auto_pilot_upl_P.Gain4_Gain_e,      /* 20: Block Parameter */
  &auto_pilot_upl_P.Gain5_Gain,        /* 21: Block Parameter */
  &auto_pilot_upl_P.AEB_Approaching_Speed_Threshold_const,/* 22: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant_const_b,/* 23: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant1_const_l,/* 24: Mask Parameter */
  &auto_pilot_upl_P.DetectChange_vinit,/* 25: Mask Parameter */
  &auto_pilot_upl_P.Constant_Value_m,  /* 26: Block Parameter */
  &auto_pilot_upl_P.Constant1_Value_i, /* 27: Block Parameter */
  &auto_pilot_upl_P.Constant2_Value_p, /* 28: Block Parameter */
  &auto_pilot_upl_P.Constant3_Value,   /* 29: Block Parameter */
  &auto_pilot_upl_P.PulseGenerator_Amp,/* 30: Block Parameter */
  &auto_pilot_upl_P.PulseGenerator_Period,/* 31: Block Parameter */
  &auto_pilot_upl_P.PulseGenerator_Duty,/* 32: Block Parameter */
  &auto_pilot_upl_P.PulseGenerator_PhaseDelay,/* 33: Block Parameter */
  &auto_pilot_upl_P.Gain1_Gain_d,      /* 34: Block Parameter */
  &auto_pilot_upl_P.RateTransition5_InitialCondition_e,/* 35: Block Parameter */
  &auto_pilot_upl_P.RateTransition6_InitialCondition,/* 36: Block Parameter */
  &auto_pilot_upl_P.RateTransition7_InitialCondition,/* 37: Block Parameter */
  &auto_pilot_upl_P.RateLimiter_RisingLim,/* 38: Block Parameter */
  &auto_pilot_upl_P.RateLimiter_FallingLim,/* 39: Block Parameter */
  &auto_pilot_upl_P.RateLimiter1_RisingLim,/* 40: Block Parameter */
  &auto_pilot_upl_P.RateLimiter1_FallingLim,/* 41: Block Parameter */
  &auto_pilot_upl_P.RateLimiter1_IC,   /* 42: Block Parameter */
  &auto_pilot_upl_P.Saturation_UpperSat_e,/* 43: Block Parameter */
  &auto_pilot_upl_P.Saturation_LowerSat_ll,/* 44: Block Parameter */
  &auto_pilot_upl_P.Switch2_Threshold, /* 45: Block Parameter */
  &auto_pilot_upl_P.Delay_InitialCondition,/* 46: Block Parameter */
  &auto_pilot_upl_P.Delay1_InitialCondition,/* 47: Block Parameter */
  &auto_pilot_upl_P.filtering_NumCoef[0],/* 48: Block Parameter */
  &auto_pilot_upl_P.filtering_DenCoef[0],/* 49: Block Parameter */
  &auto_pilot_upl_P.filtering_InitialStates,/* 50: Block Parameter */
  &auto_pilot_upl_P.PulseGenerator_Amp_f,/* 51: Block Parameter */
  &auto_pilot_upl_P.PulseGenerator_Period_n,/* 52: Block Parameter */
  &auto_pilot_upl_P.PulseGenerator_Duty_n,/* 53: Block Parameter */
  &auto_pilot_upl_P.PulseGenerator_PhaseDelay_g,/* 54: Block Parameter */
  &auto_pilot_upl_P.Gain_Gain_f,       /* 55: Block Parameter */
  &auto_pilot_upl_P.Switch_Threshold,  /* 56: Block Parameter */
  &auto_pilot_upl_P.Gain4_Gain,        /* 57: Block Parameter */
  &auto_pilot_upl_P.CompareToConstant1_const_b,/* 58: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant4_const_n,/* 59: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant5_const,/* 60: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant6_const,/* 61: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant8_const,/* 62: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant9_const,/* 63: Mask Parameter */
  &auto_pilot_upl_P.DiscreteDerivative_ICPrevScaledInput_d,/* 64: Mask Parameter */
  &auto_pilot_upl_P.DiscreteDerivative1_ICPrevScaledInput,/* 65: Mask Parameter */
  &auto_pilot_upl_P.Constant_Value_mq, /* 66: Block Parameter */
  &auto_pilot_upl_P.Constant2_Value_b, /* 67: Block Parameter */
  &auto_pilot_upl_P.Gain_Gain_p,       /* 68: Block Parameter */
  &auto_pilot_upl_P.Gain2_Gain,        /* 69: Block Parameter */
  &auto_pilot_upl_P.Gain3_Gain_j,      /* 70: Block Parameter */
  &auto_pilot_upl_P.Gain4_Gain_p,      /* 71: Block Parameter */
  &auto_pilot_upl_P.Integrator_IC,     /* 72: Block Parameter */
  &auto_pilot_upl_P.Integrator1_IC,    /* 73: Block Parameter */
  &auto_pilot_upl_P.Memory_InitialCondition_g,/* 74: Block Parameter */
  &auto_pilot_upl_P.Memory1_InitialCondition_l,/* 75: Block Parameter */
  &auto_pilot_upl_P.Memory2_InitialCondition_c,/* 76: Block Parameter */
  &auto_pilot_upl_P.RateTransition5_InitialCondition,/* 77: Block Parameter */
  &auto_pilot_upl_P.RateTransition8_InitialCondition,/* 78: Block Parameter */
  &auto_pilot_upl_P.RateLimiter_IC,    /* 79: Block Parameter */
  &auto_pilot_upl_P.ACC_Output_Brake_Gain_Gain,/* 80: Block Parameter */
  &auto_pilot_upl_P.AEB_Output_Brake_Gain_Gain,/* 81: Block Parameter */
  &auto_pilot_upl_P.Gain_Gain_a,       /* 82: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_lf[0],/* 83: Block Parameter */
  &auto_pilot_upl_P.Memory_InitialCondition_n,/* 84: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P1[0],/* 85: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P2,/* 86: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P3[0],/* 87: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P4[0],/* 88: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P5,/* 89: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P6,/* 90: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P7,/* 91: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P1[0],/* 92: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P2,/* 93: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P3[0],/* 94: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P4[0],/* 95: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P5,/* 96: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P6,/* 97: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P7,/* 98: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_State_Manager_P1[0],/* 99: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_State_Manager_P2,/* 100: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_State_Manager_P3[0],/* 101: Block Parameter */
  &auto_pilot_upl_P.VI_WorldSim_State_Manager_P4,/* 102: Block Parameter */
  &auto_pilot_upl_P.CompareToConstant_const_d,/* 103: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant1_const_f,/* 104: Mask Parameter */
  &auto_pilot_upl_P.DetectDecrease_vinit,/* 105: Mask Parameter */
  &auto_pilot_upl_P.Memory_InitialCondition,/* 106: Block Parameter */
  &auto_pilot_upl_P.ACC_PID_Kb,        /* 107: Mask Parameter */
  &auto_pilot_upl_P.DetectIncrease_vinit,/* 108: Mask Parameter */
  &auto_pilot_upl_P.DetectIncrease1_vinit_p,/* 109: Mask Parameter */
  &auto_pilot_upl_P.DiscretePIDController1_InitialConditionForIntegrator,/* 110: Mask Parameter */
  &auto_pilot_upl_P.DiscretePIDController1_Kb,/* 111: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder10_PoleZ,/* 112: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder10_ICPrevOutput,/* 113: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder11_PoleZ,/* 114: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder11_ICPrevOutput,/* 115: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder4_PoleZ,/* 116: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder4_ICPrevOutput,/* 117: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder5_PoleZ,/* 118: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder5_ICPrevOutput,/* 119: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder6_PoleZ,/* 120: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder6_ICPrevOutput,/* 121: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder7_PoleZ,/* 122: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder7_ICPrevOutput,/* 123: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder8_PoleZ,/* 124: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder8_ICPrevOutput,/* 125: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder9_PoleZ,/* 126: Mask Parameter */
  &auto_pilot_upl_P.TransferFcnFirstOrder9_ICPrevOutput,/* 127: Mask Parameter */
  &auto_pilot_upl_P.Constant_Value_oj, /* 128: Block Parameter */
  &auto_pilot_upl_P.ACC_Brake_Gain1_Gain,/* 129: Block Parameter */
  &auto_pilot_upl_P.ACC_Brake_Gain2_Gain,/* 130: Block Parameter */
  &auto_pilot_upl_P.Memory_InitialCondition_l,/* 131: Block Parameter */
  &auto_pilot_upl_P.Memory1_InitialCondition,/* 132: Block Parameter */
  &auto_pilot_upl_P.Memory2_InitialCondition,/* 133: Block Parameter */
  &auto_pilot_upl_P.Saturation1_UpperSat,/* 134: Block Parameter */
  &auto_pilot_upl_P.Saturation1_LowerSat,/* 135: Block Parameter */
  &auto_pilot_upl_P.Saturation2_UpperSat,/* 136: Block Parameter */
  &auto_pilot_upl_P.Saturation2_LowerSat,/* 137: Block Parameter */
  &auto_pilot_upl_P.Saturation3_UpperSat,/* 138: Block Parameter */
  &auto_pilot_upl_P.Saturation3_LowerSat,/* 139: Block Parameter */
  &auto_pilot_upl_P.Saturation4_UpperSat,/* 140: Block Parameter */
  &auto_pilot_upl_P.Saturation4_LowerSat,/* 141: Block Parameter */
  &auto_pilot_upl_P.Saturation8_UpperSat,/* 142: Block Parameter */
  &auto_pilot_upl_P.Saturation8_LowerSat,/* 143: Block Parameter */
  &auto_pilot_upl_P.Saturation9_UpperSat,/* 144: Block Parameter */
  &auto_pilot_upl_P.Saturation9_LowerSat,/* 145: Block Parameter */
  &auto_pilot_upl_P.Target_Distance_Saturation_LowerSat,/* 146: Block Parameter */
  &auto_pilot_upl_P.Switch2_Threshold_d,/* 147: Block Parameter */
  &auto_pilot_upl_P.CompareToConstant1_const,/* 148: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant2_const_f,/* 149: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant3_const,/* 150: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant4_const,/* 151: Mask Parameter */
  &auto_pilot_upl_P.DetectIncrease_vinit_m,/* 152: Mask Parameter */
  &auto_pilot_upl_P.DetectIncrease1_vinit,/* 153: Mask Parameter */
  &auto_pilot_upl_P.Constant_Value_k,  /* 154: Block Parameter */
  &auto_pilot_upl_P.Memory_InitialCondition_p,/* 155: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_g,  /* 156: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_ne, /* 157: Block Parameter */
  &auto_pilot_upl_P.Delay_InitialCondition_h,/* 158: Block Parameter */
  &auto_pilot_upl_P.Delay1_InitialCondition_b,/* 159: Block Parameter */
  &auto_pilot_upl_P.Delay2_InitialCondition,/* 160: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_o,  /* 161: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_b,  /* 162: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_az, /* 163: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_l,  /* 164: Block Parameter */
  &auto_pilot_upl_P.Gain_Gain_g,       /* 165: Block Parameter */
  &auto_pilot_upl_P.DiscreteDerivative_ICPrevScaledInput,/* 166: Mask Parameter */
  &auto_pilot_upl_P.Gain_Gain_n,       /* 167: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_e,  /* 168: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_c,  /* 169: Block Parameter */
  &auto_pilot_upl_P.TSamp_WtEt_b,      /* 170: Block Parameter */
  &auto_pilot_upl_P.TSamp_WtEt_h,      /* 171: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_m5, /* 172: Block Parameter */
  &auto_pilot_upl_P.DelayInput2_InitialCondition,/* 173: Block Parameter */
  &auto_pilot_upl_P.sampletime_WtEt,   /* 174: Block Parameter */
  &auto_pilot_upl_P.DetectIncrease_vinit_a,/* 175: Mask Parameter */
  &auto_pilot_upl_P.DetectIncrease1_vinit_j,/* 176: Mask Parameter */
  &auto_pilot_upl_P.Gain_Gain_c,       /* 177: Block Parameter */
  &auto_pilot_upl_P.Saturation_UpperSat,/* 178: Block Parameter */
  &auto_pilot_upl_P.Saturation_LowerSat,/* 179: Block Parameter */
  &auto_pilot_upl_P.Constant_Value,    /* 180: Block Parameter */
  &auto_pilot_upl_P.tACC_PID_InitialConditionForIntegrator,/* 181: Mask Parameter */
  &auto_pilot_upl_P.tACC_PID_DifferentiatorICPrevScaledInput,/* 182: Mask Parameter */
  &auto_pilot_upl_P.tACC_PID_Kb,       /* 183: Mask Parameter */
  &auto_pilot_upl_P.Constant_Value_n4, /* 184: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_f,  /* 185: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_a,  /* 186: Block Parameter */
  &auto_pilot_upl_P.Switch1_Threshold, /* 187: Block Parameter */
  &auto_pilot_upl_P.CompareToConstant_const_l,/* 188: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant1_const_p,/* 189: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant2_const_p,/* 190: Mask Parameter */
  &auto_pilot_upl_P.CompareToConstant3_const_m,/* 191: Mask Parameter */
  &auto_pilot_upl_P.Constant_Value_n,  /* 192: Block Parameter */
  &auto_pilot_upl_P.Gain_Gain_ff,      /* 193: Block Parameter */
  &auto_pilot_upl_P.Gain1_Gain_b,      /* 194: Block Parameter */
  &auto_pilot_upl_P.Constant1_Value_d, /* 195: Block Parameter */
  &auto_pilot_upl_P.Saturation_UpperSat_j,/* 196: Block Parameter */
  &auto_pilot_upl_P.Saturation_LowerSat_l,/* 197: Block Parameter */
  &auto_pilot_upl_P.DiscreteDerivative_ICPrevScaledInput_j,/* 198: Mask Parameter */
  &auto_pilot_upl_P.Gain_Gain_nd,      /* 199: Block Parameter */
  &auto_pilot_upl_P.Saturation_UpperSat_o,/* 200: Block Parameter */
  &auto_pilot_upl_P.Saturation_LowerSat_j,/* 201: Block Parameter */
  &auto_pilot_upl_P.DiscreteDerivative1_ICPrevScaledInput_g,/* 202: Mask Parameter */
  &auto_pilot_upl_P.DiscreteDerivative2_ICPrevScaledInput,/* 203: Mask Parameter */
  &auto_pilot_upl_P.Lane_Left_Edge_Y_Distance_Value,/* 204: Block Parameter */
  &auto_pilot_upl_P.Lane_Right_Edge_Y_Distance_Value,/* 205: Block Parameter */
  &auto_pilot_upl_P.Gain1_Gain_l,      /* 206: Block Parameter */
  &auto_pilot_upl_P.Gain2_Gain_n,      /* 207: Block Parameter */
  &auto_pilot_upl_P.Saturation_UpperSat_i,/* 208: Block Parameter */
  &auto_pilot_upl_P.Saturation_LowerSat_i,/* 209: Block Parameter */
  &auto_pilot_upl_P.Saturation1_UpperSat_c,/* 210: Block Parameter */
  &auto_pilot_upl_P.Saturation1_LowerSat_d,/* 211: Block Parameter */
  &auto_pilot_upl_P.TSamp_WtEt,        /* 212: Block Parameter */
  &auto_pilot_upl_P.PulseGenerator_Amp_g,/* 213: Block Parameter */
  &auto_pilot_upl_P.PulseGenerator_Period_j,/* 214: Block Parameter */
  &auto_pilot_upl_P.PulseGenerator_Duty_d,/* 215: Block Parameter */
  &auto_pilot_upl_P.PulseGenerator_PhaseDelay_e,/* 216: Block Parameter */
  &auto_pilot_upl_P.Gain2_Gain_f,      /* 217: Block Parameter */
  &auto_pilot_upl_P.DiscreteFilter_NumCoef[0],/* 218: Block Parameter */
  &auto_pilot_upl_P.DiscreteFilter_DenCoef[0],/* 219: Block Parameter */
  &auto_pilot_upl_P.DiscreteFilter_InitialStates,/* 220: Block Parameter */
  &auto_pilot_upl_P.DiscreteFilter1_NumCoef[0],/* 221: Block Parameter */
  &auto_pilot_upl_P.DiscreteFilter1_DenCoef[0],/* 222: Block Parameter */
  &auto_pilot_upl_P.DiscreteFilter1_InitialStates,/* 223: Block Parameter */
  &auto_pilot_upl_P.Constant_Value_pa, /* 224: Block Parameter */
  &auto_pilot_upl_P.Constant2_Value[0],/* 225: Block Parameter */
  &auto_pilot_upl_P.Constant3_Value_g[0],/* 226: Block Parameter */
  &auto_pilot_upl_P.Constant4_Value[0],/* 227: Block Parameter */
  &auto_pilot_upl_P.Constant5_Value[0],/* 228: Block Parameter */
  &auto_pilot_upl_P.Constant6_Value,   /* 229: Block Parameter */
  &auto_pilot_upl_P.Constant7_Value,   /* 230: Block Parameter */
  &auto_pilot_upl_P.Gain_Gain_j,       /* 231: Block Parameter */
  &auto_pilot_upl_P.TSamp_WtEt_i,      /* 232: Block Parameter */
  &auto_pilot_upl_P.TSamp_WtEt_a,      /* 233: Block Parameter */
  &auto_pilot_upl_P.TSamp_WtEt_f,      /* 234: Block Parameter */
  &auto_pilot_upl_P.Integrator_gainval_pc,/* 235: Block Parameter */
  &auto_pilot_upl_P.Integrator_gainval,/* 236: Block Parameter */
  &auto_pilot_upl_P.Integrator_gainval_f,/* 237: Block Parameter */
  &auto_pilot_upl_P.Integrator_gainval_p,/* 238: Block Parameter */
  &auto_pilot_upl_P.Tsamp_WtEt_d,      /* 239: Block Parameter */
  &auto_pilot_upl_P.Tsamp_WtEt,        /* 240: Block Parameter */
  &auto_pilot_upl_P.ACC_Adaptive_P[0], /* 241: Model Parameter */
  &auto_pilot_upl_P.ACC_Classic_I,     /* 242: Model Parameter */
  &auto_pilot_upl_P.ACC_Classic_P,     /* 243: Model Parameter */
  &auto_pilot_upl_P.ACC_MaxBrake,      /* 244: Model Parameter */
  &auto_pilot_upl_P.ACC_MaxThrottle,   /* 245: Model Parameter */
  &auto_pilot_upl_P.ACC_Module_Activity_Flag,/* 246: Model Parameter */
  &auto_pilot_upl_P.ACC_Ready_Speed,   /* 247: Model Parameter */
  &auto_pilot_upl_P.ACC_SensorMaxDistance,/* 248: Model Parameter */
  &auto_pilot_upl_P.ACC_Speed_Distance_Gain[0],/* 249: Model Parameter */
  &auto_pilot_upl_P.ACC_Speed_Distance_control,/* 250: Model Parameter */
  &auto_pilot_upl_P.ADAS_Control_Mode, /* 251: Model Parameter */
  &auto_pilot_upl_P.AEB_Distance_To_Collision_Brake,/* 252: Model Parameter */
  &auto_pilot_upl_P.AEB_Gain[0],       /* 253: Model Parameter */
  &auto_pilot_upl_P.AEB_Gain_set,      /* 254: Model Parameter */
  &auto_pilot_upl_P.AEB_Gain_set_mult, /* 255: Model Parameter */
  &auto_pilot_upl_P.AEB_Max_Decel[0],  /* 256: Model Parameter */
  &auto_pilot_upl_P.AEB_Max_Speed,     /* 257: Model Parameter */
  &auto_pilot_upl_P.AEB_Min_Distance_at_Stop,/* 258: Model Parameter */
  &auto_pilot_upl_P.AEB_Module_Activity_Flag,/* 259: Model Parameter */
  &auto_pilot_upl_P.AEB_Pedestrian_type,/* 260: Model Parameter */
  &auto_pilot_upl_P.AEB_Steer_Max,     /* 261: Model Parameter */
  &auto_pilot_upl_P.AP_Activity_Flag,  /* 262: Model Parameter */
  &auto_pilot_upl_P.AP_D[0],           /* 263: Model Parameter */
  &auto_pilot_upl_P.AP_Dyn_Rate_Limiter_Gain,/* 264: Model Parameter */
  &auto_pilot_upl_P.AP_Dyn_Rate_Limiter_Power,/* 265: Model Parameter */
  &auto_pilot_upl_P.AP_Error_Max,      /* 266: Model Parameter */
  &auto_pilot_upl_P.AP_I[0],           /* 267: Model Parameter */
  &auto_pilot_upl_P.AP_Max_Error_dydt_Disable,/* 268: Model Parameter */
  &auto_pilot_upl_P.AP_On_Request_Time,/* 269: Model Parameter */
  &auto_pilot_upl_P.AP_P[0],           /* 270: Model Parameter */
  &auto_pilot_upl_P.AP_Steer_Error_Max,/* 271: Model Parameter */
  &auto_pilot_upl_P.AP_Steer_Rate_Max_radps,/* 272: Model Parameter */
  &auto_pilot_upl_P.AP_Transition_Rate,/* 273: Model Parameter */
  &auto_pilot_upl_P.Lane_Width,        /* 274: Model Parameter */
  &auto_pilot_upl_P.No_Target_Display_Value,/* 275: Model Parameter */
  &auto_pilot_upl_P.radar_source,      /* 276: Model Parameter */
  &auto_pilot_upl_P.vehicle_width,     /* 277: Model Parameter */
};

/* Declare Data Run-Time Dimension Buffer Addresses statically */
static int32_T* rtVarDimsAddrMap[] = {
  (NULL)
};

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), (uint8_T)SS_DOUBLE, 0, 0, 0 },

  { "unsigned char", "boolean_T", 0, 0, sizeof(boolean_T), (uint8_T)SS_BOOLEAN,
    0, 0, 0 },

  { "signed char", "int8_T", 0, 0, sizeof(int8_T), (uint8_T)SS_INT8, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static const rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 },

  { rtwCAPI_VECTOR, 2, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 },

  { rtwCAPI_VECTOR, 8, 2, 0 },

  { rtwCAPI_VECTOR, 10, 2, 0 },

  { rtwCAPI_VECTOR, 12, 2, 0 },

  { rtwCAPI_VECTOR, 14, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static const uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1,                                   /* 1 */
  1,                                   /* 2 */
  3,                                   /* 3 */
  64,                                  /* 4 */
  7,                                   /* 5 */
  1,                                   /* 6 */
  9,                                   /* 7 */
  1,                                   /* 8 */
  16,                                  /* 9 */
  1,                                   /* 10 */
  15,                                  /* 11 */
  1,                                   /* 12 */
  2,                                   /* 13 */
  1,                                   /* 14 */
  4                                    /* 15 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.0, 1.0
};

/* Fixed Point Map */
static const rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, (boolean_T)0 },

  { (const void *) &rtcapiStoredFloats[1], (const void *) &rtcapiStoredFloats[0],
    rtwCAPI_FIX_UNIFORM_SCALING, 8, -7, (boolean_T)1 }
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static const rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  {
    (NULL), (NULL), 0, 0
  }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { (NULL), 0,
    (NULL), 0,
    (NULL), 0 },

  { rtBlockParameters, 241,
    rtModelParameters, 37 },

  { (NULL), 0 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 4088153576U,
    3615441775U,
    845640061U,
    504932241U },
  (NULL), 0,
  (boolean_T)0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  auto_pilot_upl_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void auto_pilot_upl_InitializeDataMapInfo(void)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(auto_pilot_upl_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(auto_pilot_upl_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(auto_pilot_upl_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetDataAddressMap(auto_pilot_upl_M->DataMapInfo.mmi, rtDataAddrMap);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetVarDimsAddressMap(auto_pilot_upl_M->DataMapInfo.mmi,
    rtVarDimsAddrMap);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(auto_pilot_upl_M->DataMapInfo.mmi, (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(auto_pilot_upl_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetChildMMIArrayLen(auto_pilot_upl_M->DataMapInfo.mmi, 0);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C"
{

#endif

  void auto_pilot_upl_host_InitializeDataMapInfo
    (auto_pilot_upl_host_DataMapInfo_T *dataMap, const char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, (NULL));

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, (NULL));

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, (NULL));

    /* Set reference to submodels */
    rtwCAPI_SetChildMMIArray(dataMap->mmi, (NULL));
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 0);
  }

#ifdef __cplusplus

}

#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: auto_pilot_upl_capi.c */
