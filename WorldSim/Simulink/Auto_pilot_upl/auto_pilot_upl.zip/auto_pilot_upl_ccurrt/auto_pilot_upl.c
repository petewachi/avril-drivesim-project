/*
 * auto_pilot_upl.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "auto_pilot_upl".
 *
 * Model version              : 17.110
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Thu Feb  1 00:30:37 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "auto_pilot_upl.h"
#include "rtwtypes.h"
#include "auto_pilot_upl_private.h"
#include <string.h>
#include <math.h>
#include <emmintrin.h>
#include "rt_nonfinite.h"
#include "auto_pilot_upl_capi.h"
#include "zero_crossing_types.h"
#define auto_pilot_upl_period          (0.001)
#define auto_pilot_upl_period_d        (0.02)
#ifdef __cplusplus

extern "C"
{

#endif

  int checkMetaDataType(uint8_T slDataID, short cvtDataId);

#ifdef __cplusplus

}

#endif

#ifdef __cplusplus

extern "C"
{

#endif

  int checkMetaDataType(uint8_T slDataID, short cvtDataId);

#ifdef __cplusplus

}

#endif

void *pVI_DriveSim_Inputs_ECAT_BECKH_ANA3;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_transmission_gear;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_ECAT_BECKH_ANA4;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_ECAT_BECKH_DIG4;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_chassis_velocities_longitudinal;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Outputs_Vicrt_Status;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_driver_demands_brake;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_Wheel_Spindle_Steer_L1;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_Wheel_Spindle_Steer_R1;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_driver_demands_throttle;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_driver_demands_steering;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_Steering_System_DriveSim_Steering_Feedback_Torque;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_chassis_accelerations_lateral;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Outputs_chassis_accelerations_longitudinal;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_ECAT_BECKH_DIG3;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Inputs_Driver_Demands_brake;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Inputs_Driver_Demands_throttle;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_Control_VICRT_UPSHIFT_REQ;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Inputs_Driver_Demands_str_swa;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Inputs_steer_assist_torque;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_Control_VICRT_DOWNSHIFT_REQ;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_CarRealTime_Inputs_Driver_Demands_target_speed;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_ACC_ACC_On;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_ACC_ACC_On_Display;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_ACC_ACC_Ready;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_ACC_ACC_Ready_Display;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_ACC_ACC_Speed_Target_Display;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_ACC_ACC_Target_Id_Display;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_ACC_ACC_Target_Speed;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_AEB_AEB_BrakeDemand;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_AEB_AEB_On;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_AEB_AEB_Output_Active;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_AEB_AEB_Ready;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_AEB_AEB_Target_Id_Display;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_AEB_AEB_TimeToCollision;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_AP_AP_On;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_AP_AP_Ready;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_Generic_ADAS_Error;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pADAS_Outputs_AEB_AEB_TimeToCollision_Threshold;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pWorldSim_ego_Sensors_Lane_detector_LeftLane_Crossed;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pWorldSim_ego_Sensors_Lane_detector_LeftLane_Distance;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pWorldSim_ego_Sensors_Lane_detector_RightLane_Crossed;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pWorldSim_ego_Sensors_Lane_detector_RightLane_Distance;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pWorldSim_ego_Sensors_Front_VirtualCam_obstacleData;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_Control_VICRT_RESTART_REQ;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pVI_DriveSim_Inputs_Control_VICRT_RESTORE_REQ;
       // see model_private.h for rtwvariable declaration for modelvariables.txt
void *pWorldSim_ego_Sensors_Collision_Count;
       // see model_private.h for rtwvariable declaration for modelvariables.txt

/* Block signals (default storage) */
B_auto_pilot_upl_T auto_pilot_upl_B;

/* Continuous states */
X_auto_pilot_upl_T auto_pilot_upl_X;

/* Block states (default storage) */
DW_auto_pilot_upl_T auto_pilot_upl_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_auto_pilot_upl_T auto_pilot_upl_PrevZCX;

/* Real-time model */
static RT_MODEL_auto_pilot_upl_T auto_pilot_upl_M_;
RT_MODEL_auto_pilot_upl_T *const auto_pilot_upl_M = &auto_pilot_upl_M_;
static void rate_monotonic_scheduler(void);
time_T rt_SimUpdateDiscreteEvents(
  int_T rtmNumSampTimes, void *rtmTimingData, int_T *rtmSampleHitPtr, int_T
  *rtmPerTaskSampleHits )
{
  rtmSampleHitPtr[1] = rtmStepTask(auto_pilot_upl_M, 1);
  rtmSampleHitPtr[2] = rtmStepTask(auto_pilot_upl_M, 2);
  rtmSampleHitPtr[3] = rtmStepTask(auto_pilot_upl_M, 3);
  rtmSampleHitPtr[4] = rtmStepTask(auto_pilot_upl_M, 4);
  UNUSED_PARAMETER(rtmNumSampTimes);
  UNUSED_PARAMETER(rtmTimingData);
  UNUSED_PARAMETER(rtmPerTaskSampleHits);
  return(-1);
}

/*
 *         This function updates active task flag for each subrate
 *         and rate transition flags for tasks that exchange data.
 *         The function assumes rate-monotonic multitasking scheduler.
 *         The function must be called at model base rate so that
 *         the generated code self-manages all its subrates and rate
 *         transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* To ensure a deterministic data transfer between two rates,
   * data is transferred at the priority of a fast task and the frequency
   * of the slow task.  The following flags indicate when the data transfer
   * happens.  That is, a rate interaction flag is set true when both rates
   * will run, and false otherwise.
   */

  /* tid 1 shares data with slower tid rates: 2, 3, 4 */
  if (auto_pilot_upl_M->Timing.TaskCounters.TID[1] == 0) {
    auto_pilot_upl_M->Timing.RateInteraction.TID1_2 =
      (auto_pilot_upl_M->Timing.TaskCounters.TID[2] == 0);

    /* update PerTaskSampleHits matrix for non-inline sfcn */
    auto_pilot_upl_M->Timing.perTaskSampleHits[7] =
      auto_pilot_upl_M->Timing.RateInteraction.TID1_2;
    auto_pilot_upl_M->Timing.RateInteraction.TID1_3 =
      (auto_pilot_upl_M->Timing.TaskCounters.TID[3] == 0);

    /* update PerTaskSampleHits matrix for non-inline sfcn */
    auto_pilot_upl_M->Timing.perTaskSampleHits[8] =
      auto_pilot_upl_M->Timing.RateInteraction.TID1_3;
    auto_pilot_upl_M->Timing.RateInteraction.TID1_4 =
      (auto_pilot_upl_M->Timing.TaskCounters.TID[4] == 0);

    /* update PerTaskSampleHits matrix for non-inline sfcn */
    auto_pilot_upl_M->Timing.perTaskSampleHits[9] =
      auto_pilot_upl_M->Timing.RateInteraction.TID1_4;
  }

  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (auto_pilot_upl_M->Timing.TaskCounters.TID[2])++;
  if ((auto_pilot_upl_M->Timing.TaskCounters.TID[2]) > 9) {/* Sample time: [0.01s, 0.0s] */
    auto_pilot_upl_M->Timing.TaskCounters.TID[2] = 0;
  }

  (auto_pilot_upl_M->Timing.TaskCounters.TID[3])++;
  if ((auto_pilot_upl_M->Timing.TaskCounters.TID[3]) > 19) {/* Sample time: [0.02s, 0.0s] */
    auto_pilot_upl_M->Timing.TaskCounters.TID[3] = 0;
  }

  (auto_pilot_upl_M->Timing.TaskCounters.TID[4])++;
  if ((auto_pilot_upl_M->Timing.TaskCounters.TID[4]) > 39) {/* Sample time: [0.04s, 0.0s] */
    auto_pilot_upl_M->Timing.TaskCounters.TID[4] = 0;
  }
}

/* Simplified version of numjac.cpp, for use with RTW. */
void local_numjac( RTWSolverInfo *si, real_T *y, const real_T *Fty, real_T *fac,
                  real_T *dFdy )
{
  /* constants */
  real_T THRESH = 1e-6;
  real_T EPS = 2.2e-16;                /* utGetEps(); */
  real_T BL = pow(EPS, 0.75);
  real_T BU = pow(EPS, 0.25);
  real_T FACMIN = pow(EPS, 0.78);
  real_T FACMAX = 0.1;
  int_T nx = 2;
  real_T *x = rtsiGetContStates(si);
  real_T del;
  real_T difmax;
  real_T FdelRowmax;
  real_T temp;
  real_T Fdiff;
  real_T maybe;
  real_T xscale;
  real_T fscale;
  real_T *p;
  int_T rowmax;
  int_T i,j;
  if (x != y)
    (void) memcpy(x, y,
                  (uint_T)nx*sizeof(real_T));
  rtsiSetSolverComputingJacobian(si,true);
  for (p = dFdy, j = 0; j < nx; j++, p += nx) {
    /* Select an increment del for a difference approximation to
       column j of dFdy.  The vector fac accounts for experience
       gained in previous calls to numjac. */
    xscale = fabs(x[j]);
    if (xscale < THRESH)
      xscale = THRESH;
    temp = (x[j] + fac[j]*xscale);
    del = temp - y[j];
    while (del == 0.0) {
      if (fac[j] < FACMAX) {
        fac[j] *= 100.0;
        if (fac[j] > FACMAX)
          fac[j] = FACMAX;
        temp = (x[j] + fac[j]*xscale);
        del = temp - x[j];
      } else {
        del = THRESH;                  /* thresh is nonzero */
        break;
      }
    }

    /* Keep del pointing into region. */
    if (Fty[j] >= 0.0)
      del = fabs(del);
    else
      del = -fabs(del);

    /* Form a difference approximation to column j of dFdy. */
    temp = x[j];
    x[j] += del;
    auto_pilot_upl_output0();
    rtsiSetdX(si,p);
    auto_pilot_upl_derivatives();
    x[j] = temp;
    difmax = 0.0;
    rowmax = 0;
    FdelRowmax = p[0];
    temp = 1.0 / del;
    for (i = 0; i < nx; i++) {
      Fdiff = p[i] - Fty[i];
      maybe = fabs(Fdiff);
      if (maybe > difmax) {
        difmax = maybe;
        rowmax = i;
        FdelRowmax = p[i];
      }

      p[i] = temp * Fdiff;
    }

    /* Adjust fac for next call to numjac. */
    if (((FdelRowmax != 0.0) && (Fty[rowmax] != 0.0)) || (difmax == 0.0)) {
      fscale = fabs(FdelRowmax);
      if (fscale < fabs(Fty[rowmax]))
        fscale = fabs(Fty[rowmax]);
      if (difmax <= BL*fscale) {
        /* The difference is small, so increase the increment. */
        fac[j] *= 10.0;
        if (fac[j] > FACMAX)
          fac[j] = FACMAX;
      } else if (difmax > BU*fscale) {
        /* The difference is large, so reduce the increment. */
        fac[j] *= 0.1;
        if (fac[j] < FACMIN)
          fac[j] = FACMIN;
      }
    }
  }

  rtsiSetSolverComputingJacobian(si,false);
}                                      /* end local_numjac */

/*
 * This function updates continuous states using the ODE14X fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static int_T rt_ODE14x_N[4] = { 12, 8, 6, 4 };

  time_T t0 = rtsiGetT(si);
  time_T t1 = t0;
  time_T h = rtsiGetStepSize(si);
  real_T *x1 = rtsiGetContStates(si);
  int_T order = rtsiGetSolverExtrapolationOrder(si);
  int_T numIter = rtsiGetSolverNumberNewtonIterations(si);
  ODE14X_IntgData *id = (ODE14X_IntgData *)rtsiGetSolverData(si);
  real_T *x0 = id->x0;
  real_T *f0 = id->f0;
  real_T *x1start = id->x1start;
  real_T *f1 = id->f1;
  real_T *Delta = id->Delta;
  real_T *E = id->E;
  real_T *fac = id->fac;
  real_T *dfdx = id->DFDX;
  real_T *W = id->W;
  int_T *pivots = id->pivots;
  real_T *xtmp = id->xtmp;
  real_T *ztmp = id->ztmp;
  int_T *N = &(rt_ODE14x_N[0]);
  int_T i,j,k,iter;
  int_T nx = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(x0, x1,
                (uint_T)nx*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */

  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  auto_pilot_upl_derivatives();
  local_numjac(si,x0,f0,fac,dfdx );
  for (j = 0; j < order; j++) {
    real_T *p;
    real_T hN = h/N[j];

    /* Get the iteration matrix and solution at t0 */

    /* [L,U] = lu(M - hN*J) */
    (void) memcpy(W, dfdx,
                  (uint_T)nx*nx*sizeof(real_T));
    for (p = W, i = 0; i < nx*nx; i++, p++) {
      *p *= (-hN);
    }

    for (p = W, i = 0; i < nx; i++, p += (nx+1)) {
      *p += 1.0;
    }

    rt_lu_real(W, nx,
               pivots);

    /* First Newton's iteration at t0. */
    /* rhs = hN*f0 */
    for (i = 0; i < nx; i++) {
      Delta[i] = hN*f0[i];
    }

    /* Delta = (U \ (L \ rhs)) */
    rt_ForwardSubstitutionRR_Dbl(W, Delta,
      f1, nx,
      1, pivots,
      1);
    rt_BackwardSubstitutionRR_Dbl(W+nx*nx-1, f1+nx-1,
      Delta, nx,
      1, 0);

    /* ytmp = y0 + Delta
       ztmp = (ytmp-y0)/h
     */
    (void) memcpy(x1, x0,
                  (uint_T)nx*sizeof(real_T));
    for (i = 0; i < nx; i++) {
      x1[i] += Delta[i];
      ztmp[i] = Delta[i]/hN;
    }

    /* Additional Newton's iterations, if desired.
       for iter = 2:NewtIter
       rhs = hN*feval(odefun,tn,ytmp,extraArgs{:}) - M*(ytmp - yn);
       if statedepM   % only for state dep. Mdel ~= 0
       Mdel = M - feval(massfun,tn,ytmp);
       rhs = rhs + Mdel*ztmp*h;
       end
       Delta = ( U \ ( L \ rhs ) );
       ytmp = ytmp + Delta;
       ztmp = (ytmp - yn)/h
       end
     */
    rtsiSetT(si, t0);
    rtsiSetdX(si, f1);
    for (iter = 1; iter < numIter; iter++) {
      auto_pilot_upl_output0();
      auto_pilot_upl_derivatives();
      for (i = 0; i < nx; i++) {
        Delta[i] = hN*f1[i];
        xtmp[i] = x1[i] - x0[i];
      }

      /* rhs = hN*f(tn,ytmp) - (ytmp-yn) */
      for (i = 0; i < nx; i++) {
        Delta[i] -= xtmp[i];
      }

      rt_ForwardSubstitutionRR_Dbl(W, Delta,
        f1, nx,
        1, pivots,
        1);
      rt_BackwardSubstitutionRR_Dbl(W+nx*nx-1, f1+nx-1,
        Delta, nx,
        1, 0);

      /* ytmp = ytmp + delta
         ztmp = (ytmp - yn)/h
       */
      for (i = 0; i < nx; i++) {
        x1[i] += Delta[i];
        ztmp[i] = (x1[i] - x0[i])/hN;
      }
    }

    /* Steps from t0+hN to t1 -- subintegration of N(j) steps for extrapolation
       ttmp = t0;
       for i = 2:N(j)
       ttmp = ttmp + hN
       ytmp0 = ytmp;
       for iter = 1:NewtIter
       rhs = (ytmp0 - ytmp) + hN*feval(odefun,ttmp,ytmp,extraArgs{:});
       Delta = ( U \ ( L \ rhs ) );
       ytmp = ytmp + Delta;
       end
       end
     */
    for (k = 1; k < N[j]; k++) {
      t1 = t0 + k*hN;
      (void) memcpy(x1start, x1,
                    (uint_T)nx*sizeof(real_T));
      rtsiSetT(si, t1);
      rtsiSetdX(si, f1);
      for (iter = 0; iter < numIter; iter++) {
        auto_pilot_upl_output0();
        auto_pilot_upl_derivatives();
        if (iter == 0) {
          for (i = 0; i < nx; i++) {
            Delta[i] = hN*f1[i];
          }
        } else {
          for (i = 0; i < nx; i++) {
            Delta[i] = hN*f1[i];
            xtmp[i] = (x1[i]-x1start[i]);
          }

          /* rhs = hN*f(tn,ytmp) - M*(ytmp-yn) */
          for (i = 0; i < nx; i++) {
            Delta[i] -= xtmp[i];
          }
        }

        rt_ForwardSubstitutionRR_Dbl(W, Delta,
          f1, nx,
          1, pivots,
          1);
        rt_BackwardSubstitutionRR_Dbl(W+nx*nx-1, f1+nx-1,
          Delta, nx,
          1, 0);

        /* ytmp = ytmp + Delta
           ztmp = (ytmp - ytmp0)/h
         */
        for (i = 0; i < nx; i++) {
          x1[i] += Delta[i];
          ztmp[i] = (x1[i] - x1start[i])/hN;
        }
      }
    }

    /* Extrapolate to order j
       E(:,j) = ytmp
       for k = j:-1:2
       coef = N(k-1)/(N(j) - N(k-1))
       E(:,k-1) = E(:,k) + coef*( E(:,k) - E(:,k-1) )
       end
     */
    (void) memcpy(&(E[nx*j]), x1,
                  (uint_T)nx*sizeof(real_T));
    for (k = j; k > 0; k--) {
      real_T coef = (real_T)(N[k-1]) / (N[j]-N[k-1]);
      for (i = 0; i < nx; i++) {
        x1[i] = E[nx*k+i] + coef*(E[nx*k+i] - E[nx*(k-1)+i]);
      }

      (void) memcpy(&(E[nx*(k-1)]), x1,
                    (uint_T)nx*sizeof(real_T));
    }
  }

  /* x1 = E(:,1); */
  (void) memcpy(x1, E,
                (uint_T)nx*sizeof(real_T));

  /* t1 = t0 + h; */
  rtsiSetT(si,rtsiGetSolverStopTime(si));
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/*
 * Output and update for atomic system:
 *    '<S214>/MATLAB Function'
 *    '<S214>/MATLAB Function1'
 */
void auto_pilot_upl_MATLABFunction(const real_T rtu_u[10],
  B_MATLABFunction_auto_pilot_upl_T *localB)
{
  int32_T i;

  /* MATLAB Function 'AEB/AEB_Inputs/MATLAB Function': '<S217>:1' */
  /* '<S217>:1:3' */
  for (i = 0; i < 10; i++) {
    localB->y[i] = rtu_u[i];
    if (rtu_u[i] == 121.0) {
      /* '<S217>:1:4' */
      localB->y[i] = 0.0;
    }
  }
}

/*
 * Output and update for atomic system:
 *    '<S321>/manipulation_of_objects'
 *    '<S321>/manipulation_of_objects1'
 */
void auto_pilot_upl_manipulation_of_objects(const real_T
  rtu_complete_obstacles_matrix[100], real_T rtu_detected_objects,
  B_manipulation_of_objects_auto_pilot_upl_T *localB)
{
  int32_T c;
  int32_T i;
  int32_T i_0;
  int32_T tmp;
  memcpy(&localB->filtered_matrix[0], &rtu_complete_obstacles_matrix[0], 100U *
         sizeof(real_T));

  /* MATLAB Function 'OUTPUT/WorldSim_Sensor_Outputs/manipulation_of_objects': '<S326>:1' */
  /* '<S326>:1:7' */
  /* '<S326>:1:5' */
  if (rtu_detected_objects + 1.0 > 10.0) {
    c = -1;
    i = -1;
  } else {
    c = (int32_T)(rtu_detected_objects + 1.0) - 2;
    i = 9;
  }

  /* '<S326>:1:7' */
  tmp = i - c;
  for (i = 0; i < tmp; i++) {
    for (i_0 = 0; i_0 < 10; i_0++) {
      localB->filtered_matrix[i_0 + 10 * ((c + i) + 1)] = 0.0;
    }
  }
}

real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else {
    real_T tmp;
    real_T tmp_0;
    tmp = fabs(u0);
    tmp_0 = fabs(u1);
    if (rtIsInf(u1)) {
      if (tmp == 1.0) {
        y = 1.0;
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > floor(u1))) {
      y = (rtNaN);
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

/* Model output function for TID0 */
void auto_pilot_upl_output0(void)      /* Sample time: [0.0s, 0.0s] */
{
  __m128d tmp;
  __m128d tmp_0;
  real_T TSamp_kd[30];
  real_T rtb_Rn[10];
  real_T rtb_Target_Lateral_Position[10];
  real_T rtb_Target_Longitudinal_Position[10];
  real_T deltaT;
  real_T riseValLimit;
  real_T rtb_AEB_Output_Brake_Gain;
  real_T rtb_ProportionalGain;
  real_T rtb_PulseGenerator;
  real_T rtb_Saturation3;
  real_T rtb_Sum_e;
  real_T rtb_Sum_f;
  real_T rtb_Sum_p;
  real_T rtb_Switch4;
  real_T rtb_Yk1;
  real_T rtb_Yk1_cw;
  real_T rtb_Yk1_g;
  real_T rtb_Yk1_h;
  real_T rtb_Yk1_i;
  real_T rtb_Yk1_j;
  real_T rtb_Yk1_l;
  real_T rtb_Yk1_lk;
  int32_T i;
  uint16_T rtb_Product3_o;
  uint8_T rtb_Compare_gr;
  uint8_T rtb_Compare_gs;
  uint8_T rtb_Compare_nd;
  boolean_T rtb_RelationalOperator_c[10];
  boolean_T rtb_Compare_hm;
  ZCEventType zcEvent;
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* set solver stop time */
    if (!(auto_pilot_upl_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&auto_pilot_upl_M->solverInfo,
                            ((auto_pilot_upl_M->Timing.clockTickH0 + 1) *
        auto_pilot_upl_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&auto_pilot_upl_M->solverInfo,
                            ((auto_pilot_upl_M->Timing.clockTick0 + 1) *
        auto_pilot_upl_M->Timing.stepSize0 +
        auto_pilot_upl_M->Timing.clockTickH0 *
        auto_pilot_upl_M->Timing.stepSize0 * 4294967296.0));
    }

    {                                  /* Sample time: [0.0s, 0.0s] */
      rate_monotonic_scheduler();
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(auto_pilot_upl_M)) {
    auto_pilot_upl_M->Timing.t[0] = rtsiGetT(&auto_pilot_upl_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* UnitDelay: '<S27>/UD' */
    rtb_Yk1 = auto_pilot_upl_DW.UD_DSTATE;

    /* UnitDelay: '<S26>/UD' */
    rtb_Yk1_i = auto_pilot_upl_DW.UD_DSTATE_n;

    /* UnitDelay: '<S33>/UD' */
    rtb_Yk1_g = auto_pilot_upl_DW.UD_DSTATE_d;

    /* UnitDelay: '<S34>/UD' */
    rtb_Yk1_h = auto_pilot_upl_DW.UD_DSTATE_o;
  }

  /* S-Function (simwbC_RTDBIn): '<S7>/VI_DriveSim.Inputs.ECAT.BECKH.ANA3' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S7>/VI_DriveSim.Inputs.ECAT.BECKH.ANA3 */
  auto_pilot_upl_B.VI_DriveSimInputsECATBECKHANA3 = *(real_T *)
    pVI_DriveSim_Inputs_ECAT_BECKH_ANA3;

#endif

  /* S-Function (simwbC_RTDBIn): '<S7>/VI_CarRealTime.Outputs.transmission.gear' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S7>/VI_CarRealTime.Outputs.transmission.gear */
  auto_pilot_upl_B.VI_CarRealTimeOutputstransmissiongear = *(real_T *)
    pVI_CarRealTime_Outputs_transmission_gear;

#endif

  /* S-Function (simwbC_RTDBIn): '<S7>/VI_DriveSim.Inputs.ECAT.BECKH.ANA1' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S7>/VI_DriveSim.Inputs.ECAT.BECKH.ANA1 */
  auto_pilot_upl_B.VI_DriveSimInputsECATBECKHANA1 = *(real_T *)
    pVI_DriveSim_Inputs_ECAT_BECKH_ANA4;

#endif

  /* S-Function (simwbC_RTDBIn): '<S7>/VI_DriveSim.Inputs.ECAT.BECKH.DIG4' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S7>/VI_DriveSim.Inputs.ECAT.BECKH.DIG4 */
  auto_pilot_upl_B.VI_DriveSimInputsECATBECKHDIG4 = *(real_T *)
    pVI_DriveSim_Inputs_ECAT_BECKH_DIG4;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.chassis_velocities.longitudinal' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.chassis_velocities.longitudinal */
  auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal =
    *(real_T *)pVI_CarRealTime_Outputs_chassis_velocities_longitudinal;

#endif

  /* S-Function (simwbC_RTDBIn): '<S7>/VI_DriveSim.Outputs.Vicrt.Status' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S7>/VI_DriveSim.Outputs.Vicrt.Status */
  auto_pilot_upl_B.VI_DriveSimOutputsVicrtStatus = *(real_T *)
    pVI_DriveSim_Outputs_Vicrt_Status;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.driver_demands.brake' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.driver_demands.brake */
  auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandsbrake = *(real_T *)
    pVI_CarRealTime_Outputs_driver_demands_brake;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1 */
  auto_pilot_upl_B.VI_CarRealTimeOutputsWheelSpindle_SteerL1 = *(real_T *)
    pVI_CarRealTime_Outputs_Wheel_Spindle_Steer_L1;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1 */
  auto_pilot_upl_B.VI_CarRealTimeOutputsWheelSpindle_SteerR1 = *(real_T *)
    pVI_CarRealTime_Outputs_Wheel_Spindle_Steer_R1;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.driver_demands.throttle' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.driver_demands.throttle */
  auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandsthrottle = *(real_T *)
    pVI_CarRealTime_Outputs_driver_demands_throttle;

#endif

  /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.driver_demands.steering' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <Root>/VI_CarRealTime.Outputs.driver_demands.steering */
  auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandssteering = *(real_T *)
    pVI_CarRealTime_Outputs_driver_demands_steering;

#endif

  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <Root>/VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque */
    auto_pilot_upl_B.VI_CarRealTimeOutputsSteering_SystemDriveSim_Steering_Feedback_Torque
      = *(real_T *)
      pVI_CarRealTime_Outputs_Steering_System_DriveSim_Steering_Feedback_Torque;

#endif

    /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.chassis_accelerations.lateral' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <Root>/VI_CarRealTime.Outputs.chassis_accelerations.lateral */
    auto_pilot_upl_B.VI_CarRealTimeOutputschassis_accelerationslateral =
      *(real_T *)pVI_CarRealTime_Outputs_chassis_accelerations_lateral;

#endif

    /* S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.chassis_accelerations.longitudinal' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <Root>/VI_CarRealTime.Outputs.chassis_accelerations.longitudinal */
    auto_pilot_upl_B.VI_CarRealTimeOutputschassis_accelerationslongitudinal =
      *(real_T *)pVI_CarRealTime_Outputs_chassis_accelerations_longitudinal;

#endif

  }

  /* S-Function (simwbC_RTDBIn): '<S7>/VI_DriveSim.Inputs.ECAT.BECKH.DIG3' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S7>/VI_DriveSim.Inputs.ECAT.BECKH.DIG3 */
  auto_pilot_upl_B.VI_DriveSimInputsECATBECKHDIG3 = *(real_T *)
    pVI_DriveSim_Inputs_ECAT_BECKH_DIG3;

#endif

  /* RelationalOperator: '<S348>/Compare' incorporates:
   *  Constant: '<S348>/Constant'
   */
  rtb_Compare_gr = (uint8_T)(auto_pilot_upl_B.VI_DriveSimInputsECATBECKHANA3 >=
    auto_pilot_upl_P.shift_paddle_threshold1_const);

  /* RelationalOperator: '<S344>/Compare' incorporates:
   *  Constant: '<S344>/Constant'
   */
  rtb_Compare_gs = (uint8_T)
    (auto_pilot_upl_B.VI_CarRealTimeOutputstransmissiongear >=
     auto_pilot_upl_P.CompareToConstant2_const);

  /* DataTypeConversion: '<S7>/Data Type Conversion3' incorporates:
   *  Product: '<S7>/Product2'
   */
  rtb_Saturation3 = rtb_Compare_gr * rtb_Compare_gs;

  /* RelationalOperator: '<S347>/Compare' incorporates:
   *  Constant: '<S347>/Constant'
   */
  rtb_Compare_nd = (uint8_T)(auto_pilot_upl_B.VI_DriveSimInputsECATBECKHANA1 >=
    auto_pilot_upl_P.shift_paddle_threshold_const);
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* RelationalOperator: '<S194>/FixPt Relational Operator' incorporates:
     *  Constant: '<S8>/Constant1'
     *  UnitDelay: '<S194>/Delay Input1'
     */
    auto_pilot_upl_B.FixPtRelationalOperator = (auto_pilot_upl_P.Constant1_Value
      > auto_pilot_upl_DW.DelayInput1_DSTATE);

    /* UnitDelay: '<S13>/Delay Input1' */
    auto_pilot_upl_B.Uk1_i = auto_pilot_upl_DW.DelayInput1_DSTATE_h;
  }

  /* RelationalOperator: '<S12>/Compare' incorporates:
   *  Clock: '<S8>/Clock'
   *  Constant: '<S12>/Constant'
   */
  auto_pilot_upl_B.Compare = (auto_pilot_upl_M->Timing.t[0] >=
    auto_pilot_upl_P.CompareToConstant_const);

  /* DataTypeConversion: '<S8>/Cast To Double' incorporates:
   *  RelationalOperator: '<S13>/FixPt Relational Operator'
   */
  auto_pilot_upl_B.CastToDouble = ((int32_T)auto_pilot_upl_B.Compare > (int32_T)
    auto_pilot_upl_B.Uk1_i);

  /* Product: '<S8>/Product' */
  auto_pilot_upl_B.Product = auto_pilot_upl_B.CastToDouble *
    auto_pilot_upl_B.VI_DriveSimInputsECATBECKHDIG4;
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* UnitDelay: '<S14>/Delay Input1' */
    auto_pilot_upl_B.Uk1 = auto_pilot_upl_DW.DelayInput1_DSTATE_a;

    /* Memory: '<S11>/Memory' */
    auto_pilot_upl_B.Memory = auto_pilot_upl_DW.Memory_PreviousInput;
  }

  /* Switch: '<S11>/Switch' incorporates:
   *  RelationalOperator: '<S14>/FixPt Relational Operator'
   */
  if (auto_pilot_upl_B.Product < auto_pilot_upl_B.Uk1) {
    /* DataTypeConversion: '<S11>/Cast To Double1' */
    auto_pilot_upl_B.CastToDouble1_p = 1.0;

    /* Switch: '<S11>/Switch' */
    auto_pilot_upl_B.Switch = auto_pilot_upl_B.CastToDouble1_p;
  } else {
    /* Switch: '<S11>/Switch' */
    auto_pilot_upl_B.Switch = auto_pilot_upl_B.Memory;
  }

  /* End of Switch: '<S11>/Switch' */

  /* Product: '<S11>/Product' */
  auto_pilot_upl_B.Product_o = auto_pilot_upl_B.Switch * auto_pilot_upl_B.Switch;

  /* Logic: '<S8>/Logical Operator' */
  auto_pilot_upl_B.LogicalOperator = ((rtb_Saturation3 != 0.0) ||
    (auto_pilot_upl_B.Product_o != 0.0));
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* UnitDelay: '<S193>/Delay Input1' */
    auto_pilot_upl_B.Uk1_k = auto_pilot_upl_DW.DelayInput1_DSTATE_ay;

    /* Product: '<S16>/Product2' incorporates:
     *  Constant: '<S16>/ACC_Module_Activity_Flag'
     *  Constant: '<S16>/Constant'
     *  Constant: '<S16>/Constant4'
     *  Constant: '<S191>/Constant'
     *  DataTypeConversion: '<S16>/Cast To Double'
     *  Logic: '<S16>/OR'
     *  RelationalOperator: '<S191>/Compare'
     */
    auto_pilot_upl_B.Product2 = (real_T)
      ((auto_pilot_upl_P.ACC_Module_Activity_Flag != 0.0) ||
       (auto_pilot_upl_P.AP_Activity_Flag != 0.0)) * (real_T)
      (auto_pilot_upl_P.Constant_Value_k == auto_pilot_upl_P.Constant_Value_f);
  }

  /* Product: '<S16>/Product1' */
  auto_pilot_upl_B.Product1 =
    auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal *
    auto_pilot_upl_B.Product2;

  /* DataTypeConversion: '<S16>/Data Type Conversion' incorporates:
   *  Constant: '<S185>/Constant'
   *  RelationalOperator: '<S185>/Compare'
   */
  auto_pilot_upl_B.DataTypeConversion = (auto_pilot_upl_B.Product1 >=
    auto_pilot_upl_P.ACC_Ready_Speed);

  /* RateTransition: '<S215>/Rate Transition7' */
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_4) {
      /* RateTransition: '<S215>/Rate Transition7' */
      memcpy(&auto_pilot_upl_B.RateTransition7[0],
             &auto_pilot_upl_DW.RateTransition7_Buffer0[0], 30U * sizeof(real_T));

      /* RateTransition generated from: '<S215>/derivation_speed' */
      memcpy(&auto_pilot_upl_B.Target_X_Distance_mux[0],
             &auto_pilot_upl_DW.Target_X_Distance_mux_Buffer0[0], 30U * sizeof
             (real_T));
    }

    /* DiscretePulseGenerator: '<S215>/Pulse Generator' */
    rtb_PulseGenerator = (auto_pilot_upl_DW.clockTickCounter <
                          auto_pilot_upl_P.PulseGenerator_Duty) &&
      (auto_pilot_upl_DW.clockTickCounter >= 0) ?
      auto_pilot_upl_P.PulseGenerator_Amp : 0.0;
    if (auto_pilot_upl_DW.clockTickCounter >=
        auto_pilot_upl_P.PulseGenerator_Period - 1.0) {
      auto_pilot_upl_DW.clockTickCounter = 0;
    } else {
      auto_pilot_upl_DW.clockTickCounter++;
    }

    /* End of DiscretePulseGenerator: '<S215>/Pulse Generator' */

    /* Outputs for Triggered SubSystem: '<S215>/derivation_speed' incorporates:
     *  TriggerPort: '<S235>/Trigger'
     */
    if (rtsiIsModeUpdateTimeStep(&auto_pilot_upl_M->solverInfo)) {
      zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                         &auto_pilot_upl_PrevZCX.derivation_speed_Trig_ZCE_l,
                         (rtb_PulseGenerator));
      if (zcEvent != NO_ZCEVENT) {
        uint32_T derivation_speed_ELAPS_T_tmp_tmp;
        uint32_T elapseT_H;
        uint32_T elapseT_H_tmp;
        derivation_speed_ELAPS_T_tmp_tmp = auto_pilot_upl_M->Timing.clockTick1;
        auto_pilot_upl_DW.derivation_speed_ELAPS_T[0] =
          derivation_speed_ELAPS_T_tmp_tmp -
          auto_pilot_upl_DW.derivation_speed_PREV_T[0];
        elapseT_H_tmp = auto_pilot_upl_M->Timing.clockTickH1;
        elapseT_H = elapseT_H_tmp - auto_pilot_upl_DW.derivation_speed_PREV_T[1];
        if (auto_pilot_upl_DW.derivation_speed_PREV_T[0] >
            derivation_speed_ELAPS_T_tmp_tmp) {
          elapseT_H--;
        }

        auto_pilot_upl_DW.derivation_speed_ELAPS_T[1] = elapseT_H;
        auto_pilot_upl_DW.derivation_speed_PREV_T[0] =
          derivation_speed_ELAPS_T_tmp_tmp;
        auto_pilot_upl_DW.derivation_speed_PREV_T[1] = elapseT_H_tmp;

        /* SampleTimeMath: '<S246>/TSamp'
         *
         * About '<S246>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_PulseGenerator = ((real_T)
                              auto_pilot_upl_DW.derivation_speed_ELAPS_T[0] *
                              0.001 + (real_T)
                              auto_pilot_upl_DW.derivation_speed_ELAPS_T[1] *
                              4.294967296E+6) * auto_pilot_upl_P.TSamp_WtEt;
        for (i = 0; i <= 28; i += 2) {
          tmp = _mm_loadu_pd(&auto_pilot_upl_B.Target_X_Distance_mux[i]);
          tmp = _mm_div_pd(tmp, _mm_set1_pd(rtb_PulseGenerator));
          tmp_0 = _mm_loadu_pd(&auto_pilot_upl_DW.UD_DSTATE_nt[i]);
          _mm_storeu_pd(&auto_pilot_upl_B.Gain_a[i], _mm_mul_pd(_mm_sub_pd(tmp,
            tmp_0), _mm_set1_pd(auto_pilot_upl_P.Gain_Gain_n)));
          _mm_storeu_pd(&auto_pilot_upl_DW.UD_DSTATE_nt[i], tmp);
        }
      }
    }

    /* End of Outputs for SubSystem: '<S215>/derivation_speed' */

    /* MinMax: '<S215>/MinMax1' incorporates:
     *  Gain: '<S235>/Gain'
     *  SampleTimeMath: '<S246>/TSamp'
     *  UnitDelay: '<S246>/UD'
     * *
     * About '<S246>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    rtb_AEB_Output_Brake_Gain = auto_pilot_upl_B.Gain_a[0];
    for (i = 0; i < 29; i++) {
      rtb_AEB_Output_Brake_Gain = fmax(rtb_AEB_Output_Brake_Gain,
        auto_pilot_upl_B.Gain_a[i + 1]);
    }

    /* RelationalOperator: '<S219>/Compare' incorporates:
     *  Constant: '<S219>/Constant'
     *  MinMax: '<S215>/MinMax1'
     */
    rtb_Compare_hm = (rtb_AEB_Output_Brake_Gain >
                      auto_pilot_upl_P.AEB_Approaching_Speed_Threshold_const);

    /* RateLimiter: '<S215>/Rate Limiter1' incorporates:
     *  DataTypeConversion: '<S215>/Data Type Conversion3'
     */
    rtb_AEB_Output_Brake_Gain = (real_T)rtb_Compare_hm - auto_pilot_upl_DW.PrevY;
    if (rtb_AEB_Output_Brake_Gain > auto_pilot_upl_P.RateLimiter1_RisingLim *
        auto_pilot_upl_period) {
      rtb_PulseGenerator = auto_pilot_upl_P.RateLimiter1_RisingLim *
        auto_pilot_upl_period + auto_pilot_upl_DW.PrevY;
    } else if (rtb_AEB_Output_Brake_Gain <
               auto_pilot_upl_P.RateLimiter1_FallingLim * auto_pilot_upl_period)
    {
      rtb_PulseGenerator = auto_pilot_upl_P.RateLimiter1_FallingLim *
        auto_pilot_upl_period + auto_pilot_upl_DW.PrevY;
    } else {
      rtb_PulseGenerator = rtb_Compare_hm;
    }

    auto_pilot_upl_DW.PrevY = rtb_PulseGenerator;

    /* End of RateLimiter: '<S215>/Rate Limiter1' */

    /* RelationalOperator: '<S228>/Compare' incorporates:
     *  Constant: '<S228>/Constant'
     */
    auto_pilot_upl_B.Compare_d = (rtb_PulseGenerator >
      auto_pilot_upl_P.Constant_Value_az);
  }

  /* End of RateTransition: '<S215>/Rate Transition7' */

  /* RelationalOperator: '<S223>/Compare' incorporates:
   *  Constant: '<S223>/Constant'
   */
  rtb_Compare_hm =
    (auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal >
     auto_pilot_upl_P.CompareToConstant_const_b);

  /* RateLimiter: '<S215>/Rate Limiter' incorporates:
   *  DataTypeConversion: '<S215>/Data Type Conversion2'
   *  RateLimiter: '<S10>/Rate Limiter'
   *  RateLimiter: '<S250>/Rate Limiter1'
   */
  rtb_PulseGenerator = auto_pilot_upl_M->Timing.t[0];
  if ((auto_pilot_upl_DW.LastMajorTimeA >= rtb_PulseGenerator) &&
      (auto_pilot_upl_DW.LastMajorTimeB >= rtb_PulseGenerator)) {
    /* RateLimiter: '<S215>/Rate Limiter' incorporates:
     *  DataTypeConversion: '<S215>/Data Type Conversion2'
     */
    auto_pilot_upl_B.RateLimiter = rtb_Compare_hm;
  } else {
    if (((auto_pilot_upl_DW.LastMajorTimeA < auto_pilot_upl_DW.LastMajorTimeB) &&
         (auto_pilot_upl_DW.LastMajorTimeB < rtb_PulseGenerator)) ||
        ((auto_pilot_upl_DW.LastMajorTimeA >= auto_pilot_upl_DW.LastMajorTimeB) &&
         (auto_pilot_upl_DW.LastMajorTimeA >= rtb_PulseGenerator))) {
      deltaT = rtb_PulseGenerator - auto_pilot_upl_DW.LastMajorTimeB;
      rtb_Switch4 = auto_pilot_upl_DW.PrevYB;
    } else {
      deltaT = rtb_PulseGenerator - auto_pilot_upl_DW.LastMajorTimeA;
      rtb_Switch4 = auto_pilot_upl_DW.PrevYA;
    }

    riseValLimit = deltaT * auto_pilot_upl_P.RateLimiter_RisingLim;
    rtb_AEB_Output_Brake_Gain = (real_T)rtb_Compare_hm - rtb_Switch4;
    if (rtb_AEB_Output_Brake_Gain > riseValLimit) {
      /* RateLimiter: '<S215>/Rate Limiter' */
      auto_pilot_upl_B.RateLimiter = rtb_Switch4 + riseValLimit;
    } else {
      deltaT *= auto_pilot_upl_P.RateLimiter_FallingLim;
      if (rtb_AEB_Output_Brake_Gain < deltaT) {
        /* RateLimiter: '<S215>/Rate Limiter' */
        auto_pilot_upl_B.RateLimiter = rtb_Switch4 + deltaT;
      } else {
        /* RateLimiter: '<S215>/Rate Limiter' */
        auto_pilot_upl_B.RateLimiter = rtb_Compare_hm;
      }
    }
  }

  /* End of RateLimiter: '<S215>/Rate Limiter' */

  /* Product: '<S215>/Product1' incorporates:
   *  Constant: '<S229>/Constant'
   *  RelationalOperator: '<S229>/Compare'
   */
  rtb_Product3_o = (uint16_T)(auto_pilot_upl_B.Compare_d ?
    auto_pilot_upl_B.RateLimiter > auto_pilot_upl_P.Constant_Value_l : 0);
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* Delay: '<S215>/Delay1' */
    memcpy(&auto_pilot_upl_B.Delay1[0], &auto_pilot_upl_DW.Delay1_DSTATE[0], 30U
           * sizeof(real_T));
  }

  for (i = 0; i < 30; i++) {
    /* Switch: '<S215>/Switch2' */
    if (auto_pilot_upl_B.RateTransition7[i] > auto_pilot_upl_P.Switch2_Threshold)
    {
      /* Switch: '<S215>/Switch2' incorporates:
       *  Constant: '<S215>/Constant3'
       */
      auto_pilot_upl_B.Switch2[i] = auto_pilot_upl_P.Constant3_Value;
    } else {
      /* Switch: '<S215>/Switch2' incorporates:
       *  Product: '<S215>/Product'
       */
      auto_pilot_upl_B.Switch2[i] = (real_T)rtb_Product3_o *
        auto_pilot_upl_B.Delay1[i];
    }

    /* End of Switch: '<S215>/Switch2' */
  }

  /* MinMax: '<S215>/MinMax' */
  rtb_AEB_Output_Brake_Gain = auto_pilot_upl_B.Switch2[0];
  for (i = 0; i < 29; i++) {
    rtb_AEB_Output_Brake_Gain = fmax(rtb_AEB_Output_Brake_Gain,
      auto_pilot_upl_B.Switch2[i + 1]);
  }

  /* RateTransition generated from: '<S220>/Product5' incorporates:
   *  RateTransition: '<S215>/Rate Transition6'
   */
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_4) {
      /* RateTransition generated from: '<S220>/Product5' */
      memcpy(&auto_pilot_upl_B.TmpRTBAtProduct5Inport1[0],
             &auto_pilot_upl_DW.TmpRTBAtProduct5Inport1_Buffer0[0], 30U * sizeof
             (real_T));
    }

    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_4) {
      /* RateTransition: '<S215>/Rate Transition6' */
      auto_pilot_upl_B.RateTransition6 =
        auto_pilot_upl_DW.RateTransition6_Buffer0;
    }

    /* Product: '<S216>/Product2' incorporates:
     *  Constant: '<S16>/Constant'
     *  Constant: '<S216>/AEB_Module_Activity_Flag'
     *  Constant: '<S248>/Constant'
     *  RelationalOperator: '<S248>/Compare'
     */
    auto_pilot_upl_B.Product2_h = (real_T)(auto_pilot_upl_P.Constant_Value_k ==
      auto_pilot_upl_P.Constant_Value_e) *
      auto_pilot_upl_P.AEB_Module_Activity_Flag;
  }

  /* End of RateTransition generated from: '<S220>/Product5' */

  /* Switch: '<S220>/Switch4' incorporates:
   *  Constant: '<S220>/No_Target_Display_Value'
   *  MinMax: '<S215>/MinMax'
   */
  if (rtb_AEB_Output_Brake_Gain != 0.0) {
    /* Product: '<S220>/Product5' incorporates:
     *  RelationalOperator: '<S220>/Relational Operator1'
     */
    for (i = 0; i < 30; i++) {
      TSamp_kd[i] = (real_T)(auto_pilot_upl_B.Switch2[i] ==
        rtb_AEB_Output_Brake_Gain) * auto_pilot_upl_B.TmpRTBAtProduct5Inport1[i];
    }

    /* End of Product: '<S220>/Product5' */

    /* MinMax: '<S220>/MinMax3' */
    rtb_Switch4 = TSamp_kd[0];
    for (i = 0; i < 29; i++) {
      rtb_Switch4 = fmax(rtb_Switch4, TSamp_kd[i + 1]);
    }

    /* End of MinMax: '<S220>/MinMax3' */
  } else {
    rtb_Switch4 = auto_pilot_upl_P.No_Target_Display_Value;
  }

  /* End of Switch: '<S220>/Switch4' */

  /* Switch: '<S216>/Switch' */
  if (auto_pilot_upl_B.Product2_h > auto_pilot_upl_P.Switch_Threshold) {
    /* Switch: '<S216>/Switch' incorporates:
     *  Constant: '<S215>/Constant'
     *  Constant: '<S226>/Constant'
     *  DataTypeConversion: '<S215>/Data Type Conversion'
     *  MinMax: '<S215>/MinMax'
     *  RelationalOperator: '<S226>/Compare'
     */
    auto_pilot_upl_B.Switch_h[0] = rtb_AEB_Output_Brake_Gain;
    auto_pilot_upl_B.Switch_h[1] = auto_pilot_upl_P.Constant_Value_m;
    auto_pilot_upl_B.Switch_h[2] = (rtb_AEB_Output_Brake_Gain >
      auto_pilot_upl_P.Constant_Value_o);
    auto_pilot_upl_B.Switch_h[3] = rtb_Switch4;
    auto_pilot_upl_B.Switch_h[4] = auto_pilot_upl_B.RateTransition6;
  } else {
    /* Switch: '<S216>/Switch' incorporates:
     *  Constant: '<S215>/Constant'
     *  Constant: '<S226>/Constant'
     *  DataTypeConversion: '<S215>/Data Type Conversion'
     *  Gain: '<S216>/Gain'
     *  MinMax: '<S215>/MinMax'
     *  RelationalOperator: '<S226>/Compare'
     */
    auto_pilot_upl_B.Switch_h[0] = auto_pilot_upl_P.Gain_Gain_f *
      rtb_AEB_Output_Brake_Gain;
    auto_pilot_upl_B.Switch_h[1] = auto_pilot_upl_P.Gain_Gain_f *
      auto_pilot_upl_P.Constant_Value_m;
    auto_pilot_upl_B.Switch_h[2] = (real_T)(rtb_AEB_Output_Brake_Gain >
      auto_pilot_upl_P.Constant_Value_o) * auto_pilot_upl_P.Gain_Gain_f;
    auto_pilot_upl_B.Switch_h[3] = auto_pilot_upl_P.Gain_Gain_f * rtb_Switch4;
    auto_pilot_upl_B.Switch_h[4] = auto_pilot_upl_P.Gain_Gain_f *
      auto_pilot_upl_B.RateTransition6;
  }

  /* End of Switch: '<S216>/Switch' */
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* RelationalOperator: '<S190>/Compare' incorporates:
     *  Constant: '<S190>/Constant'
     *  Constant: '<S8>/Constant1'
     */
    auto_pilot_upl_B.Compare_m = (auto_pilot_upl_P.Constant1_Value ==
      auto_pilot_upl_P.CompareToConstant4_const);

    /* Memory: '<S16>/Memory' */
    auto_pilot_upl_B.Memory_i = auto_pilot_upl_DW.Memory_PreviousInput_b;

    /* UnitDelay: '<S23>/Delay Input1' */
    auto_pilot_upl_B.Uk1_p = auto_pilot_upl_DW.DelayInput1_DSTATE_n;

    /* Memory: '<S15>/Memory' */
    auto_pilot_upl_B.Memory_d = auto_pilot_upl_DW.Memory_PreviousInput_l;

    /* Logic: '<S15>/OR' incorporates:
     *  Constant: '<S15>/ACC_Module_Activity_Flag'
     *  Constant: '<S15>/AP_Module_Activity_Flag'
     */
    auto_pilot_upl_B.OR = ((auto_pilot_upl_P.ACC_Module_Activity_Flag != 0.0) ||
      (auto_pilot_upl_P.AP_Activity_Flag != 0.0));
  }

  /* Switch: '<S16>/Switch' incorporates:
   *  Constant: '<S187>/Constant'
   *  Logic: '<S16>/Logical Operator'
   *  Logic: '<S16>/Logical Operator2'
   *  RelationalOperator: '<S187>/Compare'
   *  RelationalOperator: '<S193>/FixPt Relational Operator'
   */
  if ((auto_pilot_upl_B.FixPtRelationalOperator || ((int32_T)
        auto_pilot_upl_B.LogicalOperator > (int32_T)auto_pilot_upl_B.Uk1_k)) &&
      (auto_pilot_upl_B.DataTypeConversion != 0.0) &&
      (auto_pilot_upl_B.VI_DriveSimOutputsVicrtStatus ==
       auto_pilot_upl_P.CompareToConstant1_const)) {
    /* Switch: '<S16>/Switch' */
    auto_pilot_upl_B.Switch_o = 1.0;
  } else {
    /* RelationalOperator: '<S188>/Compare' incorporates:
     *  Constant: '<S188>/Constant'
     */
    rtb_Compare_hm = (auto_pilot_upl_B.VI_DriveSimOutputsVicrtStatus ==
                      auto_pilot_upl_P.CompareToConstant2_const_f);

    /* Switch: '<S16>/Switch' incorporates:
     *  Constant: '<S189>/Constant'
     *  Constant: '<S192>/Constant'
     *  Logic: '<S16>/Logical Operator1'
     *  Product: '<S16>/Product'
     *  RelationalOperator: '<S189>/Compare'
     *  RelationalOperator: '<S192>/Compare'
     */
    auto_pilot_upl_B.Switch_o = (real_T)
      ((auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandsbrake <=
        auto_pilot_upl_P.CompareToConstant3_const) && rtb_Compare_hm &&
       rtb_Compare_hm && (auto_pilot_upl_B.Switch_h[2] ==
                          auto_pilot_upl_P.Constant_Value_a) &&
       (auto_pilot_upl_B.Product2 != 0.0) && auto_pilot_upl_B.Compare_m) *
      auto_pilot_upl_B.Memory_i;
  }

  /* End of Switch: '<S16>/Switch' */

  /* Switch: '<S15>/Switch' incorporates:
   *  Constant: '<S15>/Constant'
   *  RelationalOperator: '<S23>/FixPt Relational Operator'
   *  Sum: '<S15>/Sum3'
   */
  if (auto_pilot_upl_B.Switch_o > auto_pilot_upl_B.Uk1_p) {
    rtb_Switch4 =
      auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal -
      auto_pilot_upl_P.Constant_Value_oj;
  } else {
    rtb_Switch4 = auto_pilot_upl_B.Memory_d;
  }

  /* Product: '<S15>/Product8' incorporates:
   *  Constant: '<S8>/Constant'
   *  DataTypeConversion: '<S7>/Data Type Conversion5'
   *  Gain: '<S8>/Gain1'
   *  Product: '<S15>/Product3'
   *  Product: '<S7>/Product4'
   *  Product: '<S8>/Divide'
   *  Sum: '<S15>/Sum2'
   *  Sum: '<S8>/Sum'
   *  Switch: '<S15>/Switch'
   */
  auto_pilot_upl_B.Product8 = (((real_T)(rtb_Compare_gs * rtb_Compare_nd) *
    auto_pilot_upl_P.Gain1_Gain + rtb_Saturation3) /
    auto_pilot_upl_P.Constant_Value_p * auto_pilot_upl_B.Switch_o + rtb_Switch4)
    * (real_T)auto_pilot_upl_B.OR;

  /* Sum: '<S15>/Error2' */
  auto_pilot_upl_B.Error2 = auto_pilot_upl_B.Product8 -
    auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal;
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* Gain: '<S122>/Proportional Gain' */
    rtb_ProportionalGain = auto_pilot_upl_P.ACC_Classic_P *
      auto_pilot_upl_B.Error2;

    /* Switch: '<S330>/Switch1' incorporates:
     *  Constant: '<S321>/Constant'
     *  Fcn: '<S330>/Fcn6'
     *  MATLAB Function: '<S330>/MATLAB Function1'
     */
    /* MATLAB Function 'OUTPUT/WorldSim_Sensor_Outputs/Subsystem/multiagent radar  SimpleRadar_... are single double representing id, yaw, range, power_db, range_rate, yaw_rate, status/MATLAB Function1': '<S336>:1' */
    /* '<S336>:1:3' */
    /* '<S336>:1:4' */
    /* '<S336>:1:5' */
    /* '<S336>:1:6' */
    /* '<S336>:1:7' */
    /* '<S336>:1:8' */
    /* '<S336>:1:9' */
    if (auto_pilot_upl_P.Constant_Value_lf[384] != 0.0) {
      /* Switch: '<S330>/Switch1' incorporates:
       *  Fcn: '<S330>/Fcn2'
       */
      auto_pilot_upl_B.Switch1 = auto_pilot_upl_P.Constant_Value_lf[128];
    } else {
      /* Switch: '<S330>/Switch1' incorporates:
       *  Constant: '<S330>/Constant7'
       */
      auto_pilot_upl_B.Switch1 = auto_pilot_upl_P.Constant7_Value;
    }

    /* End of Switch: '<S330>/Switch1' */

    /* Fcn: '<S330>/Fcn1' incorporates:
     *  Constant: '<S321>/Constant'
     *  MATLAB Function: '<S330>/MATLAB Function1'
     */
    auto_pilot_upl_B.Fcn1 = auto_pilot_upl_P.Constant_Value_lf[64];

    /* RateTransition generated from: '<S324>/Multiport Switch' */
    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_2) {
      /* RateTransition generated from: '<S324>/Multiport Switch' */
      memcpy(&auto_pilot_upl_B.TmpRTBAtMultiportSwitchInport3[0],
             &auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[0], 120U *
             sizeof(real_T));
    }

    /* End of RateTransition generated from: '<S324>/Multiport Switch' */
  }

  /* MultiPortSwitch: '<S324>/Multiport Switch' incorporates:
   *  Constant: '<S324>/Constant1'
   */
  if ((int32_T)auto_pilot_upl_P.radar_source == 1) {
    /* MultiPortSwitch: '<S324>/Multiport Switch' incorporates:
     *  Constant: '<S330>/Constant'
     *  Constant: '<S330>/Constant2'
     *  Constant: '<S330>/Constant3'
     *  Constant: '<S330>/Constant4'
     *  Constant: '<S330>/Constant5'
     *  Constant: '<S330>/Constant6'
     */
    auto_pilot_upl_B.MultiportSwitch[0] = auto_pilot_upl_P.Constant6_Value;
    auto_pilot_upl_B.MultiportSwitch[10] = auto_pilot_upl_B.Switch1;
    auto_pilot_upl_B.MultiportSwitch[20] = auto_pilot_upl_B.Fcn1;
    auto_pilot_upl_B.MultiportSwitch[30] = auto_pilot_upl_P.Constant_Value_pa;
    auto_pilot_upl_B.MultiportSwitch[40] = auto_pilot_upl_P.Constant6_Value;
    auto_pilot_upl_B.MultiportSwitch[50] = auto_pilot_upl_B.Switch1;
    auto_pilot_upl_B.MultiportSwitch[60] = auto_pilot_upl_B.Fcn1;
    auto_pilot_upl_B.MultiportSwitch[70] = auto_pilot_upl_P.Constant_Value_pa;
    auto_pilot_upl_B.MultiportSwitch[80] = auto_pilot_upl_P.Constant6_Value;
    auto_pilot_upl_B.MultiportSwitch[90] = auto_pilot_upl_B.Switch1;
    auto_pilot_upl_B.MultiportSwitch[100] = auto_pilot_upl_B.Fcn1;
    auto_pilot_upl_B.MultiportSwitch[110] = auto_pilot_upl_P.Constant_Value_pa;
    for (i = 0; i < 9; i++) {
      auto_pilot_upl_B.MultiportSwitch[i + 1] =
        auto_pilot_upl_P.Constant2_Value[i];
      auto_pilot_upl_B.MultiportSwitch[i + 11] =
        auto_pilot_upl_P.Constant3_Value_g[i];
      auto_pilot_upl_B.MultiportSwitch[i + 21] =
        auto_pilot_upl_P.Constant4_Value[i];
      auto_pilot_upl_B.MultiportSwitch[i + 31] =
        auto_pilot_upl_P.Constant5_Value[i];
      auto_pilot_upl_B.MultiportSwitch[i + 41] =
        auto_pilot_upl_P.Constant2_Value[i];
      auto_pilot_upl_B.MultiportSwitch[i + 51] =
        auto_pilot_upl_P.Constant3_Value_g[i];
      auto_pilot_upl_B.MultiportSwitch[i + 61] =
        auto_pilot_upl_P.Constant4_Value[i];
      auto_pilot_upl_B.MultiportSwitch[i + 71] =
        auto_pilot_upl_P.Constant5_Value[i];
      auto_pilot_upl_B.MultiportSwitch[i + 81] =
        auto_pilot_upl_P.Constant2_Value[i];
      auto_pilot_upl_B.MultiportSwitch[i + 91] =
        auto_pilot_upl_P.Constant3_Value_g[i];
      auto_pilot_upl_B.MultiportSwitch[i + 101] =
        auto_pilot_upl_P.Constant4_Value[i];
      auto_pilot_upl_B.MultiportSwitch[i + 111] =
        auto_pilot_upl_P.Constant5_Value[i];
    }
  } else {
    /* MultiPortSwitch: '<S324>/Multiport Switch' */
    memcpy(&auto_pilot_upl_B.MultiportSwitch[0],
           &auto_pilot_upl_B.TmpRTBAtMultiportSwitchInport3[0], 120U * sizeof
           (real_T));
  }

  /* End of MultiPortSwitch: '<S324>/Multiport Switch' */

  /* Gain: '<S320>/Gain' incorporates:
   *  Sum: '<S320>/Sum'
   */
  rtb_AEB_Output_Brake_Gain =
    (auto_pilot_upl_B.VI_CarRealTimeOutputsWheelSpindle_SteerL1 +
     auto_pilot_upl_B.VI_CarRealTimeOutputsWheelSpindle_SteerR1) *
    auto_pilot_upl_P.Gain_Gain_a;

  /* Gain: '<S199>/Gain' */
  rtb_Saturation3 = auto_pilot_upl_P.Gain_Gain_ff * rtb_AEB_Output_Brake_Gain;

  /* MATLAB Function: '<S199>/MATLAB Function' incorporates:
   *  Constant: '<S199>/Constant'
   */
  /* MATLAB Function 'ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_LongitudinalDistance_mux/Target_Longitudinal_Position': '<S212>:1' */
  /* '<S212>:1:4' */
  /* MATLAB Function 'ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_LateralDistance_mux/Target_Lateral_Position': '<S211>:1' */
  /* '<S211>:1:4' */
  /* MATLAB Function 'ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_InCurvedLane_mux/MATLAB Function': '<S207>:1' */
  /* '<S207>:1:3' */
  /* '<S207>:1:6' */
  rtb_Switch4 = auto_pilot_upl_P.vehicle_width * 0.8 / tan(rtb_Saturation3);

  /* '<S207>:1:7' */
  /* '<S207>:1:13' */
  for (i = 0; i < 10; i++) {
    /* MATLAB Function: '<S201>/Target_Lateral_Position' */
    deltaT = auto_pilot_upl_B.MultiportSwitch[i + 10] * sin
      (auto_pilot_upl_B.MultiportSwitch[i + 20]);

    /* MATLAB Function: '<S199>/MATLAB Function' */
    riseValLimit = deltaT - rtb_Switch4;
    rtb_Rn[i] = riseValLimit * riseValLimit;

    /* MATLAB Function: '<S202>/Target_Longitudinal_Position' */
    rtb_Target_Longitudinal_Position[i] = auto_pilot_upl_B.MultiportSwitch[i +
      10] * cos(auto_pilot_upl_B.MultiportSwitch[i + 20]);

    /* MATLAB Function: '<S201>/Target_Lateral_Position' */
    rtb_Target_Lateral_Position[i] = deltaT;
  }

  /* MATLAB Function: '<S199>/MATLAB Function' incorporates:
   *  Constant: '<S199>/Constant'
   */
  rtb_Switch4 = auto_pilot_upl_P.vehicle_width * 0.8;
  for (i = 0; i <= 8; i += 2) {
    /* MATLAB Function: '<S199>/MATLAB Function' */
    tmp = _mm_loadu_pd(&rtb_Target_Longitudinal_Position[i]);
    tmp = _mm_sub_pd(tmp, _mm_set1_pd(-rtb_Switch4));
    tmp = _mm_mul_pd(tmp, tmp);

    /* MATLAB Function: '<S199>/MATLAB Function' */
    tmp_0 = _mm_loadu_pd(&rtb_Rn[i]);
    _mm_storeu_pd(&rtb_Target_Longitudinal_Position[i], tmp);
    _mm_storeu_pd(&rtb_Rn[i], _mm_sqrt_pd(_mm_add_pd(tmp_0, tmp)));
  }

  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* Gain: '<S199>/Gain1' incorporates:
     *  Constant: '<S199>/Lane_Width//2'
     */
    auto_pilot_upl_B.Gain1 = auto_pilot_upl_P.Lane_Width / 2.0 *
      auto_pilot_upl_P.Gain1_Gain_b;
  }

  /* Abs: '<S197>/Abs' */
  rtb_AEB_Output_Brake_Gain = fabs(rtb_AEB_Output_Brake_Gain);

  /* Switch: '<S197>/Switch1' incorporates:
   *  Abs: '<S200>/Abs'
   *  Logic: '<S199>/Logical Operator'
   *  RelationalOperator: '<S199>/Relational Operator'
   *  RelationalOperator: '<S199>/Relational Operator1'
   *  RelationalOperator: '<S210>/Compare'
   */
  if (rtb_AEB_Output_Brake_Gain > auto_pilot_upl_P.Switch1_Threshold) {
    /* Abs: '<S199>/Abs' incorporates:
     *  Constant: '<S199>/Constant'
     *  MATLAB Function: '<S199>/MATLAB Function'
     */
    rtb_AEB_Output_Brake_Gain = fabs(auto_pilot_upl_P.vehicle_width * 0.8 / sin
      (rtb_Saturation3));

    /* Sum: '<S199>/Sum1' */
    rtb_Saturation3 = rtb_AEB_Output_Brake_Gain - auto_pilot_upl_B.Gain1;

    /* Sum: '<S199>/Sum' */
    rtb_AEB_Output_Brake_Gain += auto_pilot_upl_B.Gain1;
    for (i = 0; i < 10; i++) {
      rtb_Switch4 = rtb_Rn[i];
      rtb_RelationalOperator_c[i] = ((rtb_AEB_Output_Brake_Gain > rtb_Switch4) &&
        (rtb_Saturation3 < rtb_Switch4));
    }
  } else {
    /* RelationalOperator: '<S210>/Compare' incorporates:
     *  Constant: '<S210>/Constant'
     */
    rtb_Switch4 = auto_pilot_upl_P.Lane_Width / 2.0;
    for (i = 0; i < 10; i++) {
      rtb_RelationalOperator_c[i] = (fabs(rtb_Target_Lateral_Position[i]) <=
        rtb_Switch4);
    }
  }

  /* End of Switch: '<S197>/Switch1' */

  /* Switch: '<S197>/Switch' incorporates:
   *  Constant: '<S197>/ACC_SensorMaxDistance'
   */
  for (i = 0; i < 10; i++) {
    if (rtb_RelationalOperator_c[i]) {
      rtb_Target_Lateral_Position[i] = auto_pilot_upl_B.MultiportSwitch[i + 10];
    } else {
      rtb_Target_Lateral_Position[i] = auto_pilot_upl_P.ACC_SensorMaxDistance +
        1.0;
    }
  }

  /* End of Switch: '<S197>/Switch' */

  /* MinMax: '<S197>/MinMax' */
  rtb_Saturation3 = rtb_Target_Lateral_Position[0];
  for (i = 0; i < 9; i++) {
    rtb_Saturation3 = fmin(rtb_Saturation3, rtb_Target_Lateral_Position[i + 1]);
  }

  /* MinMax: '<S197>/MinMax' */
  auto_pilot_upl_B.MinMax = rtb_Saturation3;

  /* Product: '<S15>/Product4' incorporates:
   *  Constant: '<S21>/Constant'
   *  RelationalOperator: '<S21>/Compare'
   */
  auto_pilot_upl_B.Product4 = (real_T)(auto_pilot_upl_P.ACC_SensorMaxDistance +
    1.0 != auto_pilot_upl_B.MinMax) * auto_pilot_upl_B.Switch_o;

  /* RateTransition generated from: '<S177>/Sum' */
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* DiscreteIntegrator: '<S117>/Integrator' */
    if (((auto_pilot_upl_B.Product4 > 0.0) &&
         (auto_pilot_upl_DW.Integrator_PrevResetState <= 0)) ||
        ((auto_pilot_upl_B.Product4 <= 0.0) &&
         (auto_pilot_upl_DW.Integrator_PrevResetState == 1))) {
      auto_pilot_upl_DW.Integrator_DSTATE =
        auto_pilot_upl_P.DiscretePIDController1_InitialConditionForIntegrator;
    }

    /* Sum: '<S126>/Sum' incorporates:
     *  DiscreteIntegrator: '<S117>/Integrator'
     */
    rtb_Sum_p = rtb_ProportionalGain + auto_pilot_upl_DW.Integrator_DSTATE;

    /* Saturate: '<S124>/Saturation' */
    if (rtb_Sum_p > auto_pilot_upl_P.ACC_MaxThrottle) {
      /* Saturate: '<S124>/Saturation' */
      auto_pilot_upl_B.Saturation = auto_pilot_upl_P.ACC_MaxThrottle;
    } else if (rtb_Sum_p < -auto_pilot_upl_P.ACC_MaxBrake) {
      /* Saturate: '<S124>/Saturation' */
      auto_pilot_upl_B.Saturation = -auto_pilot_upl_P.ACC_MaxBrake;
    } else {
      /* Saturate: '<S124>/Saturation' */
      auto_pilot_upl_B.Saturation = rtb_Sum_p;
    }

    /* End of Saturate: '<S124>/Saturation' */

    /* RateTransition generated from: '<S163>/Tsamp'
     *
     * About RateTransition generated from '<S163>/Tsamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_3) {
      /* RateTransition generated from: '<S177>/Sum' */
      auto_pilot_upl_B.TmpRTBAtSumInport1 =
        auto_pilot_upl_DW.TmpRTBAtSumInport1_Buffer0;

      /* RateTransition generated from: '<S163>/Tsamp'
       *
       * About RateTransition generated from '<S163>/Tsamp':
       *  y = u * K where K = 1 / ( w * Ts )
       */
      auto_pilot_upl_B.TmpRTBAtTsampOutport1 =
        auto_pilot_upl_DW.TmpRTBAtTsampOutport1_Buffer0;
    }

    /* End of RateTransition generated from: '<S163>/Tsamp' */

    /* DiscreteIntegrator: '<S168>/Integrator' */
    if (((auto_pilot_upl_B.Product4 > 0.0) &&
         (auto_pilot_upl_DW.Integrator_PrevResetState_d <= 0)) ||
        ((auto_pilot_upl_B.Product4 <= 0.0) &&
         (auto_pilot_upl_DW.Integrator_PrevResetState_d == 1))) {
      auto_pilot_upl_DW.Integrator_DSTATE_i =
        auto_pilot_upl_P.tACC_PID_InitialConditionForIntegrator;
    }

    /* Delay: '<S161>/UD' */
    if (rt_ZCFcn(ANY_ZERO_CROSSING,&auto_pilot_upl_PrevZCX.UD_Reset_ZCE,
                 (auto_pilot_upl_B.Product4)) != NO_ZCEVENT) {
      auto_pilot_upl_DW.UD_DSTATE_e =
        auto_pilot_upl_P.tACC_PID_DifferentiatorICPrevScaledInput;
    }

    /* Sum: '<S177>/Sum' incorporates:
     *  Delay: '<S161>/UD'
     *  DiscreteIntegrator: '<S168>/Integrator'
     *  Sum: '<S161>/Diff'
     */
    rtb_Sum_e = (auto_pilot_upl_B.TmpRTBAtSumInport1 +
                 auto_pilot_upl_DW.Integrator_DSTATE_i) +
      (auto_pilot_upl_B.TmpRTBAtTsampOutport1 - auto_pilot_upl_DW.UD_DSTATE_e);

    /* Saturate: '<S175>/Saturation' */
    if (rtb_Sum_e > auto_pilot_upl_P.ACC_MaxThrottle) {
      /* Saturate: '<S175>/Saturation' */
      auto_pilot_upl_B.Saturation_o = auto_pilot_upl_P.ACC_MaxThrottle;
    } else if (rtb_Sum_e < -auto_pilot_upl_P.ACC_MaxBrake) {
      /* Saturate: '<S175>/Saturation' */
      auto_pilot_upl_B.Saturation_o = -auto_pilot_upl_P.ACC_MaxBrake;
    } else {
      /* Saturate: '<S175>/Saturation' */
      auto_pilot_upl_B.Saturation_o = rtb_Sum_e;
    }

    /* End of Saturate: '<S175>/Saturation' */

    /* Memory: '<S15>/Memory1' */
    auto_pilot_upl_B.Memory1 = auto_pilot_upl_DW.Memory1_PreviousInput;

    /* Memory: '<S15>/Memory2' */
    auto_pilot_upl_B.Memory2 = auto_pilot_upl_DW.Memory2_PreviousInput;
  }

  /* End of RateTransition generated from: '<S177>/Sum' */

  /* MinMax: '<S15>/MinMax2' incorporates:
   *  Product: '<S15>/Product7'
   *  Product: '<S15>/Product9'
   */
  rtb_AEB_Output_Brake_Gain = fmin(auto_pilot_upl_B.Saturation *
    auto_pilot_upl_B.Product4, auto_pilot_upl_B.Saturation_o *
    auto_pilot_upl_B.Product4);

  /* Switch: '<S15>/Switch2' */
  if (auto_pilot_upl_B.Switch_o > auto_pilot_upl_P.Switch2_Threshold_d) {
    /* Switch: '<S15>/Switch2' */
    auto_pilot_upl_B.setspeedmemory = auto_pilot_upl_B.Memory1;
  } else {
    /* Switch: '<S15>/Switch2' */
    auto_pilot_upl_B.setspeedmemory = auto_pilot_upl_B.Memory2;
  }

  /* End of Switch: '<S15>/Switch2' */
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* RelationalOperator: '<S24>/FixPt Relational Operator' incorporates:
     *  Constant: '<S8>/Constant1'
     *  UnitDelay: '<S24>/Delay Input1'
     */
    auto_pilot_upl_B.FixPtRelationalOperator_a =
      (auto_pilot_upl_P.Constant1_Value > auto_pilot_upl_DW.DelayInput1_DSTATE_l);
  }

  /* Switch: '<S15>/Switch1' */
  if (auto_pilot_upl_B.FixPtRelationalOperator_a) {
    /* Switch: '<S15>/Switch1' */
    auto_pilot_upl_B.Switch1_e = auto_pilot_upl_B.setspeedmemory;
  } else {
    /* Switch: '<S15>/Switch1' */
    auto_pilot_upl_B.Switch1_e = auto_pilot_upl_B.Product8;
  }

  /* End of Switch: '<S15>/Switch1' */

  /* Product: '<S15>/Product1' incorporates:
   *  Sum: '<S15>/Error'
   */
  auto_pilot_upl_B.differencebetweerreferenceandactualspeed =
    (auto_pilot_upl_B.Switch1_e -
     auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal) *
    auto_pilot_upl_B.Switch_o;

  /* Product: '<S15>/Product2' incorporates:
   *  Constant: '<S20>/Constant'
   *  RelationalOperator: '<S20>/Compare'
   */
  auto_pilot_upl_B.Product2_g = (real_T)(auto_pilot_upl_P.ACC_SensorMaxDistance
    + 1.0 == auto_pilot_upl_B.MinMax) * auto_pilot_upl_B.Switch_o;
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* DiscreteIntegrator: '<S67>/Integrator' */
    if (auto_pilot_upl_DW.Integrator_IC_LOADING != 0) {
      auto_pilot_upl_DW.Integrator_DSTATE_i3 =
        auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandsthrottle;
    }

    if (((auto_pilot_upl_B.Product2_g > 0.0) &&
         (auto_pilot_upl_DW.Integrator_PrevResetState_c <= 0)) ||
        ((auto_pilot_upl_B.Product2_g <= 0.0) &&
         (auto_pilot_upl_DW.Integrator_PrevResetState_c == 1))) {
      auto_pilot_upl_DW.Integrator_DSTATE_i3 =
        auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandsthrottle;
    }

    /* Sum: '<S76>/Sum' incorporates:
     *  DiscreteIntegrator: '<S67>/Integrator'
     *  Gain: '<S72>/Proportional Gain'
     */
    rtb_Sum_f = auto_pilot_upl_P.ACC_Classic_P *
      auto_pilot_upl_B.differencebetweerreferenceandactualspeed +
      auto_pilot_upl_DW.Integrator_DSTATE_i3;

    /* Saturate: '<S74>/Saturation' */
    if (rtb_Sum_f > auto_pilot_upl_P.ACC_MaxThrottle) {
      /* Saturate: '<S74>/Saturation' */
      auto_pilot_upl_B.Saturation_d = auto_pilot_upl_P.ACC_MaxThrottle;
    } else if (rtb_Sum_f < -auto_pilot_upl_P.ACC_MaxBrake) {
      /* Saturate: '<S74>/Saturation' */
      auto_pilot_upl_B.Saturation_d = -auto_pilot_upl_P.ACC_MaxBrake;
    } else {
      /* Saturate: '<S74>/Saturation' */
      auto_pilot_upl_B.Saturation_d = rtb_Sum_f;
    }

    /* End of Saturate: '<S74>/Saturation' */
  }

  /* Product: '<S15>/Product6' */
  rtb_Saturation3 = auto_pilot_upl_B.Saturation_d * auto_pilot_upl_B.Product2_g;

  /* RelationalOperator: '<S22>/Compare' incorporates:
   *  Constant: '<S22>/Constant'
   */
  rtb_Compare_hm = (auto_pilot_upl_B.Switch_o == auto_pilot_upl_P.Constant_Value);

  /* Saturate: '<S15>/Saturation1' */
  if (rtb_AEB_Output_Brake_Gain > auto_pilot_upl_P.Saturation1_UpperSat) {
    rtb_Switch4 = auto_pilot_upl_P.Saturation1_UpperSat;
  } else if (rtb_AEB_Output_Brake_Gain < auto_pilot_upl_P.Saturation1_LowerSat)
  {
    rtb_Switch4 = auto_pilot_upl_P.Saturation1_LowerSat;
  } else {
    rtb_Switch4 = rtb_AEB_Output_Brake_Gain;
  }

  /* Saturate: '<S15>/Saturation2' */
  if (rtb_Saturation3 > auto_pilot_upl_P.Saturation2_UpperSat) {
    deltaT = auto_pilot_upl_P.Saturation2_UpperSat;
  } else if (rtb_Saturation3 < auto_pilot_upl_P.Saturation2_LowerSat) {
    deltaT = auto_pilot_upl_P.Saturation2_LowerSat;
  } else {
    deltaT = rtb_Saturation3;
  }

  /* Sum: '<S15>/Sum' incorporates:
   *  Gain: '<S15>/ACC_Brake_Gain1'
   *  Gain: '<S15>/ACC_Brake_Gain2'
   *  Product: '<S15>/Product'
   *  Saturate: '<S15>/Saturation1'
   *  Saturate: '<S15>/Saturation2'
   */
  auto_pilot_upl_B.Sum = (auto_pilot_upl_P.ACC_Brake_Gain2_Gain * rtb_Switch4 +
    auto_pilot_upl_P.ACC_Brake_Gain1_Gain * deltaT) +
    auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandsbrake * (real_T)
    rtb_Compare_hm;
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* Sum: '<S34>/Sum' incorporates:
     *  Gain: '<S34>/Gain'
     *  Sum: '<S34>/Diff'
     */
    auto_pilot_upl_B.Sum_e = (rtb_Yk1_h - auto_pilot_upl_B.Sum) *
      auto_pilot_upl_P.TransferFcnFirstOrder9_PoleZ + auto_pilot_upl_B.Sum;

    /* Sum: '<S33>/Sum' incorporates:
     *  Gain: '<S33>/Gain'
     *  Sum: '<S33>/Diff'
     */
    auto_pilot_upl_B.Sum_p = (rtb_Yk1_g - auto_pilot_upl_B.Sum_e) *
      auto_pilot_upl_P.TransferFcnFirstOrder8_PoleZ + auto_pilot_upl_B.Sum_e;

    /* Sum: '<S26>/Sum' incorporates:
     *  Gain: '<S26>/Gain'
     *  Sum: '<S26>/Diff'
     */
    auto_pilot_upl_B.Sum_a = (rtb_Yk1_i - auto_pilot_upl_B.Sum_p) *
      auto_pilot_upl_P.TransferFcnFirstOrder10_PoleZ + auto_pilot_upl_B.Sum_p;

    /* Sum: '<S27>/Sum' incorporates:
     *  Gain: '<S27>/Gain'
     *  Sum: '<S27>/Diff'
     */
    auto_pilot_upl_B.Sum_l = (rtb_Yk1 - auto_pilot_upl_B.Sum_a) *
      auto_pilot_upl_P.TransferFcnFirstOrder11_PoleZ + auto_pilot_upl_B.Sum_a;

    /* Saturate: '<S15>/Saturation8' */
    if (auto_pilot_upl_B.Sum_l > auto_pilot_upl_P.Saturation8_UpperSat) {
      /* Saturate: '<S15>/Saturation8' */
      auto_pilot_upl_B.Saturation8 = auto_pilot_upl_P.Saturation8_UpperSat;
    } else if (auto_pilot_upl_B.Sum_l < auto_pilot_upl_P.Saturation8_LowerSat) {
      /* Saturate: '<S15>/Saturation8' */
      auto_pilot_upl_B.Saturation8 = auto_pilot_upl_P.Saturation8_LowerSat;
    } else {
      /* Saturate: '<S15>/Saturation8' */
      auto_pilot_upl_B.Saturation8 = auto_pilot_upl_B.Sum_l;
    }

    /* End of Saturate: '<S15>/Saturation8' */

    /* UnitDelay: '<S32>/UD' */
    rtb_Yk1_l = auto_pilot_upl_DW.UD_DSTATE_p;

    /* UnitDelay: '<S31>/UD' */
    rtb_Yk1_j = auto_pilot_upl_DW.UD_DSTATE_ou;

    /* UnitDelay: '<S29>/UD' */
    rtb_Yk1_cw = auto_pilot_upl_DW.UD_DSTATE_f;

    /* UnitDelay: '<S30>/UD' */
    rtb_Yk1_lk = auto_pilot_upl_DW.UD_DSTATE_em;
  }

  /* Saturate: '<S15>/Saturation3' */
  if (rtb_Saturation3 > auto_pilot_upl_P.Saturation3_UpperSat) {
    rtb_Saturation3 = auto_pilot_upl_P.Saturation3_UpperSat;
  } else if (rtb_Saturation3 < auto_pilot_upl_P.Saturation3_LowerSat) {
    rtb_Saturation3 = auto_pilot_upl_P.Saturation3_LowerSat;
  }

  /* Saturate: '<S15>/Saturation4' */
  if (rtb_AEB_Output_Brake_Gain > auto_pilot_upl_P.Saturation4_UpperSat) {
    rtb_AEB_Output_Brake_Gain = auto_pilot_upl_P.Saturation4_UpperSat;
  } else if (rtb_AEB_Output_Brake_Gain < auto_pilot_upl_P.Saturation4_LowerSat)
  {
    rtb_AEB_Output_Brake_Gain = auto_pilot_upl_P.Saturation4_LowerSat;
  }

  /* Sum: '<S15>/Sum1' incorporates:
   *  Product: '<S15>/Product5'
   *  Saturate: '<S15>/Saturation3'
   *  Saturate: '<S15>/Saturation4'
   */
  auto_pilot_upl_B.Sum1 = ((real_T)rtb_Compare_hm *
    auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandsthrottle +
    rtb_Saturation3) + rtb_AEB_Output_Brake_Gain;
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* Sum: '<S30>/Sum' incorporates:
     *  Gain: '<S30>/Gain'
     *  Sum: '<S30>/Diff'
     */
    auto_pilot_upl_B.Sum_g = (rtb_Yk1_lk - auto_pilot_upl_B.Sum1) *
      auto_pilot_upl_P.TransferFcnFirstOrder5_PoleZ + auto_pilot_upl_B.Sum1;

    /* Sum: '<S29>/Sum' incorporates:
     *  Gain: '<S29>/Gain'
     *  Sum: '<S29>/Diff'
     */
    auto_pilot_upl_B.Sum_py = (rtb_Yk1_cw - auto_pilot_upl_B.Sum_g) *
      auto_pilot_upl_P.TransferFcnFirstOrder4_PoleZ + auto_pilot_upl_B.Sum_g;

    /* Sum: '<S31>/Sum' incorporates:
     *  Gain: '<S31>/Gain'
     *  Sum: '<S31>/Diff'
     */
    auto_pilot_upl_B.Sum_ep = (rtb_Yk1_j - auto_pilot_upl_B.Sum_py) *
      auto_pilot_upl_P.TransferFcnFirstOrder6_PoleZ + auto_pilot_upl_B.Sum_py;

    /* Sum: '<S32>/Sum' incorporates:
     *  Gain: '<S32>/Gain'
     *  Sum: '<S32>/Diff'
     */
    auto_pilot_upl_B.Sum_h = (rtb_Yk1_l - auto_pilot_upl_B.Sum_ep) *
      auto_pilot_upl_P.TransferFcnFirstOrder7_PoleZ + auto_pilot_upl_B.Sum_ep;

    /* Saturate: '<S15>/Saturation9' */
    if (auto_pilot_upl_B.Sum_h > auto_pilot_upl_P.Saturation9_UpperSat) {
      /* Saturate: '<S15>/Saturation9' */
      auto_pilot_upl_B.Saturation9 = auto_pilot_upl_P.Saturation9_UpperSat;
    } else if (auto_pilot_upl_B.Sum_h < auto_pilot_upl_P.Saturation9_LowerSat) {
      /* Saturate: '<S15>/Saturation9' */
      auto_pilot_upl_B.Saturation9 = auto_pilot_upl_P.Saturation9_LowerSat;
    } else {
      /* Saturate: '<S15>/Saturation9' */
      auto_pilot_upl_B.Saturation9 = auto_pilot_upl_B.Sum_h;
    }

    /* End of Saturate: '<S15>/Saturation9' */

    /* RelationalOperator: '<S206>/Compare' incorporates:
     *  Constant: '<S198>/Constant1'
     *  Constant: '<S206>/Constant'
     */
    auto_pilot_upl_B.Compare_i = (auto_pilot_upl_P.radar_source ==
      auto_pilot_upl_P.CompareToConstant3_const_m);

    /* RelationalOperator: '<S204>/Compare' incorporates:
     *  Constant: '<S198>/Constant'
     *  Constant: '<S204>/Constant'
     */
    auto_pilot_upl_B.Compare_k = (auto_pilot_upl_P.Constant_Value_n !=
      auto_pilot_upl_P.CompareToConstant1_const_p);
  }

  /* Product: '<S198>/Product' incorporates:
   *  RelationalOperator: '<S198>/Relational Operator'
   */
  for (i = 0; i < 10; i++) {
    rtb_Target_Lateral_Position[i] = (real_T)(auto_pilot_upl_B.MultiportSwitch[i
      + 10] == auto_pilot_upl_B.MinMax) * auto_pilot_upl_B.MultiportSwitch[i];
  }

  /* End of Product: '<S198>/Product' */

  /* MinMax: '<S198>/MinMax' */
  rtb_AEB_Output_Brake_Gain = rtb_Target_Lateral_Position[0];
  for (i = 0; i < 9; i++) {
    rtb_AEB_Output_Brake_Gain = fmax(rtb_AEB_Output_Brake_Gain,
      rtb_Target_Lateral_Position[i + 1]);
  }

  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* Product: '<S10>/Product2' incorporates:
     *  Constant: '<S10>/ACC_Module_Activity_Flag1'
     *  Constant: '<S10>/Constant4'
     *  Constant: '<S16>/Constant'
     *  Constant: '<S213>/Constant'
     *  DataTypeConversion: '<S10>/Cast To Double'
     *  Logic: '<S10>/OR'
     *  RelationalOperator: '<S213>/Compare'
     */
    auto_pilot_upl_B.Product2_n = (real_T)
      ((auto_pilot_upl_P.ACC_Module_Activity_Flag != 0.0) ||
       (auto_pilot_upl_P.AP_Activity_Flag != 0.0)) * (real_T)
      (auto_pilot_upl_P.Constant_Value_k == auto_pilot_upl_P.Constant_Value_g);
  }

  /* Switch: '<S10>/Switch' incorporates:
   *  Gain: '<S10>/Gain'
   *  Switch: '<S198>/Switch'
   */
  if (auto_pilot_upl_B.Product2_n > auto_pilot_upl_P.Switch_Threshold_c) {
    rtb_Switch4 = auto_pilot_upl_B.Saturation8;
    rtb_Saturation3 = auto_pilot_upl_B.Saturation9;
    rtb_Yk1_i = auto_pilot_upl_B.Switch_o;

    /* Switch: '<S198>/Switch1' incorporates:
     *  Constant: '<S205>/Constant'
     *  Logic: '<S198>/AND'
     *  RelationalOperator: '<S205>/Compare'
     */
    if (auto_pilot_upl_B.Compare_i) {
      rtb_Compare_hm = ((auto_pilot_upl_B.MinMax ==
                         auto_pilot_upl_P.CompareToConstant2_const_p) &&
                        auto_pilot_upl_B.Compare_i);
    } else {
      rtb_Compare_hm = auto_pilot_upl_B.Compare_k;
    }

    /* Switch: '<S198>/Switch' incorporates:
     *  Constant: '<S198>/No_Target_Display_Value'
     *  Constant: '<S203>/Constant'
     *  Logic: '<S198>/Logical Operator'
     *  Logic: '<S198>/Logical Operator1'
     *  MinMax: '<S198>/MinMax'
     *  RelationalOperator: '<S198>/Relational Operator1'
     *  RelationalOperator: '<S198>/Relational Operator2'
     *  RelationalOperator: '<S203>/Compare'
     *  Switch: '<S198>/Switch1'
     */
    if (rtb_Compare_hm || rtIsInf(rtb_AEB_Output_Brake_Gain) || rtIsNaN
        (rtb_AEB_Output_Brake_Gain) || (((auto_pilot_upl_B.DataTypeConversion !=
           0.0) || (auto_pilot_upl_B.Switch_o != 0.0)) != (int32_T)
         auto_pilot_upl_P.CompareToConstant_const_l)) {
      rtb_Yk1_g = auto_pilot_upl_P.No_Target_Display_Value;
    } else {
      rtb_Yk1_g = rtb_AEB_Output_Brake_Gain;
    }

    rtb_Yk1_h = auto_pilot_upl_B.DataTypeConversion;
    rtb_Yk1 = auto_pilot_upl_B.Product8;
  } else {
    rtb_Switch4 = auto_pilot_upl_P.Gain_Gain * auto_pilot_upl_B.Saturation8;
    rtb_Saturation3 = auto_pilot_upl_P.Gain_Gain * auto_pilot_upl_B.Saturation9;
    rtb_Yk1_i = auto_pilot_upl_P.Gain_Gain * auto_pilot_upl_B.Switch_o;

    /* Switch: '<S198>/Switch1' incorporates:
     *  Constant: '<S205>/Constant'
     *  Gain: '<S10>/Gain'
     *  Logic: '<S198>/AND'
     *  RelationalOperator: '<S205>/Compare'
     */
    if (auto_pilot_upl_B.Compare_i) {
      rtb_Compare_hm = ((auto_pilot_upl_B.MinMax ==
                         auto_pilot_upl_P.CompareToConstant2_const_p) &&
                        auto_pilot_upl_B.Compare_i);
    } else {
      rtb_Compare_hm = auto_pilot_upl_B.Compare_k;
    }

    /* Switch: '<S198>/Switch' incorporates:
     *  Constant: '<S198>/No_Target_Display_Value'
     *  Constant: '<S203>/Constant'
     *  Logic: '<S198>/Logical Operator'
     *  Logic: '<S198>/Logical Operator1'
     *  MinMax: '<S198>/MinMax'
     *  RelationalOperator: '<S198>/Relational Operator1'
     *  RelationalOperator: '<S198>/Relational Operator2'
     *  RelationalOperator: '<S203>/Compare'
     *  Switch: '<S198>/Switch1'
     */
    if (rtb_Compare_hm || rtIsInf(rtb_AEB_Output_Brake_Gain) || rtIsNaN
        (rtb_AEB_Output_Brake_Gain) || (((auto_pilot_upl_B.DataTypeConversion !=
           0.0) || (auto_pilot_upl_B.Switch_o != 0.0)) != (int32_T)
         auto_pilot_upl_P.CompareToConstant_const_l)) {
      rtb_AEB_Output_Brake_Gain = auto_pilot_upl_P.No_Target_Display_Value;
    }

    rtb_Yk1_g = auto_pilot_upl_P.Gain_Gain * rtb_AEB_Output_Brake_Gain;
    rtb_Yk1_h = auto_pilot_upl_P.Gain_Gain * auto_pilot_upl_B.DataTypeConversion;
    rtb_Yk1 = auto_pilot_upl_P.Gain_Gain * auto_pilot_upl_B.Product8;
  }

  /* End of Switch: '<S10>/Switch' */

  /* MinMax: '<S319>/Max' incorporates:
   *  Gain: '<S319>/ACC_Output_Brake_Gain'
   *  Gain: '<S319>/AEB_Output_Brake_Gain'
   */
  auto_pilot_upl_B.Max = fmax(fmax(auto_pilot_upl_P.ACC_Output_Brake_Gain_Gain *
    rtb_Switch4, auto_pilot_upl_P.AEB_Output_Brake_Gain_Gain *
    auto_pilot_upl_B.Switch_h[0]),
    auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandsbrake);

  /* MinMax: '<S319>/Max1' */
  auto_pilot_upl_B.Max1 = fmax
    (auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandsthrottle,
     rtb_Saturation3);

  /* DataTypeConversion: '<S7>/Data Type Conversion6' incorporates:
   *  Constant: '<S346>/Constant'
   *  Product: '<S7>/Product5'
   *  RelationalOperator: '<S346>/Compare'
   */
  auto_pilot_upl_B.DataTypeConversion6 =
    (auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal <
     auto_pilot_upl_P.gear_change_max_speed_up_const) * rtb_Compare_gr;

  /* Gain: '<S249>/Gain4' */
  auto_pilot_upl_B.Gain4 = auto_pilot_upl_P.Gain4_Gain *
    auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandssteering;
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* RelationalOperator: '<S253>/Compare' incorporates:
     *  Constant: '<S253>/Constant'
     *  Memory: '<S250>/Memory2'
     */
    auto_pilot_upl_B.Compare_n = (auto_pilot_upl_DW.Memory2_PreviousInput_c !=
      auto_pilot_upl_P.CompareToConstant1_const_b);

    /* RelationalOperator: '<S256>/Compare' incorporates:
     *  Constant: '<S250>/Constant'
     *  Constant: '<S256>/Constant'
     */
    auto_pilot_upl_B.Compare_ix = (auto_pilot_upl_P.Constant_Value_mq !=
      auto_pilot_upl_P.CompareToConstant4_const_n);

    /* RateTransition: '<S250>/Rate Transition8' */
    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_3) {
      /* RateTransition: '<S250>/Rate Transition8' */
      auto_pilot_upl_B.RateTransition8 =
        auto_pilot_upl_DW.RateTransition8_Buffer0;
    }

    /* End of RateTransition: '<S250>/Rate Transition8' */

    /* RelationalOperator: '<S254>/Compare' incorporates:
     *  Abs: '<S250>/Abs2'
     *  Constant: '<S254>/Constant'
     */
    auto_pilot_upl_B.Compare_k0 = (fabs(auto_pilot_upl_B.RateTransition8) <=
      auto_pilot_upl_P.AP_Max_Error_dydt_Disable);

    /* RelationalOperator: '<S258>/Compare' incorporates:
     *  Constant: '<S250>/Constant'
     *  Constant: '<S258>/Constant'
     */
    auto_pilot_upl_B.Compare_g = (auto_pilot_upl_P.Constant_Value_mq !=
      auto_pilot_upl_P.CompareToConstant6_const);

    /* Product: '<S250>/Product5' incorporates:
     *  Constant: '<S16>/Constant'
     *  Constant: '<S250>/Constant4'
     *  Constant: '<S261>/Constant'
     *  RelationalOperator: '<S261>/Compare'
     */
    auto_pilot_upl_B.Product5 = (real_T)(auto_pilot_upl_P.Constant_Value_k ==
      auto_pilot_upl_P.Constant_Value_c) * auto_pilot_upl_P.AP_Activity_Flag;
  }

  /* RelationalOperator: '<S259>/Compare' incorporates:
   *  Constant: '<S259>/Constant'
   */
  rtb_Compare_hm = (auto_pilot_upl_B.VI_DriveSimOutputsVicrtStatus ==
                    auto_pilot_upl_P.CompareToConstant8_const);

  /* DataTypeConversion: '<S250>/Data Type Conversion3' incorporates:
   *  Logic: '<S250>/Logical Operator'
   */
  auto_pilot_upl_B.DataTypeConversion3 = ((auto_pilot_upl_B.DataTypeConversion
    != 0.0) && auto_pilot_upl_B.Compare_n && auto_pilot_upl_B.Compare_ix &&
    auto_pilot_upl_B.Compare_k0 && auto_pilot_upl_B.Compare_g &&
    (auto_pilot_upl_B.Product5 != 0.0) && rtb_Compare_hm);

  /* DataTypeConversion: '<S250>/Data Type Conversion2' incorporates:
   *  Constant: '<S257>/Constant'
   *  RelationalOperator: '<S257>/Compare'
   */
  auto_pilot_upl_B.DataTypeConversion2_g = (auto_pilot_upl_B.DataTypeConversion3
    >= auto_pilot_upl_P.CompareToConstant5_const);

  /* Product: '<S250>/Product6' */
  auto_pilot_upl_B.Product6 = auto_pilot_upl_B.Product_o *
    auto_pilot_upl_B.DataTypeConversion2_g;

  /* Integrator: '<S250>/Integrator' */
  if (rtsiIsModeUpdateTimeStep(&auto_pilot_upl_M->solverInfo)) {
    zcEvent = rt_ZCFcn(ANY_ZERO_CROSSING,
                       &auto_pilot_upl_PrevZCX.Integrator_Reset_ZCE,
                       (auto_pilot_upl_B.Product6));

    /* evaluate zero-crossings */
    if (zcEvent != NO_ZCEVENT) {
      auto_pilot_upl_X.Integrator_CSTATE = auto_pilot_upl_P.Integrator_IC;
    }
  }

  /* Integrator: '<S250>/Integrator' */
  auto_pilot_upl_B.Integrator = auto_pilot_upl_X.Integrator_CSTATE;
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* Memory: '<S250>/Memory1' */
    auto_pilot_upl_B.delatch = auto_pilot_upl_DW.Memory1_PreviousInput_n;

    /* Memory: '<S250>/Memory' */
    auto_pilot_upl_B.Memory_f = auto_pilot_upl_DW.Memory_PreviousInput_n;
  }

  /* Switch: '<S250>/Switch' incorporates:
   *  Constant: '<S252>/Constant'
   *  RelationalOperator: '<S252>/Compare'
   */
  if (auto_pilot_upl_B.Integrator >= auto_pilot_upl_P.AP_On_Request_Time) {
    /* Switch: '<S250>/Switch' */
    auto_pilot_upl_B.Switch_j = 1.0;
  } else {
    /* Switch: '<S250>/Switch' incorporates:
     *  Constant: '<S260>/Constant'
     *  Product: '<S250>/Product4'
     *  RelationalOperator: '<S260>/Compare'
     */
    auto_pilot_upl_B.Switch_j = auto_pilot_upl_B.Switch_o * (real_T)
      auto_pilot_upl_B.delatch * (real_T)auto_pilot_upl_B.Compare_g * (real_T)
      rtb_Compare_hm * auto_pilot_upl_B.Product5 * auto_pilot_upl_B.Memory_f *
      (real_T)(auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandsbrake <=
               auto_pilot_upl_P.CompareToConstant9_const);
  }

  /* End of Switch: '<S250>/Switch' */

  /* RateLimiter: '<S250>/Rate Limiter1' */
  if ((auto_pilot_upl_DW.LastMajorTimeA_g >= rtb_PulseGenerator) &&
      (auto_pilot_upl_DW.LastMajorTimeB_b >= rtb_PulseGenerator)) {
    /* RateLimiter: '<S250>/Rate Limiter1' */
    auto_pilot_upl_B.RateLimiter1 = auto_pilot_upl_B.Switch_j;
  } else {
    if (((auto_pilot_upl_DW.LastMajorTimeA_g <
          auto_pilot_upl_DW.LastMajorTimeB_b) &&
         (auto_pilot_upl_DW.LastMajorTimeB_b < rtb_PulseGenerator)) ||
        ((auto_pilot_upl_DW.LastMajorTimeA_g >=
          auto_pilot_upl_DW.LastMajorTimeB_b) &&
         (auto_pilot_upl_DW.LastMajorTimeA_g >= rtb_PulseGenerator))) {
      deltaT = rtb_PulseGenerator - auto_pilot_upl_DW.LastMajorTimeB_b;
      rtb_Switch4 = auto_pilot_upl_DW.PrevYB_e;
    } else {
      deltaT = rtb_PulseGenerator - auto_pilot_upl_DW.LastMajorTimeA_g;
      rtb_Switch4 = auto_pilot_upl_DW.PrevYA_p;
    }

    riseValLimit = deltaT * auto_pilot_upl_P.AP_Transition_Rate;
    rtb_AEB_Output_Brake_Gain = auto_pilot_upl_B.Switch_j - rtb_Switch4;
    if (rtb_AEB_Output_Brake_Gain > riseValLimit) {
      /* RateLimiter: '<S250>/Rate Limiter1' */
      auto_pilot_upl_B.RateLimiter1 = rtb_Switch4 + riseValLimit;
    } else {
      deltaT *= -auto_pilot_upl_P.AP_Transition_Rate;
      if (rtb_AEB_Output_Brake_Gain < deltaT) {
        /* RateLimiter: '<S250>/Rate Limiter1' */
        auto_pilot_upl_B.RateLimiter1 = rtb_Switch4 + deltaT;
      } else {
        /* RateLimiter: '<S250>/Rate Limiter1' */
        auto_pilot_upl_B.RateLimiter1 = auto_pilot_upl_B.Switch_j;
      }
    }
  }

  /* RateTransition: '<S250>/Rate Transition5' */
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_3) {
      /* RateTransition: '<S250>/Rate Transition5' */
      auto_pilot_upl_B.RateTransition5 =
        auto_pilot_upl_DW.RateTransition5_Buffer0;
    }

    /* Sum: '<S60>/SumI4' incorporates:
     *  Gain: '<S60>/Kb'
     *  Gain: '<S64>/Integral Gain'
     *  Sum: '<S60>/SumI2'
     */
    auto_pilot_upl_B.SumI4 = (auto_pilot_upl_B.Saturation_d - rtb_Sum_f) *
      auto_pilot_upl_P.ACC_PID_Kb + auto_pilot_upl_P.ACC_Classic_I *
      auto_pilot_upl_B.differencebetweerreferenceandactualspeed;

    /* Saturate: '<S19>/Saturation' */
    if (auto_pilot_upl_DW.Memory_PreviousInput_a >
        auto_pilot_upl_P.Saturation_UpperSat) {
      rtb_Switch4 = auto_pilot_upl_P.Saturation_UpperSat;
    } else if (auto_pilot_upl_DW.Memory_PreviousInput_a <
               auto_pilot_upl_P.Saturation_LowerSat) {
      rtb_Switch4 = auto_pilot_upl_P.Saturation_LowerSat;
    } else {
      rtb_Switch4 = auto_pilot_upl_DW.Memory_PreviousInput_a;
    }

    /* Sum: '<S19>/Sum' incorporates:
     *  Constant: '<S8>/Constant1'
     *  Gain: '<S19>/Gain'
     *  RelationalOperator: '<S84>/FixPt Relational Operator'
     *  RelationalOperator: '<S85>/FixPt Relational Operator'
     *  Saturate: '<S19>/Saturation'
     *  UnitDelay: '<S84>/Delay Input1'
     *  UnitDelay: '<S85>/Delay Input1'
     */
    auto_pilot_upl_B.Sum_k = ((real_T)(auto_pilot_upl_P.Constant1_Value >
      auto_pilot_upl_DW.DelayInput1_DSTATE_g ? (int32_T)
      auto_pilot_upl_P.Gain_Gain_c : 0) * 0.0078125 + (real_T)
      (auto_pilot_upl_P.Constant1_Value > auto_pilot_upl_DW.DelayInput1_DSTATE_j))
      + rtb_Switch4;
  }

  /* End of RateTransition: '<S250>/Rate Transition5' */

  /* Gain: '<S250>/Gain2' incorporates:
   *  Constant: '<S250>/Constant2'
   *  Product: '<S250>/Product2'
   *  Product: '<S250>/Product3'
   *  Sum: '<S250>/Add'
   *  Sum: '<S250>/Subtract1'
   */
  auto_pilot_upl_B.Gain2 = ((auto_pilot_upl_P.Constant2_Value_b -
    auto_pilot_upl_B.RateLimiter1) * auto_pilot_upl_B.Gain4 +
    auto_pilot_upl_B.RateLimiter1 * auto_pilot_upl_B.RateTransition5) *
    auto_pilot_upl_P.Gain2_Gain;

  /* DataTypeConversion: '<S7>/Data Type Conversion4' incorporates:
   *  Constant: '<S345>/Constant'
   *  Product: '<S7>/Product3'
   *  RelationalOperator: '<S345>/Compare'
   */
  auto_pilot_upl_B.DataTypeConversion4 =
    (auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal <
     auto_pilot_upl_P.gear_change_max_speed_down_const) * rtb_Compare_nd;

  /* MultiPortSwitch: '<S19>/Multiport Switch' */
  switch ((int32_T)auto_pilot_upl_B.Sum_k) {
   case 1:
    /* MultiPortSwitch: '<S19>/Multiport Switch' incorporates:
     *  Gain: '<S19>/ACC_Speed_Distance_Gain'
     */
    auto_pilot_upl_B.MultiportSwitch_h =
      auto_pilot_upl_P.ACC_Speed_Distance_Gain[0] *
      auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal;
    break;

   case 2:
    /* MultiPortSwitch: '<S19>/Multiport Switch' incorporates:
     *  Gain: '<S19>/ACC_Speed_Distance_Gain1'
     */
    auto_pilot_upl_B.MultiportSwitch_h =
      auto_pilot_upl_P.ACC_Speed_Distance_Gain[1] *
      auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal;
    break;

   case 3:
    /* MultiPortSwitch: '<S19>/Multiport Switch' incorporates:
     *  Gain: '<S19>/ACC_Speed_Distance_Gain2'
     */
    auto_pilot_upl_B.MultiportSwitch_h =
      auto_pilot_upl_P.ACC_Speed_Distance_Gain[2] *
      auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal;
    break;

   case 4:
    /* MultiPortSwitch: '<S19>/Multiport Switch' incorporates:
     *  Gain: '<S19>/ACC_Speed_Distance_Gain3'
     */
    auto_pilot_upl_B.MultiportSwitch_h =
      auto_pilot_upl_P.ACC_Speed_Distance_Gain[3] *
      auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal;
    break;

   default:
    /* MultiPortSwitch: '<S19>/Multiport Switch' incorporates:
     *  Gain: '<S19>/ACC_Speed_Distance_Gain1'
     */
    auto_pilot_upl_B.MultiportSwitch_h =
      auto_pilot_upl_P.ACC_Speed_Distance_Gain[1] *
      auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal;
    break;
  }

  /* End of MultiPortSwitch: '<S19>/Multiport Switch' */
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* Sum: '<S110>/SumI4' incorporates:
     *  Gain: '<S110>/Kb'
     *  Gain: '<S114>/Integral Gain'
     *  Sum: '<S110>/SumI2'
     */
    auto_pilot_upl_B.SumI4_k = (auto_pilot_upl_B.Saturation - rtb_Sum_p) *
      auto_pilot_upl_P.DiscretePIDController1_Kb +
      auto_pilot_upl_P.ACC_Classic_I * auto_pilot_upl_B.Error2;

    /* RateTransition: '<S15>/Rate Transition' incorporates:
     *  RateTransition generated from: '<S159>/SumI4'
     */
    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_3) {
      auto_pilot_upl_DW.RateTransition_Buffer = auto_pilot_upl_B.MinMax;

      /* RateTransition: '<S15>/Rate Transition1' */
      auto_pilot_upl_DW.RateTransition1_Buffer =
        auto_pilot_upl_B.MultiportSwitch_h;

      /* RateTransition generated from: '<S159>/SumI4' */
      auto_pilot_upl_B.TmpRTBAtSumI4Inport2 =
        auto_pilot_upl_DW.TmpRTBAtSumI4Inport2_Buffer0;
    }

    /* End of RateTransition: '<S15>/Rate Transition' */

    /* Sum: '<S159>/SumI4' incorporates:
     *  Gain: '<S159>/Kb'
     *  Sum: '<S159>/SumI2'
     */
    auto_pilot_upl_B.SumI4_a = (auto_pilot_upl_B.Saturation_o - rtb_Sum_e) *
      auto_pilot_upl_P.tACC_PID_Kb + auto_pilot_upl_B.TmpRTBAtSumI4Inport2;
  }

  /* Product: '<S10>/Product' */
  rtb_Yk1 *= rtb_Yk1_i;

  /* Product: '<S10>/Product1' */
  auto_pilot_upl_B.Product1_n = rtb_Yk1_i * rtb_Yk1_g;

  /* RateLimiter: '<S10>/Rate Limiter' */
  if ((auto_pilot_upl_DW.LastMajorTimeA_gx >= rtb_PulseGenerator) &&
      (auto_pilot_upl_DW.LastMajorTimeB_e >= rtb_PulseGenerator)) {
    /* RateLimiter: '<S10>/Rate Limiter' */
    auto_pilot_upl_B.RateLimiter_p = rtb_Yk1;
  } else {
    if (((auto_pilot_upl_DW.LastMajorTimeA_gx <
          auto_pilot_upl_DW.LastMajorTimeB_e) &&
         (auto_pilot_upl_DW.LastMajorTimeB_e < rtb_PulseGenerator)) ||
        ((auto_pilot_upl_DW.LastMajorTimeA_gx >=
          auto_pilot_upl_DW.LastMajorTimeB_e) &&
         (auto_pilot_upl_DW.LastMajorTimeA_gx >= rtb_PulseGenerator))) {
      deltaT = rtb_PulseGenerator - auto_pilot_upl_DW.LastMajorTimeB_e;
      rtb_Switch4 = auto_pilot_upl_DW.PrevYB_f;
    } else {
      deltaT = rtb_PulseGenerator - auto_pilot_upl_DW.LastMajorTimeA_gx;
      rtb_Switch4 = auto_pilot_upl_DW.PrevYA_c;
    }

    riseValLimit = deltaT * auto_pilot_upl_P.RateLimiter_RisingLim_p;
    rtb_AEB_Output_Brake_Gain = rtb_Yk1 - rtb_Switch4;
    if (rtb_AEB_Output_Brake_Gain > riseValLimit) {
      /* RateLimiter: '<S10>/Rate Limiter' */
      auto_pilot_upl_B.RateLimiter_p = rtb_Switch4 + riseValLimit;
    } else {
      deltaT *= auto_pilot_upl_P.RateLimiter_FallingLim_f;
      if (rtb_AEB_Output_Brake_Gain < deltaT) {
        /* RateLimiter: '<S10>/Rate Limiter' */
        auto_pilot_upl_B.RateLimiter_p = rtb_Switch4 + deltaT;
      } else {
        /* RateLimiter: '<S10>/Rate Limiter' */
        auto_pilot_upl_B.RateLimiter_p = rtb_Yk1;
      }
    }
  }

  /* Sum: '<S10>/Sum' */
  auto_pilot_upl_B.Sum_g0 = rtb_Yk1_h - rtb_Yk1_i;

  /* RateTransition: '<S215>/Rate Transition5' */
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* DiscretePulseGenerator: '<S216>/Pulse Generator' */
    auto_pilot_upl_B.PulseGenerator = (auto_pilot_upl_DW.clockTickCounter_k <
      auto_pilot_upl_P.PulseGenerator_Duty_n) &&
      (auto_pilot_upl_DW.clockTickCounter_k >= 0) ?
      auto_pilot_upl_P.PulseGenerator_Amp_f : 0.0;

    /* DiscretePulseGenerator: '<S216>/Pulse Generator' */
    if (auto_pilot_upl_DW.clockTickCounter_k >=
        auto_pilot_upl_P.PulseGenerator_Period_n - 1.0) {
      auto_pilot_upl_DW.clockTickCounter_k = 0;
    } else {
      auto_pilot_upl_DW.clockTickCounter_k++;
    }

    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_4) {
      /* RateTransition: '<S215>/Rate Transition5' */
      auto_pilot_upl_B.RateTransition5_n =
        auto_pilot_upl_DW.RateTransition5_Buffer0_h;
    }
  }

  /* End of RateTransition: '<S215>/Rate Transition5' */

  /* Product: '<S216>/Product1' */
  auto_pilot_upl_B.Product1_m = auto_pilot_upl_B.Switch_h[2] *
    auto_pilot_upl_B.PulseGenerator;

  /* Product: '<S216>/Product' incorporates:
   *  Constant: '<S247>/Constant'
   *  RelationalOperator: '<S247>/Compare'
   */
  auto_pilot_upl_B.Product_p = (real_T)
    (auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal <
     auto_pilot_upl_P.AEB_Max_Speed) * auto_pilot_upl_B.Product2_h;
  for (i = 0; i <= 8; i += 2) {
    /* Gain: '<S214>/Gain2' */
    tmp = _mm_loadu_pd(&auto_pilot_upl_B.MultiportSwitch[i + 20]);

    /* Gain: '<S214>/Gain2' */
    _mm_storeu_pd(&auto_pilot_upl_B.Gain2_l[i], _mm_mul_pd(tmp, _mm_set1_pd
      (auto_pilot_upl_P.Gain2_Gain_k)));

    /* Gain: '<S214>/Gain2' incorporates:
     *  Gain: '<S214>/Gain4'
     */
    tmp = _mm_loadu_pd(&auto_pilot_upl_B.MultiportSwitch[i + 60]);

    /* Gain: '<S214>/Gain4' incorporates:
     *  Gain: '<S214>/Gain2'
     */
    _mm_storeu_pd(&auto_pilot_upl_B.Gain4_n[i], _mm_mul_pd(tmp, _mm_set1_pd
      (auto_pilot_upl_P.Gain4_Gain_e)));

    /* Gain: '<S214>/Gain2' incorporates:
     *  Gain: '<S214>/Gain5'
     */
    tmp = _mm_loadu_pd(&auto_pilot_upl_B.MultiportSwitch[i + 100]);

    /* Gain: '<S214>/Gain5' incorporates:
     *  Gain: '<S214>/Gain2'
     */
    _mm_storeu_pd(&auto_pilot_upl_B.Gain5[i], _mm_mul_pd(tmp, _mm_set1_pd
      (auto_pilot_upl_P.Gain5_Gain)));

    /* Gain: '<S214>/Gain2' incorporates:
     *  Gain: '<S214>/Gain'
     */
    tmp = _mm_loadu_pd(&auto_pilot_upl_B.MultiportSwitch[i + 10]);

    /* Gain: '<S214>/Gain' incorporates:
     *  Gain: '<S214>/Gain2'
     */
    _mm_storeu_pd(&auto_pilot_upl_B.Gain[i], _mm_mul_pd(tmp, _mm_set1_pd
      (auto_pilot_upl_P.Gain_Gain_nj)));
  }

  /* MATLAB Function: '<S214>/MATLAB Function' incorporates:
   *  MultiPortSwitch: '<S324>/Multiport Switch'
   */
  auto_pilot_upl_MATLABFunction(&auto_pilot_upl_B.MultiportSwitch[50],
    &auto_pilot_upl_B.sf_MATLABFunction_f);

  /* MATLAB Function: '<S214>/MATLAB Function1' incorporates:
   *  MultiPortSwitch: '<S324>/Multiport Switch'
   */
  auto_pilot_upl_MATLABFunction(&auto_pilot_upl_B.MultiportSwitch[90],
    &auto_pilot_upl_B.sf_MATLABFunction1);
  for (i = 0; i <= 8; i += 2) {
    /* Gain: '<S214>/Gain1' */
    tmp = _mm_loadu_pd(&auto_pilot_upl_B.MultiportSwitch[i]);

    /* Gain: '<S214>/Gain1' */
    _mm_storeu_pd(&auto_pilot_upl_B.Gain1_i[i], _mm_mul_pd(_mm_set1_pd
      (auto_pilot_upl_P.Gain1_Gain_m), tmp));

    /* Gain: '<S214>/Gain1' incorporates:
     *  Gain: '<S214>/Gain3'
     */
    tmp = _mm_loadu_pd(&auto_pilot_upl_B.MultiportSwitch[i + 30]);

    /* Gain: '<S214>/Gain3' incorporates:
     *  Gain: '<S214>/Gain1'
     */
    _mm_storeu_pd(&auto_pilot_upl_B.Gain3[i], _mm_mul_pd(tmp, _mm_set1_pd
      (auto_pilot_upl_P.Gain3_Gain)));
  }

  /* RelationalOperator: '<S236>/Compare' incorporates:
   *  Constant: '<S236>/Constant'
   */
  auto_pilot_upl_B.Compare_e =
    (auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal <
     auto_pilot_upl_P.AEB_Max_Speed);

  /* RelationalOperator: '<S237>/Compare' incorporates:
   *  Abs: '<S221>/Abs2'
   *  Constant: '<S237>/Constant'
   */
  auto_pilot_upl_B.Compare_j = (fabs
    (auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandssteering) <
    auto_pilot_upl_P.AEB_Steer_Max * 3.1415926535897931 / 180.0);

  /* RateTransition: '<S221>/Rate Transition' */
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_4) {
      auto_pilot_upl_DW.RateTransition_Buffer_e = auto_pilot_upl_B.Compare_j;

      /* RateTransition: '<S221>/Rate Transition1' */
      auto_pilot_upl_DW.RateTransition1_Buffer_f = auto_pilot_upl_B.Compare_e;

      /* RateTransition: '<S221>/Rate Transition2' */
      for (i = 0; i < 10; i++) {
        auto_pilot_upl_DW.RateTransition2_Buffer[i] = auto_pilot_upl_B.Gain3[i];
        auto_pilot_upl_DW.RateTransition2_Buffer[i + 10] =
          auto_pilot_upl_B.MultiportSwitch[i + 70];
        auto_pilot_upl_DW.RateTransition2_Buffer[i + 20] =
          auto_pilot_upl_B.MultiportSwitch[i + 110];
      }

      /* End of RateTransition: '<S221>/Rate Transition2' */

      /* RateTransition generated from: '<S215>/filtering' */
      memcpy(&auto_pilot_upl_B.after_saturation[0],
             &auto_pilot_upl_DW.after_saturation_Buffer0[0], 30U * sizeof(real_T));
    }

    /* DiscreteFilter: '<S215>/filtering' */
    for (i = 0; i < 30; i++) {
      int32_T memOffset;
      memOffset = i << 1;
      rtb_PulseGenerator = auto_pilot_upl_DW.filtering_states[memOffset + 1];
      auto_pilot_upl_DW.filtering_tmp[i] = ((auto_pilot_upl_B.after_saturation[i]
        - auto_pilot_upl_P.filtering_DenCoef[1] *
        auto_pilot_upl_DW.filtering_states[memOffset]) - rtb_PulseGenerator *
        auto_pilot_upl_P.filtering_DenCoef[2]) /
        auto_pilot_upl_P.filtering_DenCoef[0];
      TSamp_kd[i] = (auto_pilot_upl_P.filtering_NumCoef[0] *
                     auto_pilot_upl_DW.filtering_tmp[i] +
                     auto_pilot_upl_P.filtering_NumCoef[1] *
                     auto_pilot_upl_DW.filtering_states[memOffset]) +
        rtb_PulseGenerator * auto_pilot_upl_P.filtering_NumCoef[2];
    }

    /* End of DiscreteFilter: '<S215>/filtering' */

    /* RateTransition: '<S231>/Rate Transition1' */
    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_4) {
      memcpy(&auto_pilot_upl_DW.RateTransition1_Buffer_g[0], &TSamp_kd[0], 30U *
             sizeof(real_T));

      /* RateTransition: '<S215>/Rate Transition' */
      memcpy(&auto_pilot_upl_DW.RateTransition_Buffer_h[0],
             &auto_pilot_upl_B.Gain[0], 10U * sizeof(real_T));
      memcpy(&auto_pilot_upl_DW.RateTransition_Buffer_h[10],
             &auto_pilot_upl_B.sf_MATLABFunction_f.y[0], 10U * sizeof(real_T));
      memcpy(&auto_pilot_upl_DW.RateTransition_Buffer_h[20],
             &auto_pilot_upl_B.sf_MATLABFunction1.y[0], 10U * sizeof(real_T));
      for (i = 0; i < 10; i++) {
        auto_pilot_upl_DW.RateTransition_Buffer_h[i + 30] =
          auto_pilot_upl_B.Gain2_l[i];
        auto_pilot_upl_DW.RateTransition_Buffer_h[i + 40] =
          auto_pilot_upl_B.Gain4_n[i];
        auto_pilot_upl_DW.RateTransition_Buffer_h[i + 50] =
          auto_pilot_upl_B.Gain5[i];
        auto_pilot_upl_DW.RateTransition_Buffer_h[i + 60] =
          auto_pilot_upl_B.Gain1_i[i];
        auto_pilot_upl_DW.RateTransition_Buffer_h[i + 70] =
          auto_pilot_upl_B.MultiportSwitch[i + 40];
        auto_pilot_upl_DW.RateTransition_Buffer_h[i + 80] =
          auto_pilot_upl_B.MultiportSwitch[i + 80];
      }

      /* End of RateTransition: '<S215>/Rate Transition' */

      /* RateTransition: '<S215>/Rate Transition1' */
      memcpy(&auto_pilot_upl_DW.RateTransition1_Buffer_b[0],
             &auto_pilot_upl_B.Gain_a[0], 30U * sizeof(real_T));

      /* RateTransition: '<S239>/Rate Transition' */
      auto_pilot_upl_DW.RateTransition_Buffer_a =
        auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal;
    }

    /* End of RateTransition: '<S231>/Rate Transition1' */
  }

  /* End of RateTransition: '<S221>/Rate Transition' */

  /* RelationalOperator: '<S255>/Compare' incorporates:
   *  Abs: '<S250>/Abs3'
   *  Constant: '<S255>/Constant'
   *  Gain: '<S250>/Gain4'
   *  Sum: '<S250>/Subtract2'
   */
  auto_pilot_upl_B.Compare_i5 = (fabs(auto_pilot_upl_B.Gain2 -
    auto_pilot_upl_P.Gain4_Gain_p * auto_pilot_upl_B.Gain4) <=
    auto_pilot_upl_P.AP_Steer_Error_Max);

  /* Integrator: '<S250>/Integrator1' */
  if (rtsiIsModeUpdateTimeStep(&auto_pilot_upl_M->solverInfo)) {
    zcEvent = rt_ZCFcn(ANY_ZERO_CROSSING,
                       &auto_pilot_upl_PrevZCX.Integrator1_Reset_ZCE,
                       (auto_pilot_upl_B.DataTypeConversion3));

    /* evaluate zero-crossings */
    if (zcEvent != NO_ZCEVENT) {
      auto_pilot_upl_X.Integrator1_CSTATE = auto_pilot_upl_P.Integrator1_IC;
    }
  }

  /* End of Integrator: '<S250>/Integrator1' */

  /* RateTransition generated from: '<S329>/Sum' */
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* RateTransition generated from: '<S329>/Discrete Filter1' */
    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_2) {
      /* RateTransition generated from: '<S329>/Sum' */
      auto_pilot_upl_B.TmpRTBAtSumOutport1 =
        auto_pilot_upl_DW.TmpRTBAtSumOutport1_Buffer0;

      /* RateTransition generated from: '<S329>/Discrete Filter1' */
      auto_pilot_upl_B.TmpRTBAtDiscreteFilter1Inport1 =
        auto_pilot_upl_DW.TmpRTBAtDiscreteFilter1Inport1_Buffer0;
    }

    /* End of RateTransition generated from: '<S329>/Discrete Filter1' */

    /* DiscreteFilter: '<S329>/Discrete Filter' */
    auto_pilot_upl_DW.DiscreteFilter_tmp =
      ((auto_pilot_upl_B.TmpRTBAtSumOutport1 -
        auto_pilot_upl_DW.DiscreteFilter_states[0] *
        auto_pilot_upl_P.DiscreteFilter_DenCoef[1]) -
       auto_pilot_upl_DW.DiscreteFilter_states[1] *
       auto_pilot_upl_P.DiscreteFilter_DenCoef[2]) /
      auto_pilot_upl_P.DiscreteFilter_DenCoef[0];

    /* DiscreteFilter: '<S329>/Discrete Filter' */
    auto_pilot_upl_B.DiscreteFilter = (auto_pilot_upl_P.DiscreteFilter_NumCoef[0]
      * auto_pilot_upl_DW.DiscreteFilter_tmp +
      auto_pilot_upl_DW.DiscreteFilter_states[0] *
      auto_pilot_upl_P.DiscreteFilter_NumCoef[1]) +
      auto_pilot_upl_DW.DiscreteFilter_states[1] *
      auto_pilot_upl_P.DiscreteFilter_NumCoef[2];

    /* DiscreteFilter: '<S329>/Discrete Filter1' */
    auto_pilot_upl_DW.DiscreteFilter1_tmp =
      ((auto_pilot_upl_B.TmpRTBAtDiscreteFilter1Inport1 -
        auto_pilot_upl_DW.DiscreteFilter1_states[0] *
        auto_pilot_upl_P.DiscreteFilter1_DenCoef[1]) -
       auto_pilot_upl_DW.DiscreteFilter1_states[1] *
       auto_pilot_upl_P.DiscreteFilter1_DenCoef[2]) /
      auto_pilot_upl_P.DiscreteFilter1_DenCoef[0];

    /* DiscreteFilter: '<S329>/Discrete Filter1' */
    auto_pilot_upl_B.DiscreteFilter1 =
      (auto_pilot_upl_P.DiscreteFilter1_NumCoef[0] *
       auto_pilot_upl_DW.DiscreteFilter1_tmp +
       auto_pilot_upl_DW.DiscreteFilter1_states[0] *
       auto_pilot_upl_P.DiscreteFilter1_NumCoef[1]) +
      auto_pilot_upl_DW.DiscreteFilter1_states[1] *
      auto_pilot_upl_P.DiscreteFilter1_NumCoef[2];

    /* RateTransition: '<S250>/Rate Transition' */
    if (auto_pilot_upl_M->Timing.RateInteraction.TID1_3) {
      auto_pilot_upl_DW.RateTransition_Buffer_f[0] =
        auto_pilot_upl_B.DiscreteFilter;
      auto_pilot_upl_DW.RateTransition_Buffer_f[1] =
        auto_pilot_upl_B.DiscreteFilter1;

      /* RateTransition: '<S250>/Rate Transition1' */
      auto_pilot_upl_DW.RateTransition1_Buffer_e = auto_pilot_upl_B.Switch_j;

      /* RateTransition: '<S250>/Rate Transition2' */
      auto_pilot_upl_DW.RateTransition2_Buffer_n = auto_pilot_upl_B.Gain4;
    }

    /* End of RateTransition: '<S250>/Rate Transition' */

    /* DiscretePulseGenerator: '<S329>/Pulse Generator' */
    if (auto_pilot_upl_DW.clockTickCounter_h >=
        auto_pilot_upl_P.PulseGenerator_Period_j - 1.0) {
      auto_pilot_upl_DW.clockTickCounter_h = 0;
    } else {
      auto_pilot_upl_DW.clockTickCounter_h++;
    }

    /* End of DiscretePulseGenerator: '<S329>/Pulse Generator' */

    /* DataTypeConversion: '<S322>/Cast To Double' incorporates:
     *  Constant: '<S339>/Constant'
     *  RelationalOperator: '<S339>/Compare'
     */
    auto_pilot_upl_B.CastToDouble_k = (auto_pilot_upl_B.DiscreteFilter <=
      auto_pilot_upl_P.CompareToConstant_const_d);

    /* DataTypeConversion: '<S322>/Cast To Double1' incorporates:
     *  Constant: '<S340>/Constant'
     *  RelationalOperator: '<S340>/Compare'
     */
    auto_pilot_upl_B.CastToDouble1 = (auto_pilot_upl_B.DiscreteFilter1 <=
      auto_pilot_upl_P.CompareToConstant1_const_f);
  }

  /* End of RateTransition generated from: '<S329>/Sum' */

  /* Product: '<S7>/Product' incorporates:
   *  Constant: '<S342>/Constant'
   *  DataTypeConversion: '<S7>/Data Type Conversion'
   *  RelationalOperator: '<S342>/Compare'
   */
  auto_pilot_upl_B.Product_l = auto_pilot_upl_B.VI_DriveSimInputsECATBECKHDIG4 *
    auto_pilot_upl_B.VI_DriveSimInputsECATBECKHDIG3 * (real_T)
    (auto_pilot_upl_B.VI_DriveSimOutputsVicrtStatus !=
     auto_pilot_upl_P.CompareToConstant_const_g);

  /* Product: '<S7>/Product1' incorporates:
   *  Constant: '<S343>/Constant'
   *  RelationalOperator: '<S343>/Compare'
   */
  auto_pilot_upl_B.Product1_g = (real_T)
    (auto_pilot_upl_B.VI_DriveSimInputsECATBECKHDIG4 !=
     auto_pilot_upl_P.CompareToConstant1_const_bt) *
    auto_pilot_upl_B.VI_DriveSimInputsECATBECKHDIG3;
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.Driver_Demands.brake' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <Root>/VI_CarRealTime.Inputs.Driver_Demands.brake */
    *(real_T *)pVI_CarRealTime_Inputs_Driver_Demands_brake =
      auto_pilot_upl_B.Max;

#endif

    /* S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.Driver_Demands.throttle' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <Root>/VI_CarRealTime.Inputs.Driver_Demands.throttle */
    *(real_T *)pVI_CarRealTime_Inputs_Driver_Demands_throttle =
      auto_pilot_upl_B.Max1;

#endif

    /* S-Function (simwbC_RTDBOut): '<Root>/VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <Root>/VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ */
    *(real_T *)pVI_DriveSim_Inputs_Control_VICRT_UPSHIFT_REQ =
      auto_pilot_upl_B.DataTypeConversion6;

#endif

    /* S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.Driver_Demands.str_swa' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <Root>/VI_CarRealTime.Inputs.Driver_Demands.str_swa */
    *(real_T *)pVI_CarRealTime_Inputs_Driver_Demands_str_swa =
      auto_pilot_upl_B.Gain2;

#endif

    /* S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.steer_assist.torque' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <Root>/VI_CarRealTime.Inputs.steer_assist.torque */
    *(real_T *)pVI_CarRealTime_Inputs_steer_assist_torque = 0.0;

#endif

    /* S-Function (simwbC_RTDBOut): '<Root>/VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <Root>/VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ */
    *(real_T *)pVI_DriveSim_Inputs_Control_VICRT_DOWNSHIFT_REQ =
      auto_pilot_upl_B.DataTypeConversion4;

#endif

    /* S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.Driver_Demands.target_speed' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <Root>/VI_CarRealTime.Inputs.Driver_Demands.target_speed */
    *(real_T *)pVI_CarRealTime_Inputs_Driver_Demands_target_speed =
      auto_pilot_upl_B.Product8;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_On' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.ACC.ACC_On */
    *(real_T *)pADAS_Outputs_ACC_ACC_On = auto_pilot_upl_B.Switch_o;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_On_Display' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.ACC.ACC_On_Display */
    *(real_T *)pADAS_Outputs_ACC_ACC_On_Display = auto_pilot_upl_B.Switch_o;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_Ready' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.ACC.ACC_Ready */
    *(real_T *)pADAS_Outputs_ACC_ACC_Ready = auto_pilot_upl_B.DataTypeConversion;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_Ready_Display' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.ACC.ACC_Ready_Display */
    *(real_T *)pADAS_Outputs_ACC_ACC_Ready_Display = auto_pilot_upl_B.Sum_g0;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_Speed_Target_Display' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.ACC.ACC_Speed_Target_Display */
    *(real_T *)pADAS_Outputs_ACC_ACC_Speed_Target_Display =
      auto_pilot_upl_B.RateLimiter_p;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_Target_Id_Display' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.ACC.ACC_Target_Id_Display */
    *(real_T *)pADAS_Outputs_ACC_ACC_Target_Id_Display =
      auto_pilot_upl_B.Product1_n;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_Target_Speed' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.ACC.ACC_Target_Speed */
    *(real_T *)pADAS_Outputs_ACC_ACC_Target_Speed = auto_pilot_upl_B.Product8;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AEB.AEB_BrakeDemand' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.AEB.AEB_BrakeDemand */
    *(real_T *)pADAS_Outputs_AEB_AEB_BrakeDemand = auto_pilot_upl_B.Switch_h[0];

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AEB.AEB_On' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.AEB.AEB_On */
    *(real_T *)pADAS_Outputs_AEB_AEB_On = auto_pilot_upl_B.Product1_m;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AEB.AEB_Output_Active' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.AEB.AEB_Output_Active */
    *(real_T *)pADAS_Outputs_AEB_AEB_Output_Active = auto_pilot_upl_B.Switch_h[2];

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AEB.AEB_Ready' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.AEB.AEB_Ready */
    *(real_T *)pADAS_Outputs_AEB_AEB_Ready = auto_pilot_upl_B.Product_p;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AEB.AEB_Target_Id_Display' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.AEB.AEB_Target_Id_Display */
    *(real_T *)pADAS_Outputs_AEB_AEB_Target_Id_Display =
      auto_pilot_upl_B.Switch_h[3];

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AEB.AEB_TimeToCollision' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.AEB.AEB_TimeToCollision */
    *(real_T *)pADAS_Outputs_AEB_AEB_TimeToCollision =
      auto_pilot_upl_B.Switch_h[4];

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AP.AP_On' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.AP.AP_On */
    *(real_T *)pADAS_Outputs_AP_AP_On = auto_pilot_upl_B.Switch_j;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AP.AP_Ready' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.AP.AP_Ready */
    *(real_T *)pADAS_Outputs_AP_AP_Ready =
      auto_pilot_upl_B.DataTypeConversion2_g;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.Generic.ADAS_Error' incorporates:
     *  Constant: '<S16>/Constant'
     */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/ADAS.Outputs.Generic.ADAS_Error */
    *(real_T *)pADAS_Outputs_Generic_ADAS_Error =
      auto_pilot_upl_P.Constant_Value_k;

#endif

    /* S-Function (simwbC_RTDBOut): '<S2>/AEB_TimeToCollision_Threshold' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S2>/AEB_TimeToCollision_Threshold */
    *(real_T *)pADAS_Outputs_AEB_AEB_TimeToCollision_Threshold =
      auto_pilot_upl_B.RateTransition5_n;

#endif

    /* S-Function (simwbC_RTDBOut): '<S322>/WorldSim.ego.Sensors.Lane_detector.LeftLane.Crossed' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S322>/WorldSim.ego.Sensors.Lane_detector.LeftLane.Crossed */
    *(real_T *)pWorldSim_ego_Sensors_Lane_detector_LeftLane_Crossed =
      auto_pilot_upl_B.CastToDouble_k;

#endif

    /* S-Function (simwbC_RTDBOut): '<S322>/WorldSim.ego.Sensors.Lane_detector.LeftLane.Distance' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S322>/WorldSim.ego.Sensors.Lane_detector.LeftLane.Distance */
    *(real_T *)pWorldSim_ego_Sensors_Lane_detector_LeftLane_Distance =
      auto_pilot_upl_B.DiscreteFilter;

#endif

    /* S-Function (simwbC_RTDBOut): '<S322>/WorldSim.ego.Sensors.Lane_detector.RightLane.Crossed' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S322>/WorldSim.ego.Sensors.Lane_detector.RightLane.Crossed */
    *(real_T *)pWorldSim_ego_Sensors_Lane_detector_RightLane_Crossed =
      auto_pilot_upl_B.CastToDouble1;

#endif

    /* S-Function (simwbC_RTDBOut): '<S322>/WorldSim.ego.Sensors.Lane_detector.RightLane.Distance' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S322>/WorldSim.ego.Sensors.Lane_detector.RightLane.Distance */
    *(real_T *)pWorldSim_ego_Sensors_Lane_detector_RightLane_Distance =
      auto_pilot_upl_B.DiscreteFilter1;

#endif

    /* S-Function (simwbC_RTDBOut): '<S322>/WorldSim.ego.Sensors.Front_VirtualCam.obstacleData' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S322>/WorldSim.ego.Sensors.Front_VirtualCam.obstacleData */
    *(real_T *)pWorldSim_ego_Sensors_Front_VirtualCam_obstacleData = 0.0;

#endif

    /* S-Function (simwbC_RTDBOut): '<S7>/VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S7>/VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ */
    *(real_T *)pVI_DriveSim_Inputs_Control_VICRT_RESTART_REQ =
      auto_pilot_upl_B.Product_l;

#endif

    /* S-Function (simwbC_RTDBOut): '<S7>/VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ' */
#ifdef GENSIMWBCODE

    /* S-Function Block: <S7>/VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ */
    *(real_T *)pVI_DriveSim_Inputs_Control_VICRT_RESTORE_REQ =
      auto_pilot_upl_B.Product1_g;

#endif

  }
}

/* Model update function for TID0 */
void auto_pilot_upl_update0(void)      /* Sample time: [0.0s, 0.0s] */
{
  int32_T i;
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* Update for UnitDelay: '<S27>/UD' */
    auto_pilot_upl_DW.UD_DSTATE = auto_pilot_upl_B.Sum_l;

    /* Update for UnitDelay: '<S26>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_n = auto_pilot_upl_B.Sum_a;

    /* Update for UnitDelay: '<S33>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_d = auto_pilot_upl_B.Sum_p;

    /* Update for UnitDelay: '<S34>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_o = auto_pilot_upl_B.Sum_e;

    /* Update for UnitDelay: '<S194>/Delay Input1' incorporates:
     *  Constant: '<S8>/Constant1'
     */
    auto_pilot_upl_DW.DelayInput1_DSTATE = auto_pilot_upl_P.Constant1_Value;

    /* Update for UnitDelay: '<S13>/Delay Input1' */
    auto_pilot_upl_DW.DelayInput1_DSTATE_h = auto_pilot_upl_B.Compare;

    /* Update for UnitDelay: '<S14>/Delay Input1' */
    auto_pilot_upl_DW.DelayInput1_DSTATE_a = auto_pilot_upl_B.Product;

    /* Update for Memory: '<S11>/Memory' */
    auto_pilot_upl_DW.Memory_PreviousInput = auto_pilot_upl_B.Switch;

    /* Update for UnitDelay: '<S193>/Delay Input1' */
    auto_pilot_upl_DW.DelayInput1_DSTATE_ay = auto_pilot_upl_B.LogicalOperator;

    /* Update for Delay: '<S215>/Delay1' */
    memcpy(&auto_pilot_upl_DW.Delay1_DSTATE[0], &auto_pilot_upl_B.Switch2[0],
           30U * sizeof(real_T));

    /* Update for Memory: '<S16>/Memory' */
    auto_pilot_upl_DW.Memory_PreviousInput_b = auto_pilot_upl_B.Switch_o;

    /* Update for UnitDelay: '<S23>/Delay Input1' */
    auto_pilot_upl_DW.DelayInput1_DSTATE_n = auto_pilot_upl_B.Switch_o;

    /* Update for Memory: '<S15>/Memory' */
    auto_pilot_upl_DW.Memory_PreviousInput_l = auto_pilot_upl_B.Switch1_e;

    /* Update for DiscreteIntegrator: '<S117>/Integrator' */
    auto_pilot_upl_DW.Integrator_DSTATE += auto_pilot_upl_P.Integrator_gainval *
      auto_pilot_upl_B.SumI4_k;
    if (auto_pilot_upl_B.Product4 > 0.0) {
      auto_pilot_upl_DW.Integrator_PrevResetState = 1;
    } else if (auto_pilot_upl_B.Product4 < 0.0) {
      auto_pilot_upl_DW.Integrator_PrevResetState = -1;
    } else if (auto_pilot_upl_B.Product4 == 0.0) {
      auto_pilot_upl_DW.Integrator_PrevResetState = 0;
    } else {
      auto_pilot_upl_DW.Integrator_PrevResetState = 2;
    }

    /* End of Update for DiscreteIntegrator: '<S117>/Integrator' */

    /* Update for DiscreteIntegrator: '<S168>/Integrator' */
    auto_pilot_upl_DW.Integrator_DSTATE_i +=
      auto_pilot_upl_P.Integrator_gainval_p * auto_pilot_upl_B.SumI4_a;
    if (auto_pilot_upl_B.Product4 > 0.0) {
      auto_pilot_upl_DW.Integrator_PrevResetState_d = 1;
    } else if (auto_pilot_upl_B.Product4 < 0.0) {
      auto_pilot_upl_DW.Integrator_PrevResetState_d = -1;
    } else if (auto_pilot_upl_B.Product4 == 0.0) {
      auto_pilot_upl_DW.Integrator_PrevResetState_d = 0;
    } else {
      auto_pilot_upl_DW.Integrator_PrevResetState_d = 2;
    }

    /* End of Update for DiscreteIntegrator: '<S168>/Integrator' */

    /* Update for Delay: '<S161>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_e = auto_pilot_upl_B.TmpRTBAtTsampOutport1;

    /* Update for Memory: '<S15>/Memory1' */
    auto_pilot_upl_DW.Memory1_PreviousInput = auto_pilot_upl_B.Product8;

    /* Update for Memory: '<S15>/Memory2' */
    auto_pilot_upl_DW.Memory2_PreviousInput = auto_pilot_upl_B.setspeedmemory;

    /* Update for UnitDelay: '<S24>/Delay Input1' incorporates:
     *  Constant: '<S8>/Constant1'
     */
    auto_pilot_upl_DW.DelayInput1_DSTATE_l = auto_pilot_upl_P.Constant1_Value;

    /* Update for DiscreteIntegrator: '<S67>/Integrator' */
    auto_pilot_upl_DW.Integrator_IC_LOADING = 0U;
    auto_pilot_upl_DW.Integrator_DSTATE_i3 +=
      auto_pilot_upl_P.Integrator_gainval_pc * auto_pilot_upl_B.SumI4;
    if (auto_pilot_upl_B.Product2_g > 0.0) {
      auto_pilot_upl_DW.Integrator_PrevResetState_c = 1;
    } else if (auto_pilot_upl_B.Product2_g < 0.0) {
      auto_pilot_upl_DW.Integrator_PrevResetState_c = -1;
    } else if (auto_pilot_upl_B.Product2_g == 0.0) {
      auto_pilot_upl_DW.Integrator_PrevResetState_c = 0;
    } else {
      auto_pilot_upl_DW.Integrator_PrevResetState_c = 2;
    }

    /* End of Update for DiscreteIntegrator: '<S67>/Integrator' */

    /* Update for UnitDelay: '<S32>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_p = auto_pilot_upl_B.Sum_h;

    /* Update for UnitDelay: '<S31>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_ou = auto_pilot_upl_B.Sum_ep;

    /* Update for UnitDelay: '<S29>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_f = auto_pilot_upl_B.Sum_py;

    /* Update for UnitDelay: '<S30>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_em = auto_pilot_upl_B.Sum_g;

    /* Update for Memory: '<S250>/Memory2' incorporates:
     *  Constant: '<S250>/Constant'
     */
    auto_pilot_upl_DW.Memory2_PreviousInput_c =
      auto_pilot_upl_P.Constant_Value_mq;

    /* Update for Memory: '<S250>/Memory1' */
    auto_pilot_upl_DW.Memory1_PreviousInput_n = auto_pilot_upl_B.Compare_i5;

    /* Update for Memory: '<S250>/Memory' */
    auto_pilot_upl_DW.Memory_PreviousInput_n = auto_pilot_upl_B.Switch_j;
  }

  /* Update for RateLimiter: '<S215>/Rate Limiter' */
  if (auto_pilot_upl_DW.LastMajorTimeA == (rtInf)) {
    auto_pilot_upl_DW.LastMajorTimeA = auto_pilot_upl_M->Timing.t[0];
    auto_pilot_upl_DW.PrevYA = auto_pilot_upl_B.RateLimiter;
  } else if (auto_pilot_upl_DW.LastMajorTimeB == (rtInf)) {
    auto_pilot_upl_DW.LastMajorTimeB = auto_pilot_upl_M->Timing.t[0];
    auto_pilot_upl_DW.PrevYB = auto_pilot_upl_B.RateLimiter;
  } else if (auto_pilot_upl_DW.LastMajorTimeA < auto_pilot_upl_DW.LastMajorTimeB)
  {
    auto_pilot_upl_DW.LastMajorTimeA = auto_pilot_upl_M->Timing.t[0];
    auto_pilot_upl_DW.PrevYA = auto_pilot_upl_B.RateLimiter;
  } else {
    auto_pilot_upl_DW.LastMajorTimeB = auto_pilot_upl_M->Timing.t[0];
    auto_pilot_upl_DW.PrevYB = auto_pilot_upl_B.RateLimiter;
  }

  /* End of Update for RateLimiter: '<S215>/Rate Limiter' */

  /* Update for RateLimiter: '<S250>/Rate Limiter1' */
  if (auto_pilot_upl_DW.LastMajorTimeA_g == (rtInf)) {
    auto_pilot_upl_DW.LastMajorTimeA_g = auto_pilot_upl_M->Timing.t[0];
    auto_pilot_upl_DW.PrevYA_p = auto_pilot_upl_B.RateLimiter1;
  } else if (auto_pilot_upl_DW.LastMajorTimeB_b == (rtInf)) {
    auto_pilot_upl_DW.LastMajorTimeB_b = auto_pilot_upl_M->Timing.t[0];
    auto_pilot_upl_DW.PrevYB_e = auto_pilot_upl_B.RateLimiter1;
  } else if (auto_pilot_upl_DW.LastMajorTimeA_g <
             auto_pilot_upl_DW.LastMajorTimeB_b) {
    auto_pilot_upl_DW.LastMajorTimeA_g = auto_pilot_upl_M->Timing.t[0];
    auto_pilot_upl_DW.PrevYA_p = auto_pilot_upl_B.RateLimiter1;
  } else {
    auto_pilot_upl_DW.LastMajorTimeB_b = auto_pilot_upl_M->Timing.t[0];
    auto_pilot_upl_DW.PrevYB_e = auto_pilot_upl_B.RateLimiter1;
  }

  /* End of Update for RateLimiter: '<S250>/Rate Limiter1' */
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    /* Update for UnitDelay: '<S84>/Delay Input1' incorporates:
     *  Constant: '<S8>/Constant1'
     */
    auto_pilot_upl_DW.DelayInput1_DSTATE_g = auto_pilot_upl_P.Constant1_Value;

    /* Update for UnitDelay: '<S85>/Delay Input1' incorporates:
     *  Constant: '<S8>/Constant1'
     */
    auto_pilot_upl_DW.DelayInput1_DSTATE_j = auto_pilot_upl_P.Constant1_Value;

    /* Update for Memory: '<S19>/Memory' */
    auto_pilot_upl_DW.Memory_PreviousInput_a = auto_pilot_upl_B.Sum_k;

    /* Update for DiscreteFilter: '<S215>/filtering' */
    for (i = 0; i < 30; i++) {
      int32_T memOffset;
      memOffset = i << 1;
      auto_pilot_upl_DW.filtering_states[memOffset - -1] =
        auto_pilot_upl_DW.filtering_states[memOffset];
      auto_pilot_upl_DW.filtering_states[memOffset] =
        auto_pilot_upl_DW.filtering_tmp[i];
    }

    /* End of Update for DiscreteFilter: '<S215>/filtering' */

    /* Update for DiscreteFilter: '<S329>/Discrete Filter' */
    auto_pilot_upl_DW.DiscreteFilter_states[1] =
      auto_pilot_upl_DW.DiscreteFilter_states[0];
    auto_pilot_upl_DW.DiscreteFilter_states[0] =
      auto_pilot_upl_DW.DiscreteFilter_tmp;

    /* Update for DiscreteFilter: '<S329>/Discrete Filter1' */
    auto_pilot_upl_DW.DiscreteFilter1_states[1] =
      auto_pilot_upl_DW.DiscreteFilter1_states[0];
    auto_pilot_upl_DW.DiscreteFilter1_states[0] =
      auto_pilot_upl_DW.DiscreteFilter1_tmp;
  }

  /* Update for RateLimiter: '<S10>/Rate Limiter' */
  if (auto_pilot_upl_DW.LastMajorTimeA_gx == (rtInf)) {
    auto_pilot_upl_DW.LastMajorTimeA_gx = auto_pilot_upl_M->Timing.t[0];
    auto_pilot_upl_DW.PrevYA_c = auto_pilot_upl_B.RateLimiter_p;
  } else if (auto_pilot_upl_DW.LastMajorTimeB_e == (rtInf)) {
    auto_pilot_upl_DW.LastMajorTimeB_e = auto_pilot_upl_M->Timing.t[0];
    auto_pilot_upl_DW.PrevYB_f = auto_pilot_upl_B.RateLimiter_p;
  } else if (auto_pilot_upl_DW.LastMajorTimeA_gx <
             auto_pilot_upl_DW.LastMajorTimeB_e) {
    auto_pilot_upl_DW.LastMajorTimeA_gx = auto_pilot_upl_M->Timing.t[0];
    auto_pilot_upl_DW.PrevYA_c = auto_pilot_upl_B.RateLimiter_p;
  } else {
    auto_pilot_upl_DW.LastMajorTimeB_e = auto_pilot_upl_M->Timing.t[0];
    auto_pilot_upl_DW.PrevYB_f = auto_pilot_upl_B.RateLimiter_p;
  }

  /* End of Update for RateLimiter: '<S10>/Rate Limiter' */
  if (rtmIsMajorTimeStep(auto_pilot_upl_M)) {
    rt_ertODEUpdateContinuousStates(&auto_pilot_upl_M->solverInfo);
  }

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++auto_pilot_upl_M->Timing.clockTick0)) {
    ++auto_pilot_upl_M->Timing.clockTickH0;
  }

  auto_pilot_upl_M->Timing.t[0] = rtsiGetSolverStopTime
    (&auto_pilot_upl_M->solverInfo);

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick1"
   * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick1 and the high bits
   * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++auto_pilot_upl_M->Timing.clockTick1)) {
    ++auto_pilot_upl_M->Timing.clockTickH1;
  }

  auto_pilot_upl_M->Timing.t[1] = auto_pilot_upl_M->Timing.clockTick1 *
    auto_pilot_upl_M->Timing.stepSize1 + auto_pilot_upl_M->Timing.clockTickH1 *
    auto_pilot_upl_M->Timing.stepSize1 * 4294967296.0;
}

/* Derivatives for root system: '<Root>' */
void auto_pilot_upl_derivatives(void)
{
  XDot_auto_pilot_upl_T *_rtXdot;
  _rtXdot = ((XDot_auto_pilot_upl_T *) auto_pilot_upl_M->derivs);

  /* Derivatives for Integrator: '<S250>/Integrator' */
  _rtXdot->Integrator_CSTATE = auto_pilot_upl_B.Product6;

  /* Derivatives for Integrator: '<S250>/Integrator1' */
  _rtXdot->Integrator1_CSTATE = auto_pilot_upl_B.DataTypeConversion3;
}

/* Model output function for TID2 */
void auto_pilot_upl_output2(void)      /* Sample time: [0.01s, 0.0s] */
{
  real_T rtb_distanceToCollision[10];
  real_T rtb_yaw[10];
  real_T x[10];
  real_T rtb_Sum1;
  real_T rtb_Sum_k5;
  int32_T i;

  /* S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S321>/VI_WorldSim_Sensor_VirtualCamera' */

  /* Level2 S-Function Block: '<S321>/VI_WorldSim_Sensor_VirtualCamera' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = auto_pilot_upl_M->childSfunctions[0];
    sfcnOutputs(rts,2);
  }

  /* MATLAB Function: '<S321>/manipulation_of_objects' */
  auto_pilot_upl_manipulation_of_objects(auto_pilot_upl_B.matrix_obstacles,
    auto_pilot_upl_B.valid_matrix_obstacles,
    &auto_pilot_upl_B.sf_manipulation_of_objects);

  /* MATLAB Function: '<S331>/MATLAB Function' incorporates:
   *  Gain: '<S331>/Gain'
   *  MATLAB Function: '<S331>/MATLAB Function2'
   *  Sum: '<S331>/Sum'
   */
  /* MATLAB Function 'OUTPUT/WorldSim_Sensor_Outputs/Subsystem/obstacle detection /MATLAB Function2': '<S338>:1' */
  /* '<S338>:1:4' */
  /* '<S338>:1:5' */
  /* '<S338>:1:6' */
  /* '<S338>:1:7' */
  /* '<S338>:1:8' */
  /* '<S338>:1:9' */
  /* '<S338>:1:10' */
  /* '<S338>:1:11' */
  /* '<S338>:1:12' */
  /* '<S338>:1:13' */
  for (i = 0; i < 10; i++) {
    x[i] = auto_pilot_upl_B.sf_manipulation_of_objects.filtered_matrix[10 * i +
      1] - auto_pilot_upl_B.sf_manipulation_of_objects.filtered_matrix[10 * i +
      7] * auto_pilot_upl_P.Gain_Gain_j;
  }

  for (i = 0; i < 10; i++) {
    rtb_yaw[i] = auto_pilot_upl_B.sf_manipulation_of_objects.filtered_matrix[10 *
      i + 2];
  }

  /* MATLAB Function 'OUTPUT/WorldSim_Sensor_Outputs/Subsystem/obstacle detection /MATLAB Function': '<S337>:1' */
  /* '<S337>:1:6' */
  /* '<S337>:1:7' */
  for (i = 0; i < 10; i++) {
    rtb_Sum_k5 = x[i];
    rtb_Sum1 = rtb_yaw[i];
    if (rtb_Sum_k5 == 0.0) {
      /* '<S337>:1:3' */
      rtb_Sum_k5 = 121.0;
    }

    if (rtb_Sum1 == 0.0) {
      /* '<S337>:1:4' */
      rtb_Sum1 = 121.0;
    }

    rtb_Sum1 = atan(rtb_Sum1 / rtb_Sum_k5);
    rtb_distanceToCollision[i] = rtb_Sum_k5 / cos(rtb_Sum1);
    if (rtb_Sum_k5 == 121.0) {
      /* '<S337>:1:8' */
      rtb_distanceToCollision[i] = 121.0;
    }

    rtb_yaw[i] = rtb_Sum1;
    x[i] = rtb_Sum_k5;
  }

  /* End of MATLAB Function: '<S331>/MATLAB Function' */

  /* S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */

  /* Level2 S-Function Block: '<S321>/VI_WorldSim_Sensor_VirtualCamera1' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = auto_pilot_upl_M->childSfunctions[1];
    sfcnOutputs(rts,2);
  }

  /* MATLAB Function: '<S321>/manipulation_of_objects1' */
  auto_pilot_upl_manipulation_of_objects(auto_pilot_upl_B.matrix_obstacles_a,
    auto_pilot_upl_B.valid_matrix_obstacles_k,
    &auto_pilot_upl_B.sf_manipulation_of_objects1);

  /* Sum: '<S329>/Sum' incorporates:
   *  Constant: '<S325>/Semitrack'
   *  MATLAB Function: '<S321>/MATLAB Function'
   *  S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  /* MATLAB Function 'OUTPUT/WorldSim_Sensor_Outputs/Subsystem/bsd setection from ostacle recognition/MATLAB Function3': '<S333>:1' */
  /* '<S333>:1:7' */
  /* '<S333>:1:2' */
  /* '<S333>:1:3' */
  /* '<S333>:1:7' */
  /* '<S333>:1:10' */
  /* '<S333>:1:11' */
  /* MATLAB Function 'OUTPUT/WorldSim_Sensor_Outputs/MATLAB Function': '<S323>:1' */
  /* '<S323>:1:3' */
  /* '<S323>:1:4' */
  rtb_Sum_k5 = auto_pilot_upl_B.lanecoefficients2x4[0] -
    auto_pilot_upl_P.vehicle_width / 2.0;

  /* Sum: '<S329>/Sum1' incorporates:
   *  Constant: '<S325>/Semitrack'
   *  Gain: '<S329>/Gain2'
   *  MATLAB Function: '<S321>/MATLAB Function'
   *  S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  rtb_Sum1 = auto_pilot_upl_P.Gain2_Gain_f *
    auto_pilot_upl_B.lanecoefficients2x4[1] - auto_pilot_upl_P.vehicle_width /
    2.0;

  /* RateTransition generated from: '<S329>/Discrete Filter1' */
  auto_pilot_upl_DW.TmpRTBAtDiscreteFilter1Inport1_Buffer0 = rtb_Sum1;

  /* RateTransition generated from: '<S329>/Sum' */
  auto_pilot_upl_DW.TmpRTBAtSumOutport1_Buffer0 = rtb_Sum_k5;

  /* S-Function (VI_WorldSim_State_Manager_mex): '<S321>/VI_WorldSim_State_Manager' */

  /* Level2 S-Function Block: '<S321>/VI_WorldSim_State_Manager' (VI_WorldSim_State_Manager_mex) */
  {
    SimStruct *rts = auto_pilot_upl_M->childSfunctions[2];
    sfcnOutputs(rts,2);
  }

  /* Sum: '<S321>/Sum' incorporates:
   *  Memory: '<S321>/Memory'
   */
  auto_pilot_upl_B.additivecollision =
    auto_pilot_upl_B.VI_WorldSim_State_Manager_o3 +
    auto_pilot_upl_DW.Memory_PreviousInput_d;

  /* RateTransition generated from: '<S324>/Multiport Switch' incorporates:
   *  MATLAB Function: '<S331>/MATLAB Function2'
   */
  for (i = 0; i < 10; i++) {
    auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i] =
      auto_pilot_upl_B.sf_manipulation_of_objects.filtered_matrix[10 * i];
  }

  for (i = 0; i < 10; i++) {
    auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i + 10] =
      rtb_distanceToCollision[i];
    auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i + 20] = rtb_yaw[i];
  }

  for (i = 0; i < 10; i++) {
    auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i + 30] =
      auto_pilot_upl_B.sf_manipulation_of_objects.filtered_matrix[10 * i];
  }

  for (i = 0; i < 10; i++) {
    auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i + 40] =
      auto_pilot_upl_B.sf_manipulation_of_objects.filtered_matrix[10 * i];
  }

  for (i = 0; i < 10; i++) {
    auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i + 50] =
      rtb_distanceToCollision[i];
    auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i + 60] = rtb_yaw[i];
  }

  for (i = 0; i < 10; i++) {
    auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i + 70] =
      auto_pilot_upl_B.sf_manipulation_of_objects.filtered_matrix[10 * i];
  }

  for (i = 0; i < 10; i++) {
    auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i + 80] =
      auto_pilot_upl_B.sf_manipulation_of_objects.filtered_matrix[10 * i];
  }

  for (i = 0; i < 10; i++) {
    auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i + 90] =
      rtb_distanceToCollision[i];
    auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i + 100] =
      rtb_yaw[i];
  }

  for (i = 0; i < 10; i++) {
    auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i + 110] =
      auto_pilot_upl_B.sf_manipulation_of_objects.filtered_matrix[10 * i];
  }

  /* End of RateTransition generated from: '<S324>/Multiport Switch' */

  /* S-Function (simwbC_RTDBOut): '<S322>/WorldSim.ego.Sensors.Collision.Count' */
#ifdef GENSIMWBCODE

  /* S-Function Block: <S322>/WorldSim.ego.Sensors.Collision.Count */
  *(real_T *)pWorldSim_ego_Sensors_Collision_Count =
    auto_pilot_upl_B.additivecollision;

#endif

}

/* Model update function for TID2 */
void auto_pilot_upl_update2(void)      /* Sample time: [0.01s, 0.0s] */
{
  /* Update for S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  /* Level2 S-Function Block: '<S321>/VI_WorldSim_Sensor_VirtualCamera' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = auto_pilot_upl_M->childSfunctions[0];
    sfcnUpdate(rts,2);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Update for S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  /* Level2 S-Function Block: '<S321>/VI_WorldSim_Sensor_VirtualCamera1' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = auto_pilot_upl_M->childSfunctions[1];
    sfcnUpdate(rts,2);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Update for Memory: '<S321>/Memory' */
  auto_pilot_upl_DW.Memory_PreviousInput_d = auto_pilot_upl_B.additivecollision;

  /* Update for S-Function (VI_WorldSim_State_Manager_mex): '<S321>/VI_WorldSim_State_Manager' */
  /* Level2 S-Function Block: '<S321>/VI_WorldSim_State_Manager' (VI_WorldSim_State_Manager_mex) */
  {
    SimStruct *rts = auto_pilot_upl_M->childSfunctions[2];
    sfcnUpdate(rts,2);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Update absolute time */
  /* The "clockTick2" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick2"
   * and "Timing.stepSize2". Size of "clockTick2" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick2 and the high bits
   * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++auto_pilot_upl_M->Timing.clockTick2)) {
    ++auto_pilot_upl_M->Timing.clockTickH2;
  }

  auto_pilot_upl_M->Timing.t[2] = auto_pilot_upl_M->Timing.clockTick2 *
    auto_pilot_upl_M->Timing.stepSize2 + auto_pilot_upl_M->Timing.clockTickH2 *
    auto_pilot_upl_M->Timing.stepSize2 * 4294967296.0;
}

/* Model output function for TID3 */
void auto_pilot_upl_output3(void)      /* Sample time: [0.02s, 0.0s] */
{
  /* local block i/o variables */
  real_T rtb_Product1;
  real_T rtb_Gain1_b;
  real_T rtb_IProdOut;
  real_T rtb_Integrator_n;
  real_T rtb_MultiportSwitch_idx_0;
  real_T rtb_SumofElements;

  /* Saturate: '<S15>/Target_Distance_Saturation' */
  if (auto_pilot_upl_DW.RateTransition1_Buffer >
      auto_pilot_upl_P.ACC_SensorMaxDistance) {
    rtb_Integrator_n = auto_pilot_upl_P.ACC_SensorMaxDistance;
  } else if (auto_pilot_upl_DW.RateTransition1_Buffer <
             auto_pilot_upl_P.Target_Distance_Saturation_LowerSat) {
    rtb_Integrator_n = auto_pilot_upl_P.Target_Distance_Saturation_LowerSat;
  } else {
    rtb_Integrator_n = auto_pilot_upl_DW.RateTransition1_Buffer;
  }

  /* Sum: '<S15>/Error1' incorporates:
   *  RateTransition: '<S15>/Rate Transition'
   *  Saturate: '<S15>/Target_Distance_Saturation'
   */
  rtb_Integrator_n = auto_pilot_upl_DW.RateTransition_Buffer - rtb_Integrator_n;

  /* MultiPortSwitch: '<S35>/Multiport Switch' incorporates:
   *  Constant: '<S35>/ACC_Adaptive_P'
   *  Constant: '<S35>/ACC_Adaptive_P2'
   *  Constant: '<S35>/ADAS_Control_Mode'
   */
  switch ((int32_T)auto_pilot_upl_P.ADAS_Control_Mode) {
   case 1:
    rtb_Gain1_b = auto_pilot_upl_P.ACC_Adaptive_P[0];
    break;

   case 2:
    rtb_Gain1_b = auto_pilot_upl_P.ACC_Adaptive_P[1];
    break;

   default:
    rtb_Gain1_b = auto_pilot_upl_P.ACC_Adaptive_P[0];
    break;
  }

  /* End of MultiPortSwitch: '<S35>/Multiport Switch' */

  /* Product: '<S165>/IProd Out' incorporates:
   *  Constant: '<S35>/Constant'
   *  Product: '<S160>/DProd Out'
   */
  rtb_IProdOut = rtb_Integrator_n * auto_pilot_upl_P.Constant_Value_n4;

  /* RateTransition generated from: '<S159>/SumI4' */
  auto_pilot_upl_DW.TmpRTBAtSumI4Inport2_Buffer0 = rtb_IProdOut;

  /* RateTransition generated from: '<S163>/Tsamp' incorporates:
   *  SampleTimeMath: '<S163>/Tsamp'
   *
   * About RateTransition generated from '<S163>/Tsamp':
   *  y = u * K where K = 1 / ( w * Ts )
   *
   * About '<S163>/Tsamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  auto_pilot_upl_DW.TmpRTBAtTsampOutport1_Buffer0 = rtb_IProdOut *
    auto_pilot_upl_P.Tsamp_WtEt;

  /* RateTransition generated from: '<S177>/Sum' incorporates:
   *  Product: '<S173>/PProd Out'
   */
  auto_pilot_upl_DW.TmpRTBAtSumInport1_Buffer0 = rtb_Integrator_n * rtb_Gain1_b;

  /* Sum: '<S250>/Subtract4' incorporates:
   *  Gain: '<S250>/Gain3'
   *  RateTransition: '<S250>/Rate Transition'
   *  Sum: '<S250>/Sum of Elements'
   */
  rtb_Integrator_n = (auto_pilot_upl_DW.RateTransition_Buffer_f[0] +
                      auto_pilot_upl_DW.RateTransition_Buffer_f[1]) *
    auto_pilot_upl_P.Gain3_Gain_j - auto_pilot_upl_DW.RateTransition_Buffer_f[0];

  /* Saturate: '<S250>/Saturation' */
  if (rtb_Integrator_n > auto_pilot_upl_P.AP_Error_Max) {
    rtb_Integrator_n = auto_pilot_upl_P.AP_Error_Max;
  } else if (rtb_Integrator_n < -auto_pilot_upl_P.AP_Error_Max) {
    rtb_Integrator_n = -auto_pilot_upl_P.AP_Error_Max;
  }

  /* End of Saturate: '<S250>/Saturation' */

  /* SampleTimeMath: '<S262>/TSamp'
   *
   * About '<S262>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  auto_pilot_upl_B.TSamp = rtb_Integrator_n * auto_pilot_upl_P.TSamp_WtEt_b;

  /* Sum: '<S262>/Diff' incorporates:
   *  UnitDelay: '<S262>/UD'
   */
  rtb_SumofElements = auto_pilot_upl_B.TSamp - auto_pilot_upl_DW.UD_DSTATE_i;

  /* SampleTimeMath: '<S263>/TSamp'
   *
   * About '<S263>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  auto_pilot_upl_B.TSamp_p = rtb_SumofElements * auto_pilot_upl_P.TSamp_WtEt_h;

  /* RateTransition: '<S250>/Rate Transition1' */
  auto_pilot_upl_B.RateTransition1 = auto_pilot_upl_DW.RateTransition1_Buffer_e;

  /* Product: '<S250>/Product' */
  rtb_Integrator_n *= auto_pilot_upl_B.RateTransition1;

  /* MultiPortSwitch: '<S264>/Multiport Switch' incorporates:
   *  Constant: '<S264>/ADAS_Control_Mode'
   *  Constant: '<S264>/AP_D(1)(1)'
   *  Constant: '<S264>/AP_D(2)(1)1'
   *  Constant: '<S264>/AP_I(1)(1)'
   *  Constant: '<S264>/AP_I(2)(1)1'
   *  Constant: '<S264>/AP_P(1)(1)'
   *  Constant: '<S264>/AP_P(2)(1)1'
   */
  switch ((int32_T)auto_pilot_upl_P.ADAS_Control_Mode) {
   case 1:
    rtb_MultiportSwitch_idx_0 = auto_pilot_upl_P.AP_P[0];
    rtb_Gain1_b = auto_pilot_upl_P.AP_I[0];
    rtb_IProdOut = auto_pilot_upl_P.AP_D[0];
    break;

   case 2:
    rtb_MultiportSwitch_idx_0 = auto_pilot_upl_P.AP_P[1];
    rtb_Gain1_b = auto_pilot_upl_P.AP_I[1];
    rtb_IProdOut = auto_pilot_upl_P.AP_D[1];
    break;

   default:
    rtb_MultiportSwitch_idx_0 = auto_pilot_upl_P.AP_P[0];
    rtb_Gain1_b = auto_pilot_upl_P.AP_I[0];
    rtb_IProdOut = auto_pilot_upl_P.AP_D[0];
    break;
  }

  /* End of MultiPortSwitch: '<S264>/Multiport Switch' */

  /* SampleTimeMath: '<S296>/Tsamp' incorporates:
   *  Product: '<S293>/DProd Out'
   *
   * About '<S296>/Tsamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  auto_pilot_upl_B.Tsamp = rtb_Integrator_n * rtb_IProdOut *
    auto_pilot_upl_P.Tsamp_WtEt_d;

  /* Delay: '<S294>/UD' incorporates:
   *  Constant: '<S264>/Constant'
   */
  if (rt_ZCFcn(ANY_ZERO_CROSSING,&auto_pilot_upl_PrevZCX.UD_Reset_ZCE_m,
               (auto_pilot_upl_B.RateTransition1)) != NO_ZCEVENT) {
    auto_pilot_upl_DW.icLoad = true;
  }

  if (auto_pilot_upl_DW.icLoad) {
    auto_pilot_upl_DW.UD_DSTATE_j = auto_pilot_upl_P.Constant_Value_m5;
  }

  /* Product: '<S298>/IProd Out' */
  auto_pilot_upl_B.IProdOut = rtb_Integrator_n * rtb_Gain1_b;

  /* DiscreteIntegrator: '<S301>/Integrator' incorporates:
   *  RateTransition: '<S250>/Rate Transition2'
   */
  if (auto_pilot_upl_DW.Integrator_IC_LOADING_j != 0) {
    auto_pilot_upl_DW.Integrator_DSTATE_c =
      auto_pilot_upl_DW.RateTransition2_Buffer_n;
  }

  if (((auto_pilot_upl_B.RateTransition1 > 0.0) &&
       (auto_pilot_upl_DW.Integrator_PrevResetState_j <= 0)) ||
      ((auto_pilot_upl_B.RateTransition1 <= 0.0) &&
       (auto_pilot_upl_DW.Integrator_PrevResetState_j == 1))) {
    auto_pilot_upl_DW.Integrator_DSTATE_c =
      auto_pilot_upl_DW.RateTransition2_Buffer_n;
  }

  /* Gain: '<S250>/Gain1' incorporates:
   *  Abs: '<S250>/Abs'
   *  Sum: '<S263>/Diff'
   *  UnitDelay: '<S263>/UD'
   */
  rtb_Gain1_b = fabs(auto_pilot_upl_B.TSamp_p - auto_pilot_upl_DW.UD_DSTATE_df) *
    auto_pilot_upl_P.AP_Dyn_Rate_Limiter_Gain;

  /* Math: '<S250>/Math Function1' incorporates:
   *  Constant: '<S250>/Constant1'
   */
  if ((rtb_Gain1_b < 0.0) && (auto_pilot_upl_P.AP_Dyn_Rate_Limiter_Power > floor
       (auto_pilot_upl_P.AP_Dyn_Rate_Limiter_Power))) {
    rtb_Gain1_b = -rt_powd_snf(-rtb_Gain1_b,
      auto_pilot_upl_P.AP_Dyn_Rate_Limiter_Power);
  } else {
    rtb_Gain1_b = rt_powd_snf(rtb_Gain1_b,
      auto_pilot_upl_P.AP_Dyn_Rate_Limiter_Power);
  }

  /* End of Math: '<S250>/Math Function1' */

  /* MATLAB Function: '<S250>/MATLAB Function' */
  /* MATLAB Function 'AP/AP_Logic/MATLAB Function': '<S265>:1' */
  if (rtb_Gain1_b == 0.0) {
    /* '<S265>:1:3' */
    /* '<S265>:1:4' */
    rtb_Gain1_b = 1.0E-6;
  } else {
    /* '<S265>:1:6' */
  }

  /* End of MATLAB Function: '<S250>/MATLAB Function' */

  /* Product: '<S250>/Reciprocal' */
  rtb_IProdOut = 1.0 / rtb_Gain1_b;

  /* Product: '<S250>/Product1' incorporates:
   *  Delay: '<S294>/UD'
   *  DiscreteIntegrator: '<S301>/Integrator'
   *  Product: '<S306>/PProd Out'
   *  Sum: '<S294>/Diff'
   *  Sum: '<S310>/Sum'
   */
  rtb_Product1 = ((rtb_Integrator_n * rtb_MultiportSwitch_idx_0 +
                   auto_pilot_upl_DW.Integrator_DSTATE_c) +
                  (auto_pilot_upl_B.Tsamp - auto_pilot_upl_DW.UD_DSTATE_j)) *
    auto_pilot_upl_B.RateTransition1;

  /* Product: '<S266>/delta rise limit' incorporates:
   *  SampleTimeMath: '<S266>/sample time'
   *
   * About '<S266>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_Integrator_n = rtb_IProdOut * auto_pilot_upl_P.sampletime_WtEt;

  /* Sum: '<S266>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S266>/Delay Input2'
   */
  rtb_Gain1_b = rtb_Product1 - auto_pilot_upl_DW.DelayInput2_DSTATE;

  /* Switch: '<S318>/Switch2' incorporates:
   *  RelationalOperator: '<S318>/LowerRelop1'
   */
  if (!(rtb_Gain1_b > rtb_Integrator_n)) {
    /* Product: '<S266>/delta fall limit' incorporates:
     *  Gain: '<S250>/Gain'
     *  SampleTimeMath: '<S266>/sample time'
     *
     * About '<S266>/sample time':
     *  y = K where K = ( w * Ts )
     */
    rtb_Integrator_n = auto_pilot_upl_P.Gain_Gain_p * rtb_IProdOut *
      auto_pilot_upl_P.sampletime_WtEt;

    /* Switch: '<S318>/Switch' incorporates:
     *  RelationalOperator: '<S318>/UpperRelop'
     */
    if (!(rtb_Gain1_b < rtb_Integrator_n)) {
      rtb_Integrator_n = rtb_Gain1_b;
    }

    /* End of Switch: '<S318>/Switch' */
  }

  /* End of Switch: '<S318>/Switch2' */

  /* Sum: '<S266>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S266>/Delay Input2'
   */
  auto_pilot_upl_B.DifferenceInputs2 = rtb_Integrator_n +
    auto_pilot_upl_DW.DelayInput2_DSTATE;

  /* RateLimiter: '<S250>/Rate Limiter' */
  rtb_Gain1_b = auto_pilot_upl_B.DifferenceInputs2 - auto_pilot_upl_DW.PrevY_m;
  if (rtb_Gain1_b > auto_pilot_upl_P.AP_Steer_Rate_Max_radps *
      auto_pilot_upl_period_d) {
    rtb_Gain1_b = auto_pilot_upl_P.AP_Steer_Rate_Max_radps *
      auto_pilot_upl_period_d + auto_pilot_upl_DW.PrevY_m;
  } else {
    rtb_Integrator_n = -auto_pilot_upl_P.AP_Steer_Rate_Max_radps *
      auto_pilot_upl_period_d;
    if (rtb_Gain1_b < rtb_Integrator_n) {
      rtb_Gain1_b = rtb_Integrator_n + auto_pilot_upl_DW.PrevY_m;
    } else {
      rtb_Gain1_b = auto_pilot_upl_B.DifferenceInputs2;
    }
  }

  auto_pilot_upl_DW.PrevY_m = rtb_Gain1_b;

  /* End of RateLimiter: '<S250>/Rate Limiter' */

  /* RateTransition: '<S250>/Rate Transition5' */
  auto_pilot_upl_DW.RateTransition5_Buffer0 = rtb_Gain1_b;

  /* RateTransition: '<S250>/Rate Transition8' */
  auto_pilot_upl_DW.RateTransition8_Buffer0 = rtb_SumofElements;
}

/* Model update function for TID3 */
void auto_pilot_upl_update3(void)      /* Sample time: [0.02s, 0.0s] */
{
  /* Update for UnitDelay: '<S262>/UD' */
  auto_pilot_upl_DW.UD_DSTATE_i = auto_pilot_upl_B.TSamp;

  /* Update for UnitDelay: '<S263>/UD' */
  auto_pilot_upl_DW.UD_DSTATE_df = auto_pilot_upl_B.TSamp_p;

  /* Update for Delay: '<S294>/UD' */
  auto_pilot_upl_DW.icLoad = false;
  auto_pilot_upl_DW.UD_DSTATE_j = auto_pilot_upl_B.Tsamp;

  /* Update for DiscreteIntegrator: '<S301>/Integrator' */
  auto_pilot_upl_DW.Integrator_IC_LOADING_j = 0U;
  auto_pilot_upl_DW.Integrator_DSTATE_c += auto_pilot_upl_P.Integrator_gainval_f
    * auto_pilot_upl_B.IProdOut;
  if (auto_pilot_upl_B.RateTransition1 > 0.0) {
    auto_pilot_upl_DW.Integrator_PrevResetState_j = 1;
  } else if (auto_pilot_upl_B.RateTransition1 < 0.0) {
    auto_pilot_upl_DW.Integrator_PrevResetState_j = -1;
  } else if (auto_pilot_upl_B.RateTransition1 == 0.0) {
    auto_pilot_upl_DW.Integrator_PrevResetState_j = 0;
  } else {
    auto_pilot_upl_DW.Integrator_PrevResetState_j = 2;
  }

  /* End of Update for DiscreteIntegrator: '<S301>/Integrator' */

  /* Update for UnitDelay: '<S266>/Delay Input2' */
  auto_pilot_upl_DW.DelayInput2_DSTATE = auto_pilot_upl_B.DifferenceInputs2;

  /* Update absolute time */
  /* The "clockTick3" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick3"
   * and "Timing.stepSize3". Size of "clockTick3" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick3 and the high bits
   * Timing.clockTickH3. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++auto_pilot_upl_M->Timing.clockTick3)) {
    ++auto_pilot_upl_M->Timing.clockTickH3;
  }

  auto_pilot_upl_M->Timing.t[3] = auto_pilot_upl_M->Timing.clockTick3 *
    auto_pilot_upl_M->Timing.stepSize3 + auto_pilot_upl_M->Timing.clockTickH3 *
    auto_pilot_upl_M->Timing.stepSize3 * 4294967296.0;
}

/* Model output function for TID4 */
void auto_pilot_upl_output4(void)      /* Sample time: [0.04s, 0.0s] */
{
  real_T rtb_Switch1[60];
  real_T rtb_Target_X_Distance_mux[30];
  real_T rtb_Target_Y_Distance_mux[30];
  real_T rtb_MinMax4;
  real_T rtb_MultiportSwitch_l;
  real_T rtb_Sum_jp;
  real_T rtb_Target_Y_Distance_mux_g;
  real_T rtb_Target_Y_Distance_mux_tmp;
  real_T u0;
  int32_T i;
  int8_T rtb_Product_n[150];
  boolean_T rtb_LogicalOperator_n[30];

  /* RateTransition: '<S215>/Rate Transition' */
  memcpy(&auto_pilot_upl_B.RateTransition[0],
         &auto_pilot_upl_DW.RateTransition_Buffer_h[0], 90U * sizeof(real_T));

  /* RateTransition generated from: '<S220>/Product5' */
  memcpy(&auto_pilot_upl_DW.TmpRTBAtProduct5Inport1_Buffer0[0],
         &auto_pilot_upl_B.RateTransition[60], 30U * sizeof(real_T));

  /* Sum: '<S239>/Sum1' incorporates:
   *  Constant: '<S239>/Constant'
   *  Constant: '<S239>/Constant1'
   *  Gain: '<S239>/Gain2'
   *  RateTransition: '<S239>/Rate Transition'
   *  Sum: '<S239>/Sum'
   */
  rtb_MultiportSwitch_l = (auto_pilot_upl_P.AEB_Gain_set -
    auto_pilot_upl_DW.RateTransition_Buffer_a) *
    auto_pilot_upl_P.AEB_Gain_set_mult + auto_pilot_upl_P.Constant1_Value_d;

  /* Saturate: '<S239>/Saturation' */
  if (rtb_MultiportSwitch_l > auto_pilot_upl_P.Saturation_UpperSat_j) {
    rtb_MultiportSwitch_l = auto_pilot_upl_P.Saturation_UpperSat_j;
  } else if (rtb_MultiportSwitch_l < auto_pilot_upl_P.Saturation_LowerSat_l) {
    rtb_MultiportSwitch_l = auto_pilot_upl_P.Saturation_LowerSat_l;
  }

  /* End of Saturate: '<S239>/Saturation' */

  /* RelationalOperator: '<S225>/Compare' incorporates:
   *  Constant: '<S225>/Constant'
   */
  /* MATLAB Function 'AEB/AEB_Logic/Target_XY_Distance': '<S233>:1' */
  /* '<S233>:1:4' */
  /* '<S233>:1:5' */
  rtb_MinMax4 = auto_pilot_upl_P.Lane_Width / 2.0;
  for (i = 0; i < 30; i++) {
    real_T rtb_DataTypeConversion1_n;
    real_T rtb_Gain_bq;

    /* MATLAB Function: '<S215>/Target_XY_Distance' */
    rtb_Target_Y_Distance_mux_tmp = auto_pilot_upl_B.RateTransition[i + 30];
    rtb_Target_Y_Distance_mux_g = sin(rtb_Target_Y_Distance_mux_tmp) *
      auto_pilot_upl_B.RateTransition[i];
    rtb_Target_Y_Distance_mux_tmp = cos(rtb_Target_Y_Distance_mux_tmp) *
      auto_pilot_upl_B.RateTransition[i];

    /* Sum: '<S241>/Sum1' incorporates:
     *  Constant: '<S241>/Lane_Right_Edge_Y_Distance'
     */
    rtb_Gain_bq = rtb_Target_Y_Distance_mux_g -
      auto_pilot_upl_P.Lane_Right_Edge_Y_Distance_Value;

    /* SampleTimeMath: '<S244>/TSamp'
     *
     * About '<S244>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    auto_pilot_upl_B.TSamp_d[i] = rtb_Gain_bq * auto_pilot_upl_P.TSamp_WtEt_f;

    /* Sum: '<S244>/Diff' incorporates:
     *  UnitDelay: '<S244>/UD'
     */
    u0 = auto_pilot_upl_B.TSamp_d[i] - auto_pilot_upl_DW.UD_DSTATE_a[i];

    /* Saturate: '<S241>/Saturation' */
    if (u0 > auto_pilot_upl_P.Saturation_UpperSat_i) {
      u0 = auto_pilot_upl_P.Saturation_UpperSat_i;
    } else if (u0 < auto_pilot_upl_P.Saturation_LowerSat_i) {
      u0 = auto_pilot_upl_P.Saturation_LowerSat_i;
    }

    /* Gain: '<S241>/Gain2' incorporates:
     *  Product: '<S241>/Div2'
     *  Saturate: '<S241>/Saturation'
     */
    rtb_DataTypeConversion1_n = rtb_Gain_bq / u0 * auto_pilot_upl_P.Gain2_Gain_n;

    /* Sum: '<S241>/Sum' incorporates:
     *  Constant: '<S241>/Lane_Left_Edge_Y_Distance'
     */
    rtb_Gain_bq = rtb_Target_Y_Distance_mux_g -
      auto_pilot_upl_P.Lane_Left_Edge_Y_Distance_Value;

    /* SampleTimeMath: '<S243>/TSamp'
     *
     * About '<S243>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    auto_pilot_upl_B.TSamp_k[i] = rtb_Gain_bq * auto_pilot_upl_P.TSamp_WtEt_a;

    /* Sum: '<S243>/Diff' incorporates:
     *  UnitDelay: '<S243>/UD'
     */
    u0 = auto_pilot_upl_B.TSamp_k[i] - auto_pilot_upl_DW.UD_DSTATE_pg[i];

    /* Saturate: '<S241>/Saturation1' */
    if (u0 > auto_pilot_upl_P.Saturation1_UpperSat_c) {
      u0 = auto_pilot_upl_P.Saturation1_UpperSat_c;
    } else if (u0 < auto_pilot_upl_P.Saturation1_LowerSat_d) {
      u0 = auto_pilot_upl_P.Saturation1_LowerSat_d;
    }

    /* Gain: '<S241>/Gain1' incorporates:
     *  Product: '<S241>/Div1'
     *  Saturate: '<S241>/Saturation1'
     */
    rtb_Sum_jp = rtb_Gain_bq / u0 * auto_pilot_upl_P.Gain1_Gain_l;

    /* SampleTimeMath: '<S242>/TSamp'
     *
     * About '<S242>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    auto_pilot_upl_B.TSamp_f[i] = rtb_Target_Y_Distance_mux_tmp *
      auto_pilot_upl_P.TSamp_WtEt_i;

    /* Sum: '<S242>/Diff' incorporates:
     *  UnitDelay: '<S242>/UD'
     */
    u0 = auto_pilot_upl_B.TSamp_f[i] - auto_pilot_upl_DW.UD_DSTATE_h[i];

    /* Saturate: '<S240>/Saturation' */
    if (u0 > auto_pilot_upl_P.Saturation_UpperSat_o) {
      u0 = auto_pilot_upl_P.Saturation_UpperSat_o;
    } else if (u0 < auto_pilot_upl_P.Saturation_LowerSat_j) {
      u0 = auto_pilot_upl_P.Saturation_LowerSat_j;
    }

    /* Gain: '<S240>/Gain' incorporates:
     *  Product: '<S240>/Div'
     *  Saturate: '<S240>/Saturation'
     */
    rtb_Gain_bq = rtb_Target_Y_Distance_mux_tmp / u0 *
      auto_pilot_upl_P.Gain_Gain_nd;

    /* SignalConversion generated from: '<S221>/Delay' incorporates:
     *  Constant: '<S224>/Constant'
     *  Gain: '<S239>/Gain'
     *  Gain: '<S239>/Gain1'
     *  Logic: '<S239>/Logical Operator'
     *  MinMax: '<S239>/MinMax'
     *  MinMax: '<S239>/MinMax1'
     *  Product: '<S239>/Product'
     *  Product: '<S239>/Product1'
     *  RateTransition: '<S215>/Rate Transition1'
     *  RelationalOperator: '<S224>/Compare'
     *  RelationalOperator: '<S239>/Relational Operator'
     *  RelationalOperator: '<S239>/Relational Operator1'
     */
    auto_pilot_upl_B.TmpSignalConversionAtDelayInport1[i] =
      (auto_pilot_upl_DW.RateTransition1_Buffer_b[i] >
       auto_pilot_upl_P.CompareToConstant1_const_l);
    auto_pilot_upl_B.TmpSignalConversionAtDelayInport1[i + 30] =
      ((auto_pilot_upl_P.AEB_Gain[0] * fmin(rtb_DataTypeConversion1_n,
         rtb_Sum_jp) * rtb_MultiportSwitch_l < rtb_Gain_bq) &&
       (auto_pilot_upl_P.AEB_Gain[1] * fmax(rtb_DataTypeConversion1_n,
         rtb_Sum_jp) * rtb_MultiportSwitch_l > rtb_Gain_bq));

    /* RelationalOperator: '<S215>/Relational Operator' incorporates:
     *  RelationalOperator: '<S230>/FixPt Relational Operator'
     */
    rtb_Gain_bq = auto_pilot_upl_B.RateTransition[i + 60];

    /* SignalConversion generated from: '<S221>/Delay' incorporates:
     *  Abs: '<S215>/Abs'
     *  Constant: '<S227>/Constant'
     *  RelationalOperator: '<S215>/Relational Operator'
     *  RelationalOperator: '<S225>/Compare'
     *  RelationalOperator: '<S227>/Compare'
     *  RelationalOperator: '<S230>/FixPt Relational Operator'
     *  UnitDelay: '<S230>/Delay Input1'
     */
    auto_pilot_upl_B.TmpSignalConversionAtDelayInport1[i + 60] = ((!rtIsNaN
      (rtb_Gain_bq)) && (!rtIsInf(rtb_Gain_bq)));
    auto_pilot_upl_B.TmpSignalConversionAtDelayInport1[i + 90] = ((rtb_Gain_bq
      != auto_pilot_upl_DW.DelayInput1_DSTATE_f[i]) == (int32_T)
      auto_pilot_upl_P.Constant_Value_b);
    auto_pilot_upl_B.TmpSignalConversionAtDelayInport1[i + 120] = (fabs
      (rtb_Target_Y_Distance_mux_g) <= rtb_MinMax4);

    /* MATLAB Function: '<S215>/Target_XY_Distance' */
    rtb_Target_X_Distance_mux[i] = rtb_Target_Y_Distance_mux_tmp;
  }

  /* Product: '<S221>/Product' incorporates:
   *  Delay: '<S221>/Delay'
   *  Delay: '<S221>/Delay1'
   *  Delay: '<S221>/Delay2'
   */
  for (i = 0; i < 150; i++) {
    rtb_Product_n[i] = (int8_T)(auto_pilot_upl_DW.Delay2_DSTATE[i] ?
      auto_pilot_upl_DW.Delay1_DSTATE_i[i] ?
      auto_pilot_upl_B.TmpSignalConversionAtDelayInport1[i] ? (int32_T)
      auto_pilot_upl_DW.Delay_DSTATE_l[i] : 0 : 0 : 0);
  }

  /* End of Product: '<S221>/Product' */

  /* Logic: '<S221>/Logical Operator' incorporates:
   *  RateTransition: '<S221>/Rate Transition'
   *  RateTransition: '<S221>/Rate Transition1'
   *  Switch: '<S221>/Switch'
   */
  for (i = 0; i < 30; i++) {
    /* Switch: '<S221>/Switch' incorporates:
     *  Constant: '<S221>/Constant'
     *  Constant: '<S238>/Constant'
     *  RateTransition: '<S221>/Rate Transition2'
     *  RelationalOperator: '<S238>/Compare'
     */
    if (auto_pilot_upl_DW.RateTransition2_Buffer[i] ==
        auto_pilot_upl_P.AEB_Pedestrian_type) {
      rtb_MultiportSwitch_l = auto_pilot_upl_P.Constant_Value_ne;
    } else {
      rtb_MultiportSwitch_l = rtb_Product_n[i + 120];
    }

    rtb_LogicalOperator_n[i] = ((rtb_Product_n[i] != 0) && (rtb_Product_n[i + 30]
      != 0) && (rtb_Product_n[i + 60] != 0) && (rtb_Product_n[i + 90] != 0) &&
      (rtb_MultiportSwitch_l != 0.0) &&
      auto_pilot_upl_DW.RateTransition_Buffer_e &&
      auto_pilot_upl_DW.RateTransition1_Buffer_f);
  }

  /* End of Logic: '<S221>/Logical Operator' */

  /* MultiPortSwitch: '<S231>/Multiport Switch' incorporates:
   *  Constant: '<S231>/ADAS_Control_Mode'
   *  Constant: '<S231>/AEB_Max_Decel'
   *  Constant: '<S231>/AEB_Max_Decel1'
   */
  switch ((int32_T)auto_pilot_upl_P.ADAS_Control_Mode) {
   case 1:
    rtb_MultiportSwitch_l = auto_pilot_upl_P.AEB_Max_Decel[0];
    break;

   case 2:
    rtb_MultiportSwitch_l = auto_pilot_upl_P.AEB_Max_Decel[1];
    break;

   default:
    rtb_MultiportSwitch_l = auto_pilot_upl_P.AEB_Max_Decel[0];
    break;
  }

  /* End of MultiPortSwitch: '<S231>/Multiport Switch' */

  /* Gain: '<S231>/Gain' */
  rtb_MultiportSwitch_l *= auto_pilot_upl_P.Gain_Gain_g;

  /* MATLAB Function 'AEB/AEB_Logic/MATLAB Function': '<S232>:1' */
  /* '<S232>:1:3' */
  for (i = 0; i < 30; i++) {
    /* RelationalOperator: '<S222>/Compare' */
    rtb_Target_Y_Distance_mux_tmp = rtb_Target_X_Distance_mux[i];

    /* Sum: '<S231>/Sum' incorporates:
     *  Constant: '<S231>/Constant'
     *  Math: '<S231>/Square'
     *  Product: '<S231>/Product1'
     *  RateTransition: '<S231>/Rate Transition1'
     */
    rtb_Sum_jp = auto_pilot_upl_DW.RateTransition1_Buffer_g[i] *
      auto_pilot_upl_DW.RateTransition1_Buffer_g[i] / rtb_MultiportSwitch_l +
      auto_pilot_upl_P.AEB_Min_Distance_at_Stop;

    /* Gain: '<S215>/Gain1' incorporates:
     *  Constant: '<S222>/Constant'
     *  DataTypeConversion: '<S215>/Data Type Conversion1'
     *  Logic: '<S215>/Logical Operator'
     *  RelationalOperator: '<S215>/Relational Operator1'
     *  RelationalOperator: '<S222>/Compare'
     */
    auto_pilot_upl_B.Gain1_o[i] = (real_T)((rtb_Target_Y_Distance_mux_tmp <
      auto_pilot_upl_P.AEB_Distance_To_Collision_Brake) ||
      (rtb_Target_Y_Distance_mux_tmp <= rtb_Sum_jp)) *
      auto_pilot_upl_P.Gain1_Gain_d;

    /* Switch: '<S215>/Switch1' incorporates:
     *  Constant: '<S215>/Constant2'
     */
    if (rtb_LogicalOperator_n[i]) {
      rtb_Switch1[i] = rtb_Target_Y_Distance_mux_tmp;
      rtb_Switch1[i + 30] = rtb_Sum_jp;
    } else {
      rtb_Switch1[i] = auto_pilot_upl_P.Constant2_Value_p;
      rtb_Switch1[i + 30] = auto_pilot_upl_P.Constant2_Value_p;
    }

    /* End of Switch: '<S215>/Switch1' */
  }

  /* MinMax: '<S215>/MinMax3' */
  rtb_MultiportSwitch_l = rtb_Switch1[0];

  /* MinMax: '<S215>/MinMax4' */
  rtb_MinMax4 = rtb_Switch1[30];
  for (i = 0; i < 29; i++) {
    /* MinMax: '<S215>/MinMax3' */
    rtb_MultiportSwitch_l = fmin(rtb_MultiportSwitch_l, rtb_Switch1[i + 1]);

    /* MinMax: '<S215>/MinMax4' */
    rtb_MinMax4 = fmin(rtb_MinMax4, rtb_Switch1[i + 31]);
  }

  /* RateTransition: '<S215>/Rate Transition5' */
  auto_pilot_upl_DW.RateTransition5_Buffer0_h = rtb_MinMax4;

  /* RateTransition: '<S215>/Rate Transition6' */
  auto_pilot_upl_DW.RateTransition6_Buffer0 = rtb_MultiportSwitch_l;
  for (i = 0; i < 30; i++) {
    /* Switch: '<S215>/Switch' incorporates:
     *  Constant: '<S215>/Constant1'
     *  Delay: '<S215>/Delay'
     */
    if (rtb_LogicalOperator_n[i]) {
      rtb_Target_Y_Distance_mux_g = auto_pilot_upl_DW.Delay_DSTATE[i];
    } else {
      rtb_Target_Y_Distance_mux_g = auto_pilot_upl_P.Constant1_Value_i;
    }

    /* End of Switch: '<S215>/Switch' */

    /* RateTransition: '<S215>/Rate Transition7' */
    auto_pilot_upl_DW.RateTransition7_Buffer0[i] = rtb_Target_Y_Distance_mux_g;
  }

  for (i = 0; i < 30; i++) {
    /* RateTransition: '<S215>/Rate Transition1' */
    u0 = auto_pilot_upl_DW.RateTransition1_Buffer_b[i];

    /* Saturate: '<S215>/Saturation' */
    if (u0 > auto_pilot_upl_P.Saturation_UpperSat_e) {
      rtb_Target_Y_Distance_mux[i] = auto_pilot_upl_P.Saturation_UpperSat_e;
    } else if (u0 < auto_pilot_upl_P.Saturation_LowerSat_ll) {
      rtb_Target_Y_Distance_mux[i] = auto_pilot_upl_P.Saturation_LowerSat_ll;
    } else {
      rtb_Target_Y_Distance_mux[i] = u0;
    }

    /* End of Saturate: '<S215>/Saturation' */

    /* RateTransition generated from: '<S215>/derivation_speed' */
    auto_pilot_upl_DW.Target_X_Distance_mux_Buffer0[i] =
      rtb_Target_X_Distance_mux[i];
  }

  /* RateTransition generated from: '<S215>/filtering' */
  memcpy(&auto_pilot_upl_DW.after_saturation_Buffer0[0],
         &rtb_Target_Y_Distance_mux[0], 30U * sizeof(real_T));
}

/* Model update function for TID4 */
void auto_pilot_upl_update4(void)      /* Sample time: [0.04s, 0.0s] */
{
  int32_T i;
  for (i = 0; i < 150; i++) {
    /* Update for Delay: '<S221>/Delay' */
    auto_pilot_upl_DW.Delay_DSTATE_l[i] =
      auto_pilot_upl_B.TmpSignalConversionAtDelayInport1[i];

    /* Update for Delay: '<S221>/Delay1' */
    auto_pilot_upl_DW.Delay1_DSTATE_i[i] = auto_pilot_upl_DW.Delay1_DSTATE_i[i +
      150];
    auto_pilot_upl_DW.Delay1_DSTATE_i[i + 150] =
      auto_pilot_upl_B.TmpSignalConversionAtDelayInport1[i];
  }

  for (i = 0; i < 300; i++) {
    /* Update for Delay: '<S221>/Delay2' */
    auto_pilot_upl_DW.Delay2_DSTATE[i] = auto_pilot_upl_DW.Delay2_DSTATE[i + 150];
  }

  /* Update for Delay: '<S221>/Delay2' */
  memcpy(&auto_pilot_upl_DW.Delay2_DSTATE[300],
         &auto_pilot_upl_B.TmpSignalConversionAtDelayInport1[0], 150U * sizeof
         (boolean_T));

  /* Update for UnitDelay: '<S244>/UD' */
  memcpy(&auto_pilot_upl_DW.UD_DSTATE_a[0], &auto_pilot_upl_B.TSamp_d[0], 30U *
         sizeof(real_T));

  /* Update for UnitDelay: '<S243>/UD' */
  memcpy(&auto_pilot_upl_DW.UD_DSTATE_pg[0], &auto_pilot_upl_B.TSamp_k[0], 30U *
         sizeof(real_T));

  /* Update for UnitDelay: '<S242>/UD' */
  memcpy(&auto_pilot_upl_DW.UD_DSTATE_h[0], &auto_pilot_upl_B.TSamp_f[0], 30U *
         sizeof(real_T));

  /* Update for UnitDelay: '<S230>/Delay Input1' */
  memcpy(&auto_pilot_upl_DW.DelayInput1_DSTATE_f[0],
         &auto_pilot_upl_B.RateTransition[60], 30U * sizeof(real_T));

  /* Update for Delay: '<S215>/Delay' */
  memcpy(&auto_pilot_upl_DW.Delay_DSTATE[0], &auto_pilot_upl_B.Gain1_o[0], 30U *
         sizeof(real_T));

  /* Update absolute time */
  /* The "clockTick4" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick4"
   * and "Timing.stepSize4". Size of "clockTick4" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick4 and the high bits
   * Timing.clockTickH4. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++auto_pilot_upl_M->Timing.clockTick4)) {
    ++auto_pilot_upl_M->Timing.clockTickH4;
  }

  auto_pilot_upl_M->Timing.t[4] = auto_pilot_upl_M->Timing.clockTick4 *
    auto_pilot_upl_M->Timing.stepSize4 + auto_pilot_upl_M->Timing.clockTickH4 *
    auto_pilot_upl_M->Timing.stepSize4 * 4294967296.0;
}

/* Use this function only if you need to maintain compatibility with an existing static main program. */
void auto_pilot_upl_output(int_T tid)
{
  switch (tid) {
   case 0 :
    auto_pilot_upl_output0();
    break;

   case 2 :
    auto_pilot_upl_output2();
    break;

   case 3 :
    auto_pilot_upl_output3();
    break;

   case 4 :
    auto_pilot_upl_output4();
    break;

   default :
    /* do nothing */
    break;
  }
}

/* Use this function only if you need to maintain compatibility with an existing static main program. */
void auto_pilot_upl_update(int_T tid)
{
  switch (tid) {
   case 0 :
    auto_pilot_upl_update0();
    break;

   case 2 :
    auto_pilot_upl_update2();
    break;

   case 3 :
    auto_pilot_upl_update3();
    break;

   case 4 :
    auto_pilot_upl_update4();
    break;

   default :
    /* do nothing */
    break;
  }
}

/* Model initialize function */
void auto_pilot_upl_initialize(void)
{
  {
    int32_T i;

    /* Start for S-Function (simwbC_RTDBIn): '<S7>/VI_DriveSim.Inputs.ECAT.BECKH.ANA3' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.ECAT.BECKH.ANA3",&pItem) <
          0) {
        fprintf(stderr,
                "MDL:  input var VI_DriveSim.Inputs.ECAT.BECKH.ANA3 not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.ANA3 not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_DriveSim.Inputs.ECAT.BECKH.ANA3 datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.ANA3 datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_DriveSim_Inputs_ECAT_BECKH_ANA3 = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<S7>/VI_CarRealTime.Outputs.transmission.gear' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_CarRealTime.Outputs.transmission.gear",
           &pItem) < 0) {
        fprintf(stderr,
                "MDL:  input var VI_CarRealTime.Outputs.transmission.gear not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.transmission.gear not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Outputs.transmission.gear datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.transmission.gear datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Outputs_transmission_gear = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<S7>/VI_DriveSim.Inputs.ECAT.BECKH.ANA1' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.ECAT.BECKH.ANA4",&pItem) <
          0) {
        fprintf(stderr,
                "MDL:  input var VI_DriveSim.Inputs.ECAT.BECKH.ANA4 not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.ANA4 not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_DriveSim.Inputs.ECAT.BECKH.ANA4 datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.ANA4 datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_DriveSim_Inputs_ECAT_BECKH_ANA4 = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<S7>/VI_DriveSim.Inputs.ECAT.BECKH.DIG4' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.ECAT.BECKH.DIG4",&pItem) <
          0) {
        fprintf(stderr,
                "MDL:  input var VI_DriveSim.Inputs.ECAT.BECKH.DIG4 not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.DIG4 not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_DriveSim.Inputs.ECAT.BECKH.DIG4 datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.DIG4 datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_DriveSim_Inputs_ECAT_BECKH_DIG4 = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.chassis_velocities.longitudinal' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "VI_CarRealTime.Outputs.chassis_velocities.longitudinal",&pItem) < 0)
      {
        fprintf(stderr,
                "MDL:  input var VI_CarRealTime.Outputs.chassis_velocities.longitudinal not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.chassis_velocities.longitudinal not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Outputs.chassis_velocities.longitudinal datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.chassis_velocities.longitudinal datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Outputs_chassis_velocities_longitudinal = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<S7>/VI_DriveSim.Outputs.Vicrt.Status' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_DriveSim.Outputs.Vicrt.Status",&pItem) < 0)
      {
        fprintf(stderr,
                "MDL:  input var VI_DriveSim.Outputs.Vicrt.Status not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_DriveSim.Outputs.Vicrt.Status not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_DriveSim.Outputs.Vicrt.Status datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_DriveSim.Outputs.Vicrt.Status datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_DriveSim_Outputs_Vicrt_Status = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.driver_demands.brake' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_CarRealTime.Outputs.driver_demands.brake",
           &pItem) < 0) {
        fprintf(stderr,
                "MDL:  input var VI_CarRealTime.Outputs.driver_demands.brake not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.driver_demands.brake not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Outputs.driver_demands.brake datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.driver_demands.brake datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Outputs_driver_demands_brake = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1",&pItem) < 0) {
        fprintf(stderr,
                "MDL:  input var VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1 not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1 not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1 datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1 datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Outputs_Wheel_Spindle_Steer_L1 = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1",&pItem) < 0) {
        fprintf(stderr,
                "MDL:  input var VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1 not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1 not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1 datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1 datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Outputs_Wheel_Spindle_Steer_R1 = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.driver_demands.throttle' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "VI_CarRealTime.Outputs.driver_demands.throttle",&pItem) < 0) {
        fprintf(stderr,
                "MDL:  input var VI_CarRealTime.Outputs.driver_demands.throttle not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.driver_demands.throttle not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Outputs.driver_demands.throttle datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.driver_demands.throttle datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Outputs_driver_demands_throttle = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.driver_demands.steering' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "VI_CarRealTime.Outputs.driver_demands.steering",&pItem) < 0) {
        fprintf(stderr,
                "MDL:  input var VI_CarRealTime.Outputs.driver_demands.steering not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.driver_demands.steering not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Outputs.driver_demands.steering datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.driver_demands.steering datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Outputs_driver_demands_steering = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque",
           &pItem) < 0) {
        fprintf(stderr,
                "MDL:  input var VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Outputs_Steering_System_DriveSim_Steering_Feedback_Torque =
        &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.chassis_accelerations.lateral' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "VI_CarRealTime.Outputs.chassis_accelerations.lateral",&pItem) < 0) {
        fprintf(stderr,
                "MDL:  input var VI_CarRealTime.Outputs.chassis_accelerations.lateral not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.chassis_accelerations.lateral not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Outputs.chassis_accelerations.lateral datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.chassis_accelerations.lateral datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Outputs_chassis_accelerations_lateral = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<Root>/VI_CarRealTime.Outputs.chassis_accelerations.longitudinal' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "VI_CarRealTime.Outputs.chassis_accelerations.longitudinal",&pItem) <
          0) {
        fprintf(stderr,
                "MDL:  input var VI_CarRealTime.Outputs.chassis_accelerations.longitudinal not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.chassis_accelerations.longitudinal not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Outputs.chassis_accelerations.longitudinal datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_CarRealTime.Outputs.chassis_accelerations.longitudinal datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Outputs_chassis_accelerations_longitudinal = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBIn): '<S7>/VI_DriveSim.Inputs.ECAT.BECKH.DIG3' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.ECAT.BECKH.DIG3",&pItem) <
          0) {
        fprintf(stderr,
                "MDL:  input var VI_DriveSim.Inputs.ECAT.BECKH.DIG3 not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.DIG3 not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_DriveSim.Inputs.ECAT.BECKH.DIG3 datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL input variable: VI_DriveSim.Inputs.ECAT.BECKH.DIG3 datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_DriveSim_Inputs_ECAT_BECKH_DIG3 = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for DiscretePulseGenerator: '<S215>/Pulse Generator' */
    auto_pilot_upl_DW.clockTickCounter = 0;
    for (i = 0; i < 30; i++) {
      /* Start for RateTransition: '<S215>/Rate Transition7' */
      auto_pilot_upl_B.RateTransition7[i] =
        auto_pilot_upl_P.RateTransition7_InitialCondition;

      /* Start for RateTransition generated from: '<S215>/derivation_speed' */
      auto_pilot_upl_B.Target_X_Distance_mux[i] =
        auto_pilot_upl_P.Target_X_Distance_mux_InitialCondition;

      /* Start for RateTransition generated from: '<S220>/Product5' */
      auto_pilot_upl_B.TmpRTBAtProduct5Inport1[i] =
        auto_pilot_upl_P.TmpRTBAtProduct5Inport1_InitialCondition;
    }

    /* Start for RateTransition: '<S215>/Rate Transition6' */
    auto_pilot_upl_B.RateTransition6 =
      auto_pilot_upl_P.RateTransition6_InitialCondition;
    for (i = 0; i < 120; i++) {
      /* Start for RateTransition generated from: '<S324>/Multiport Switch' */
      auto_pilot_upl_B.TmpRTBAtMultiportSwitchInport3[i] =
        auto_pilot_upl_P.TmpRTBAtMultiportSwitchInport3_InitialCondition;
    }

    /* Start for RateTransition generated from: '<S177>/Sum' */
    auto_pilot_upl_B.TmpRTBAtSumInport1 =
      auto_pilot_upl_P.TmpRTBAtSumInport1_InitialCondition;

    /* Start for RateTransition generated from: '<S163>/Tsamp'
     *
     * About RateTransition generated from '<S163>/Tsamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    auto_pilot_upl_B.TmpRTBAtTsampOutport1 =
      auto_pilot_upl_P.TmpRTBAtTsampOutport1_InitialCondition;

    /* Start for RateTransition: '<S250>/Rate Transition8' */
    auto_pilot_upl_B.RateTransition8 =
      auto_pilot_upl_P.RateTransition8_InitialCondition;

    /* Start for RateTransition: '<S250>/Rate Transition5' */
    auto_pilot_upl_B.RateTransition5 =
      auto_pilot_upl_P.RateTransition5_InitialCondition;

    /* Start for RateTransition generated from: '<S159>/SumI4' */
    auto_pilot_upl_B.TmpRTBAtSumI4Inport2 =
      auto_pilot_upl_P.TmpRTBAtSumI4Inport2_InitialCondition;

    /* Start for DiscretePulseGenerator: '<S216>/Pulse Generator' */
    auto_pilot_upl_DW.clockTickCounter_k = 0;

    /* Start for RateTransition: '<S215>/Rate Transition5' */
    auto_pilot_upl_B.RateTransition5_n =
      auto_pilot_upl_P.RateTransition5_InitialCondition_e;
    for (i = 0; i < 30; i++) {
      /* Start for RateTransition generated from: '<S215>/filtering' */
      auto_pilot_upl_B.after_saturation[i] =
        auto_pilot_upl_P.after_saturation_InitialCondition;
    }

    /* Start for RateTransition generated from: '<S329>/Sum' */
    auto_pilot_upl_B.TmpRTBAtSumOutport1 =
      auto_pilot_upl_P.TmpRTBAtSumOutport1_InitialCondition;

    /* Start for RateTransition generated from: '<S329>/Discrete Filter1' */
    auto_pilot_upl_B.TmpRTBAtDiscreteFilter1Inport1 =
      auto_pilot_upl_P.TmpRTBAtDiscreteFilter1Inport1_InitialCondition;

    /* Start for DiscretePulseGenerator: '<S329>/Pulse Generator' */
    auto_pilot_upl_DW.clockTickCounter_h = 0;

    /* Start for S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.Driver_Demands.brake' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_CarRealTime.Inputs.Driver_Demands.brake",
           &pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var VI_CarRealTime.Inputs.Driver_Demands.brake not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_CarRealTime.Inputs.Driver_Demands.brake not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Inputs.Driver_Demands.brake datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_CarRealTime.Inputs.Driver_Demands.brake datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Inputs_Driver_Demands_brake = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.Driver_Demands.throttle' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "VI_CarRealTime.Inputs.Driver_Demands.throttle",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var VI_CarRealTime.Inputs.Driver_Demands.throttle not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_CarRealTime.Inputs.Driver_Demands.throttle not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Inputs.Driver_Demands.throttle datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_CarRealTime.Inputs.Driver_Demands.throttle datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Inputs_Driver_Demands_throttle = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<Root>/VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ",
           &pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_UPSHIFT_REQ datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_DriveSim_Inputs_Control_VICRT_UPSHIFT_REQ = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.Driver_Demands.str_swa' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_CarRealTime.Inputs.Driver_Demands.str_swa",
           &pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var VI_CarRealTime.Inputs.Driver_Demands.str_swa not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_CarRealTime.Inputs.Driver_Demands.str_swa not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Inputs.Driver_Demands.str_swa datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_CarRealTime.Inputs.Driver_Demands.str_swa datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Inputs_Driver_Demands_str_swa = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.steer_assist.torque' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_CarRealTime.Inputs.steer_assist.torque",
           &pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var VI_CarRealTime.Inputs.steer_assist.torque not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_CarRealTime.Inputs.steer_assist.torque not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Inputs.steer_assist.torque datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_CarRealTime.Inputs.steer_assist.torque datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Inputs_steer_assist_torque = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<Root>/VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_DOWNSHIFT_REQ datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_DriveSim_Inputs_Control_VICRT_DOWNSHIFT_REQ = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<Root>/VI_CarRealTime.Inputs.Driver_Demands.target_speed' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "VI_CarRealTime.Inputs.Driver_Demands.target_speed",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var VI_CarRealTime.Inputs.Driver_Demands.target_speed not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_CarRealTime.Inputs.Driver_Demands.target_speed not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_CarRealTime.Inputs.Driver_Demands.target_speed datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_CarRealTime.Inputs.Driver_Demands.target_speed datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_CarRealTime_Inputs_Driver_Demands_target_speed = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_On' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.ACC.ACC_On",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.ACC.ACC_On not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_On not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.ACC.ACC_On datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_On datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_ACC_ACC_On = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_On_Display' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.ACC.ACC_On_Display",&pItem) < 0)
      {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.ACC.ACC_On_Display not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_On_Display not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.ACC.ACC_On_Display datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_On_Display datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_ACC_ACC_On_Display = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_Ready' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.ACC.ACC_Ready",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.ACC.ACC_Ready not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_Ready not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.ACC.ACC_Ready datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_Ready datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_ACC_ACC_Ready = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_Ready_Display' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.ACC.ACC_Ready_Display",&pItem) <
          0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.ACC.ACC_Ready_Display not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_Ready_Display not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.ACC.ACC_Ready_Display datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_Ready_Display datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_ACC_ACC_Ready_Display = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_Speed_Target_Display' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.ACC.ACC_Speed_Target_Display",
           &pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.ACC.ACC_Speed_Target_Display not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_Speed_Target_Display not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.ACC.ACC_Speed_Target_Display datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_Speed_Target_Display datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_ACC_ACC_Speed_Target_Display = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_Target_Id_Display' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.ACC.ACC_Target_Id_Display",
           &pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.ACC.ACC_Target_Id_Display not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_Target_Id_Display not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.ACC.ACC_Target_Id_Display datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_Target_Id_Display datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_ACC_ACC_Target_Id_Display = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.ACC.ACC_Target_Speed' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.ACC.ACC_Target_Speed",&pItem) <
          0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.ACC.ACC_Target_Speed not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_Target_Speed not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.ACC.ACC_Target_Speed datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.ACC.ACC_Target_Speed datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_ACC_ACC_Target_Speed = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AEB.AEB_BrakeDemand' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.AEB.AEB_BrakeDemand",&pItem) < 0)
      {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.AEB.AEB_BrakeDemand not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_BrakeDemand not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.AEB.AEB_BrakeDemand datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_BrakeDemand datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_AEB_AEB_BrakeDemand = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AEB.AEB_On' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.AEB.AEB_On",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.AEB.AEB_On not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_On not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.AEB.AEB_On datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_On datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_AEB_AEB_On = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AEB.AEB_Output_Active' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.AEB.AEB_Output_Active",&pItem) <
          0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.AEB.AEB_Output_Active not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_Output_Active not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.AEB.AEB_Output_Active datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_Output_Active datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_AEB_AEB_Output_Active = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AEB.AEB_Ready' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.AEB.AEB_Ready",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.AEB.AEB_Ready not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_Ready not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.AEB.AEB_Ready datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_Ready datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_AEB_AEB_Ready = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AEB.AEB_Target_Id_Display' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.AEB.AEB_Target_Id_Display",
           &pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.AEB.AEB_Target_Id_Display not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_Target_Id_Display not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.AEB.AEB_Target_Id_Display datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_Target_Id_Display datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_AEB_AEB_Target_Id_Display = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AEB.AEB_TimeToCollision' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.AEB.AEB_TimeToCollision",&pItem)
          < 0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.AEB.AEB_TimeToCollision not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_TimeToCollision not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.AEB.AEB_TimeToCollision datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_TimeToCollision datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_AEB_AEB_TimeToCollision = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AP.AP_On' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.AP.AP_On",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.AP.AP_On not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AP.AP_On not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.AP.AP_On datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AP.AP_On datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_AP_AP_On = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.AP.AP_Ready' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.AP.AP_Ready",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.AP.AP_Ready not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AP.AP_Ready not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.AP.AP_Ready datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AP.AP_Ready datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_AP_AP_Ready = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/ADAS.Outputs.Generic.ADAS_Error' incorporates:
     *  Constant: '<S16>/Constant'
     */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("ADAS.Outputs.Generic.ADAS_Error",&pItem) < 0)
      {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.Generic.ADAS_Error not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.Generic.ADAS_Error not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.Generic.ADAS_Error datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.Generic.ADAS_Error datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_Generic_ADAS_Error = &pCVT[pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S2>/AEB_TimeToCollision_Threshold' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "ADAS.Outputs.AEB.AEB_TimeToCollision_Threshold",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var ADAS.Outputs.AEB.AEB_TimeToCollision_Threshold not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_TimeToCollision_Threshold not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var ADAS.Outputs.AEB.AEB_TimeToCollision_Threshold datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: ADAS.Outputs.AEB.AEB_TimeToCollision_Threshold datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pADAS_Outputs_AEB_AEB_TimeToCollision_Threshold = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S322>/WorldSim.ego.Sensors.Lane_detector.LeftLane.Crossed' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "WorldSim.ego.Sensors.Lane_detector.LeftLane.Crossed",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var WorldSim.ego.Sensors.Lane_detector.LeftLane.Crossed not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: WorldSim.ego.Sensors.Lane_detector.LeftLane.Crossed not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var WorldSim.ego.Sensors.Lane_detector.LeftLane.Crossed datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: WorldSim.ego.Sensors.Lane_detector.LeftLane.Crossed datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pWorldSim_ego_Sensors_Lane_detector_LeftLane_Crossed = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S322>/WorldSim.ego.Sensors.Lane_detector.LeftLane.Distance' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "WorldSim.ego.Sensors.Lane_detector.LeftLane.Distance",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var WorldSim.ego.Sensors.Lane_detector.LeftLane.Distance not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: WorldSim.ego.Sensors.Lane_detector.LeftLane.Distance not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var WorldSim.ego.Sensors.Lane_detector.LeftLane.Distance datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: WorldSim.ego.Sensors.Lane_detector.LeftLane.Distance datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pWorldSim_ego_Sensors_Lane_detector_LeftLane_Distance = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S322>/WorldSim.ego.Sensors.Lane_detector.RightLane.Crossed' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "WorldSim.ego.Sensors.Lane_detector.RightLane.Crossed",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var WorldSim.ego.Sensors.Lane_detector.RightLane.Crossed not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: WorldSim.ego.Sensors.Lane_detector.RightLane.Crossed not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var WorldSim.ego.Sensors.Lane_detector.RightLane.Crossed datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: WorldSim.ego.Sensors.Lane_detector.RightLane.Crossed datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pWorldSim_ego_Sensors_Lane_detector_RightLane_Crossed = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S322>/WorldSim.ego.Sensors.Lane_detector.RightLane.Distance' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "WorldSim.ego.Sensors.Lane_detector.RightLane.Distance",&pItem) < 0)
      {
        fprintf(stderr,
                "MDL: string input var WorldSim.ego.Sensors.Lane_detector.RightLane.Distance not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: WorldSim.ego.Sensors.Lane_detector.RightLane.Distance not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var WorldSim.ego.Sensors.Lane_detector.RightLane.Distance datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: WorldSim.ego.Sensors.Lane_detector.RightLane.Distance datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pWorldSim_ego_Sensors_Lane_detector_RightLane_Distance = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S322>/WorldSim.ego.Sensors.Front_VirtualCam.obstacleData' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress(
           "WorldSim.ego.Sensors.Front_VirtualCam.obstacleData",&pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var WorldSim.ego.Sensors.Front_VirtualCam.obstacleData not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: WorldSim.ego.Sensors.Front_VirtualCam.obstacleData not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var WorldSim.ego.Sensors.Front_VirtualCam.obstacleData datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: WorldSim.ego.Sensors.Front_VirtualCam.obstacleData datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pWorldSim_ego_Sensors_Front_VirtualCam_obstacleData = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S7>/VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ",
           &pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_RESTART_REQ datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_DriveSim_Inputs_Control_VICRT_RESTART_REQ = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (simwbC_RTDBOut): '<S7>/VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ",
           &pItem) < 0) {
        fprintf(stderr,
                "MDL: string input var VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: VI_DriveSim.Inputs.Control.VICRT_RESTORE_REQ datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pVI_DriveSim_Inputs_Control_VICRT_RESTORE_REQ = &pCVT
        [pItem->meta.cvtOffset];
    }

#endif

    /* Start for S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
    /* Level2 S-Function Block: '<S321>/VI_WorldSim_Sensor_VirtualCamera' (VI_WorldSim_Sensor_VirtualCamera_mex) */
    {
      SimStruct *rts = auto_pilot_upl_M->childSfunctions[0];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
    /* Level2 S-Function Block: '<S321>/VI_WorldSim_Sensor_VirtualCamera1' (VI_WorldSim_Sensor_VirtualCamera_mex) */
    {
      SimStruct *rts = auto_pilot_upl_M->childSfunctions[1];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (VI_WorldSim_State_Manager_mex): '<S321>/VI_WorldSim_State_Manager' */
    /* Level2 S-Function Block: '<S321>/VI_WorldSim_State_Manager' (VI_WorldSim_State_Manager_mex) */
    {
      SimStruct *rts = auto_pilot_upl_M->childSfunctions[2];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (simwbC_RTDBOut): '<S322>/WorldSim.ego.Sensors.Collision.Count' */
#ifdef GENSIMWBCODE

    {
      RTDBItem *pItem;
      if (ccurRTDB_getItemAddress("WorldSim.ego.Sensors.Collision.Count",&pItem)
          < 0) {
        fprintf(stderr,
                "MDL: string input var WorldSim.ego.Sensors.Collision.Count not found!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: WorldSim.ego.Sensors.Collision.Count not found !");
        ccurSched_initFailed();
        exit(1);
      }

#if 0

      if (checkMetaDataType(0,pItem->meta.cvtType) < 0) {
        fprintf(stderr,
                "MDL: var WorldSim.ego.Sensors.Collision.Count datatype in model is inconsistent with RTDB.!\n");
        ccurLog_printf(defaultLogger,LOG_CRITICAL,
                       "MDL output variable: WorldSim.ego.Sensors.Collision.Count datatype inconsistent with RTDB !");
        ccurSched_initFailed();
        exit(1);
      }

#endif

      pWorldSim_ego_Sensors_Collision_Count = &pCVT[pItem->meta.cvtOffset];
    }

#endif

  }

  auto_pilot_upl_PrevZCX.UD_Reset_ZCE = UNINITIALIZED_ZCSIG;
  auto_pilot_upl_PrevZCX.Integrator_Reset_ZCE = UNINITIALIZED_ZCSIG;
  auto_pilot_upl_PrevZCX.Integrator1_Reset_ZCE = UNINITIALIZED_ZCSIG;
  auto_pilot_upl_PrevZCX.UD_Reset_ZCE_m = UNINITIALIZED_ZCSIG;
  auto_pilot_upl_PrevZCX.derivation_speed_Trig_ZCE_l = UNINITIALIZED_ZCSIG;
  auto_pilot_upl_PrevZCX.derivation_speed_Trig_ZCE = UNINITIALIZED_ZCSIG;

  {
    int32_T i;

    /* InitializeConditions for UnitDelay: '<S27>/UD' */
    auto_pilot_upl_DW.UD_DSTATE =
      auto_pilot_upl_P.TransferFcnFirstOrder11_ICPrevOutput;

    /* InitializeConditions for UnitDelay: '<S26>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_n =
      auto_pilot_upl_P.TransferFcnFirstOrder10_ICPrevOutput;

    /* InitializeConditions for UnitDelay: '<S33>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_d =
      auto_pilot_upl_P.TransferFcnFirstOrder8_ICPrevOutput;

    /* InitializeConditions for UnitDelay: '<S34>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_o =
      auto_pilot_upl_P.TransferFcnFirstOrder9_ICPrevOutput;

    /* InitializeConditions for UnitDelay: '<S194>/Delay Input1' */
    auto_pilot_upl_DW.DelayInput1_DSTATE =
      auto_pilot_upl_P.DetectIncrease1_vinit;

    /* InitializeConditions for UnitDelay: '<S13>/Delay Input1' */
    auto_pilot_upl_DW.DelayInput1_DSTATE_h =
      auto_pilot_upl_P.DetectIncrease_vinit_ao;

    /* InitializeConditions for UnitDelay: '<S14>/Delay Input1' */
    auto_pilot_upl_DW.DelayInput1_DSTATE_a =
      auto_pilot_upl_P.DetectDecrease_vinit;

    /* InitializeConditions for Memory: '<S11>/Memory' */
    auto_pilot_upl_DW.Memory_PreviousInput =
      auto_pilot_upl_P.Memory_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S193>/Delay Input1' */
    auto_pilot_upl_DW.DelayInput1_DSTATE_ay =
      auto_pilot_upl_P.DetectIncrease_vinit_m;

    /* InitializeConditions for RateTransition: '<S215>/Rate Transition7' */
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.RateTransition7_Buffer0[i] =
        auto_pilot_upl_P.RateTransition7_InitialCondition;
    }

    /* End of InitializeConditions for RateTransition: '<S215>/Rate Transition7' */

    /* InitializeConditions for RateTransition generated from: '<S215>/derivation_speed' */
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.Target_X_Distance_mux_Buffer0[i] =
        auto_pilot_upl_P.Target_X_Distance_mux_InitialCondition;
    }

    /* End of InitializeConditions for RateTransition generated from: '<S215>/derivation_speed' */

    /* InitializeConditions for RateLimiter: '<S215>/Rate Limiter1' */
    auto_pilot_upl_DW.PrevY = auto_pilot_upl_P.RateLimiter1_IC;

    /* InitializeConditions for RateLimiter: '<S215>/Rate Limiter' */
    auto_pilot_upl_DW.LastMajorTimeA = (rtInf);
    auto_pilot_upl_DW.LastMajorTimeB = (rtInf);
    for (i = 0; i < 30; i++) {
      /* InitializeConditions for Delay: '<S215>/Delay1' */
      auto_pilot_upl_DW.Delay1_DSTATE[i] =
        auto_pilot_upl_P.Delay1_InitialCondition;

      /* InitializeConditions for RateTransition generated from: '<S220>/Product5' */
      auto_pilot_upl_DW.TmpRTBAtProduct5Inport1_Buffer0[i] =
        auto_pilot_upl_P.TmpRTBAtProduct5Inport1_InitialCondition;
    }

    /* InitializeConditions for RateTransition: '<S215>/Rate Transition6' */
    auto_pilot_upl_DW.RateTransition6_Buffer0 =
      auto_pilot_upl_P.RateTransition6_InitialCondition;

    /* InitializeConditions for Memory: '<S16>/Memory' */
    auto_pilot_upl_DW.Memory_PreviousInput_b =
      auto_pilot_upl_P.Memory_InitialCondition_p;

    /* InitializeConditions for UnitDelay: '<S23>/Delay Input1' */
    auto_pilot_upl_DW.DelayInput1_DSTATE_n =
      auto_pilot_upl_P.DetectIncrease_vinit;

    /* InitializeConditions for Memory: '<S15>/Memory' */
    auto_pilot_upl_DW.Memory_PreviousInput_l =
      auto_pilot_upl_P.Memory_InitialCondition_l;

    /* InitializeConditions for RateTransition generated from: '<S324>/Multiport Switch' */
    for (i = 0; i < 120; i++) {
      auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i] =
        auto_pilot_upl_P.TmpRTBAtMultiportSwitchInport3_InitialCondition;
    }

    /* End of InitializeConditions for RateTransition generated from: '<S324>/Multiport Switch' */

    /* InitializeConditions for DiscreteIntegrator: '<S117>/Integrator' */
    auto_pilot_upl_DW.Integrator_DSTATE =
      auto_pilot_upl_P.DiscretePIDController1_InitialConditionForIntegrator;
    auto_pilot_upl_DW.Integrator_PrevResetState = 2;

    /* InitializeConditions for RateTransition generated from: '<S177>/Sum' */
    auto_pilot_upl_DW.TmpRTBAtSumInport1_Buffer0 =
      auto_pilot_upl_P.TmpRTBAtSumInport1_InitialCondition;

    /* InitializeConditions for DiscreteIntegrator: '<S168>/Integrator' */
    auto_pilot_upl_DW.Integrator_DSTATE_i =
      auto_pilot_upl_P.tACC_PID_InitialConditionForIntegrator;
    auto_pilot_upl_DW.Integrator_PrevResetState_d = 2;

    /* InitializeConditions for RateTransition generated from: '<S163>/Tsamp'
     *
     * About RateTransition generated from '<S163>/Tsamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    auto_pilot_upl_DW.TmpRTBAtTsampOutport1_Buffer0 =
      auto_pilot_upl_P.TmpRTBAtTsampOutport1_InitialCondition;

    /* InitializeConditions for Delay: '<S161>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_e =
      auto_pilot_upl_P.tACC_PID_DifferentiatorICPrevScaledInput;

    /* InitializeConditions for Memory: '<S15>/Memory1' */
    auto_pilot_upl_DW.Memory1_PreviousInput =
      auto_pilot_upl_P.Memory1_InitialCondition;

    /* InitializeConditions for Memory: '<S15>/Memory2' */
    auto_pilot_upl_DW.Memory2_PreviousInput =
      auto_pilot_upl_P.Memory2_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S24>/Delay Input1' */
    auto_pilot_upl_DW.DelayInput1_DSTATE_l =
      auto_pilot_upl_P.DetectIncrease1_vinit_p;

    /* InitializeConditions for DiscreteIntegrator: '<S67>/Integrator' */
    auto_pilot_upl_DW.Integrator_PrevResetState_c = 2;
    auto_pilot_upl_DW.Integrator_IC_LOADING = 1U;

    /* InitializeConditions for UnitDelay: '<S32>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_p =
      auto_pilot_upl_P.TransferFcnFirstOrder7_ICPrevOutput;

    /* InitializeConditions for UnitDelay: '<S31>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_ou =
      auto_pilot_upl_P.TransferFcnFirstOrder6_ICPrevOutput;

    /* InitializeConditions for UnitDelay: '<S29>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_f =
      auto_pilot_upl_P.TransferFcnFirstOrder4_ICPrevOutput;

    /* InitializeConditions for UnitDelay: '<S30>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_em =
      auto_pilot_upl_P.TransferFcnFirstOrder5_ICPrevOutput;

    /* InitializeConditions for Memory: '<S250>/Memory2' */
    auto_pilot_upl_DW.Memory2_PreviousInput_c =
      auto_pilot_upl_P.Memory2_InitialCondition_c;

    /* InitializeConditions for RateTransition: '<S250>/Rate Transition8' */
    auto_pilot_upl_DW.RateTransition8_Buffer0 =
      auto_pilot_upl_P.RateTransition8_InitialCondition;

    /* InitializeConditions for Integrator: '<S250>/Integrator' */
    auto_pilot_upl_X.Integrator_CSTATE = auto_pilot_upl_P.Integrator_IC;

    /* InitializeConditions for Memory: '<S250>/Memory1' */
    auto_pilot_upl_DW.Memory1_PreviousInput_n =
      auto_pilot_upl_P.Memory1_InitialCondition_l;

    /* InitializeConditions for Memory: '<S250>/Memory' */
    auto_pilot_upl_DW.Memory_PreviousInput_n =
      auto_pilot_upl_P.Memory_InitialCondition_g;

    /* InitializeConditions for RateLimiter: '<S250>/Rate Limiter1' */
    auto_pilot_upl_DW.LastMajorTimeA_g = (rtInf);
    auto_pilot_upl_DW.LastMajorTimeB_b = (rtInf);

    /* InitializeConditions for RateTransition: '<S250>/Rate Transition5' */
    auto_pilot_upl_DW.RateTransition5_Buffer0 =
      auto_pilot_upl_P.RateTransition5_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S84>/Delay Input1' */
    auto_pilot_upl_DW.DelayInput1_DSTATE_g =
      auto_pilot_upl_P.DetectIncrease_vinit_a;

    /* InitializeConditions for UnitDelay: '<S85>/Delay Input1' */
    auto_pilot_upl_DW.DelayInput1_DSTATE_j =
      auto_pilot_upl_P.DetectIncrease1_vinit_j;

    /* InitializeConditions for Memory: '<S19>/Memory' */
    auto_pilot_upl_DW.Memory_PreviousInput_a =
      auto_pilot_upl_P.ACC_Speed_Distance_control;

    /* InitializeConditions for RateTransition generated from: '<S159>/SumI4' */
    auto_pilot_upl_DW.TmpRTBAtSumI4Inport2_Buffer0 =
      auto_pilot_upl_P.TmpRTBAtSumI4Inport2_InitialCondition;

    /* InitializeConditions for RateLimiter: '<S10>/Rate Limiter' */
    auto_pilot_upl_DW.LastMajorTimeA_gx = (rtInf);
    auto_pilot_upl_DW.LastMajorTimeB_e = (rtInf);

    /* InitializeConditions for RateTransition: '<S215>/Rate Transition5' */
    auto_pilot_upl_DW.RateTransition5_Buffer0_h =
      auto_pilot_upl_P.RateTransition5_InitialCondition_e;

    /* InitializeConditions for RateTransition generated from: '<S215>/filtering' */
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.after_saturation_Buffer0[i] =
        auto_pilot_upl_P.after_saturation_InitialCondition;
    }

    /* End of InitializeConditions for RateTransition generated from: '<S215>/filtering' */

    /* InitializeConditions for DiscreteFilter: '<S215>/filtering' */
    for (i = 0; i < 60; i++) {
      auto_pilot_upl_DW.filtering_states[i] =
        auto_pilot_upl_P.filtering_InitialStates;
    }

    /* End of InitializeConditions for DiscreteFilter: '<S215>/filtering' */

    /* InitializeConditions for Integrator: '<S250>/Integrator1' */
    auto_pilot_upl_X.Integrator1_CSTATE = auto_pilot_upl_P.Integrator1_IC;

    /* InitializeConditions for RateTransition generated from: '<S329>/Sum' */
    auto_pilot_upl_DW.TmpRTBAtSumOutport1_Buffer0 =
      auto_pilot_upl_P.TmpRTBAtSumOutport1_InitialCondition;

    /* InitializeConditions for DiscreteFilter: '<S329>/Discrete Filter' */
    auto_pilot_upl_DW.DiscreteFilter_states[0] =
      auto_pilot_upl_P.DiscreteFilter_InitialStates;
    auto_pilot_upl_DW.DiscreteFilter_states[1] =
      auto_pilot_upl_P.DiscreteFilter_InitialStates;

    /* InitializeConditions for RateTransition generated from: '<S329>/Discrete Filter1' */
    auto_pilot_upl_DW.TmpRTBAtDiscreteFilter1Inport1_Buffer0 =
      auto_pilot_upl_P.TmpRTBAtDiscreteFilter1Inport1_InitialCondition;

    /* InitializeConditions for DiscreteFilter: '<S329>/Discrete Filter1' */
    auto_pilot_upl_DW.DiscreteFilter1_states[0] =
      auto_pilot_upl_P.DiscreteFilter1_InitialStates;
    auto_pilot_upl_DW.DiscreteFilter1_states[1] =
      auto_pilot_upl_P.DiscreteFilter1_InitialStates;

    /* InitializeConditions for Memory: '<S321>/Memory' */
    auto_pilot_upl_DW.Memory_PreviousInput_d =
      auto_pilot_upl_P.Memory_InitialCondition_n;

    /* InitializeConditions for UnitDelay: '<S262>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_i =
      auto_pilot_upl_P.DiscreteDerivative_ICPrevScaledInput_d;

    /* InitializeConditions for UnitDelay: '<S263>/UD' */
    auto_pilot_upl_DW.UD_DSTATE_df =
      auto_pilot_upl_P.DiscreteDerivative1_ICPrevScaledInput;

    /* InitializeConditions for Delay: '<S294>/UD' */
    auto_pilot_upl_DW.icLoad = true;

    /* InitializeConditions for DiscreteIntegrator: '<S301>/Integrator' */
    auto_pilot_upl_DW.Integrator_PrevResetState_j = 2;
    auto_pilot_upl_DW.Integrator_IC_LOADING_j = 1U;

    /* InitializeConditions for UnitDelay: '<S266>/Delay Input2' */
    auto_pilot_upl_DW.DelayInput2_DSTATE =
      auto_pilot_upl_P.DelayInput2_InitialCondition;

    /* InitializeConditions for RateLimiter: '<S250>/Rate Limiter' */
    auto_pilot_upl_DW.PrevY_m = auto_pilot_upl_P.RateLimiter_IC;

    /* InitializeConditions for Delay: '<S221>/Delay' */
    for (i = 0; i < 150; i++) {
      auto_pilot_upl_DW.Delay_DSTATE_l[i] =
        auto_pilot_upl_P.Delay_InitialCondition_h;
    }

    /* End of InitializeConditions for Delay: '<S221>/Delay' */

    /* InitializeConditions for Delay: '<S221>/Delay1' */
    for (i = 0; i < 300; i++) {
      auto_pilot_upl_DW.Delay1_DSTATE_i[i] =
        auto_pilot_upl_P.Delay1_InitialCondition_b;
    }

    /* End of InitializeConditions for Delay: '<S221>/Delay1' */

    /* InitializeConditions for Delay: '<S221>/Delay2' */
    for (i = 0; i < 450; i++) {
      auto_pilot_upl_DW.Delay2_DSTATE[i] =
        auto_pilot_upl_P.Delay2_InitialCondition;
    }

    /* End of InitializeConditions for Delay: '<S221>/Delay2' */

    /* SystemInitialize for Triggered SubSystem: '<S215>/derivation_speed' */
    auto_pilot_upl_DW.derivation_speed_PREV_T[0] =
      auto_pilot_upl_M->Timing.clockTick1;
    auto_pilot_upl_DW.derivation_speed_PREV_T[1] =
      auto_pilot_upl_M->Timing.clockTickH1;
    for (i = 0; i < 30; i++) {
      /* InitializeConditions for UnitDelay: '<S244>/UD' */
      auto_pilot_upl_DW.UD_DSTATE_a[i] =
        auto_pilot_upl_P.DiscreteDerivative2_ICPrevScaledInput;

      /* InitializeConditions for UnitDelay: '<S243>/UD' */
      auto_pilot_upl_DW.UD_DSTATE_pg[i] =
        auto_pilot_upl_P.DiscreteDerivative1_ICPrevScaledInput_g;

      /* InitializeConditions for UnitDelay: '<S242>/UD' */
      auto_pilot_upl_DW.UD_DSTATE_h[i] =
        auto_pilot_upl_P.DiscreteDerivative_ICPrevScaledInput_j;

      /* InitializeConditions for UnitDelay: '<S230>/Delay Input1' */
      auto_pilot_upl_DW.DelayInput1_DSTATE_f[i] =
        auto_pilot_upl_P.DetectChange_vinit;

      /* InitializeConditions for Delay: '<S215>/Delay' */
      auto_pilot_upl_DW.Delay_DSTATE[i] =
        auto_pilot_upl_P.Delay_InitialCondition;

      /* InitializeConditions for UnitDelay: '<S246>/UD' */
      auto_pilot_upl_DW.UD_DSTATE_nt[i] =
        auto_pilot_upl_P.DiscreteDerivative_ICPrevScaledInput;
    }

    /* End of SystemInitialize for SubSystem: '<S215>/derivation_speed' */
  }
}

/* Model terminate function */
void auto_pilot_upl_terminate(void)
{
  /* Terminate for S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  /* Level2 S-Function Block: '<S321>/VI_WorldSim_Sensor_VirtualCamera' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = auto_pilot_upl_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (VI_WorldSim_Sensor_VirtualCamera_mex): '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  /* Level2 S-Function Block: '<S321>/VI_WorldSim_Sensor_VirtualCamera1' (VI_WorldSim_Sensor_VirtualCamera_mex) */
  {
    SimStruct *rts = auto_pilot_upl_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (VI_WorldSim_State_Manager_mex): '<S321>/VI_WorldSim_State_Manager' */
  /* Level2 S-Function Block: '<S321>/VI_WorldSim_State_Manager' (VI_WorldSim_State_Manager_mex) */
  {
    SimStruct *rts = auto_pilot_upl_M->childSfunctions[2];
    sfcnTerminate(rts);
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  if (tid == 1)
    tid = 0;
  auto_pilot_upl_output(tid);
}

void MdlUpdate(int_T tid)
{
  if (tid == 1)
    tid = 0;
  auto_pilot_upl_update(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  auto_pilot_upl_initialize();
}

void MdlTerminate(void)
{
  auto_pilot_upl_terminate();
}

/* Registration function */
RT_MODEL_auto_pilot_upl_T *auto_pilot_upl(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  auto_pilot_upl_P.RateLimiter1_RisingLim = rtInf;
  auto_pilot_upl_P.RateLimiter_RisingLim = rtInf;
  auto_pilot_upl_P.RateLimiter_RisingLim_p = rtInf;
  auto_pilot_upl_P.Saturation_LowerSat_i = rtMinusInf;
  auto_pilot_upl_P.Saturation1_LowerSat_d = rtMinusInf;
  auto_pilot_upl_P.Saturation_LowerSat_j = rtMinusInf;
  auto_pilot_upl_P.Saturation_UpperSat_e = rtInf;

  /* initialize real-time model */
  (void) memset((void *)auto_pilot_upl_M, 0,
                sizeof(RT_MODEL_auto_pilot_upl_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&auto_pilot_upl_M->solverInfo,
                          &auto_pilot_upl_M->Timing.simTimeStep);
    rtsiSetTPtr(&auto_pilot_upl_M->solverInfo, &rtmGetTPtr(auto_pilot_upl_M));
    rtsiSetStepSizePtr(&auto_pilot_upl_M->solverInfo,
                       &auto_pilot_upl_M->Timing.stepSize0);
    rtsiSetdXPtr(&auto_pilot_upl_M->solverInfo, &auto_pilot_upl_M->derivs);
    rtsiSetContStatesPtr(&auto_pilot_upl_M->solverInfo, (real_T **)
                         &auto_pilot_upl_M->contStates);
    rtsiSetNumContStatesPtr(&auto_pilot_upl_M->solverInfo,
      &auto_pilot_upl_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&auto_pilot_upl_M->solverInfo,
      &auto_pilot_upl_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&auto_pilot_upl_M->solverInfo,
      &auto_pilot_upl_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&auto_pilot_upl_M->solverInfo,
      &auto_pilot_upl_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&auto_pilot_upl_M->solverInfo, (&rtmGetErrorStatus
      (auto_pilot_upl_M)));
    rtsiSetRTModelPtr(&auto_pilot_upl_M->solverInfo, auto_pilot_upl_M);
  }

  rtsiSetSimTimeStep(&auto_pilot_upl_M->solverInfo, MAJOR_TIME_STEP);
  auto_pilot_upl_M->intgData.x0 = auto_pilot_upl_M->odeX0;
  auto_pilot_upl_M->intgData.f0 = auto_pilot_upl_M->odeF0;
  auto_pilot_upl_M->intgData.x1start = auto_pilot_upl_M->odeX1START;
  auto_pilot_upl_M->intgData.f1 = auto_pilot_upl_M->odeF1;
  auto_pilot_upl_M->intgData.Delta = auto_pilot_upl_M->odeDELTA;
  auto_pilot_upl_M->intgData.E = auto_pilot_upl_M->odeE;
  auto_pilot_upl_M->intgData.fac = auto_pilot_upl_M->odeFAC;

  /* initialize */
  {
    int_T i;
    real_T *f = auto_pilot_upl_M->intgData.fac;
    for (i = 0; i < (int_T)(sizeof(auto_pilot_upl_M->odeFAC)/sizeof(real_T)); i
         ++) {
      f[i] = 1.5e-8;
    }
  }

  auto_pilot_upl_M->intgData.DFDX = auto_pilot_upl_M->odeDFDX;
  auto_pilot_upl_M->intgData.W = auto_pilot_upl_M->odeW;
  auto_pilot_upl_M->intgData.pivots = auto_pilot_upl_M->odePIVOTS;
  auto_pilot_upl_M->intgData.xtmp = auto_pilot_upl_M->odeXTMP;
  auto_pilot_upl_M->intgData.ztmp = auto_pilot_upl_M->odeZTMP;
  auto_pilot_upl_M->intgData.isFirstStep = true;
  rtsiSetSolverExtrapolationOrder(&auto_pilot_upl_M->solverInfo, 4);
  rtsiSetSolverNumberNewtonIterations(&auto_pilot_upl_M->solverInfo, 1);
  auto_pilot_upl_M->contStates = ((real_T *) &auto_pilot_upl_X);
  rtsiSetSolverData(&auto_pilot_upl_M->solverInfo, (void *)
                    &auto_pilot_upl_M->intgData);
  rtsiSetIsMinorTimeStepWithModeChange(&auto_pilot_upl_M->solverInfo, false);
  rtsiSetSolverName(&auto_pilot_upl_M->solverInfo,"ode14x");
  auto_pilot_upl_M->solverInfoPtr = (&auto_pilot_upl_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = auto_pilot_upl_M->Timing.sampleTimeTaskIDArray;
    int_T i;
    for (i = 0; i < 5; i++) {
      mdlTsMap[i] = i;
    }

    /* polyspace +2 MISRA2012:D4.1 [Justified:Low] "auto_pilot_upl_M points to
       static memory which is guaranteed to be non-NULL" */
    auto_pilot_upl_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    auto_pilot_upl_M->Timing.sampleTimes =
      (&auto_pilot_upl_M->Timing.sampleTimesArray[0]);
    auto_pilot_upl_M->Timing.offsetTimes =
      (&auto_pilot_upl_M->Timing.offsetTimesArray[0]);

    /* task periods */
    auto_pilot_upl_M->Timing.sampleTimes[0] = (0.0);
    auto_pilot_upl_M->Timing.sampleTimes[1] = (0.001);
    auto_pilot_upl_M->Timing.sampleTimes[2] = (0.01);
    auto_pilot_upl_M->Timing.sampleTimes[3] = (0.02);
    auto_pilot_upl_M->Timing.sampleTimes[4] = (0.04);

    /* task offsets */
    auto_pilot_upl_M->Timing.offsetTimes[0] = (0.0);
    auto_pilot_upl_M->Timing.offsetTimes[1] = (0.0);
    auto_pilot_upl_M->Timing.offsetTimes[2] = (0.0);
    auto_pilot_upl_M->Timing.offsetTimes[3] = (0.0);
    auto_pilot_upl_M->Timing.offsetTimes[4] = (0.0);
  }

  rtmSetTPtr(auto_pilot_upl_M, &auto_pilot_upl_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = auto_pilot_upl_M->Timing.sampleHitArray;
    int_T *mdlPerTaskSampleHits =
      auto_pilot_upl_M->Timing.perTaskSampleHitsArray;
    auto_pilot_upl_M->Timing.perTaskSampleHits = (&mdlPerTaskSampleHits[0]);
    mdlSampleHits[0] = 1;
    auto_pilot_upl_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(auto_pilot_upl_M, -1);
  auto_pilot_upl_M->Timing.stepSize0 = 0.001;
  auto_pilot_upl_M->Timing.stepSize1 = 0.001;
  auto_pilot_upl_M->Timing.stepSize2 = 0.01;
  auto_pilot_upl_M->Timing.stepSize3 = 0.02;
  auto_pilot_upl_M->Timing.stepSize4 = 0.04;
  auto_pilot_upl_M->solverInfoPtr = (&auto_pilot_upl_M->solverInfo);
  auto_pilot_upl_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&auto_pilot_upl_M->solverInfo, 0.001);
  rtsiSetSolverMode(&auto_pilot_upl_M->solverInfo, SOLVER_MODE_MULTITASKING);

  /* block I/O */
  auto_pilot_upl_M->blockIO = ((void *) &auto_pilot_upl_B);
  (void) memset(((void *) &auto_pilot_upl_B), 0,
                sizeof(B_auto_pilot_upl_T));

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_B.RateTransition7[i] = 0.0;
    }

    for (i = 0; i < 30; i++) {
      auto_pilot_upl_B.Target_X_Distance_mux[i] = 0.0;
    }

    for (i = 0; i < 30; i++) {
      auto_pilot_upl_B.Delay1[i] = 0.0;
    }

    for (i = 0; i < 30; i++) {
      auto_pilot_upl_B.Switch2[i] = 0.0;
    }

    for (i = 0; i < 30; i++) {
      auto_pilot_upl_B.TmpRTBAtProduct5Inport1[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      auto_pilot_upl_B.Switch_h[i] = 0.0;
    }

    for (i = 0; i < 120; i++) {
      auto_pilot_upl_B.TmpRTBAtMultiportSwitchInport3[i] = 0.0;
    }

    for (i = 0; i < 120; i++) {
      auto_pilot_upl_B.MultiportSwitch[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      auto_pilot_upl_B.Gain2_l[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      auto_pilot_upl_B.Gain4_n[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      auto_pilot_upl_B.Gain5[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      auto_pilot_upl_B.Gain[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      auto_pilot_upl_B.Gain1_i[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      auto_pilot_upl_B.Gain3[i] = 0.0;
    }

    for (i = 0; i < 30; i++) {
      auto_pilot_upl_B.after_saturation[i] = 0.0;
    }

    for (i = 0; i < 8; i++) {
      auto_pilot_upl_B.lanecoefficients2x4[i] = 0.0;
    }

    for (i = 0; i < 610; i++) {
      auto_pilot_upl_B.matrix_lanes_points[i] = 0.0;
    }

    for (i = 0; i < 100; i++) {
      auto_pilot_upl_B.matrix_obstacles[i] = 0.0;
    }

    for (i = 0; i < 100; i++) {
      auto_pilot_upl_B.matrix_objects[i] = 0.0;
    }

    for (i = 0; i < 8; i++) {
      auto_pilot_upl_B.lanecoefficients2x4_f[i] = 0.0;
    }

    for (i = 0; i < 610; i++) {
      auto_pilot_upl_B.matrix_lanes_points_b[i] = 0.0;
    }

    for (i = 0; i < 100; i++) {
      auto_pilot_upl_B.matrix_obstacles_a[i] = 0.0;
    }

    for (i = 0; i < 100; i++) {
      auto_pilot_upl_B.matrix_objects_o[i] = 0.0;
    }

    for (i = 0; i < 9; i++) {
      auto_pilot_upl_B.VI_WorldSim_State_Manager_o4[i] = 0.0;
    }

    for (i = 0; i < 90; i++) {
      auto_pilot_upl_B.RateTransition[i] = 0.0;
    }

    for (i = 0; i < 30; i++) {
      auto_pilot_upl_B.TSamp_d[i] = 0.0;
    }

    for (i = 0; i < 30; i++) {
      auto_pilot_upl_B.TSamp_k[i] = 0.0;
    }

    for (i = 0; i < 30; i++) {
      auto_pilot_upl_B.TSamp_f[i] = 0.0;
    }

    for (i = 0; i < 30; i++) {
      auto_pilot_upl_B.Gain1_o[i] = 0.0;
    }

    for (i = 0; i < 30; i++) {
      auto_pilot_upl_B.Gain_a[i] = 0.0;
    }

    for (i = 0; i < 100; i++) {
      auto_pilot_upl_B.sf_manipulation_of_objects1.filtered_matrix[i] = 0.0;
    }

    for (i = 0; i < 100; i++) {
      auto_pilot_upl_B.sf_manipulation_of_objects.filtered_matrix[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      auto_pilot_upl_B.sf_MATLABFunction1.y[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      auto_pilot_upl_B.sf_MATLABFunction_f.y[i] = 0.0;
    }

    auto_pilot_upl_B.VI_DriveSimInputsECATBECKHANA3 = 0.0;
    auto_pilot_upl_B.VI_CarRealTimeOutputstransmissiongear = 0.0;
    auto_pilot_upl_B.VI_DriveSimInputsECATBECKHANA1 = 0.0;
    auto_pilot_upl_B.VI_DriveSimInputsECATBECKHDIG4 = 0.0;
    auto_pilot_upl_B.VI_CarRealTimeOutputschassis_velocitieslongitudinal = 0.0;
    auto_pilot_upl_B.VI_DriveSimOutputsVicrtStatus = 0.0;
    auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandsbrake = 0.0;
    auto_pilot_upl_B.VI_CarRealTimeOutputsWheelSpindle_SteerL1 = 0.0;
    auto_pilot_upl_B.VI_CarRealTimeOutputsWheelSpindle_SteerR1 = 0.0;
    auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandsthrottle = 0.0;
    auto_pilot_upl_B.VI_CarRealTimeOutputsdriver_demandssteering = 0.0;
    auto_pilot_upl_B.VI_CarRealTimeOutputsSteering_SystemDriveSim_Steering_Feedback_Torque
      = 0.0;
    auto_pilot_upl_B.VI_CarRealTimeOutputschassis_accelerationslateral = 0.0;
    auto_pilot_upl_B.VI_CarRealTimeOutputschassis_accelerationslongitudinal =
      0.0;
    auto_pilot_upl_B.VI_DriveSimInputsECATBECKHDIG3 = 0.0;
    auto_pilot_upl_B.CastToDouble = 0.0;
    auto_pilot_upl_B.Product = 0.0;
    auto_pilot_upl_B.Uk1 = 0.0;
    auto_pilot_upl_B.Memory = 0.0;
    auto_pilot_upl_B.Switch = 0.0;
    auto_pilot_upl_B.Product_o = 0.0;
    auto_pilot_upl_B.Product2 = 0.0;
    auto_pilot_upl_B.Product1 = 0.0;
    auto_pilot_upl_B.DataTypeConversion = 0.0;
    auto_pilot_upl_B.RateLimiter = 0.0;
    auto_pilot_upl_B.RateTransition6 = 0.0;
    auto_pilot_upl_B.Product2_h = 0.0;
    auto_pilot_upl_B.Memory_i = 0.0;
    auto_pilot_upl_B.Switch_o = 0.0;
    auto_pilot_upl_B.Uk1_p = 0.0;
    auto_pilot_upl_B.Memory_d = 0.0;
    auto_pilot_upl_B.Product8 = 0.0;
    auto_pilot_upl_B.Error2 = 0.0;
    auto_pilot_upl_B.Switch1 = 0.0;
    auto_pilot_upl_B.Fcn1 = 0.0;
    auto_pilot_upl_B.Gain1 = 0.0;
    auto_pilot_upl_B.MinMax = 0.0;
    auto_pilot_upl_B.Product4 = 0.0;
    auto_pilot_upl_B.Saturation = 0.0;
    auto_pilot_upl_B.TmpRTBAtSumInport1 = 0.0;
    auto_pilot_upl_B.TmpRTBAtTsampOutport1 = 0.0;
    auto_pilot_upl_B.Saturation_o = 0.0;
    auto_pilot_upl_B.Memory1 = 0.0;
    auto_pilot_upl_B.Memory2 = 0.0;
    auto_pilot_upl_B.setspeedmemory = 0.0;
    auto_pilot_upl_B.Switch1_e = 0.0;
    auto_pilot_upl_B.differencebetweerreferenceandactualspeed = 0.0;
    auto_pilot_upl_B.Product2_g = 0.0;
    auto_pilot_upl_B.Saturation_d = 0.0;
    auto_pilot_upl_B.Sum = 0.0;
    auto_pilot_upl_B.Sum_e = 0.0;
    auto_pilot_upl_B.Sum_p = 0.0;
    auto_pilot_upl_B.Sum_a = 0.0;
    auto_pilot_upl_B.Sum_l = 0.0;
    auto_pilot_upl_B.Saturation8 = 0.0;
    auto_pilot_upl_B.Sum1 = 0.0;
    auto_pilot_upl_B.Sum_g = 0.0;
    auto_pilot_upl_B.Sum_py = 0.0;
    auto_pilot_upl_B.Sum_ep = 0.0;
    auto_pilot_upl_B.Sum_h = 0.0;
    auto_pilot_upl_B.Saturation9 = 0.0;
    auto_pilot_upl_B.Product2_n = 0.0;
    auto_pilot_upl_B.Max = 0.0;
    auto_pilot_upl_B.Max1 = 0.0;
    auto_pilot_upl_B.DataTypeConversion6 = 0.0;
    auto_pilot_upl_B.Gain4 = 0.0;
    auto_pilot_upl_B.RateTransition8 = 0.0;
    auto_pilot_upl_B.Product5 = 0.0;
    auto_pilot_upl_B.DataTypeConversion3 = 0.0;
    auto_pilot_upl_B.DataTypeConversion2_g = 0.0;
    auto_pilot_upl_B.Product6 = 0.0;
    auto_pilot_upl_B.Integrator = 0.0;
    auto_pilot_upl_B.Memory_f = 0.0;
    auto_pilot_upl_B.Switch_j = 0.0;
    auto_pilot_upl_B.RateLimiter1 = 0.0;
    auto_pilot_upl_B.RateTransition5 = 0.0;
    auto_pilot_upl_B.Gain2 = 0.0;
    auto_pilot_upl_B.DataTypeConversion4 = 0.0;
    auto_pilot_upl_B.SumI4 = 0.0;
    auto_pilot_upl_B.Sum_k = 0.0;
    auto_pilot_upl_B.MultiportSwitch_h = 0.0;
    auto_pilot_upl_B.SumI4_k = 0.0;
    auto_pilot_upl_B.TmpRTBAtSumI4Inport2 = 0.0;
    auto_pilot_upl_B.SumI4_a = 0.0;
    auto_pilot_upl_B.Product1_n = 0.0;
    auto_pilot_upl_B.RateLimiter_p = 0.0;
    auto_pilot_upl_B.Sum_g0 = 0.0;
    auto_pilot_upl_B.PulseGenerator = 0.0;
    auto_pilot_upl_B.Product1_m = 0.0;
    auto_pilot_upl_B.Product_p = 0.0;
    auto_pilot_upl_B.RateTransition5_n = 0.0;
    auto_pilot_upl_B.TmpRTBAtSumOutport1 = 0.0;
    auto_pilot_upl_B.DiscreteFilter = 0.0;
    auto_pilot_upl_B.TmpRTBAtDiscreteFilter1Inport1 = 0.0;
    auto_pilot_upl_B.DiscreteFilter1 = 0.0;
    auto_pilot_upl_B.CastToDouble_k = 0.0;
    auto_pilot_upl_B.CastToDouble1 = 0.0;
    auto_pilot_upl_B.Product_l = 0.0;
    auto_pilot_upl_B.Product1_g = 0.0;
    auto_pilot_upl_B.messagecount[0] = 0.0;
    auto_pilot_upl_B.messagecount[1] = 0.0;
    auto_pilot_upl_B.valid_matrix_lanes_points = 0.0;
    auto_pilot_upl_B.valid_matrix_obstacles = 0.0;
    auto_pilot_upl_B.valid_matrix_objects = 0.0;
    auto_pilot_upl_B.messagecount_m[0] = 0.0;
    auto_pilot_upl_B.messagecount_m[1] = 0.0;
    auto_pilot_upl_B.valid_matrix_lanes_points_b = 0.0;
    auto_pilot_upl_B.valid_matrix_obstacles_k = 0.0;
    auto_pilot_upl_B.valid_matrix_objects_m = 0.0;
    auto_pilot_upl_B.collisionmsginfo[0] = 0.0;
    auto_pilot_upl_B.collisionmsginfo[1] = 0.0;
    auto_pilot_upl_B.VI_WorldSim_State_Manager_o2[0] = 0.0;
    auto_pilot_upl_B.VI_WorldSim_State_Manager_o2[1] = 0.0;
    auto_pilot_upl_B.VI_WorldSim_State_Manager_o2[2] = 0.0;
    auto_pilot_upl_B.VI_WorldSim_State_Manager_o3 = 0.0;
    auto_pilot_upl_B.additivecollision = 0.0;
    auto_pilot_upl_B.TSamp = 0.0;
    auto_pilot_upl_B.TSamp_p = 0.0;
    auto_pilot_upl_B.RateTransition1 = 0.0;
    auto_pilot_upl_B.Tsamp = 0.0;
    auto_pilot_upl_B.IProdOut = 0.0;
    auto_pilot_upl_B.DifferenceInputs2 = 0.0;
    auto_pilot_upl_B.CastToDouble1_p = 0.0;
  }

  /* parameters */
  auto_pilot_upl_M->defaultParam = ((real_T *)&auto_pilot_upl_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &auto_pilot_upl_X;
    auto_pilot_upl_M->contStates = (x);
    (void) memset((void *)&auto_pilot_upl_X, 0,
                  sizeof(X_auto_pilot_upl_T));
  }

  /* states (dwork) */
  auto_pilot_upl_M->dwork = ((void *) &auto_pilot_upl_DW);
  (void) memset((void *)&auto_pilot_upl_DW, 0,
                sizeof(DW_auto_pilot_upl_T));
  auto_pilot_upl_DW.UD_DSTATE = 0.0;
  auto_pilot_upl_DW.UD_DSTATE_n = 0.0;
  auto_pilot_upl_DW.UD_DSTATE_d = 0.0;
  auto_pilot_upl_DW.UD_DSTATE_o = 0.0;
  auto_pilot_upl_DW.DelayInput1_DSTATE = 0.0;
  auto_pilot_upl_DW.DelayInput1_DSTATE_a = 0.0;

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.Delay1_DSTATE[i] = 0.0;
    }
  }

  auto_pilot_upl_DW.DelayInput1_DSTATE_n = 0.0;
  auto_pilot_upl_DW.Integrator_DSTATE = 0.0;
  auto_pilot_upl_DW.Integrator_DSTATE_i = 0.0;
  auto_pilot_upl_DW.UD_DSTATE_e = 0.0;
  auto_pilot_upl_DW.DelayInput1_DSTATE_l = 0.0;
  auto_pilot_upl_DW.Integrator_DSTATE_i3 = 0.0;
  auto_pilot_upl_DW.UD_DSTATE_p = 0.0;
  auto_pilot_upl_DW.UD_DSTATE_ou = 0.0;
  auto_pilot_upl_DW.UD_DSTATE_f = 0.0;
  auto_pilot_upl_DW.UD_DSTATE_em = 0.0;
  auto_pilot_upl_DW.DelayInput1_DSTATE_g = 0.0;
  auto_pilot_upl_DW.DelayInput1_DSTATE_j = 0.0;

  {
    int32_T i;
    for (i = 0; i < 60; i++) {
      auto_pilot_upl_DW.filtering_states[i] = 0.0;
    }
  }

  auto_pilot_upl_DW.DiscreteFilter_states[0] = 0.0;
  auto_pilot_upl_DW.DiscreteFilter_states[1] = 0.0;
  auto_pilot_upl_DW.DiscreteFilter1_states[0] = 0.0;
  auto_pilot_upl_DW.DiscreteFilter1_states[1] = 0.0;
  auto_pilot_upl_DW.UD_DSTATE_i = 0.0;
  auto_pilot_upl_DW.UD_DSTATE_df = 0.0;
  auto_pilot_upl_DW.UD_DSTATE_j = 0.0;
  auto_pilot_upl_DW.Integrator_DSTATE_c = 0.0;
  auto_pilot_upl_DW.DelayInput2_DSTATE = 0.0;

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.UD_DSTATE_a[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.UD_DSTATE_pg[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.UD_DSTATE_h[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.DelayInput1_DSTATE_f[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.Delay_DSTATE[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.UD_DSTATE_nt[i] = 0.0;
    }
  }

  auto_pilot_upl_DW.Memory_PreviousInput = 0.0;

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.RateTransition7_Buffer0[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.Target_X_Distance_mux_Buffer0[i] = 0.0;
    }
  }

  auto_pilot_upl_DW.PrevY = 0.0;
  auto_pilot_upl_DW.PrevYA = 0.0;
  auto_pilot_upl_DW.PrevYB = 0.0;
  auto_pilot_upl_DW.LastMajorTimeA = 0.0;
  auto_pilot_upl_DW.LastMajorTimeB = 0.0;

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.TmpRTBAtProduct5Inport1_Buffer0[i] = 0.0;
    }
  }

  auto_pilot_upl_DW.RateTransition6_Buffer0 = 0.0;
  auto_pilot_upl_DW.Memory_PreviousInput_b = 0.0;
  auto_pilot_upl_DW.Memory_PreviousInput_l = 0.0;

  {
    int32_T i;
    for (i = 0; i < 120; i++) {
      auto_pilot_upl_DW.TmpRTBAtMultiportSwitchInport3_Buffer0[i] = 0.0;
    }
  }

  auto_pilot_upl_DW.TmpRTBAtSumInport1_Buffer0 = 0.0;
  auto_pilot_upl_DW.TmpRTBAtTsampOutport1_Buffer0 = 0.0;
  auto_pilot_upl_DW.Memory1_PreviousInput = 0.0;
  auto_pilot_upl_DW.Memory2_PreviousInput = 0.0;
  auto_pilot_upl_DW.Memory2_PreviousInput_c = 0.0;
  auto_pilot_upl_DW.RateTransition8_Buffer0 = 0.0;
  auto_pilot_upl_DW.Memory_PreviousInput_n = 0.0;
  auto_pilot_upl_DW.PrevYA_p = 0.0;
  auto_pilot_upl_DW.PrevYB_e = 0.0;
  auto_pilot_upl_DW.LastMajorTimeA_g = 0.0;
  auto_pilot_upl_DW.LastMajorTimeB_b = 0.0;
  auto_pilot_upl_DW.RateTransition5_Buffer0 = 0.0;
  auto_pilot_upl_DW.Memory_PreviousInput_a = 0.0;
  auto_pilot_upl_DW.RateTransition_Buffer = 0.0;
  auto_pilot_upl_DW.RateTransition1_Buffer = 0.0;
  auto_pilot_upl_DW.TmpRTBAtSumI4Inport2_Buffer0 = 0.0;
  auto_pilot_upl_DW.PrevYA_c = 0.0;
  auto_pilot_upl_DW.PrevYB_f = 0.0;
  auto_pilot_upl_DW.LastMajorTimeA_gx = 0.0;
  auto_pilot_upl_DW.LastMajorTimeB_e = 0.0;
  auto_pilot_upl_DW.RateTransition5_Buffer0_h = 0.0;

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.RateTransition2_Buffer[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.after_saturation_Buffer0[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.filtering_tmp[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.RateTransition1_Buffer_g[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 90; i++) {
      auto_pilot_upl_DW.RateTransition_Buffer_h[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 30; i++) {
      auto_pilot_upl_DW.RateTransition1_Buffer_b[i] = 0.0;
    }
  }

  auto_pilot_upl_DW.RateTransition_Buffer_a = 0.0;
  auto_pilot_upl_DW.TmpRTBAtSumOutport1_Buffer0 = 0.0;
  auto_pilot_upl_DW.DiscreteFilter_tmp = 0.0;
  auto_pilot_upl_DW.TmpRTBAtDiscreteFilter1Inport1_Buffer0 = 0.0;
  auto_pilot_upl_DW.DiscreteFilter1_tmp = 0.0;
  auto_pilot_upl_DW.RateTransition_Buffer_f[0] = 0.0;
  auto_pilot_upl_DW.RateTransition_Buffer_f[1] = 0.0;
  auto_pilot_upl_DW.RateTransition1_Buffer_e = 0.0;
  auto_pilot_upl_DW.RateTransition2_Buffer_n = 0.0;
  auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK2 = 0.0;
  auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK3 = 0.0;
  auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK4 = 0.0;
  auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK2 = 0.0;
  auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK3 = 0.0;
  auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK4 = 0.0;
  auto_pilot_upl_DW.Memory_PreviousInput_d = 0.0;
  auto_pilot_upl_DW.VI_WorldSim_State_Manager_DWORK2 = 0.0;
  auto_pilot_upl_DW.VI_WorldSim_State_Manager_DWORK3 = 0.0;
  auto_pilot_upl_DW.VI_WorldSim_State_Manager_DWORK4 = 0.0;
  auto_pilot_upl_DW.PrevY_m = 0.0;

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  auto_pilot_upl_InitializeDataMapInfo();

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &auto_pilot_upl_M->NonInlinedSFcns.sfcnInfo;
    auto_pilot_upl_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(auto_pilot_upl_M)));
    auto_pilot_upl_M->Sizes.numSampTimes = (5);
    rtssSetNumRootSampTimesPtr(sfcnInfo, &auto_pilot_upl_M->Sizes.numSampTimes);
    auto_pilot_upl_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (auto_pilot_upl_M)[0]);
    auto_pilot_upl_M->NonInlinedSFcns.taskTimePtrs[1] = &(rtmGetTPtr
      (auto_pilot_upl_M)[1]);
    auto_pilot_upl_M->NonInlinedSFcns.taskTimePtrs[2] = &(rtmGetTPtr
      (auto_pilot_upl_M)[2]);
    auto_pilot_upl_M->NonInlinedSFcns.taskTimePtrs[3] = &(rtmGetTPtr
      (auto_pilot_upl_M)[3]);
    auto_pilot_upl_M->NonInlinedSFcns.taskTimePtrs[4] = &(rtmGetTPtr
      (auto_pilot_upl_M)[4]);
    rtssSetTPtrPtr(sfcnInfo,auto_pilot_upl_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(auto_pilot_upl_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(auto_pilot_upl_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (auto_pilot_upl_M));
    rtssSetStepSizePtr(sfcnInfo, &auto_pilot_upl_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(auto_pilot_upl_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &auto_pilot_upl_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo, &auto_pilot_upl_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &auto_pilot_upl_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo, &auto_pilot_upl_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &auto_pilot_upl_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &auto_pilot_upl_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &auto_pilot_upl_M->solverInfoPtr);
  }

  auto_pilot_upl_M->Sizes.numSFcns = (3);

  /* register each child */
  {
    (void) memset((void *)&auto_pilot_upl_M->NonInlinedSFcns.childSFunctions[0],
                  0,
                  3*sizeof(SimStruct));
    auto_pilot_upl_M->childSfunctions =
      (&auto_pilot_upl_M->NonInlinedSFcns.childSFunctionPtrs[0]);
    auto_pilot_upl_M->childSfunctions[0] =
      (&auto_pilot_upl_M->NonInlinedSFcns.childSFunctions[0]);
    auto_pilot_upl_M->childSfunctions[1] =
      (&auto_pilot_upl_M->NonInlinedSFcns.childSFunctions[1]);
    auto_pilot_upl_M->childSfunctions[2] =
      (&auto_pilot_upl_M->NonInlinedSFcns.childSFunctions[2]);

    /* Level2 S-Function Block: auto_pilot_upl/<S321>/VI_WorldSim_Sensor_VirtualCamera (VI_WorldSim_Sensor_VirtualCamera_mex) */
    {
      SimStruct *rts = auto_pilot_upl_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &auto_pilot_upl_M->NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &auto_pilot_upl_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, auto_pilot_upl_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &auto_pilot_upl_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &auto_pilot_upl_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &auto_pilot_upl_M->NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &auto_pilot_upl_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        ssSetPortInfoForOutputs(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 8);
        _ssSetPortInfo2ForOutputUnits(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        ssSetOutputPortUnit(rts, 5, 0);
        ssSetOutputPortUnit(rts, 6, 0);
        ssSetOutputPortUnit(rts, 7, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 5, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 6, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 7, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            auto_pilot_upl_B.messagecount));
        }

        /* port 1 */
        {
          int_T *dimensions = (int_T *)
            &auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.oDims1;
          dimensions[0] = 2;
          dimensions[1] = 4;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 1, dimensions);
          _ssSetOutputPortNumDimensions(rts, 1, 2);
          ssSetOutputPortWidthAsInt(rts, 1, 8);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            auto_pilot_upl_B.lanecoefficients2x4));
        }

        /* port 2 */
        {
          int_T *dimensions = (int_T *)
            &auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.oDims2;
          dimensions[0] = 10;
          dimensions[1] = 61;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 2, dimensions);
          _ssSetOutputPortNumDimensions(rts, 2, 2);
          ssSetOutputPortWidthAsInt(rts, 2, 610);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            auto_pilot_upl_B.matrix_lanes_points));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidthAsInt(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((real_T *)
            &auto_pilot_upl_B.valid_matrix_lanes_points));
        }

        /* port 4 */
        {
          int_T *dimensions = (int_T *)
            &auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.oDims4;
          dimensions[0] = 10;
          dimensions[1] = 10;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 4, dimensions);
          _ssSetOutputPortNumDimensions(rts, 4, 2);
          ssSetOutputPortWidthAsInt(rts, 4, 100);
          ssSetOutputPortSignal(rts, 4, ((real_T *)
            auto_pilot_upl_B.matrix_obstacles));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidthAsInt(rts, 5, 1);
          ssSetOutputPortSignal(rts, 5, ((real_T *)
            &auto_pilot_upl_B.valid_matrix_obstacles));
        }

        /* port 6 */
        {
          int_T *dimensions = (int_T *)
            &auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.oDims6;
          dimensions[0] = 10;
          dimensions[1] = 10;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 6, dimensions);
          _ssSetOutputPortNumDimensions(rts, 6, 2);
          ssSetOutputPortWidthAsInt(rts, 6, 100);
          ssSetOutputPortSignal(rts, 6, ((real_T *)
            auto_pilot_upl_B.matrix_objects));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidthAsInt(rts, 7, 1);
          ssSetOutputPortSignal(rts, 7, ((real_T *)
            &auto_pilot_upl_B.valid_matrix_objects));
        }
      }

      /* path info */
      ssSetModelName(rts, "VI_WorldSim_Sensor_VirtualCamera");
      ssSetPath(rts,
                "auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera");
      ssSetRTModel(rts,auto_pilot_upl_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera_P7_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 5);

        /* DWORK1 */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK1);

        /* DWORK2 */
        ssSetDWorkWidthAsInt(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1,
                   &auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK2);

        /* DWORK3 */
        ssSetDWorkWidthAsInt(rts, 2, 1);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2,
                   &auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK3);

        /* DWORK4 */
        ssSetDWorkWidthAsInt(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3,
                   &auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera_DWORK4);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4,
                   &auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera_PWORK);
      }

      /* registration */
      VI_WorldSim_Sensor_VirtualCamera_mex(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 0);
      _ssSetOutputPortConnected(rts, 3, 0);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 0);
      _ssSetOutputPortConnected(rts, 7, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: auto_pilot_upl/<S321>/VI_WorldSim_Sensor_VirtualCamera1 (VI_WorldSim_Sensor_VirtualCamera_mex) */
    {
      SimStruct *rts = auto_pilot_upl_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod = auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset = auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &auto_pilot_upl_M->NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &auto_pilot_upl_M->NonInlinedSFcns.inputOutputPortInfo2[1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, auto_pilot_upl_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &auto_pilot_upl_M->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &auto_pilot_upl_M->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &auto_pilot_upl_M->NonInlinedSFcns.methods4[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &auto_pilot_upl_M->NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        ssSetPortInfoForOutputs(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 8);
        _ssSetPortInfo2ForOutputUnits(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        ssSetOutputPortUnit(rts, 5, 0);
        ssSetOutputPortUnit(rts, 6, 0);
        ssSetOutputPortUnit(rts, 7, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 5, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 6, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 7, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            auto_pilot_upl_B.messagecount_m));
        }

        /* port 1 */
        {
          int_T *dimensions = (int_T *)
            &auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.oDims1;
          dimensions[0] = 2;
          dimensions[1] = 4;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 1, dimensions);
          _ssSetOutputPortNumDimensions(rts, 1, 2);
          ssSetOutputPortWidthAsInt(rts, 1, 8);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            auto_pilot_upl_B.lanecoefficients2x4_f));
        }

        /* port 2 */
        {
          int_T *dimensions = (int_T *)
            &auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.oDims2;
          dimensions[0] = 10;
          dimensions[1] = 61;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 2, dimensions);
          _ssSetOutputPortNumDimensions(rts, 2, 2);
          ssSetOutputPortWidthAsInt(rts, 2, 610);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            auto_pilot_upl_B.matrix_lanes_points_b));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidthAsInt(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((real_T *)
            &auto_pilot_upl_B.valid_matrix_lanes_points_b));
        }

        /* port 4 */
        {
          int_T *dimensions = (int_T *)
            &auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.oDims4;
          dimensions[0] = 10;
          dimensions[1] = 10;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 4, dimensions);
          _ssSetOutputPortNumDimensions(rts, 4, 2);
          ssSetOutputPortWidthAsInt(rts, 4, 100);
          ssSetOutputPortSignal(rts, 4, ((real_T *)
            auto_pilot_upl_B.matrix_obstacles_a));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidthAsInt(rts, 5, 1);
          ssSetOutputPortSignal(rts, 5, ((real_T *)
            &auto_pilot_upl_B.valid_matrix_obstacles_k));
        }

        /* port 6 */
        {
          int_T *dimensions = (int_T *)
            &auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.oDims6;
          dimensions[0] = 10;
          dimensions[1] = 10;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 6, dimensions);
          _ssSetOutputPortNumDimensions(rts, 6, 2);
          ssSetOutputPortWidthAsInt(rts, 6, 100);
          ssSetOutputPortSignal(rts, 6, ((real_T *)
            auto_pilot_upl_B.matrix_objects_o));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidthAsInt(rts, 7, 1);
          ssSetOutputPortSignal(rts, 7, ((real_T *)
            &auto_pilot_upl_B.valid_matrix_objects_m));
        }
      }

      /* path info */
      ssSetModelName(rts, "VI_WorldSim_Sensor_VirtualCamera1");
      ssSetPath(rts,
                "auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_Sensor_VirtualCamera1");
      ssSetRTModel(rts,auto_pilot_upl_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_Sensor_VirtualCamera1_P7_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 5);

        /* DWORK1 */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK1);

        /* DWORK2 */
        ssSetDWorkWidthAsInt(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1,
                   &auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK2);

        /* DWORK3 */
        ssSetDWorkWidthAsInt(rts, 2, 1);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2,
                   &auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK3);

        /* DWORK4 */
        ssSetDWorkWidthAsInt(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3,
                   &auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera1_DWORK4);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4,
                   &auto_pilot_upl_DW.VI_WorldSim_Sensor_VirtualCamera1_PWORK);
      }

      /* registration */
      VI_WorldSim_Sensor_VirtualCamera_mex(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 0);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 0);
      _ssSetOutputPortConnected(rts, 3, 0);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 0);
      _ssSetOutputPortConnected(rts, 7, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: auto_pilot_upl/<S321>/VI_WorldSim_State_Manager (VI_WorldSim_State_Manager_mex) */
    {
      SimStruct *rts = auto_pilot_upl_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod = auto_pilot_upl_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset = auto_pilot_upl_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = auto_pilot_upl_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &auto_pilot_upl_M->NonInlinedSFcns.blkInfo2[2]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &auto_pilot_upl_M->NonInlinedSFcns.inputOutputPortInfo2[2]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, auto_pilot_upl_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &auto_pilot_upl_M->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &auto_pilot_upl_M->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &auto_pilot_upl_M->NonInlinedSFcns.methods4[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &auto_pilot_upl_M->NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        ssSetPortInfoForOutputs(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 4);
        _ssSetPortInfo2ForOutputUnits(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn2.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn2.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            auto_pilot_upl_B.collisionmsginfo));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 3);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            auto_pilot_upl_B.VI_WorldSim_State_Manager_o2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidthAsInt(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            &auto_pilot_upl_B.VI_WorldSim_State_Manager_o3));
        }

        /* port 3 */
        {
          int_T *dimensions = (int_T *)
            &auto_pilot_upl_M->NonInlinedSFcns.Sfcn2.oDims3;
          dimensions[0] = 3;
          dimensions[1] = 3;
          _ssSetOutputPortDimensionsPtrAsInt(rts, 3, dimensions);
          _ssSetOutputPortNumDimensions(rts, 3, 2);
          ssSetOutputPortWidthAsInt(rts, 3, 9);
          ssSetOutputPortSignal(rts, 3, ((real_T *)
            auto_pilot_upl_B.VI_WorldSim_State_Manager_o4));
        }
      }

      /* path info */
      ssSetModelName(rts, "VI_WorldSim_State_Manager");
      ssSetPath(rts,
                "auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/VI_WorldSim_State_Manager");
      ssSetRTModel(rts,auto_pilot_upl_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 4);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_State_Manager_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_State_Manager_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_State_Manager_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       auto_pilot_upl_P.VI_WorldSim_State_Manager_P4_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &auto_pilot_upl_DW.VI_WorldSim_State_Manager_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn2.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &auto_pilot_upl_M->NonInlinedSFcns.Sfcn2.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 5);

        /* DWORK1 */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &auto_pilot_upl_DW.VI_WorldSim_State_Manager_DWORK1);

        /* DWORK2 */
        ssSetDWorkWidthAsInt(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &auto_pilot_upl_DW.VI_WorldSim_State_Manager_DWORK2);

        /* DWORK3 */
        ssSetDWorkWidthAsInt(rts, 2, 1);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &auto_pilot_upl_DW.VI_WorldSim_State_Manager_DWORK3);

        /* DWORK4 */
        ssSetDWorkWidthAsInt(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &auto_pilot_upl_DW.VI_WorldSim_State_Manager_DWORK4);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &auto_pilot_upl_DW.VI_WorldSim_State_Manager_PWORK);
      }

      /* registration */
      VI_WorldSim_State_Manager_mex(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 0);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);

      /* Update the BufferDstPort flags for each input port */
    }
  }

  /* Initialize Sizes */
  auto_pilot_upl_M->Sizes.numContStates = (2);/* Number of continuous states */
  auto_pilot_upl_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  auto_pilot_upl_M->Sizes.numY = (0);  /* Number of model outputs */
  auto_pilot_upl_M->Sizes.numU = (0);  /* Number of model inputs */
  auto_pilot_upl_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  auto_pilot_upl_M->Sizes.numSampTimes = (5);/* Number of sample times */
  auto_pilot_upl_M->Sizes.numBlocks = (643);/* Number of blocks */
  auto_pilot_upl_M->Sizes.numBlockIO = (176);/* Number of block outputs */
  auto_pilot_upl_M->Sizes.numBlockPrms = (882);/* Sum of parameter "widths" */
  return auto_pilot_upl_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
