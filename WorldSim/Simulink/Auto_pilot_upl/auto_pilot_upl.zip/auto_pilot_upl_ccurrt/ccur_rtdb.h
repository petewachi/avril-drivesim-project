#ifndef NO_CVTSTRUCT
#include "rtdb_cvt/UPL_Pete_AP/AP_RTDB.h"

#else
extern unsigned char *pCVT;

#endif
#define GENSIMWBCODE_MATLAB_MAJOR 2022
#define GENSIMWBCODE_MATLAB_MINOR 2
