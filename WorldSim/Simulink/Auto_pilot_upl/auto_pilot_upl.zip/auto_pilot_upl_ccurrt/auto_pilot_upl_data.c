/*
 * auto_pilot_upl_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "auto_pilot_upl".
 *
 * Model version              : 17.110
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Thu Feb  1 00:30:37 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "auto_pilot_upl.h"

/* Block parameters (default storage) */
P_auto_pilot_upl_T auto_pilot_upl_P = {
  /* Variable: ACC_Adaptive_P
   * Referenced by:
   *   '<S35>/ACC_Adaptive_P'
   *   '<S35>/ACC_Adaptive_P2'
   */
  { 5.0, 7.5 },

  /* Variable: ACC_Classic_I
   * Referenced by:
   *   '<S64>/Integral Gain'
   *   '<S114>/Integral Gain'
   */
  5.0,

  /* Variable: ACC_Classic_P
   * Referenced by:
   *   '<S72>/Proportional Gain'
   *   '<S122>/Proportional Gain'
   */
  15.0,

  /* Variable: ACC_MaxBrake
   * Referenced by:
   *   '<S74>/Saturation'
   *   '<S124>/Saturation'
   *   '<S175>/Saturation'
   */
  50.0,

  /* Variable: ACC_MaxThrottle
   * Referenced by:
   *   '<S74>/Saturation'
   *   '<S124>/Saturation'
   *   '<S175>/Saturation'
   */
  130.0,

  /* Variable: ACC_Module_Activity_Flag
   * Referenced by:
   *   '<S10>/ACC_Module_Activity_Flag1'
   *   '<S15>/ACC_Module_Activity_Flag'
   *   '<S16>/ACC_Module_Activity_Flag'
   */
  1.0,

  /* Variable: ACC_Ready_Speed
   * Referenced by: '<S185>/Constant'
   */
  30.0,

  /* Variable: ACC_SensorMaxDistance
   * Referenced by:
   *   '<S15>/Target_Distance_Saturation'
   *   '<S20>/Constant'
   *   '<S21>/Constant'
   *   '<S197>/ACC_SensorMaxDistance'
   */
  250.0,

  /* Variable: ACC_Speed_Distance_Gain
   * Referenced by:
   *   '<S19>/ACC_Speed_Distance_Gain'
   *   '<S19>/ACC_Speed_Distance_Gain1'
   *   '<S19>/ACC_Speed_Distance_Gain2'
   *   '<S19>/ACC_Speed_Distance_Gain3'
   */
  { 0.1, 0.15, 0.2, 0.25 },

  /* Variable: ACC_Speed_Distance_control
   * Referenced by: '<S19>/Memory'
   */
  3.0,

  /* Variable: ADAS_Control_Mode
   * Referenced by:
   *   '<S231>/ADAS_Control_Mode'
   *   '<S264>/ADAS_Control_Mode'
   *   '<S35>/ADAS_Control_Mode'
   */
  1.0,

  /* Variable: AEB_Distance_To_Collision_Brake
   * Referenced by: '<S222>/Constant'
   */
  5.0,

  /* Variable: AEB_Gain
   * Referenced by:
   *   '<S239>/Gain'
   *   '<S239>/Gain1'
   */
  { 1.0, 1.0 },

  /* Variable: AEB_Gain_set
   * Referenced by: '<S239>/Constant'
   */
  60.0,

  /* Variable: AEB_Gain_set_mult
   * Referenced by: '<S239>/Gain2'
   */
  0.03,

  /* Variable: AEB_Max_Decel
   * Referenced by:
   *   '<S231>/AEB_Max_Decel'
   *   '<S231>/AEB_Max_Decel1'
   */
  { 8.0, 15.0 },

  /* Variable: AEB_Max_Speed
   * Referenced by:
   *   '<S247>/Constant'
   *   '<S236>/Constant'
   */
  150.0,

  /* Variable: AEB_Min_Distance_at_Stop
   * Referenced by: '<S231>/Constant'
   */
  1.0,

  /* Variable: AEB_Module_Activity_Flag
   * Referenced by: '<S216>/AEB_Module_Activity_Flag'
   */
  1.0,

  /* Variable: AEB_Pedestrian_type
   * Referenced by: '<S238>/Constant'
   */
  68.0,

  /* Variable: AEB_Steer_Max
   * Referenced by: '<S237>/Constant'
   */
  180.0,

  /* Variable: AP_Activity_Flag
   * Referenced by:
   *   '<S10>/Constant4'
   *   '<S250>/Constant4'
   *   '<S15>/AP_Module_Activity_Flag'
   *   '<S16>/Constant4'
   */
  1.0,

  /* Variable: AP_D
   * Referenced by:
   *   '<S264>/AP_D(1)(1)'
   *   '<S264>/AP_D(2)(1)1'
   */
  { 0.3, 0.3 },

  /* Variable: AP_Dyn_Rate_Limiter_Gain
   * Referenced by: '<S250>/Gain1'
   */
  0.1,

  /* Variable: AP_Dyn_Rate_Limiter_Power
   * Referenced by: '<S250>/Constant1'
   */
  10.0,

  /* Variable: AP_Error_Max
   * Referenced by: '<S250>/Saturation'
   */
  3.0,

  /* Variable: AP_I
   * Referenced by:
   *   '<S264>/AP_I(1)(1)'
   *   '<S264>/AP_I(2)(1)1'
   */
  { 0.05, 0.05 },

  /* Variable: AP_Max_Error_dydt_Disable
   * Referenced by: '<S254>/Constant'
   */
  0.5,

  /* Variable: AP_On_Request_Time
   * Referenced by: '<S252>/Constant'
   */
  0.01,

  /* Variable: AP_P
   * Referenced by:
   *   '<S264>/AP_P(1)(1)'
   *   '<S264>/AP_P(2)(1)1'
   */
  { 0.2, 0.2 },

  /* Variable: AP_Steer_Error_Max
   * Referenced by: '<S255>/Constant'
   */
  0.7,

  /* Variable: AP_Steer_Rate_Max_radps
   * Referenced by: '<S250>/Rate Limiter'
   */
  1.0,

  /* Variable: AP_Transition_Rate
   * Referenced by: '<S250>/Rate Limiter1'
   */
  0.5,

  /* Variable: Lane_Width
   * Referenced by:
   *   '<S225>/Constant'
   *   '<S199>/Lane_Width//2'
   *   '<S210>/Constant'
   */
  3.7,

  /* Variable: No_Target_Display_Value
   * Referenced by:
   *   '<S220>/No_Target_Display_Value'
   *   '<S198>/No_Target_Display_Value'
   */
  0.0,

  /* Variable: radar_source
   * Referenced by:
   *   '<S324>/Constant1'
   *   '<S198>/Constant1'
   */
  2.0,

  /* Variable: vehicle_width
   * Referenced by:
   *   '<S325>/Semitrack'
   *   '<S199>/Constant'
   */
  2.2,

  /* Mask Parameter: tACC_PID_DifferentiatorICPrevScaledInput
   * Referenced by: '<S161>/UD'
   */
  0.0,

  /* Mask Parameter: TransferFcnFirstOrder11_ICPrevOutput
   * Referenced by: '<S27>/UD'
   */
  0.0,

  /* Mask Parameter: TransferFcnFirstOrder10_ICPrevOutput
   * Referenced by: '<S26>/UD'
   */
  0.0,

  /* Mask Parameter: TransferFcnFirstOrder8_ICPrevOutput
   * Referenced by: '<S33>/UD'
   */
  0.0,

  /* Mask Parameter: TransferFcnFirstOrder9_ICPrevOutput
   * Referenced by: '<S34>/UD'
   */
  0.0,

  /* Mask Parameter: TransferFcnFirstOrder7_ICPrevOutput
   * Referenced by: '<S32>/UD'
   */
  0.0,

  /* Mask Parameter: TransferFcnFirstOrder6_ICPrevOutput
   * Referenced by: '<S31>/UD'
   */
  0.0,

  /* Mask Parameter: TransferFcnFirstOrder4_ICPrevOutput
   * Referenced by: '<S29>/UD'
   */
  0.0,

  /* Mask Parameter: TransferFcnFirstOrder5_ICPrevOutput
   * Referenced by: '<S30>/UD'
   */
  0.0,

  /* Mask Parameter: DiscreteDerivative_ICPrevScaledInput
   * Referenced by: '<S246>/UD'
   */
  0.0,

  /* Mask Parameter: DiscreteDerivative_ICPrevScaledInput_d
   * Referenced by: '<S262>/UD'
   */
  0.0,

  /* Mask Parameter: DiscreteDerivative1_ICPrevScaledInput
   * Referenced by: '<S263>/UD'
   */
  0.0,

  /* Mask Parameter: DiscreteDerivative2_ICPrevScaledInput
   * Referenced by: '<S244>/UD'
   */
  0.0,

  /* Mask Parameter: DiscreteDerivative1_ICPrevScaledInput_g
   * Referenced by: '<S243>/UD'
   */
  0.0,

  /* Mask Parameter: DiscreteDerivative_ICPrevScaledInput_j
   * Referenced by: '<S242>/UD'
   */
  0.0,

  /* Mask Parameter: DiscretePIDController1_InitialConditionForIntegrator
   * Referenced by: '<S117>/Integrator'
   */
  0.0,

  /* Mask Parameter: tACC_PID_InitialConditionForIntegrator
   * Referenced by: '<S168>/Integrator'
   */
  0.0,

  /* Mask Parameter: ACC_PID_Kb
   * Referenced by: '<S60>/Kb'
   */
  1.0,

  /* Mask Parameter: DiscretePIDController1_Kb
   * Referenced by: '<S110>/Kb'
   */
  1.0,

  /* Mask Parameter: tACC_PID_Kb
   * Referenced by: '<S159>/Kb'
   */
  1.0,

  /* Mask Parameter: TransferFcnFirstOrder9_PoleZ
   * Referenced by: '<S34>/Gain'
   */
  0.9,

  /* Mask Parameter: TransferFcnFirstOrder8_PoleZ
   * Referenced by: '<S33>/Gain'
   */
  0.9,

  /* Mask Parameter: TransferFcnFirstOrder10_PoleZ
   * Referenced by: '<S26>/Gain'
   */
  0.9,

  /* Mask Parameter: TransferFcnFirstOrder11_PoleZ
   * Referenced by: '<S27>/Gain'
   */
  0.9,

  /* Mask Parameter: TransferFcnFirstOrder5_PoleZ
   * Referenced by: '<S30>/Gain'
   */
  0.9,

  /* Mask Parameter: TransferFcnFirstOrder4_PoleZ
   * Referenced by: '<S29>/Gain'
   */
  0.9,

  /* Mask Parameter: TransferFcnFirstOrder6_PoleZ
   * Referenced by: '<S31>/Gain'
   */
  0.9,

  /* Mask Parameter: TransferFcnFirstOrder7_PoleZ
   * Referenced by: '<S32>/Gain'
   */
  0.9,

  /* Mask Parameter: shift_paddle_threshold1_const
   * Referenced by: '<S348>/Constant'
   */
  0.5,

  /* Mask Parameter: CompareToConstant2_const
   * Referenced by: '<S344>/Constant'
   */
  1.0,

  /* Mask Parameter: shift_paddle_threshold_const
   * Referenced by: '<S347>/Constant'
   */
  0.5,

  /* Mask Parameter: CompareToConstant_const
   * Referenced by: '<S12>/Constant'
   */
  1.5,

  /* Mask Parameter: CompareToConstant1_const
   * Referenced by: '<S187>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant3_const
   * Referenced by: '<S189>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_f
   * Referenced by: '<S188>/Constant'
   */
  1.0,

  /* Mask Parameter: AEB_Approaching_Speed_Threshold_const
   * Referenced by: '<S219>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant_const_b
   * Referenced by: '<S223>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant4_const
   * Referenced by: '<S190>/Constant'
   */
  0.0,

  /* Mask Parameter: CompareToConstant2_const_p
   * Referenced by: '<S205>/Constant'
   */
  121.0,

  /* Mask Parameter: CompareToConstant3_const_m
   * Referenced by: '<S206>/Constant'
   */
  3.0,

  /* Mask Parameter: CompareToConstant1_const_p
   * Referenced by: '<S204>/Constant'
   */
  1.0,

  /* Mask Parameter: gear_change_max_speed_up_const
   * Referenced by: '<S346>/Constant'
   */
  5.0,

  /* Mask Parameter: CompareToConstant1_const_b
   * Referenced by: '<S253>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant4_const_n
   * Referenced by: '<S256>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant6_const
   * Referenced by: '<S258>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant8_const
   * Referenced by: '<S259>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant5_const
   * Referenced by: '<S257>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant9_const
   * Referenced by: '<S260>/Constant'
   */
  1.0,

  /* Mask Parameter: gear_change_max_speed_down_const
   * Referenced by: '<S345>/Constant'
   */
  5.0,

  /* Mask Parameter: CompareToConstant_const_d
   * Referenced by: '<S339>/Constant'
   */
  0.0,

  /* Mask Parameter: CompareToConstant1_const_f
   * Referenced by: '<S340>/Constant'
   */
  0.0,

  /* Mask Parameter: CompareToConstant_const_g
   * Referenced by: '<S342>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant1_const_bt
   * Referenced by: '<S343>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant1_const_l
   * Referenced by: '<S224>/Constant'
   */
  0.0,

  /* Mask Parameter: DetectIncrease1_vinit
   * Referenced by: '<S194>/Delay Input1'
   */
  0.0,

  /* Mask Parameter: DetectDecrease_vinit
   * Referenced by: '<S14>/Delay Input1'
   */
  0.0,

  /* Mask Parameter: DetectIncrease_vinit
   * Referenced by: '<S23>/Delay Input1'
   */
  0.0,

  /* Mask Parameter: DetectIncrease1_vinit_p
   * Referenced by: '<S24>/Delay Input1'
   */
  0.0,

  /* Mask Parameter: DetectIncrease_vinit_a
   * Referenced by: '<S84>/Delay Input1'
   */
  0.0,

  /* Mask Parameter: DetectIncrease1_vinit_j
   * Referenced by: '<S85>/Delay Input1'
   */
  0.0,

  /* Mask Parameter: DetectChange_vinit
   * Referenced by: '<S230>/Delay Input1'
   */
  0.0,

  /* Mask Parameter: CompareToConstant_const_l
   * Referenced by: '<S203>/Constant'
   */
  true,

  /* Mask Parameter: DetectIncrease_vinit_ao
   * Referenced by: '<S13>/Delay Input1'
   */
  false,

  /* Mask Parameter: DetectIncrease_vinit_m
   * Referenced by: '<S193>/Delay Input1'
   */
  false,

  /* Expression: 0
   * Referenced by: '<S10>/Gain'
   */
  0.0,

  /* Computed Parameter: TSamp_WtEt
   * Referenced by: '<S246>/TSamp'
   */
  1.0,

  /* Expression: -1
   * Referenced by: '<S235>/Gain'
   */
  -1.0,

  /* Expression: 0
   * Referenced by: '<S216>/Gain'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S250>/Gain'
   */
  -1.0,

  /* Expression: 121
   * Referenced by: '<S330>/Constant7'
   */
  121.0,

  /* Expression: 0
   * Referenced by: '<S22>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S191>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S192>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S213>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S226>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S228>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S229>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S248>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S261>/Constant'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S8>/Gain1'
   */
  -1.0,

  /* Expression: 300
   * Referenced by: '<S8>/Constant'
   */
  300.0,

  /* Expression: 0
   * Referenced by: '<S8>/Constant1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S11>/Memory'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S16>/Constant'
   */
  0.0,

  /* Expression: 100
   * Referenced by: '<S215>/Constant3'
   */
  100.0,

  /* Expression: 0
   * Referenced by: '<S215>/Rate Transition7'
   */
  0.0,

  /* Expression: 0
   * Referenced by:
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S215>/Pulse Generator'
   */
  1.0,

  /* Computed Parameter: PulseGenerator_Period
   * Referenced by: '<S215>/Pulse Generator'
   */
  40.0,

  /* Computed Parameter: PulseGenerator_Duty
   * Referenced by: '<S215>/Pulse Generator'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S215>/Pulse Generator'
   */
  0.0,

  /* Expression: inf
   * Referenced by: '<S215>/Rate Limiter1'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S215>/Rate Limiter1'
   */
  -1.0,

  /* Expression: 0
   * Referenced by: '<S215>/Rate Limiter1'
   */
  0.0,

  /* Expression: inf
   * Referenced by: '<S215>/Rate Limiter'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S215>/Rate Limiter'
   */
  -1.0,

  /* Expression: 0.0
   * Referenced by: '<S215>/Delay1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S215>/Switch2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S215>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by:
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S215>/Rate Transition6'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S216>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S16>/Memory'
   */
  0.0,

  /* Expression: 15
   * Referenced by: '<S15>/Constant'
   */
  15.0,

  /* Expression: 0
   * Referenced by: '<S15>/Memory'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S330>/Constant6'
   */
  1.0,

  /* Expression: [0 0 0 0 0 0 0 0 0]
   * Referenced by: '<S330>/Constant2'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Expression: zeros(64,7)
   * Referenced by: '<S321>/Constant'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Expression: [121 121 121 121 121 121 121 121 121]
   * Referenced by: '<S330>/Constant3'
   */
  { 121.0, 121.0, 121.0, 121.0, 121.0, 121.0, 121.0, 121.0, 121.0 },

  /* Expression: [0 0 0 0 0 0 0 0 0]
   * Referenced by: '<S330>/Constant4'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Expression: 1
   * Referenced by: '<S330>/Constant'
   */
  1.0,

  /* Expression: [0 0 0 0 0 0 0 0 0]
   * Referenced by: '<S330>/Constant5'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Expression: 0
   * Referenced by:
   */
  0.0,

  /* Expression: 1/2
   * Referenced by: '<S320>/Gain'
   */
  0.5,

  /* Expression: 1
   * Referenced by: '<S199>/Gain'
   */
  1.0,

  /* Expression: 1.3
   * Referenced by: '<S199>/Gain1'
   */
  1.3,

  /* Expression: 0.02
   * Referenced by: '<S197>/Switch1'
   */
  0.02,

  /* Computed Parameter: Integrator_gainval
   * Referenced by: '<S117>/Integrator'
   */
  0.001,

  /* Expression: 0
   * Referenced by:
   */
  0.0,

  /* Computed Parameter: Integrator_gainval_p
   * Referenced by: '<S168>/Integrator'
   */
  0.001,

  /* Expression: 0
   * Referenced by:
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S15>/Saturation1'
   */
  0.0,

  /* Expression: -100
   * Referenced by: '<S15>/Saturation1'
   */
  -100.0,

  /* Expression: -1
   * Referenced by: '<S15>/ACC_Brake_Gain2'
   */
  -1.0,

  /* Expression: 0
   * Referenced by: '<S15>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S15>/Memory2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S15>/Switch2'
   */
  0.0,

  /* Computed Parameter: Integrator_gainval_pc
   * Referenced by: '<S67>/Integrator'
   */
  0.001,

  /* Expression: 0
   * Referenced by: '<S15>/Saturation2'
   */
  0.0,

  /* Expression: -100
   * Referenced by: '<S15>/Saturation2'
   */
  -100.0,

  /* Expression: -1
   * Referenced by: '<S15>/ACC_Brake_Gain1'
   */
  -1.0,

  /* Expression: 100
   * Referenced by: '<S15>/Saturation8'
   */
  100.0,

  /* Expression: -100
   * Referenced by: '<S15>/Saturation8'
   */
  -100.0,

  /* Expression: 100
   * Referenced by: '<S15>/Saturation3'
   */
  100.0,

  /* Expression: 0
   * Referenced by: '<S15>/Saturation3'
   */
  0.0,

  /* Expression: 100
   * Referenced by: '<S15>/Saturation4'
   */
  100.0,

  /* Expression: 0
   * Referenced by: '<S15>/Saturation4'
   */
  0.0,

  /* Expression: 100
   * Referenced by: '<S15>/Saturation9'
   */
  100.0,

  /* Expression: -100
   * Referenced by: '<S15>/Saturation9'
   */
  -100.0,

  /* Expression: 0
   * Referenced by: '<S198>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S10>/Switch'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S319>/ACC_Output_Brake_Gain'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S319>/AEB_Output_Brake_Gain'
   */
  1.0,

  /* Expression: -1
   * Referenced by: '<S249>/Gain4'
   */
  -1.0,

  /* Expression: 1
   * Referenced by: '<S250>/Constant2'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S250>/Memory2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S250>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S250>/Rate Transition8'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S250>/Integrator'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S250>/Memory'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S250>/Rate Transition5'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S250>/Gain2'
   */
  -1.0,

  /* Expression: 4
   * Referenced by: '<S19>/Saturation'
   */
  4.0,

  /* Expression: 1
   * Referenced by: '<S19>/Saturation'
   */
  1.0,

  /* Expression: 0
   * Referenced by:
   */
  0.0,

  /* Expression: inf
   * Referenced by: '<S10>/Rate Limiter'
   */
  0.0,

  /* Expression: -100
   * Referenced by: '<S10>/Rate Limiter'
   */
  -100.0,

  /* Expression: 1
   * Referenced by: '<S216>/Pulse Generator'
   */
  1.0,

  /* Computed Parameter: PulseGenerator_Period_n
   * Referenced by: '<S216>/Pulse Generator'
   */
  200.0,

  /* Computed Parameter: PulseGenerator_Duty_n
   * Referenced by: '<S216>/Pulse Generator'
   */
  100.0,

  /* Expression: 0
   * Referenced by: '<S216>/Pulse Generator'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S215>/Rate Transition5'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S214>/Gain2'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S214>/Gain4'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S214>/Gain5'
   */
  -1.0,

  /* Expression: 0
   * Referenced by: '<S214>/Gain'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S214>/Gain1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S214>/Gain3'
   */
  0.0,

  /* Expression: 0
   * Referenced by:
   */
  0.0,

  /* Expression: [butter_b]
   * Referenced by: '<S215>/filtering'
   */
  { 9.825916820482009E-6, 1.9651833640964018E-5, 9.825916820482009E-6 },

  /* Expression: [butter_a]
   * Referenced by: '<S215>/filtering'
   */
  { 1.0, -1.9911142922016536, 0.99115359586893548 },

  /* Expression: 0
   * Referenced by: '<S215>/filtering'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S250>/Gain4'
   */
  -1.0,

  /* Expression: 0
   * Referenced by: '<S250>/Integrator1'
   */
  0.0,

  /* Expression: 0
   * Referenced by:
   */
  0.0,

  /* Expression: [butter_b]
   * Referenced by: '<S329>/Discrete Filter'
   */
  { 9.825916820482009E-6, 1.9651833640964018E-5, 9.825916820482009E-6 },

  /* Expression: [butter_a]
   * Referenced by: '<S329>/Discrete Filter'
   */
  { 1.0, -1.9911142922016536, 0.99115359586893548 },

  /* Expression: 0
   * Referenced by: '<S329>/Discrete Filter'
   */
  0.0,

  /* Expression: 0
   * Referenced by:
   */
  0.0,

  /* Expression: [butter_b]
   * Referenced by: '<S329>/Discrete Filter1'
   */
  { 9.825916820482009E-6, 1.9651833640964018E-5, 9.825916820482009E-6 },

  /* Expression: [butter_a]
   * Referenced by: '<S329>/Discrete Filter1'
   */
  { 1.0, -1.9911142922016536, 0.99115359586893548 },

  /* Expression: 0
   * Referenced by: '<S329>/Discrete Filter1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S329>/Pulse Generator'
   */
  1.0,

  /* Computed Parameter: PulseGenerator_Period_j
   * Referenced by: '<S329>/Pulse Generator'
   */
  20.0,

  /* Computed Parameter: PulseGenerator_Duty_d
   * Referenced by: '<S329>/Pulse Generator'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S329>/Pulse Generator'
   */
  0.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P1_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 9.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P1
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 49.0, 50.0, 55.0, 46.0, 48.0, 46.0, 48.0, 46.0, 49.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P2_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 1.0 },

  /* Expression: worldsim_endpoint_port
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  8080.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P3_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 3.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P3
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 101.0, 103.0, 111.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P4_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 16.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P4
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 70.0, 114.0, 111.0, 110.0, 116.0, 95.0, 86.0, 105.0, 114.0, 116.0, 117.0,
    97.0, 108.0, 67.0, 97.0, 109.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P5_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 1.0 },

  /* Expression: max_lanes
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  10.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P6_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 1.0 },

  /* Expression: max_obstacles
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  10.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P7_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  { 1.0, 1.0 },

  /* Expression: worldsim_verbose
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
   */
  0.0,

  /* Expression: 0.5
   * Referenced by: '<S331>/Gain'
   */
  0.5,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P1_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 9.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P1
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 49.0, 50.0, 55.0, 46.0, 48.0, 46.0, 48.0, 46.0, 49.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P2_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 1.0 },

  /* Expression: worldsim_endpoint_port
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  8080.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P3_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 3.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P3
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 101.0, 103.0, 111.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P4_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 15.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P4
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 82.0, 101.0, 97.0, 114.0, 95.0, 86.0, 105.0, 114.0, 116.0, 117.0, 97.0,
    108.0, 67.0, 97.0, 109.0 },

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P5_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 1.0 },

  /* Expression: max_lanes
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  10.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P6_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 1.0 },

  /* Expression: max_obstacles
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  10.0,

  /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P7_Size
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  { 1.0, 1.0 },

  /* Expression: worldsim_verbose
   * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S329>/Gain2'
   */
  -1.0,

  /* Expression: 0
   * Referenced by: '<S321>/Memory'
   */
  0.0,

  /* Computed Parameter: VI_WorldSim_State_Manager_P1_Size
   * Referenced by: '<S321>/VI_WorldSim_State_Manager'
   */
  { 1.0, 9.0 },

  /* Computed Parameter: VI_WorldSim_State_Manager_P1
   * Referenced by: '<S321>/VI_WorldSim_State_Manager'
   */
  { 49.0, 50.0, 55.0, 46.0, 48.0, 46.0, 48.0, 46.0, 49.0 },

  /* Computed Parameter: VI_WorldSim_State_Manager_P2_Size
   * Referenced by: '<S321>/VI_WorldSim_State_Manager'
   */
  { 1.0, 1.0 },

  /* Expression: worldsim_endpoint_port
   * Referenced by: '<S321>/VI_WorldSim_State_Manager'
   */
  8080.0,

  /* Computed Parameter: VI_WorldSim_State_Manager_P3_Size
   * Referenced by: '<S321>/VI_WorldSim_State_Manager'
   */
  { 1.0, 3.0 },

  /* Computed Parameter: VI_WorldSim_State_Manager_P3
   * Referenced by: '<S321>/VI_WorldSim_State_Manager'
   */
  { 101.0, 103.0, 111.0 },

  /* Computed Parameter: VI_WorldSim_State_Manager_P4_Size
   * Referenced by: '<S321>/VI_WorldSim_State_Manager'
   */
  { 1.0, 1.0 },

  /* Expression: worldsim_verbose
   * Referenced by: '<S321>/VI_WorldSim_State_Manager'
   */
  0.0,

  /* Expression: 2
   * Referenced by: '<S15>/Target_Distance_Saturation'
   */
  2.0,

  /* Expression: 0
   * Referenced by: '<S35>/Constant'
   */
  0.0,

  /* Computed Parameter: Tsamp_WtEt
   * Referenced by: '<S163>/Tsamp'
   */
  50.0,

  /* Expression: 0.5
   * Referenced by: '<S250>/Gain3'
   */
  0.5,

  /* Computed Parameter: TSamp_WtEt_b
   * Referenced by: '<S262>/TSamp'
   */
  50.0,

  /* Computed Parameter: TSamp_WtEt_h
   * Referenced by: '<S263>/TSamp'
   */
  50.0,

  /* Expression: 0
   * Referenced by: '<S264>/Constant'
   */
  0.0,

  /* Computed Parameter: Tsamp_WtEt_d
   * Referenced by: '<S296>/Tsamp'
   */
  50.0,

  /* Computed Parameter: Integrator_gainval_f
   * Referenced by: '<S301>/Integrator'
   */
  0.02,

  /* Computed Parameter: sampletime_WtEt
   * Referenced by: '<S266>/sample time'
   */
  0.02,

  /* Expression: 0
   * Referenced by: '<S266>/Delay Input2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S250>/Rate Limiter'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S221>/Constant'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S239>/Constant1'
   */
  1.0,

  /* Expression: 1.7
   * Referenced by: '<S239>/Saturation'
   */
  1.7,

  /* Expression: 0.8
   * Referenced by: '<S239>/Saturation'
   */
  0.8,

  /* Expression: -1.5
   * Referenced by: '<S241>/Lane_Right_Edge_Y_Distance'
   */
  -1.5,

  /* Computed Parameter: TSamp_WtEt_f
   * Referenced by: '<S244>/TSamp'
   */
  25.0,

  /* Expression: -1e-6
   * Referenced by: '<S241>/Saturation'
   */
  -1.0E-6,

  /* Expression: -inf
   * Referenced by: '<S241>/Saturation'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S241>/Gain2'
   */
  -1.0,

  /* Expression: 1.5
   * Referenced by: '<S241>/Lane_Left_Edge_Y_Distance'
   */
  1.5,

  /* Computed Parameter: TSamp_WtEt_a
   * Referenced by: '<S243>/TSamp'
   */
  25.0,

  /* Expression: -1e-6
   * Referenced by: '<S241>/Saturation1'
   */
  -1.0E-6,

  /* Expression: -inf
   * Referenced by: '<S241>/Saturation1'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S241>/Gain1'
   */
  -1.0,

  /* Computed Parameter: TSamp_WtEt_i
   * Referenced by: '<S242>/TSamp'
   */
  25.0,

  /* Expression: -1e-6
   * Referenced by: '<S240>/Saturation'
   */
  -1.0E-6,

  /* Expression: -inf
   * Referenced by: '<S240>/Saturation'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S240>/Gain'
   */
  -1.0,

  /* Expression: 0
   * Referenced by: '<S215>/Constant1'
   */
  0.0,

  /* Expression: 10
   * Referenced by: '<S215>/Constant2'
   */
  10.0,

  /* Expression: 2
   * Referenced by: '<S231>/Gain'
   */
  2.0,

  /* Expression: 0
   * Referenced by: '<S215>/Delay'
   */
  0.0,

  /* Expression: 100
   * Referenced by: '<S215>/Gain1'
   */
  100.0,

  /* Expression: inf
   * Referenced by: '<S215>/Saturation'
   */
  0.0,

  /* Expression: 1e-6
   * Referenced by: '<S215>/Saturation'
   */
  1.0E-6,

  /* Computed Parameter: Constant_Value_b
   * Referenced by: '<S227>/Constant'
   */
  false,

  /* Computed Parameter: Memory1_InitialCondition_l
   * Referenced by: '<S250>/Memory1'
   */
  false,

  /* Computed Parameter: Delay_InitialCondition_h
   * Referenced by: '<S221>/Delay'
   */
  false,

  /* Computed Parameter: Delay1_InitialCondition_b
   * Referenced by: '<S221>/Delay1'
   */
  false,

  /* Computed Parameter: Delay2_InitialCondition
   * Referenced by: '<S221>/Delay2'
   */
  false,

  /* Computed Parameter: Gain_Gain_c
   * Referenced by: '<S19>/Gain'
   */
  MIN_int8_T
};
