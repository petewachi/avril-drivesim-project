/*
 * auto_pilot_upl.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "auto_pilot_upl".
 *
 * Model version              : 17.110
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Thu Feb  1 00:30:37 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_auto_pilot_upl_h_
#define RTW_HEADER_auto_pilot_upl_h_
#ifndef auto_pilot_upl_COMMON_INCLUDES_
#define auto_pilot_upl_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif                                 /* auto_pilot_upl_COMMON_INCLUDES_ */

#include "auto_pilot_upl_types.h"
#include "rt_nonfinite.h"
#include <stddef.h>
#include "rt_zcfcn.h"
#include <string.h>
#include "rtGetInf.h"
#include "rtw_modelmap.h"
#include "rt_defines.h"
#include "math.h"
#include <math.h>
#include "rt_matrixlib.h"
#include "zero_crossing_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetBlockIO
#define rtmGetBlockIO(rtm)             ((rtm)->blockIO)
#endif

#ifndef rtmSetBlockIO
#define rtmSetBlockIO(rtm, val)        ((rtm)->blockIO = (val))
#endif

#ifndef rtmGetChecksums
#define rtmGetChecksums(rtm)           ((rtm)->Sizes.checksums)
#endif

#ifndef rtmSetChecksums
#define rtmSetChecksums(rtm, val)      ((rtm)->Sizes.checksums = (val))
#endif

#ifndef rtmGetConstBlockIO
#define rtmGetConstBlockIO(rtm)        ((rtm)->constBlockIO)
#endif

#ifndef rtmSetConstBlockIO
#define rtmSetConstBlockIO(rtm, val)   ((rtm)->constBlockIO = (val))
#endif

#ifndef rtmGetContStateDisabled
#define rtmGetContStateDisabled(rtm)   ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
#define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
#define rtmGetContStates(rtm)          ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
#define rtmSetContStates(rtm, val)     ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetCtrlRateMdlRefTiming
#define rtmGetCtrlRateMdlRefTiming(rtm) ()
#endif

#ifndef rtmSetCtrlRateMdlRefTiming
#define rtmSetCtrlRateMdlRefTiming(rtm, val) ()
#endif

#ifndef rtmGetCtrlRateMdlRefTimingPtr
#define rtmGetCtrlRateMdlRefTimingPtr(rtm) ()
#endif

#ifndef rtmSetCtrlRateMdlRefTimingPtr
#define rtmSetCtrlRateMdlRefTimingPtr(rtm, val) ()
#endif

#ifndef rtmGetCtrlRateNumTicksToNextHit
#define rtmGetCtrlRateNumTicksToNextHit(rtm) ()
#endif

#ifndef rtmSetCtrlRateNumTicksToNextHit
#define rtmSetCtrlRateNumTicksToNextHit(rtm, val) ()
#endif

#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm)         ((rtm)->DataMapInfo)
#endif

#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val)    ((rtm)->DataMapInfo = (val))
#endif

#ifndef rtmGetDefaultParam
#define rtmGetDefaultParam(rtm)        ((rtm)->defaultParam)
#endif

#ifndef rtmSetDefaultParam
#define rtmSetDefaultParam(rtm, val)   ((rtm)->defaultParam = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetDirectFeedThrough
#define rtmGetDirectFeedThrough(rtm)   ((rtm)->Sizes.sysDirFeedThru)
#endif

#ifndef rtmSetDirectFeedThrough
#define rtmSetDirectFeedThrough(rtm, val) ((rtm)->Sizes.sysDirFeedThru = (val))
#endif

#ifndef rtmGetErrorStatusFlag
#define rtmGetErrorStatusFlag(rtm)     ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatusFlag
#define rtmSetErrorStatusFlag(rtm, val) ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetFinalTime
#define rtmSetFinalTime(rtm, val)      ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetFirstInitCondFlag
#define rtmGetFirstInitCondFlag(rtm)   ()
#endif

#ifndef rtmSetFirstInitCondFlag
#define rtmSetFirstInitCondFlag(rtm, val) ()
#endif

#ifndef rtmGetIntgData
#define rtmGetIntgData(rtm)            ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
#define rtmSetIntgData(rtm, val)       ((rtm)->intgData = (val))
#endif

#ifndef rtmGetMdlRefGlobalRuntimeEventIndices
#define rtmGetMdlRefGlobalRuntimeEventIndices(rtm) ()
#endif

#ifndef rtmSetMdlRefGlobalRuntimeEventIndices
#define rtmSetMdlRefGlobalRuntimeEventIndices(rtm, val) ()
#endif

#ifndef rtmGetMdlRefGlobalTID
#define rtmGetMdlRefGlobalTID(rtm)     ()
#endif

#ifndef rtmSetMdlRefGlobalTID
#define rtmSetMdlRefGlobalTID(rtm, val) ()
#endif

#ifndef rtmGetMdlRefGlobalTimerIndices
#define rtmGetMdlRefGlobalTimerIndices(rtm) ()
#endif

#ifndef rtmSetMdlRefGlobalTimerIndices
#define rtmSetMdlRefGlobalTimerIndices(rtm, val) ()
#endif

#ifndef rtmGetMdlRefTriggerTID
#define rtmGetMdlRefTriggerTID(rtm)    ()
#endif

#ifndef rtmSetMdlRefTriggerTID
#define rtmSetMdlRefTriggerTID(rtm, val) ()
#endif

#ifndef rtmGetModelMappingInfo
#define rtmGetModelMappingInfo(rtm)    ((rtm)->SpecialInfo.mappingInfo)
#endif

#ifndef rtmSetModelMappingInfo
#define rtmSetModelMappingInfo(rtm, val) ((rtm)->SpecialInfo.mappingInfo = (val))
#endif

#ifndef rtmGetModelName
#define rtmGetModelName(rtm)           ((rtm)->modelName)
#endif

#ifndef rtmSetModelName
#define rtmSetModelName(rtm, val)      ((rtm)->modelName = (val))
#endif

#ifndef rtmGetNonInlinedSFcns
#define rtmGetNonInlinedSFcns(rtm)     ((rtm)->NonInlinedSFcns)
#endif

#ifndef rtmSetNonInlinedSFcns
#define rtmSetNonInlinedSFcns(rtm, val) ((rtm)->NonInlinedSFcns = (val))
#endif

#ifndef rtmGetNumBlockIO
#define rtmGetNumBlockIO(rtm)          ((rtm)->Sizes.numBlockIO)
#endif

#ifndef rtmSetNumBlockIO
#define rtmSetNumBlockIO(rtm, val)     ((rtm)->Sizes.numBlockIO = (val))
#endif

#ifndef rtmGetNumBlockParams
#define rtmGetNumBlockParams(rtm)      ((rtm)->Sizes.numBlockPrms)
#endif

#ifndef rtmSetNumBlockParams
#define rtmSetNumBlockParams(rtm, val) ((rtm)->Sizes.numBlockPrms = (val))
#endif

#ifndef rtmGetNumBlocks
#define rtmGetNumBlocks(rtm)           ((rtm)->Sizes.numBlocks)
#endif

#ifndef rtmSetNumBlocks
#define rtmSetNumBlocks(rtm, val)      ((rtm)->Sizes.numBlocks = (val))
#endif

#ifndef rtmGetNumContStates
#define rtmGetNumContStates(rtm)       ((rtm)->Sizes.numContStates)
#endif

#ifndef rtmSetNumContStates
#define rtmSetNumContStates(rtm, val)  ((rtm)->Sizes.numContStates = (val))
#endif

#ifndef rtmGetNumDWork
#define rtmGetNumDWork(rtm)            ((rtm)->Sizes.numDwork)
#endif

#ifndef rtmSetNumDWork
#define rtmSetNumDWork(rtm, val)       ((rtm)->Sizes.numDwork = (val))
#endif

#ifndef rtmGetNumInputPorts
#define rtmGetNumInputPorts(rtm)       ((rtm)->Sizes.numIports)
#endif

#ifndef rtmSetNumInputPorts
#define rtmSetNumInputPorts(rtm, val)  ((rtm)->Sizes.numIports = (val))
#endif

#ifndef rtmGetNumNonSampledZCs
#define rtmGetNumNonSampledZCs(rtm)    ((rtm)->Sizes.numNonSampZCs)
#endif

#ifndef rtmSetNumNonSampledZCs
#define rtmSetNumNonSampledZCs(rtm, val) ((rtm)->Sizes.numNonSampZCs = (val))
#endif

#ifndef rtmGetNumOutputPorts
#define rtmGetNumOutputPorts(rtm)      ((rtm)->Sizes.numOports)
#endif

#ifndef rtmSetNumOutputPorts
#define rtmSetNumOutputPorts(rtm, val) ((rtm)->Sizes.numOports = (val))
#endif

#ifndef rtmGetNumPeriodicContStates
#define rtmGetNumPeriodicContStates(rtm) ((rtm)->Sizes.numPeriodicContStates)
#endif

#ifndef rtmSetNumPeriodicContStates
#define rtmSetNumPeriodicContStates(rtm, val) ((rtm)->Sizes.numPeriodicContStates = (val))
#endif

#ifndef rtmGetNumSFcnParams
#define rtmGetNumSFcnParams(rtm)       ((rtm)->Sizes.numSFcnPrms)
#endif

#ifndef rtmSetNumSFcnParams
#define rtmSetNumSFcnParams(rtm, val)  ((rtm)->Sizes.numSFcnPrms = (val))
#endif

#ifndef rtmGetNumSFunctions
#define rtmGetNumSFunctions(rtm)       ((rtm)->Sizes.numSFcns)
#endif

#ifndef rtmSetNumSFunctions
#define rtmSetNumSFunctions(rtm, val)  ((rtm)->Sizes.numSFcns = (val))
#endif

#ifndef rtmGetNumSampleTimes
#define rtmGetNumSampleTimes(rtm)      ((rtm)->Sizes.numSampTimes)
#endif

#ifndef rtmSetNumSampleTimes
#define rtmSetNumSampleTimes(rtm, val) ((rtm)->Sizes.numSampTimes = (val))
#endif

#ifndef rtmGetNumU
#define rtmGetNumU(rtm)                ((rtm)->Sizes.numU)
#endif

#ifndef rtmSetNumU
#define rtmSetNumU(rtm, val)           ((rtm)->Sizes.numU = (val))
#endif

#ifndef rtmGetNumY
#define rtmGetNumY(rtm)                ((rtm)->Sizes.numY)
#endif

#ifndef rtmSetNumY
#define rtmSetNumY(rtm, val)           ((rtm)->Sizes.numY = (val))
#endif

#ifndef rtmGetOdeDELTA
#define rtmGetOdeDELTA(rtm)            ((rtm)->odeDELTA)
#endif

#ifndef rtmSetOdeDELTA
#define rtmSetOdeDELTA(rtm, val)       ((rtm)->odeDELTA = (val))
#endif

#ifndef rtmGetOdeDFDX
#define rtmGetOdeDFDX(rtm)             ((rtm)->odeDFDX)
#endif

#ifndef rtmSetOdeDFDX
#define rtmSetOdeDFDX(rtm, val)        ((rtm)->odeDFDX = (val))
#endif

#ifndef rtmGetOdeE
#define rtmGetOdeE(rtm)                ((rtm)->odeE)
#endif

#ifndef rtmSetOdeE
#define rtmSetOdeE(rtm, val)           ((rtm)->odeE = (val))
#endif

#ifndef rtmGetOdeF0
#define rtmGetOdeF0(rtm)               ((rtm)->odeF0)
#endif

#ifndef rtmSetOdeF0
#define rtmSetOdeF0(rtm, val)          ((rtm)->odeF0 = (val))
#endif

#ifndef rtmGetOdeF1
#define rtmGetOdeF1(rtm)               ((rtm)->odeF1)
#endif

#ifndef rtmSetOdeF1
#define rtmSetOdeF1(rtm, val)          ((rtm)->odeF1 = (val))
#endif

#ifndef rtmGetOdeFAC
#define rtmGetOdeFAC(rtm)              ((rtm)->odeFAC)
#endif

#ifndef rtmSetOdeFAC
#define rtmSetOdeFAC(rtm, val)         ((rtm)->odeFAC = (val))
#endif

#ifndef rtmGetOdePIVOTS
#define rtmGetOdePIVOTS(rtm)           ((rtm)->odePIVOTS)
#endif

#ifndef rtmSetOdePIVOTS
#define rtmSetOdePIVOTS(rtm, val)      ((rtm)->odePIVOTS = (val))
#endif

#ifndef rtmGetOdeW
#define rtmGetOdeW(rtm)                ((rtm)->odeW)
#endif

#ifndef rtmSetOdeW
#define rtmSetOdeW(rtm, val)           ((rtm)->odeW = (val))
#endif

#ifndef rtmGetOdeX0
#define rtmGetOdeX0(rtm)               ((rtm)->odeX0)
#endif

#ifndef rtmSetOdeX0
#define rtmSetOdeX0(rtm, val)          ((rtm)->odeX0 = (val))
#endif

#ifndef rtmGetOdeX1START
#define rtmGetOdeX1START(rtm)          ((rtm)->odeX1START)
#endif

#ifndef rtmSetOdeX1START
#define rtmSetOdeX1START(rtm, val)     ((rtm)->odeX1START = (val))
#endif

#ifndef rtmGetOdeXTMP
#define rtmGetOdeXTMP(rtm)             ((rtm)->odeXTMP)
#endif

#ifndef rtmSetOdeXTMP
#define rtmSetOdeXTMP(rtm, val)        ((rtm)->odeXTMP = (val))
#endif

#ifndef rtmGetOdeZTMP
#define rtmGetOdeZTMP(rtm)             ((rtm)->odeZTMP)
#endif

#ifndef rtmSetOdeZTMP
#define rtmSetOdeZTMP(rtm, val)        ((rtm)->odeZTMP = (val))
#endif

#ifndef rtmGetOffsetTimeArray
#define rtmGetOffsetTimeArray(rtm)     ((rtm)->Timing.offsetTimesArray)
#endif

#ifndef rtmSetOffsetTimeArray
#define rtmSetOffsetTimeArray(rtm, val) ((rtm)->Timing.offsetTimesArray = (val))
#endif

#ifndef rtmGetOffsetTimePtr
#define rtmGetOffsetTimePtr(rtm)       ((rtm)->Timing.offsetTimes)
#endif

#ifndef rtmSetOffsetTimePtr
#define rtmSetOffsetTimePtr(rtm, val)  ((rtm)->Timing.offsetTimes = (val))
#endif

#ifndef rtmGetOptions
#define rtmGetOptions(rtm)             ((rtm)->Sizes.options)
#endif

#ifndef rtmSetOptions
#define rtmSetOptions(rtm, val)        ((rtm)->Sizes.options = (val))
#endif

#ifndef rtmGetParamIsMalloced
#define rtmGetParamIsMalloced(rtm)     ()
#endif

#ifndef rtmSetParamIsMalloced
#define rtmSetParamIsMalloced(rtm, val) ()
#endif

#ifndef rtmGetPath
#define rtmGetPath(rtm)                ((rtm)->path)
#endif

#ifndef rtmSetPath
#define rtmSetPath(rtm, val)           ((rtm)->path = (val))
#endif

#ifndef rtmGetPerTaskSampleHits
#define rtmGetPerTaskSampleHits(rtm)   ((rtm)->Timing.RateInteraction)
#endif

#ifndef rtmSetPerTaskSampleHits
#define rtmSetPerTaskSampleHits(rtm, val) ((rtm)->Timing.RateInteraction = (val))
#endif

#ifndef rtmGetPerTaskSampleHitsArray
#define rtmGetPerTaskSampleHitsArray(rtm) ((rtm)->Timing.perTaskSampleHitsArray)
#endif

#ifndef rtmSetPerTaskSampleHitsArray
#define rtmSetPerTaskSampleHitsArray(rtm, val) ((rtm)->Timing.perTaskSampleHitsArray = (val))
#endif

#ifndef rtmGetPerTaskSampleHitsPtr
#define rtmGetPerTaskSampleHitsPtr(rtm) ((rtm)->Timing.perTaskSampleHits)
#endif

#ifndef rtmSetPerTaskSampleHitsPtr
#define rtmSetPerTaskSampleHitsPtr(rtm, val) ((rtm)->Timing.perTaskSampleHits = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
#define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
#define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
#define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
#define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetPrevZCSigState
#define rtmGetPrevZCSigState(rtm)      ((rtm)->prevZCSigState)
#endif

#ifndef rtmSetPrevZCSigState
#define rtmSetPrevZCSigState(rtm, val) ((rtm)->prevZCSigState = (val))
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmSetRTWExtModeInfo
#define rtmSetRTWExtModeInfo(rtm, val) ((rtm)->extModeInfo = (val))
#endif

#ifndef rtmGetRTWGeneratedSFcn
#define rtmGetRTWGeneratedSFcn(rtm)    ((rtm)->Sizes.rtwGenSfcn)
#endif

#ifndef rtmSetRTWGeneratedSFcn
#define rtmSetRTWGeneratedSFcn(rtm, val) ((rtm)->Sizes.rtwGenSfcn = (val))
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ()
#endif

#ifndef rtmSetRTWLogInfo
#define rtmSetRTWLogInfo(rtm, val)     ()
#endif

#ifndef rtmGetRTWRTModelMethodsInfo
#define rtmGetRTWRTModelMethodsInfo(rtm) ()
#endif

#ifndef rtmSetRTWRTModelMethodsInfo
#define rtmSetRTWRTModelMethodsInfo(rtm, val) ()
#endif

#ifndef rtmGetRTWSfcnInfo
#define rtmGetRTWSfcnInfo(rtm)         ((rtm)->sfcnInfo)
#endif

#ifndef rtmSetRTWSfcnInfo
#define rtmSetRTWSfcnInfo(rtm, val)    ((rtm)->sfcnInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfo
#define rtmGetRTWSolverInfo(rtm)       ((rtm)->solverInfo)
#endif

#ifndef rtmSetRTWSolverInfo
#define rtmSetRTWSolverInfo(rtm, val)  ((rtm)->solverInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfoPtr
#define rtmGetRTWSolverInfoPtr(rtm)    ((rtm)->solverInfoPtr)
#endif

#ifndef rtmSetRTWSolverInfoPtr
#define rtmSetRTWSolverInfoPtr(rtm, val) ((rtm)->solverInfoPtr = (val))
#endif

#ifndef rtmGetReservedForXPC
#define rtmGetReservedForXPC(rtm)      ((rtm)->SpecialInfo.xpcData)
#endif

#ifndef rtmSetReservedForXPC
#define rtmSetReservedForXPC(rtm, val) ((rtm)->SpecialInfo.xpcData = (val))
#endif

#ifndef rtmGetRootDWork
#define rtmGetRootDWork(rtm)           ((rtm)->dwork)
#endif

#ifndef rtmSetRootDWork
#define rtmSetRootDWork(rtm, val)      ((rtm)->dwork = (val))
#endif

#ifndef rtmGetSFunctions
#define rtmGetSFunctions(rtm)          ((rtm)->childSfunctions)
#endif

#ifndef rtmSetSFunctions
#define rtmSetSFunctions(rtm, val)     ((rtm)->childSfunctions = (val))
#endif

#ifndef rtmGetSampleHitArray
#define rtmGetSampleHitArray(rtm)      ((rtm)->Timing.sampleHitArray)
#endif

#ifndef rtmSetSampleHitArray
#define rtmSetSampleHitArray(rtm, val) ((rtm)->Timing.sampleHitArray = (val))
#endif

#ifndef rtmGetSampleHitPtr
#define rtmGetSampleHitPtr(rtm)        ((rtm)->Timing.sampleHits)
#endif

#ifndef rtmSetSampleHitPtr
#define rtmSetSampleHitPtr(rtm, val)   ((rtm)->Timing.sampleHits = (val))
#endif

#ifndef rtmGetSampleTimeArray
#define rtmGetSampleTimeArray(rtm)     ((rtm)->Timing.sampleTimesArray)
#endif

#ifndef rtmSetSampleTimeArray
#define rtmSetSampleTimeArray(rtm, val) ((rtm)->Timing.sampleTimesArray = (val))
#endif

#ifndef rtmGetSampleTimePtr
#define rtmGetSampleTimePtr(rtm)       ((rtm)->Timing.sampleTimes)
#endif

#ifndef rtmSetSampleTimePtr
#define rtmSetSampleTimePtr(rtm, val)  ((rtm)->Timing.sampleTimes = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDArray
#define rtmGetSampleTimeTaskIDArray(rtm) ((rtm)->Timing.sampleTimeTaskIDArray)
#endif

#ifndef rtmSetSampleTimeTaskIDArray
#define rtmSetSampleTimeTaskIDArray(rtm, val) ((rtm)->Timing.sampleTimeTaskIDArray = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDPtr
#define rtmGetSampleTimeTaskIDPtr(rtm) ((rtm)->Timing.sampleTimeTaskIDPtr)
#endif

#ifndef rtmSetSampleTimeTaskIDPtr
#define rtmSetSampleTimeTaskIDPtr(rtm, val) ((rtm)->Timing.sampleTimeTaskIDPtr = (val))
#endif

#ifndef rtmGetSelf
#define rtmGetSelf(rtm)                ()
#endif

#ifndef rtmSetSelf
#define rtmSetSelf(rtm, val)           ()
#endif

#ifndef rtmGetSimMode
#define rtmGetSimMode(rtm)             ((rtm)->simMode)
#endif

#ifndef rtmSetSimMode
#define rtmSetSimMode(rtm, val)        ((rtm)->simMode = (val))
#endif

#ifndef rtmGetSimTimeStep
#define rtmGetSimTimeStep(rtm)         ((rtm)->Timing.simTimeStep)
#endif

#ifndef rtmSetSimTimeStep
#define rtmSetSimTimeStep(rtm, val)    ((rtm)->Timing.simTimeStep = (val))
#endif

#ifndef rtmGetStartTime
#define rtmGetStartTime(rtm)           ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetStartTime
#define rtmSetStartTime(rtm, val)      ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmGetStepSize
#define rtmGetStepSize(rtm)            ((rtm)->Timing.stepSize)
#endif

#ifndef rtmSetStepSize
#define rtmSetStepSize(rtm, val)       ((rtm)->Timing.stepSize = (val))
#endif

#ifndef rtmGetStopRequestedFlag
#define rtmGetStopRequestedFlag(rtm)   ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequestedFlag
#define rtmSetStopRequestedFlag(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetTaskCounters
#define rtmGetTaskCounters(rtm)        ((rtm)->Timing.TaskCounters)
#endif

#ifndef rtmSetTaskCounters
#define rtmSetTaskCounters(rtm, val)   ((rtm)->Timing.TaskCounters = (val))
#endif

#ifndef rtmGetTaskTimeArray
#define rtmGetTaskTimeArray(rtm)       ((rtm)->Timing.tArray)
#endif

#ifndef rtmSetTaskTimeArray
#define rtmSetTaskTimeArray(rtm, val)  ((rtm)->Timing.tArray = (val))
#endif

#ifndef rtmGetTimePtr
#define rtmGetTimePtr(rtm)             ((rtm)->Timing.t)
#endif

#ifndef rtmSetTimePtr
#define rtmSetTimePtr(rtm, val)        ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTimingData
#define rtmGetTimingData(rtm)          ((rtm)->Timing.timingData)
#endif

#ifndef rtmSetTimingData
#define rtmSetTimingData(rtm, val)     ((rtm)->Timing.timingData = (val))
#endif

#ifndef rtmGetU
#define rtmGetU(rtm)                   ((rtm)->inputs)
#endif

#ifndef rtmSetU
#define rtmSetU(rtm, val)              ((rtm)->inputs = (val))
#endif

#ifndef rtmGetVarNextHitTimesListPtr
#define rtmGetVarNextHitTimesListPtr(rtm) ((rtm)->Timing.varNextHitTimesList)
#endif

#ifndef rtmSetVarNextHitTimesListPtr
#define rtmSetVarNextHitTimesListPtr(rtm, val) ((rtm)->Timing.varNextHitTimesList = (val))
#endif

#ifndef rtmGetY
#define rtmGetY(rtm)                   ((rtm)->outputs)
#endif

#ifndef rtmSetY
#define rtmSetY(rtm, val)              ((rtm)->outputs = (val))
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetZCSignalValues
#define rtmGetZCSignalValues(rtm)      ((rtm)->zcSignalValues)
#endif

#ifndef rtmSetZCSignalValues
#define rtmSetZCSignalValues(rtm, val) ((rtm)->zcSignalValues = (val))
#endif

#ifndef rtmGet_TimeOfLastOutput
#define rtmGet_TimeOfLastOutput(rtm)   ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmSet_TimeOfLastOutput
#define rtmSet_TimeOfLastOutput(rtm, val) ((rtm)->Timing.timeOfLastOutput = (val))
#endif

#ifndef rtmGetdX
#define rtmGetdX(rtm)                  ((rtm)->derivs)
#endif

#ifndef rtmSetdX
#define rtmSetdX(rtm, val)             ((rtm)->derivs = (val))
#endif

#ifndef rtmGettimingBridge
#define rtmGettimingBridge(rtm)        ()
#endif

#ifndef rtmSettimingBridge
#define rtmSettimingBridge(rtm, val)   ()
#endif

#ifndef rtmGetChecksumVal
#define rtmGetChecksumVal(rtm, idx)    ((rtm)->Sizes.checksums[idx])
#endif

#ifndef rtmSetChecksumVal
#define rtmSetChecksumVal(rtm, idx, val) ((rtm)->Sizes.checksums[idx] = (val))
#endif

#ifndef rtmGetDWork
#define rtmGetDWork(rtm, idx)          ((rtm)->dwork[idx])
#endif

#ifndef rtmSetDWork
#define rtmSetDWork(rtm, idx, val)     ((rtm)->dwork[idx] = (val))
#endif

#ifndef rtmGetOffsetTime
#define rtmGetOffsetTime(rtm, idx)     ((rtm)->Timing.offsetTimes[idx])
#endif

#ifndef rtmSetOffsetTime
#define rtmSetOffsetTime(rtm, idx, val) ((rtm)->Timing.offsetTimes[idx] = (val))
#endif

#ifndef rtmGetSFunction
#define rtmGetSFunction(rtm, idx)      ((rtm)->childSfunctions[idx])
#endif

#ifndef rtmSetSFunction
#define rtmSetSFunction(rtm, idx, val) ((rtm)->childSfunctions[idx] = (val))
#endif

#ifndef rtmGetSampleTime
#define rtmGetSampleTime(rtm, idx)     ((rtm)->Timing.sampleTimes[idx])
#endif

#ifndef rtmSetSampleTime
#define rtmSetSampleTime(rtm, idx, val) ((rtm)->Timing.sampleTimes[idx] = (val))
#endif

#ifndef rtmGetSampleTimeTaskID
#define rtmGetSampleTimeTaskID(rtm, idx) ((rtm)->Timing.sampleTimeTaskIDPtr[idx])
#endif

#ifndef rtmSetSampleTimeTaskID
#define rtmSetSampleTimeTaskID(rtm, idx, val) ((rtm)->Timing.sampleTimeTaskIDPtr[idx] = (val))
#endif

#ifndef rtmGetVarNextHitTimeList
#define rtmGetVarNextHitTimeList(rtm, idx) ((rtm)->Timing.varNextHitTimesList[idx])
#endif

#ifndef rtmSetVarNextHitTimeList
#define rtmSetVarNextHitTimeList(rtm, idx, val) ((rtm)->Timing.varNextHitTimesList[idx] = (val))
#endif

#ifndef rtmIsContinuousTask
#define rtmIsContinuousTask(rtm, tid)  ((tid) <= 1)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmIsMajorTimeStep
#define rtmIsMajorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
#define rtmIsMinorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmIsSampleHit
#define rtmIsSampleHit(rtm, sti, tid)  (((rtm)->Timing.sampleTimeTaskIDPtr[sti] == (tid)))
#endif

#ifndef rtmStepTask
#define rtmStepTask(rtm, idx)          ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmSetT
#define rtmSetT(rtm, val)                                        /* Do Nothing */
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetTFinal
#define rtmSetTFinal(rtm, val)         ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmSetTPtr
#define rtmSetTPtr(rtm, val)           ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetTStart
#define rtmSetTStart(rtm, val)         ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmTaskCounter
#define rtmTaskCounter(rtm, idx)       ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

#ifndef rtmGetTaskTime
#define rtmGetTaskTime(rtm, sti)       (rtmGetTPtr((rtm))[(rtm)->Timing.sampleTimeTaskIDPtr[sti]])
#endif

#ifndef rtmSetTaskTime
#define rtmSetTaskTime(rtm, sti, val)  (rtmGetTPtr((rtm))[sti] = (val))
#endif

#ifndef rtmGetTimeOfLastOutput
#define rtmGetTimeOfLastOutput(rtm)    ((rtm)->Timing.timeOfLastOutput)
#endif

#ifdef rtmGetRTWSolverInfo
#undef rtmGetRTWSolverInfo
#endif

#define rtmGetRTWSolverInfo(rtm)       &((rtm)->solverInfo)

/* Definition for use in the target main file */
#define auto_pilot_upl_rtModel         RT_MODEL_auto_pilot_upl_T

/* Block signals for system '<S214>/MATLAB Function' */
typedef struct {
  real_T y[10];                        /* '<S214>/MATLAB Function' */
} B_MATLABFunction_auto_pilot_upl_T;

/* Block signals for system '<S321>/manipulation_of_objects' */
typedef struct {
  real_T filtered_matrix[100];         /* '<S321>/manipulation_of_objects' */
} B_manipulation_of_objects_auto_pilot_upl_T;

/* Block signals (default storage) */
typedef struct {
  real_T VI_DriveSimInputsECATBECKHANA3;
                                 /* '<S7>/VI_DriveSim.Inputs.ECAT.BECKH.ANA3' */
  real_T VI_CarRealTimeOutputstransmissiongear;
                           /* '<S7>/VI_CarRealTime.Outputs.transmission.gear' */
  real_T VI_DriveSimInputsECATBECKHANA1;
                                 /* '<S7>/VI_DriveSim.Inputs.ECAT.BECKH.ANA1' */
  real_T VI_DriveSimInputsECATBECKHDIG4;
                                 /* '<S7>/VI_DriveSim.Inputs.ECAT.BECKH.DIG4' */
  real_T VI_CarRealTimeOutputschassis_velocitieslongitudinal;
           /* '<Root>/VI_CarRealTime.Outputs.chassis_velocities.longitudinal' */
  real_T VI_DriveSimOutputsVicrtStatus;
                                   /* '<S7>/VI_DriveSim.Outputs.Vicrt.Status' */
  real_T VI_CarRealTimeOutputsdriver_demandsbrake;
                      /* '<Root>/VI_CarRealTime.Outputs.driver_demands.brake' */
  real_T VI_CarRealTimeOutputsWheelSpindle_SteerL1;
                    /* '<Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.L1' */
  real_T VI_CarRealTimeOutputsWheelSpindle_SteerR1;
                    /* '<Root>/VI_CarRealTime.Outputs.Wheel.Spindle_Steer.R1' */
  real_T VI_CarRealTimeOutputsdriver_demandsthrottle;
                   /* '<Root>/VI_CarRealTime.Outputs.driver_demands.throttle' */
  real_T VI_CarRealTimeOutputsdriver_demandssteering;
                   /* '<Root>/VI_CarRealTime.Outputs.driver_demands.steering' */
  real_T VI_CarRealTimeOutputsSteering_SystemDriveSim_Steering_Feedback_Torque;
  /* '<Root>/VI_CarRealTime.Outputs.Steering_System.DriveSim_Steering_Feedback_Torque' */
  real_T VI_CarRealTimeOutputschassis_accelerationslateral;
             /* '<Root>/VI_CarRealTime.Outputs.chassis_accelerations.lateral' */
  real_T VI_CarRealTimeOutputschassis_accelerationslongitudinal;
        /* '<Root>/VI_CarRealTime.Outputs.chassis_accelerations.longitudinal' */
  real_T VI_DriveSimInputsECATBECKHDIG3;
                                 /* '<S7>/VI_DriveSim.Inputs.ECAT.BECKH.DIG3' */
  real_T CastToDouble;                 /* '<S8>/Cast To Double' */
  real_T Product;                      /* '<S8>/Product' */
  real_T Uk1;                          /* '<S14>/Delay Input1' */
  real_T Memory;                       /* '<S11>/Memory' */
  real_T Switch;                       /* '<S11>/Switch' */
  real_T Product_o;                    /* '<S11>/Product' */
  real_T Product2;                     /* '<S16>/Product2' */
  real_T Product1;                     /* '<S16>/Product1' */
  real_T DataTypeConversion;           /* '<S16>/Data Type Conversion' */
  real_T RateTransition7[30];          /* '<S215>/Rate Transition7' */
  real_T Target_X_Distance_mux[30];    /* '<S215>/Target_XY_Distance' */
  real_T RateLimiter;                  /* '<S215>/Rate Limiter' */
  real_T Delay1[30];                   /* '<S215>/Delay1' */
  real_T Switch2[30];                  /* '<S215>/Switch2' */
  real_T TmpRTBAtProduct5Inport1[30];
  real_T RateTransition6;              /* '<S215>/Rate Transition6' */
  real_T Product2_h;                   /* '<S216>/Product2' */
  real_T Switch_h[5];                  /* '<S216>/Switch' */
  real_T Memory_i;                     /* '<S16>/Memory' */
  real_T Switch_o;                     /* '<S16>/Switch' */
  real_T Uk1_p;                        /* '<S23>/Delay Input1' */
  real_T Memory_d;                     /* '<S15>/Memory' */
  real_T Product8;                     /* '<S15>/Product8' */
  real_T Error2;                       /* '<S15>/Error2' */
  real_T Switch1;                      /* '<S330>/Switch1' */
  real_T Fcn1;                         /* '<S330>/Fcn1' */
  real_T TmpRTBAtMultiportSwitchInport3[120];
  real_T MultiportSwitch[120];         /* '<S324>/Multiport Switch' */
  real_T Gain1;                        /* '<S199>/Gain1' */
  real_T MinMax;                       /* '<S197>/MinMax' */
  real_T Product4;                     /* '<S15>/Product4' */
  real_T Saturation;                   /* '<S124>/Saturation' */
  real_T TmpRTBAtSumInport1;
  real_T TmpRTBAtTsampOutport1;        /* '<S163>/Tsamp' */
  real_T Saturation_o;                 /* '<S175>/Saturation' */
  real_T Memory1;                      /* '<S15>/Memory1' */
  real_T Memory2;                      /* '<S15>/Memory2' */
  real_T setspeedmemory;               /* '<S15>/Switch2' */
  real_T Switch1_e;                    /* '<S15>/Switch1' */
  real_T differencebetweerreferenceandactualspeed;/* '<S15>/Product1' */
  real_T Product2_g;                   /* '<S15>/Product2' */
  real_T Saturation_d;                 /* '<S74>/Saturation' */
  real_T Sum;                          /* '<S15>/Sum' */
  real_T Sum_e;                        /* '<S34>/Sum' */
  real_T Sum_p;                        /* '<S33>/Sum' */
  real_T Sum_a;                        /* '<S26>/Sum' */
  real_T Sum_l;                        /* '<S27>/Sum' */
  real_T Saturation8;                  /* '<S15>/Saturation8' */
  real_T Sum1;                         /* '<S15>/Sum1' */
  real_T Sum_g;                        /* '<S30>/Sum' */
  real_T Sum_py;                       /* '<S29>/Sum' */
  real_T Sum_ep;                       /* '<S31>/Sum' */
  real_T Sum_h;                        /* '<S32>/Sum' */
  real_T Saturation9;                  /* '<S15>/Saturation9' */
  real_T Product2_n;                   /* '<S10>/Product2' */
  real_T Max;                          /* '<S319>/Max' */
  real_T Max1;                         /* '<S319>/Max1' */
  real_T DataTypeConversion6;          /* '<S7>/Data Type Conversion6' */
  real_T Gain4;                        /* '<S249>/Gain4' */
  real_T RateTransition8;              /* '<S250>/Rate Transition8' */
  real_T Product5;                     /* '<S250>/Product5' */
  real_T DataTypeConversion3;          /* '<S250>/Data Type Conversion3' */
  real_T DataTypeConversion2_g;        /* '<S250>/Data Type Conversion2' */
  real_T Product6;                     /* '<S250>/Product6' */
  real_T Integrator;                   /* '<S250>/Integrator' */
  real_T Memory_f;                     /* '<S250>/Memory' */
  real_T Switch_j;                     /* '<S250>/Switch' */
  real_T RateLimiter1;                 /* '<S250>/Rate Limiter1' */
  real_T RateTransition5;              /* '<S250>/Rate Transition5' */
  real_T Gain2;                        /* '<S250>/Gain2' */
  real_T DataTypeConversion4;          /* '<S7>/Data Type Conversion4' */
  real_T SumI4;                        /* '<S60>/SumI4' */
  real_T Sum_k;                        /* '<S19>/Sum' */
  real_T MultiportSwitch_h;            /* '<S19>/Multiport Switch' */
  real_T SumI4_k;                      /* '<S110>/SumI4' */
  real_T TmpRTBAtSumI4Inport2;
  real_T SumI4_a;                      /* '<S159>/SumI4' */
  real_T Product1_n;                   /* '<S10>/Product1' */
  real_T RateLimiter_p;                /* '<S10>/Rate Limiter' */
  real_T Sum_g0;                       /* '<S10>/Sum' */
  real_T PulseGenerator;               /* '<S216>/Pulse Generator' */
  real_T Product1_m;                   /* '<S216>/Product1' */
  real_T Product_p;                    /* '<S216>/Product' */
  real_T RateTransition5_n;            /* '<S215>/Rate Transition5' */
  real_T Gain2_l[10];                  /* '<S214>/Gain2' */
  real_T Gain4_n[10];                  /* '<S214>/Gain4' */
  real_T Gain5[10];                    /* '<S214>/Gain5' */
  real_T Gain[10];                     /* '<S214>/Gain' */
  real_T Gain1_i[10];                  /* '<S214>/Gain1' */
  real_T Gain3[10];                    /* '<S214>/Gain3' */
  real_T after_saturation[30];         /* '<S215>/Saturation' */
  real_T TmpRTBAtSumOutport1;          /* '<S329>/Sum' */
  real_T DiscreteFilter;               /* '<S329>/Discrete Filter' */
  real_T TmpRTBAtDiscreteFilter1Inport1;/* '<S329>/Sum1' */
  real_T DiscreteFilter1;              /* '<S329>/Discrete Filter1' */
  real_T CastToDouble_k;               /* '<S322>/Cast To Double' */
  real_T CastToDouble1;                /* '<S322>/Cast To Double1' */
  real_T Product_l;                    /* '<S7>/Product' */
  real_T Product1_g;                   /* '<S7>/Product1' */
  real_T messagecount[2];        /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  real_T lanecoefficients2x4[8]; /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  real_T matrix_lanes_points[610];
                                 /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  real_T valid_matrix_lanes_points;
                                 /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  real_T matrix_obstacles[100];  /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  real_T valid_matrix_obstacles; /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  real_T matrix_objects[100];    /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  real_T valid_matrix_objects;   /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  real_T messagecount_m[2];     /* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  real_T lanecoefficients2x4_f[8];
                                /* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  real_T matrix_lanes_points_b[610];
                                /* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  real_T valid_matrix_lanes_points_b;
                                /* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  real_T matrix_obstacles_a[100];
                                /* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  real_T valid_matrix_obstacles_k;
                                /* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  real_T matrix_objects_o[100]; /* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  real_T valid_matrix_objects_m;/* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  real_T collisionmsginfo[2];          /* '<S321>/VI_WorldSim_State_Manager' */
  real_T VI_WorldSim_State_Manager_o2[3];/* '<S321>/VI_WorldSim_State_Manager' */
  real_T VI_WorldSim_State_Manager_o3; /* '<S321>/VI_WorldSim_State_Manager' */
  real_T VI_WorldSim_State_Manager_o4[9];/* '<S321>/VI_WorldSim_State_Manager' */
  real_T additivecollision;            /* '<S321>/Sum' */
  real_T TSamp;                        /* '<S262>/TSamp' */
  real_T TSamp_p;                      /* '<S263>/TSamp' */
  real_T RateTransition1;              /* '<S250>/Rate Transition1' */
  real_T Tsamp;                        /* '<S296>/Tsamp' */
  real_T IProdOut;                     /* '<S298>/IProd Out' */
  real_T DifferenceInputs2;            /* '<S266>/Difference Inputs2' */
  real_T RateTransition[90];           /* '<S215>/Rate Transition' */
  real_T TSamp_d[30];                  /* '<S244>/TSamp' */
  real_T TSamp_k[30];                  /* '<S243>/TSamp' */
  real_T TSamp_f[30];                  /* '<S242>/TSamp' */
  real_T Gain1_o[30];                  /* '<S215>/Gain1' */
  real_T Gain_a[30];                   /* '<S235>/Gain' */
  real_T CastToDouble1_p;              /* '<S11>/Cast To Double1' */
  boolean_T FixPtRelationalOperator;   /* '<S194>/FixPt Relational Operator' */
  boolean_T Compare;                   /* '<S12>/Compare' */
  boolean_T Uk1_i;                     /* '<S13>/Delay Input1' */
  boolean_T LogicalOperator;           /* '<S8>/Logical Operator' */
  boolean_T Uk1_k;                     /* '<S193>/Delay Input1' */
  boolean_T Compare_d;                 /* '<S228>/Compare' */
  boolean_T Compare_m;                 /* '<S190>/Compare' */
  boolean_T OR;                        /* '<S15>/OR' */
  boolean_T FixPtRelationalOperator_a; /* '<S24>/FixPt Relational Operator' */
  boolean_T Compare_i;                 /* '<S206>/Compare' */
  boolean_T Compare_k;                 /* '<S204>/Compare' */
  boolean_T Compare_n;                 /* '<S253>/Compare' */
  boolean_T Compare_ix;                /* '<S256>/Compare' */
  boolean_T Compare_k0;                /* '<S254>/Compare' */
  boolean_T Compare_g;                 /* '<S258>/Compare' */
  boolean_T delatch;                   /* '<S250>/Memory1' */
  boolean_T Compare_e;                 /* '<S236>/Compare' */
  boolean_T Compare_j;                 /* '<S237>/Compare' */
  boolean_T Compare_i5;                /* '<S255>/Compare' */
  boolean_T TmpSignalConversionAtDelayInport1[150];
  B_manipulation_of_objects_auto_pilot_upl_T sf_manipulation_of_objects1;/* '<S321>/manipulation_of_objects1' */
  B_manipulation_of_objects_auto_pilot_upl_T sf_manipulation_of_objects;/* '<S321>/manipulation_of_objects' */
  B_MATLABFunction_auto_pilot_upl_T sf_MATLABFunction1;/* '<S214>/MATLAB Function1' */
  B_MATLABFunction_auto_pilot_upl_T sf_MATLABFunction_f;/* '<S214>/MATLAB Function' */
} B_auto_pilot_upl_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T UD_DSTATE;                    /* '<S27>/UD' */
  real_T UD_DSTATE_n;                  /* '<S26>/UD' */
  real_T UD_DSTATE_d;                  /* '<S33>/UD' */
  real_T UD_DSTATE_o;                  /* '<S34>/UD' */
  real_T DelayInput1_DSTATE;           /* '<S194>/Delay Input1' */
  real_T DelayInput1_DSTATE_a;         /* '<S14>/Delay Input1' */
  real_T Delay1_DSTATE[30];            /* '<S215>/Delay1' */
  real_T DelayInput1_DSTATE_n;         /* '<S23>/Delay Input1' */
  real_T Integrator_DSTATE;            /* '<S117>/Integrator' */
  real_T Integrator_DSTATE_i;          /* '<S168>/Integrator' */
  real_T UD_DSTATE_e;                  /* '<S161>/UD' */
  real_T DelayInput1_DSTATE_l;         /* '<S24>/Delay Input1' */
  real_T Integrator_DSTATE_i3;         /* '<S67>/Integrator' */
  real_T UD_DSTATE_p;                  /* '<S32>/UD' */
  real_T UD_DSTATE_ou;                 /* '<S31>/UD' */
  real_T UD_DSTATE_f;                  /* '<S29>/UD' */
  real_T UD_DSTATE_em;                 /* '<S30>/UD' */
  real_T DelayInput1_DSTATE_g;         /* '<S84>/Delay Input1' */
  real_T DelayInput1_DSTATE_j;         /* '<S85>/Delay Input1' */
  real_T filtering_states[60];         /* '<S215>/filtering' */
  real_T DiscreteFilter_states[2];     /* '<S329>/Discrete Filter' */
  real_T DiscreteFilter1_states[2];    /* '<S329>/Discrete Filter1' */
  real_T UD_DSTATE_i;                  /* '<S262>/UD' */
  real_T UD_DSTATE_df;                 /* '<S263>/UD' */
  real_T UD_DSTATE_j;                  /* '<S294>/UD' */
  real_T Integrator_DSTATE_c;          /* '<S301>/Integrator' */
  real_T DelayInput2_DSTATE;           /* '<S266>/Delay Input2' */
  real_T UD_DSTATE_a[30];              /* '<S244>/UD' */
  real_T UD_DSTATE_pg[30];             /* '<S243>/UD' */
  real_T UD_DSTATE_h[30];              /* '<S242>/UD' */
  real_T DelayInput1_DSTATE_f[30];     /* '<S230>/Delay Input1' */
  real_T Delay_DSTATE[30];             /* '<S215>/Delay' */
  real_T UD_DSTATE_nt[30];             /* '<S246>/UD' */
  real_T Memory_PreviousInput;         /* '<S11>/Memory' */
  real_T RateTransition7_Buffer0[30];  /* '<S215>/Rate Transition7' */
  real_T Target_X_Distance_mux_Buffer0[30];/* synthesized block */
  real_T PrevY;                        /* '<S215>/Rate Limiter1' */
  real_T PrevYA;                       /* '<S215>/Rate Limiter' */
  real_T PrevYB;                       /* '<S215>/Rate Limiter' */
  real_T LastMajorTimeA;               /* '<S215>/Rate Limiter' */
  real_T LastMajorTimeB;               /* '<S215>/Rate Limiter' */
  real_T TmpRTBAtProduct5Inport1_Buffer0[30];/* synthesized block */
  real_T RateTransition6_Buffer0;      /* '<S215>/Rate Transition6' */
  real_T Memory_PreviousInput_b;       /* '<S16>/Memory' */
  real_T Memory_PreviousInput_l;       /* '<S15>/Memory' */
  real_T TmpRTBAtMultiportSwitchInport3_Buffer0[120];/* synthesized block */
  real_T TmpRTBAtSumInport1_Buffer0;   /* synthesized block */
  real_T TmpRTBAtTsampOutport1_Buffer0;/* synthesized block */
  real_T Memory1_PreviousInput;        /* '<S15>/Memory1' */
  real_T Memory2_PreviousInput;        /* '<S15>/Memory2' */
  real_T Memory2_PreviousInput_c;      /* '<S250>/Memory2' */
  real_T RateTransition8_Buffer0;      /* '<S250>/Rate Transition8' */
  real_T Memory_PreviousInput_n;       /* '<S250>/Memory' */
  real_T PrevYA_p;                     /* '<S250>/Rate Limiter1' */
  real_T PrevYB_e;                     /* '<S250>/Rate Limiter1' */
  real_T LastMajorTimeA_g;             /* '<S250>/Rate Limiter1' */
  real_T LastMajorTimeB_b;             /* '<S250>/Rate Limiter1' */
  real_T RateTransition5_Buffer0;      /* '<S250>/Rate Transition5' */
  real_T Memory_PreviousInput_a;       /* '<S19>/Memory' */
  real_T RateTransition_Buffer;        /* '<S15>/Rate Transition' */
  real_T RateTransition1_Buffer;       /* '<S15>/Rate Transition1' */
  real_T TmpRTBAtSumI4Inport2_Buffer0; /* synthesized block */
  real_T PrevYA_c;                     /* '<S10>/Rate Limiter' */
  real_T PrevYB_f;                     /* '<S10>/Rate Limiter' */
  real_T LastMajorTimeA_gx;            /* '<S10>/Rate Limiter' */
  real_T LastMajorTimeB_e;             /* '<S10>/Rate Limiter' */
  real_T RateTransition5_Buffer0_h;    /* '<S215>/Rate Transition5' */
  real_T RateTransition2_Buffer[30];   /* '<S221>/Rate Transition2' */
  real_T after_saturation_Buffer0[30]; /* synthesized block */
  real_T filtering_tmp[30];            /* '<S215>/filtering' */
  real_T RateTransition1_Buffer_g[30]; /* '<S231>/Rate Transition1' */
  real_T RateTransition_Buffer_h[90];  /* '<S215>/Rate Transition' */
  real_T RateTransition1_Buffer_b[30]; /* '<S215>/Rate Transition1' */
  real_T RateTransition_Buffer_a;      /* '<S239>/Rate Transition' */
  real_T TmpRTBAtSumOutport1_Buffer0;  /* synthesized block */
  real_T DiscreteFilter_tmp;           /* '<S329>/Discrete Filter' */
  real_T TmpRTBAtDiscreteFilter1Inport1_Buffer0;/* synthesized block */
  real_T DiscreteFilter1_tmp;          /* '<S329>/Discrete Filter1' */
  real_T RateTransition_Buffer_f[2];   /* '<S250>/Rate Transition' */
  real_T RateTransition1_Buffer_e;     /* '<S250>/Rate Transition1' */
  real_T RateTransition2_Buffer_n;     /* '<S250>/Rate Transition2' */
  real_T VI_WorldSim_Sensor_VirtualCamera_DWORK2;
                                 /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  real_T VI_WorldSim_Sensor_VirtualCamera_DWORK3;
                                 /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  real_T VI_WorldSim_Sensor_VirtualCamera_DWORK4;
                                 /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  real_T VI_WorldSim_Sensor_VirtualCamera1_DWORK2;
                                /* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  real_T VI_WorldSim_Sensor_VirtualCamera1_DWORK3;
                                /* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  real_T VI_WorldSim_Sensor_VirtualCamera1_DWORK4;
                                /* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  real_T Memory_PreviousInput_d;       /* '<S321>/Memory' */
  real_T VI_WorldSim_State_Manager_DWORK2;/* '<S321>/VI_WorldSim_State_Manager' */
  real_T VI_WorldSim_State_Manager_DWORK3;/* '<S321>/VI_WorldSim_State_Manager' */
  real_T VI_WorldSim_State_Manager_DWORK4;/* '<S321>/VI_WorldSim_State_Manager' */
  real_T PrevY_m;                      /* '<S250>/Rate Limiter' */
  void *VI_WorldSim_Sensor_VirtualCamera_PWORK;
                                 /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  void *VI_WorldSim_Sensor_VirtualCamera1_PWORK;
                                /* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  void *VI_WorldSim_State_Manager_PWORK;/* '<S321>/VI_WorldSim_State_Manager' */
  int32_T clockTickCounter;            /* '<S215>/Pulse Generator' */
  int32_T clockTickCounter_k;          /* '<S216>/Pulse Generator' */
  int32_T clockTickCounter_h;          /* '<S329>/Pulse Generator' */
  uint32_T derivation_speed_ELAPS_T[2];/* '<S215>/derivation_speed' */
  uint32_T derivation_speed_PREV_T[2]; /* '<S215>/derivation_speed' */
  boolean_T DelayInput1_DSTATE_h;      /* '<S13>/Delay Input1' */
  boolean_T DelayInput1_DSTATE_ay;     /* '<S193>/Delay Input1' */
  boolean_T Delay_DSTATE_l[150];       /* '<S221>/Delay' */
  boolean_T Delay1_DSTATE_i[300];      /* '<S221>/Delay1' */
  boolean_T Delay2_DSTATE[450];        /* '<S221>/Delay2' */
  int8_T Integrator_PrevResetState;    /* '<S117>/Integrator' */
  int8_T Integrator_PrevResetState_d;  /* '<S168>/Integrator' */
  int8_T Integrator_PrevResetState_c;  /* '<S67>/Integrator' */
  int8_T Integrator_PrevResetState_j;  /* '<S301>/Integrator' */
  uint8_T Integrator_IC_LOADING;       /* '<S67>/Integrator' */
  uint8_T Integrator_IC_LOADING_j;     /* '<S301>/Integrator' */
  boolean_T Memory1_PreviousInput_n;   /* '<S250>/Memory1' */
  boolean_T RateTransition_Buffer_e;   /* '<S221>/Rate Transition' */
  boolean_T RateTransition1_Buffer_f;  /* '<S221>/Rate Transition1' */
  boolean_T VI_WorldSim_Sensor_VirtualCamera_DWORK1;
                                 /* '<S321>/VI_WorldSim_Sensor_VirtualCamera' */
  boolean_T VI_WorldSim_Sensor_VirtualCamera1_DWORK1;
                                /* '<S321>/VI_WorldSim_Sensor_VirtualCamera1' */
  boolean_T VI_WorldSim_State_Manager_DWORK1;/* '<S321>/VI_WorldSim_State_Manager' */
  boolean_T icLoad;                    /* '<S294>/UD' */
} DW_auto_pilot_upl_T;

/* Continuous states (default storage) */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S250>/Integrator' */
  real_T Integrator1_CSTATE;           /* '<S250>/Integrator1' */
} X_auto_pilot_upl_T;

/* State derivatives (default storage) */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S250>/Integrator' */
  real_T Integrator1_CSTATE;           /* '<S250>/Integrator1' */
} XDot_auto_pilot_upl_T;

/* State disabled  */
typedef struct {
  boolean_T Integrator_CSTATE;         /* '<S250>/Integrator' */
  boolean_T Integrator1_CSTATE;        /* '<S250>/Integrator1' */
} XDis_auto_pilot_upl_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState UD_Reset_ZCE;             /* '<S161>/UD' */
  ZCSigState Integrator_Reset_ZCE;     /* '<S250>/Integrator' */
  ZCSigState Integrator1_Reset_ZCE;    /* '<S250>/Integrator1' */
  ZCSigState UD_Reset_ZCE_m;           /* '<S294>/UD' */
  ZCSigState derivation_speed_Trig_ZCE;/* '<S329>/derivation_speed' */
  ZCSigState derivation_speed_Trig_ZCE_l;/* '<S215>/derivation_speed' */
} PrevZCX_auto_pilot_upl_T;

#ifndef ODE14X_INTG
#define ODE14X_INTG

/* ODE14X Integration Data */
typedef struct {
  real_T *x0;
  real_T *f0;
  real_T *x1start;
  real_T *f1;
  real_T *Delta;
  real_T *E;
  real_T *fac;
  real_T *DFDX;
  real_T *W;
  int_T *pivots;
  real_T *xtmp;
  real_T *ztmp;
  real_T *M;
  real_T *M1;
  real_T *Edot;
  real_T *xdot;
  real_T *fminusMxdot;
  boolean_T isFirstStep;
} ODE14X_IntgData;

#endif

/* Backward compatible GRT Identifiers */
#define rtB                            auto_pilot_upl_B
#define BlockIO                        B_auto_pilot_upl_T
#define rtX                            auto_pilot_upl_X
#define ContinuousStates               X_auto_pilot_upl_T
#define rtXdot                         auto_pilot_upl_XDot
#define StateDerivatives               XDot_auto_pilot_upl_T
#define tXdis                          auto_pilot_upl_XDis
#define StateDisabled                  XDis_auto_pilot_upl_T
#define rtP                            auto_pilot_upl_P
#define Parameters                     P_auto_pilot_upl_T
#define rtDWork                        auto_pilot_upl_DW
#define D_Work                         DW_auto_pilot_upl_T
#define rtPrevZCSigState               auto_pilot_upl_PrevZCX
#define PrevZCSigStates                PrevZCX_auto_pilot_upl_T

/* Parameters (default storage) */
struct P_auto_pilot_upl_T_ {
  real_T ACC_Adaptive_P[2];            /* Variable: ACC_Adaptive_P
                                        * Referenced by:
                                        *   '<S35>/ACC_Adaptive_P'
                                        *   '<S35>/ACC_Adaptive_P2'
                                        */
  real_T ACC_Classic_I;                /* Variable: ACC_Classic_I
                                        * Referenced by:
                                        *   '<S64>/Integral Gain'
                                        *   '<S114>/Integral Gain'
                                        */
  real_T ACC_Classic_P;                /* Variable: ACC_Classic_P
                                        * Referenced by:
                                        *   '<S72>/Proportional Gain'
                                        *   '<S122>/Proportional Gain'
                                        */
  real_T ACC_MaxBrake;                 /* Variable: ACC_MaxBrake
                                        * Referenced by:
                                        *   '<S74>/Saturation'
                                        *   '<S124>/Saturation'
                                        *   '<S175>/Saturation'
                                        */
  real_T ACC_MaxThrottle;              /* Variable: ACC_MaxThrottle
                                        * Referenced by:
                                        *   '<S74>/Saturation'
                                        *   '<S124>/Saturation'
                                        *   '<S175>/Saturation'
                                        */
  real_T ACC_Module_Activity_Flag;     /* Variable: ACC_Module_Activity_Flag
                                        * Referenced by:
                                        *   '<S10>/ACC_Module_Activity_Flag1'
                                        *   '<S15>/ACC_Module_Activity_Flag'
                                        *   '<S16>/ACC_Module_Activity_Flag'
                                        */
  real_T ACC_Ready_Speed;              /* Variable: ACC_Ready_Speed
                                        * Referenced by: '<S185>/Constant'
                                        */
  real_T ACC_SensorMaxDistance;        /* Variable: ACC_SensorMaxDistance
                                        * Referenced by:
                                        *   '<S15>/Target_Distance_Saturation'
                                        *   '<S20>/Constant'
                                        *   '<S21>/Constant'
                                        *   '<S197>/ACC_SensorMaxDistance'
                                        */
  real_T ACC_Speed_Distance_Gain[4];   /* Variable: ACC_Speed_Distance_Gain
                                        * Referenced by:
                                        *   '<S19>/ACC_Speed_Distance_Gain'
                                        *   '<S19>/ACC_Speed_Distance_Gain1'
                                        *   '<S19>/ACC_Speed_Distance_Gain2'
                                        *   '<S19>/ACC_Speed_Distance_Gain3'
                                        */
  real_T ACC_Speed_Distance_control;   /* Variable: ACC_Speed_Distance_control
                                        * Referenced by: '<S19>/Memory'
                                        */
  real_T ADAS_Control_Mode;            /* Variable: ADAS_Control_Mode
                                        * Referenced by:
                                        *   '<S231>/ADAS_Control_Mode'
                                        *   '<S264>/ADAS_Control_Mode'
                                        *   '<S35>/ADAS_Control_Mode'
                                        */
  real_T AEB_Distance_To_Collision_Brake;
                                    /* Variable: AEB_Distance_To_Collision_Brake
                                     * Referenced by: '<S222>/Constant'
                                     */
  real_T AEB_Gain[2];                  /* Variable: AEB_Gain
                                        * Referenced by:
                                        *   '<S239>/Gain'
                                        *   '<S239>/Gain1'
                                        */
  real_T AEB_Gain_set;                 /* Variable: AEB_Gain_set
                                        * Referenced by: '<S239>/Constant'
                                        */
  real_T AEB_Gain_set_mult;            /* Variable: AEB_Gain_set_mult
                                        * Referenced by: '<S239>/Gain2'
                                        */
  real_T AEB_Max_Decel[2];             /* Variable: AEB_Max_Decel
                                        * Referenced by:
                                        *   '<S231>/AEB_Max_Decel'
                                        *   '<S231>/AEB_Max_Decel1'
                                        */
  real_T AEB_Max_Speed;                /* Variable: AEB_Max_Speed
                                        * Referenced by:
                                        *   '<S247>/Constant'
                                        *   '<S236>/Constant'
                                        */
  real_T AEB_Min_Distance_at_Stop;     /* Variable: AEB_Min_Distance_at_Stop
                                        * Referenced by: '<S231>/Constant'
                                        */
  real_T AEB_Module_Activity_Flag;     /* Variable: AEB_Module_Activity_Flag
                                        * Referenced by: '<S216>/AEB_Module_Activity_Flag'
                                        */
  real_T AEB_Pedestrian_type;          /* Variable: AEB_Pedestrian_type
                                        * Referenced by: '<S238>/Constant'
                                        */
  real_T AEB_Steer_Max;                /* Variable: AEB_Steer_Max
                                        * Referenced by: '<S237>/Constant'
                                        */
  real_T AP_Activity_Flag;             /* Variable: AP_Activity_Flag
                                        * Referenced by:
                                        *   '<S10>/Constant4'
                                        *   '<S250>/Constant4'
                                        *   '<S15>/AP_Module_Activity_Flag'
                                        *   '<S16>/Constant4'
                                        */
  real_T AP_D[2];                      /* Variable: AP_D
                                        * Referenced by:
                                        *   '<S264>/AP_D(1)(1)'
                                        *   '<S264>/AP_D(2)(1)1'
                                        */
  real_T AP_Dyn_Rate_Limiter_Gain;     /* Variable: AP_Dyn_Rate_Limiter_Gain
                                        * Referenced by: '<S250>/Gain1'
                                        */
  real_T AP_Dyn_Rate_Limiter_Power;    /* Variable: AP_Dyn_Rate_Limiter_Power
                                        * Referenced by: '<S250>/Constant1'
                                        */
  real_T AP_Error_Max;                 /* Variable: AP_Error_Max
                                        * Referenced by: '<S250>/Saturation'
                                        */
  real_T AP_I[2];                      /* Variable: AP_I
                                        * Referenced by:
                                        *   '<S264>/AP_I(1)(1)'
                                        *   '<S264>/AP_I(2)(1)1'
                                        */
  real_T AP_Max_Error_dydt_Disable;    /* Variable: AP_Max_Error_dydt_Disable
                                        * Referenced by: '<S254>/Constant'
                                        */
  real_T AP_On_Request_Time;           /* Variable: AP_On_Request_Time
                                        * Referenced by: '<S252>/Constant'
                                        */
  real_T AP_P[2];                      /* Variable: AP_P
                                        * Referenced by:
                                        *   '<S264>/AP_P(1)(1)'
                                        *   '<S264>/AP_P(2)(1)1'
                                        */
  real_T AP_Steer_Error_Max;           /* Variable: AP_Steer_Error_Max
                                        * Referenced by: '<S255>/Constant'
                                        */
  real_T AP_Steer_Rate_Max_radps;      /* Variable: AP_Steer_Rate_Max_radps
                                        * Referenced by: '<S250>/Rate Limiter'
                                        */
  real_T AP_Transition_Rate;           /* Variable: AP_Transition_Rate
                                        * Referenced by: '<S250>/Rate Limiter1'
                                        */
  real_T Lane_Width;                   /* Variable: Lane_Width
                                        * Referenced by:
                                        *   '<S225>/Constant'
                                        *   '<S199>/Lane_Width//2'
                                        *   '<S210>/Constant'
                                        */
  real_T No_Target_Display_Value;      /* Variable: No_Target_Display_Value
                                        * Referenced by:
                                        *   '<S220>/No_Target_Display_Value'
                                        *   '<S198>/No_Target_Display_Value'
                                        */
  real_T radar_source;                 /* Variable: radar_source
                                        * Referenced by:
                                        *   '<S324>/Constant1'
                                        *   '<S198>/Constant1'
                                        */
  real_T vehicle_width;                /* Variable: vehicle_width
                                        * Referenced by:
                                        *   '<S325>/Semitrack'
                                        *   '<S199>/Constant'
                                        */
  real_T tACC_PID_DifferentiatorICPrevScaledInput;
                     /* Mask Parameter: tACC_PID_DifferentiatorICPrevScaledInput
                      * Referenced by: '<S161>/UD'
                      */
  real_T TransferFcnFirstOrder11_ICPrevOutput;
                         /* Mask Parameter: TransferFcnFirstOrder11_ICPrevOutput
                          * Referenced by: '<S27>/UD'
                          */
  real_T TransferFcnFirstOrder10_ICPrevOutput;
                         /* Mask Parameter: TransferFcnFirstOrder10_ICPrevOutput
                          * Referenced by: '<S26>/UD'
                          */
  real_T TransferFcnFirstOrder8_ICPrevOutput;
                          /* Mask Parameter: TransferFcnFirstOrder8_ICPrevOutput
                           * Referenced by: '<S33>/UD'
                           */
  real_T TransferFcnFirstOrder9_ICPrevOutput;
                          /* Mask Parameter: TransferFcnFirstOrder9_ICPrevOutput
                           * Referenced by: '<S34>/UD'
                           */
  real_T TransferFcnFirstOrder7_ICPrevOutput;
                          /* Mask Parameter: TransferFcnFirstOrder7_ICPrevOutput
                           * Referenced by: '<S32>/UD'
                           */
  real_T TransferFcnFirstOrder6_ICPrevOutput;
                          /* Mask Parameter: TransferFcnFirstOrder6_ICPrevOutput
                           * Referenced by: '<S31>/UD'
                           */
  real_T TransferFcnFirstOrder4_ICPrevOutput;
                          /* Mask Parameter: TransferFcnFirstOrder4_ICPrevOutput
                           * Referenced by: '<S29>/UD'
                           */
  real_T TransferFcnFirstOrder5_ICPrevOutput;
                          /* Mask Parameter: TransferFcnFirstOrder5_ICPrevOutput
                           * Referenced by: '<S30>/UD'
                           */
  real_T DiscreteDerivative_ICPrevScaledInput;
                         /* Mask Parameter: DiscreteDerivative_ICPrevScaledInput
                          * Referenced by: '<S246>/UD'
                          */
  real_T DiscreteDerivative_ICPrevScaledInput_d;
                       /* Mask Parameter: DiscreteDerivative_ICPrevScaledInput_d
                        * Referenced by: '<S262>/UD'
                        */
  real_T DiscreteDerivative1_ICPrevScaledInput;
                        /* Mask Parameter: DiscreteDerivative1_ICPrevScaledInput
                         * Referenced by: '<S263>/UD'
                         */
  real_T DiscreteDerivative2_ICPrevScaledInput;
                        /* Mask Parameter: DiscreteDerivative2_ICPrevScaledInput
                         * Referenced by: '<S244>/UD'
                         */
  real_T DiscreteDerivative1_ICPrevScaledInput_g;
                      /* Mask Parameter: DiscreteDerivative1_ICPrevScaledInput_g
                       * Referenced by: '<S243>/UD'
                       */
  real_T DiscreteDerivative_ICPrevScaledInput_j;
                       /* Mask Parameter: DiscreteDerivative_ICPrevScaledInput_j
                        * Referenced by: '<S242>/UD'
                        */
  real_T DiscretePIDController1_InitialConditionForIntegrator;
         /* Mask Parameter: DiscretePIDController1_InitialConditionForIntegrator
          * Referenced by: '<S117>/Integrator'
          */
  real_T tACC_PID_InitialConditionForIntegrator;
                       /* Mask Parameter: tACC_PID_InitialConditionForIntegrator
                        * Referenced by: '<S168>/Integrator'
                        */
  real_T ACC_PID_Kb;                   /* Mask Parameter: ACC_PID_Kb
                                        * Referenced by: '<S60>/Kb'
                                        */
  real_T DiscretePIDController1_Kb; /* Mask Parameter: DiscretePIDController1_Kb
                                     * Referenced by: '<S110>/Kb'
                                     */
  real_T tACC_PID_Kb;                  /* Mask Parameter: tACC_PID_Kb
                                        * Referenced by: '<S159>/Kb'
                                        */
  real_T TransferFcnFirstOrder9_PoleZ;
                                 /* Mask Parameter: TransferFcnFirstOrder9_PoleZ
                                  * Referenced by: '<S34>/Gain'
                                  */
  real_T TransferFcnFirstOrder8_PoleZ;
                                 /* Mask Parameter: TransferFcnFirstOrder8_PoleZ
                                  * Referenced by: '<S33>/Gain'
                                  */
  real_T TransferFcnFirstOrder10_PoleZ;
                                /* Mask Parameter: TransferFcnFirstOrder10_PoleZ
                                 * Referenced by: '<S26>/Gain'
                                 */
  real_T TransferFcnFirstOrder11_PoleZ;
                                /* Mask Parameter: TransferFcnFirstOrder11_PoleZ
                                 * Referenced by: '<S27>/Gain'
                                 */
  real_T TransferFcnFirstOrder5_PoleZ;
                                 /* Mask Parameter: TransferFcnFirstOrder5_PoleZ
                                  * Referenced by: '<S30>/Gain'
                                  */
  real_T TransferFcnFirstOrder4_PoleZ;
                                 /* Mask Parameter: TransferFcnFirstOrder4_PoleZ
                                  * Referenced by: '<S29>/Gain'
                                  */
  real_T TransferFcnFirstOrder6_PoleZ;
                                 /* Mask Parameter: TransferFcnFirstOrder6_PoleZ
                                  * Referenced by: '<S31>/Gain'
                                  */
  real_T TransferFcnFirstOrder7_PoleZ;
                                 /* Mask Parameter: TransferFcnFirstOrder7_PoleZ
                                  * Referenced by: '<S32>/Gain'
                                  */
  real_T shift_paddle_threshold1_const;
                                /* Mask Parameter: shift_paddle_threshold1_const
                                 * Referenced by: '<S348>/Constant'
                                 */
  real_T CompareToConstant2_const;   /* Mask Parameter: CompareToConstant2_const
                                      * Referenced by: '<S344>/Constant'
                                      */
  real_T shift_paddle_threshold_const;
                                 /* Mask Parameter: shift_paddle_threshold_const
                                  * Referenced by: '<S347>/Constant'
                                  */
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S12>/Constant'
                                       */
  real_T CompareToConstant1_const;   /* Mask Parameter: CompareToConstant1_const
                                      * Referenced by: '<S187>/Constant'
                                      */
  real_T CompareToConstant3_const;   /* Mask Parameter: CompareToConstant3_const
                                      * Referenced by: '<S189>/Constant'
                                      */
  real_T CompareToConstant2_const_f;
                                   /* Mask Parameter: CompareToConstant2_const_f
                                    * Referenced by: '<S188>/Constant'
                                    */
  real_T AEB_Approaching_Speed_Threshold_const;
                        /* Mask Parameter: AEB_Approaching_Speed_Threshold_const
                         * Referenced by: '<S219>/Constant'
                         */
  real_T CompareToConstant_const_b; /* Mask Parameter: CompareToConstant_const_b
                                     * Referenced by: '<S223>/Constant'
                                     */
  real_T CompareToConstant4_const;   /* Mask Parameter: CompareToConstant4_const
                                      * Referenced by: '<S190>/Constant'
                                      */
  real_T CompareToConstant2_const_p;
                                   /* Mask Parameter: CompareToConstant2_const_p
                                    * Referenced by: '<S205>/Constant'
                                    */
  real_T CompareToConstant3_const_m;
                                   /* Mask Parameter: CompareToConstant3_const_m
                                    * Referenced by: '<S206>/Constant'
                                    */
  real_T CompareToConstant1_const_p;
                                   /* Mask Parameter: CompareToConstant1_const_p
                                    * Referenced by: '<S204>/Constant'
                                    */
  real_T gear_change_max_speed_up_const;
                               /* Mask Parameter: gear_change_max_speed_up_const
                                * Referenced by: '<S346>/Constant'
                                */
  real_T CompareToConstant1_const_b;
                                   /* Mask Parameter: CompareToConstant1_const_b
                                    * Referenced by: '<S253>/Constant'
                                    */
  real_T CompareToConstant4_const_n;
                                   /* Mask Parameter: CompareToConstant4_const_n
                                    * Referenced by: '<S256>/Constant'
                                    */
  real_T CompareToConstant6_const;   /* Mask Parameter: CompareToConstant6_const
                                      * Referenced by: '<S258>/Constant'
                                      */
  real_T CompareToConstant8_const;   /* Mask Parameter: CompareToConstant8_const
                                      * Referenced by: '<S259>/Constant'
                                      */
  real_T CompareToConstant5_const;   /* Mask Parameter: CompareToConstant5_const
                                      * Referenced by: '<S257>/Constant'
                                      */
  real_T CompareToConstant9_const;   /* Mask Parameter: CompareToConstant9_const
                                      * Referenced by: '<S260>/Constant'
                                      */
  real_T gear_change_max_speed_down_const;
                             /* Mask Parameter: gear_change_max_speed_down_const
                              * Referenced by: '<S345>/Constant'
                              */
  real_T CompareToConstant_const_d; /* Mask Parameter: CompareToConstant_const_d
                                     * Referenced by: '<S339>/Constant'
                                     */
  real_T CompareToConstant1_const_f;
                                   /* Mask Parameter: CompareToConstant1_const_f
                                    * Referenced by: '<S340>/Constant'
                                    */
  real_T CompareToConstant_const_g; /* Mask Parameter: CompareToConstant_const_g
                                     * Referenced by: '<S342>/Constant'
                                     */
  real_T CompareToConstant1_const_bt;
                                  /* Mask Parameter: CompareToConstant1_const_bt
                                   * Referenced by: '<S343>/Constant'
                                   */
  real_T CompareToConstant1_const_l;
                                   /* Mask Parameter: CompareToConstant1_const_l
                                    * Referenced by: '<S224>/Constant'
                                    */
  real_T DetectIncrease1_vinit;        /* Mask Parameter: DetectIncrease1_vinit
                                        * Referenced by: '<S194>/Delay Input1'
                                        */
  real_T DetectDecrease_vinit;         /* Mask Parameter: DetectDecrease_vinit
                                        * Referenced by: '<S14>/Delay Input1'
                                        */
  real_T DetectIncrease_vinit;         /* Mask Parameter: DetectIncrease_vinit
                                        * Referenced by: '<S23>/Delay Input1'
                                        */
  real_T DetectIncrease1_vinit_p;     /* Mask Parameter: DetectIncrease1_vinit_p
                                       * Referenced by: '<S24>/Delay Input1'
                                       */
  real_T DetectIncrease_vinit_a;       /* Mask Parameter: DetectIncrease_vinit_a
                                        * Referenced by: '<S84>/Delay Input1'
                                        */
  real_T DetectIncrease1_vinit_j;     /* Mask Parameter: DetectIncrease1_vinit_j
                                       * Referenced by: '<S85>/Delay Input1'
                                       */
  real_T DetectChange_vinit;           /* Mask Parameter: DetectChange_vinit
                                        * Referenced by: '<S230>/Delay Input1'
                                        */
  boolean_T CompareToConstant_const_l;
                                    /* Mask Parameter: CompareToConstant_const_l
                                     * Referenced by: '<S203>/Constant'
                                     */
  boolean_T DetectIncrease_vinit_ao;  /* Mask Parameter: DetectIncrease_vinit_ao
                                       * Referenced by: '<S13>/Delay Input1'
                                       */
  boolean_T DetectIncrease_vinit_m;    /* Mask Parameter: DetectIncrease_vinit_m
                                        * Referenced by: '<S193>/Delay Input1'
                                        */
  real_T Gain_Gain;                    /* Expression: 0
                                        * Referenced by: '<S10>/Gain'
                                        */
  real_T TSamp_WtEt;                   /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S246>/TSamp'
                                        */
  real_T Gain_Gain_n;                  /* Expression: -1
                                        * Referenced by: '<S235>/Gain'
                                        */
  real_T Gain_Gain_f;                  /* Expression: 0
                                        * Referenced by: '<S216>/Gain'
                                        */
  real_T Gain_Gain_p;                  /* Expression: -1
                                        * Referenced by: '<S250>/Gain'
                                        */
  real_T Constant7_Value;              /* Expression: 121
                                        * Referenced by: '<S330>/Constant7'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S22>/Constant'
                                        */
  real_T Constant_Value_f;             /* Expression: 0
                                        * Referenced by: '<S191>/Constant'
                                        */
  real_T Constant_Value_a;             /* Expression: 0
                                        * Referenced by: '<S192>/Constant'
                                        */
  real_T Constant_Value_g;             /* Expression: 0
                                        * Referenced by: '<S213>/Constant'
                                        */
  real_T Constant_Value_o;             /* Expression: 0
                                        * Referenced by: '<S226>/Constant'
                                        */
  real_T Constant_Value_az;            /* Expression: 0
                                        * Referenced by: '<S228>/Constant'
                                        */
  real_T Constant_Value_l;             /* Expression: 0
                                        * Referenced by: '<S229>/Constant'
                                        */
  real_T Constant_Value_e;             /* Expression: 0
                                        * Referenced by: '<S248>/Constant'
                                        */
  real_T Constant_Value_c;             /* Expression: 0
                                        * Referenced by: '<S261>/Constant'
                                        */
  real_T Gain1_Gain;                   /* Expression: -1
                                        * Referenced by: '<S8>/Gain1'
                                        */
  real_T Constant_Value_p;             /* Expression: 300
                                        * Referenced by: '<S8>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S8>/Constant1'
                                        */
  real_T Memory_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S11>/Memory'
                                        */
  real_T Constant_Value_k;             /* Expression: 0
                                        * Referenced by: '<S16>/Constant'
                                        */
  real_T Constant3_Value;              /* Expression: 100
                                        * Referenced by: '<S215>/Constant3'
                                        */
  real_T RateTransition7_InitialCondition;/* Expression: 0
                                           * Referenced by: '<S215>/Rate Transition7'
                                           */
  real_T Target_X_Distance_mux_InitialCondition;/* Expression: 0
                                                 * Referenced by:
                                                 */
  real_T PulseGenerator_Amp;           /* Expression: 1
                                        * Referenced by: '<S215>/Pulse Generator'
                                        */
  real_T PulseGenerator_Period;     /* Computed Parameter: PulseGenerator_Period
                                     * Referenced by: '<S215>/Pulse Generator'
                                     */
  real_T PulseGenerator_Duty;         /* Computed Parameter: PulseGenerator_Duty
                                       * Referenced by: '<S215>/Pulse Generator'
                                       */
  real_T PulseGenerator_PhaseDelay;    /* Expression: 0
                                        * Referenced by: '<S215>/Pulse Generator'
                                        */
  real_T RateLimiter1_RisingLim;       /* Expression: inf
                                        * Referenced by: '<S215>/Rate Limiter1'
                                        */
  real_T RateLimiter1_FallingLim;      /* Expression: -1
                                        * Referenced by: '<S215>/Rate Limiter1'
                                        */
  real_T RateLimiter1_IC;              /* Expression: 0
                                        * Referenced by: '<S215>/Rate Limiter1'
                                        */
  real_T RateLimiter_RisingLim;        /* Expression: inf
                                        * Referenced by: '<S215>/Rate Limiter'
                                        */
  real_T RateLimiter_FallingLim;       /* Expression: -1
                                        * Referenced by: '<S215>/Rate Limiter'
                                        */
  real_T Delay1_InitialCondition;      /* Expression: 0.0
                                        * Referenced by: '<S215>/Delay1'
                                        */
  real_T Switch2_Threshold;            /* Expression: 0
                                        * Referenced by: '<S215>/Switch2'
                                        */
  real_T Constant_Value_m;             /* Expression: 0
                                        * Referenced by: '<S215>/Constant'
                                        */
  real_T TmpRTBAtProduct5Inport1_InitialCondition;/* Expression: 0
                                                   * Referenced by:
                                                   */
  real_T RateTransition6_InitialCondition;/* Expression: 0
                                           * Referenced by: '<S215>/Rate Transition6'
                                           */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S216>/Switch'
                                        */
  real_T Memory_InitialCondition_p;    /* Expression: 0
                                        * Referenced by: '<S16>/Memory'
                                        */
  real_T Constant_Value_oj;            /* Expression: 15
                                        * Referenced by: '<S15>/Constant'
                                        */
  real_T Memory_InitialCondition_l;    /* Expression: 0
                                        * Referenced by: '<S15>/Memory'
                                        */
  real_T Constant6_Value;              /* Expression: 1
                                        * Referenced by: '<S330>/Constant6'
                                        */
  real_T Constant2_Value[9];           /* Expression: [0 0 0 0 0 0 0 0 0]
                                        * Referenced by: '<S330>/Constant2'
                                        */
  real_T Constant_Value_lf[448];       /* Expression: zeros(64,7)
                                        * Referenced by: '<S321>/Constant'
                                        */
  real_T Constant3_Value_g[9];
                            /* Expression: [121 121 121 121 121 121 121 121 121]
                             * Referenced by: '<S330>/Constant3'
                             */
  real_T Constant4_Value[9];           /* Expression: [0 0 0 0 0 0 0 0 0]
                                        * Referenced by: '<S330>/Constant4'
                                        */
  real_T Constant_Value_pa;            /* Expression: 1
                                        * Referenced by: '<S330>/Constant'
                                        */
  real_T Constant5_Value[9];           /* Expression: [0 0 0 0 0 0 0 0 0]
                                        * Referenced by: '<S330>/Constant5'
                                        */
  real_T TmpRTBAtMultiportSwitchInport3_InitialCondition;/* Expression: 0
                                                          * Referenced by:
                                                          */
  real_T Gain_Gain_a;                  /* Expression: 1/2
                                        * Referenced by: '<S320>/Gain'
                                        */
  real_T Gain_Gain_ff;                 /* Expression: 1
                                        * Referenced by: '<S199>/Gain'
                                        */
  real_T Gain1_Gain_b;                 /* Expression: 1.3
                                        * Referenced by: '<S199>/Gain1'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0.02
                                        * Referenced by: '<S197>/Switch1'
                                        */
  real_T Integrator_gainval;           /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S117>/Integrator'
                                        */
  real_T TmpRTBAtSumInport1_InitialCondition;/* Expression: 0
                                              * Referenced by:
                                              */
  real_T Integrator_gainval_p;       /* Computed Parameter: Integrator_gainval_p
                                      * Referenced by: '<S168>/Integrator'
                                      */
  real_T TmpRTBAtTsampOutport1_InitialCondition;/* Expression: 0
                                                 * Referenced by:
                                                 */
  real_T Saturation1_UpperSat;         /* Expression: 0
                                        * Referenced by: '<S15>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: -100
                                        * Referenced by: '<S15>/Saturation1'
                                        */
  real_T ACC_Brake_Gain2_Gain;         /* Expression: -1
                                        * Referenced by: '<S15>/ACC_Brake_Gain2'
                                        */
  real_T Memory1_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S15>/Memory1'
                                        */
  real_T Memory2_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S15>/Memory2'
                                        */
  real_T Switch2_Threshold_d;          /* Expression: 0
                                        * Referenced by: '<S15>/Switch2'
                                        */
  real_T Integrator_gainval_pc;     /* Computed Parameter: Integrator_gainval_pc
                                     * Referenced by: '<S67>/Integrator'
                                     */
  real_T Saturation2_UpperSat;         /* Expression: 0
                                        * Referenced by: '<S15>/Saturation2'
                                        */
  real_T Saturation2_LowerSat;         /* Expression: -100
                                        * Referenced by: '<S15>/Saturation2'
                                        */
  real_T ACC_Brake_Gain1_Gain;         /* Expression: -1
                                        * Referenced by: '<S15>/ACC_Brake_Gain1'
                                        */
  real_T Saturation8_UpperSat;         /* Expression: 100
                                        * Referenced by: '<S15>/Saturation8'
                                        */
  real_T Saturation8_LowerSat;         /* Expression: -100
                                        * Referenced by: '<S15>/Saturation8'
                                        */
  real_T Saturation3_UpperSat;         /* Expression: 100
                                        * Referenced by: '<S15>/Saturation3'
                                        */
  real_T Saturation3_LowerSat;         /* Expression: 0
                                        * Referenced by: '<S15>/Saturation3'
                                        */
  real_T Saturation4_UpperSat;         /* Expression: 100
                                        * Referenced by: '<S15>/Saturation4'
                                        */
  real_T Saturation4_LowerSat;         /* Expression: 0
                                        * Referenced by: '<S15>/Saturation4'
                                        */
  real_T Saturation9_UpperSat;         /* Expression: 100
                                        * Referenced by: '<S15>/Saturation9'
                                        */
  real_T Saturation9_LowerSat;         /* Expression: -100
                                        * Referenced by: '<S15>/Saturation9'
                                        */
  real_T Constant_Value_n;             /* Expression: 0
                                        * Referenced by: '<S198>/Constant'
                                        */
  real_T Switch_Threshold_c;           /* Expression: 0
                                        * Referenced by: '<S10>/Switch'
                                        */
  real_T ACC_Output_Brake_Gain_Gain;   /* Expression: 1
                                        * Referenced by: '<S319>/ACC_Output_Brake_Gain'
                                        */
  real_T AEB_Output_Brake_Gain_Gain;   /* Expression: 1
                                        * Referenced by: '<S319>/AEB_Output_Brake_Gain'
                                        */
  real_T Gain4_Gain;                   /* Expression: -1
                                        * Referenced by: '<S249>/Gain4'
                                        */
  real_T Constant2_Value_b;            /* Expression: 1
                                        * Referenced by: '<S250>/Constant2'
                                        */
  real_T Memory2_InitialCondition_c;   /* Expression: 0
                                        * Referenced by: '<S250>/Memory2'
                                        */
  real_T Constant_Value_mq;            /* Expression: 0
                                        * Referenced by: '<S250>/Constant'
                                        */
  real_T RateTransition8_InitialCondition;/* Expression: 0
                                           * Referenced by: '<S250>/Rate Transition8'
                                           */
  real_T Integrator_IC;                /* Expression: 0
                                        * Referenced by: '<S250>/Integrator'
                                        */
  real_T Memory_InitialCondition_g;    /* Expression: 0
                                        * Referenced by: '<S250>/Memory'
                                        */
  real_T RateTransition5_InitialCondition;/* Expression: 0
                                           * Referenced by: '<S250>/Rate Transition5'
                                           */
  real_T Gain2_Gain;                   /* Expression: -1
                                        * Referenced by: '<S250>/Gain2'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 4
                                        * Referenced by: '<S19>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: 1
                                        * Referenced by: '<S19>/Saturation'
                                        */
  real_T TmpRTBAtSumI4Inport2_InitialCondition;/* Expression: 0
                                                * Referenced by:
                                                */
  real_T RateLimiter_RisingLim_p;      /* Expression: inf
                                        * Referenced by: '<S10>/Rate Limiter'
                                        */
  real_T RateLimiter_FallingLim_f;     /* Expression: -100
                                        * Referenced by: '<S10>/Rate Limiter'
                                        */
  real_T PulseGenerator_Amp_f;         /* Expression: 1
                                        * Referenced by: '<S216>/Pulse Generator'
                                        */
  real_T PulseGenerator_Period_n; /* Computed Parameter: PulseGenerator_Period_n
                                   * Referenced by: '<S216>/Pulse Generator'
                                   */
  real_T PulseGenerator_Duty_n;     /* Computed Parameter: PulseGenerator_Duty_n
                                     * Referenced by: '<S216>/Pulse Generator'
                                     */
  real_T PulseGenerator_PhaseDelay_g;  /* Expression: 0
                                        * Referenced by: '<S216>/Pulse Generator'
                                        */
  real_T RateTransition5_InitialCondition_e;/* Expression: 0
                                             * Referenced by: '<S215>/Rate Transition5'
                                             */
  real_T Gain2_Gain_k;                 /* Expression: 0
                                        * Referenced by: '<S214>/Gain2'
                                        */
  real_T Gain4_Gain_e;                 /* Expression: -1
                                        * Referenced by: '<S214>/Gain4'
                                        */
  real_T Gain5_Gain;                   /* Expression: -1
                                        * Referenced by: '<S214>/Gain5'
                                        */
  real_T Gain_Gain_nj;                 /* Expression: 0
                                        * Referenced by: '<S214>/Gain'
                                        */
  real_T Gain1_Gain_m;                 /* Expression: 0
                                        * Referenced by: '<S214>/Gain1'
                                        */
  real_T Gain3_Gain;                   /* Expression: 0
                                        * Referenced by: '<S214>/Gain3'
                                        */
  real_T after_saturation_InitialCondition;/* Expression: 0
                                            * Referenced by:
                                            */
  real_T filtering_NumCoef[3];         /* Expression: [butter_b]
                                        * Referenced by: '<S215>/filtering'
                                        */
  real_T filtering_DenCoef[3];         /* Expression: [butter_a]
                                        * Referenced by: '<S215>/filtering'
                                        */
  real_T filtering_InitialStates;      /* Expression: 0
                                        * Referenced by: '<S215>/filtering'
                                        */
  real_T Gain4_Gain_p;                 /* Expression: -1
                                        * Referenced by: '<S250>/Gain4'
                                        */
  real_T Integrator1_IC;               /* Expression: 0
                                        * Referenced by: '<S250>/Integrator1'
                                        */
  real_T TmpRTBAtSumOutport1_InitialCondition;/* Expression: 0
                                               * Referenced by:
                                               */
  real_T DiscreteFilter_NumCoef[3];    /* Expression: [butter_b]
                                        * Referenced by: '<S329>/Discrete Filter'
                                        */
  real_T DiscreteFilter_DenCoef[3];    /* Expression: [butter_a]
                                        * Referenced by: '<S329>/Discrete Filter'
                                        */
  real_T DiscreteFilter_InitialStates; /* Expression: 0
                                        * Referenced by: '<S329>/Discrete Filter'
                                        */
  real_T TmpRTBAtDiscreteFilter1Inport1_InitialCondition;/* Expression: 0
                                                          * Referenced by:
                                                          */
  real_T DiscreteFilter1_NumCoef[3];   /* Expression: [butter_b]
                                        * Referenced by: '<S329>/Discrete Filter1'
                                        */
  real_T DiscreteFilter1_DenCoef[3];   /* Expression: [butter_a]
                                        * Referenced by: '<S329>/Discrete Filter1'
                                        */
  real_T DiscreteFilter1_InitialStates;/* Expression: 0
                                        * Referenced by: '<S329>/Discrete Filter1'
                                        */
  real_T PulseGenerator_Amp_g;         /* Expression: 1
                                        * Referenced by: '<S329>/Pulse Generator'
                                        */
  real_T PulseGenerator_Period_j; /* Computed Parameter: PulseGenerator_Period_j
                                   * Referenced by: '<S329>/Pulse Generator'
                                   */
  real_T PulseGenerator_Duty_d;     /* Computed Parameter: PulseGenerator_Duty_d
                                     * Referenced by: '<S329>/Pulse Generator'
                                     */
  real_T PulseGenerator_PhaseDelay_e;  /* Expression: 0
                                        * Referenced by: '<S329>/Pulse Generator'
                                        */
  real_T VI_WorldSim_Sensor_VirtualCamera_P1_Size[2];
                 /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P1_Size
                  * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                  */
  real_T VI_WorldSim_Sensor_VirtualCamera_P1[9];
                      /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P1
                       * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                       */
  real_T VI_WorldSim_Sensor_VirtualCamera_P2_Size[2];
                 /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P2_Size
                  * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                  */
  real_T VI_WorldSim_Sensor_VirtualCamera_P2;/* Expression: worldsim_endpoint_port
                                              * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                                              */
  real_T VI_WorldSim_Sensor_VirtualCamera_P3_Size[2];
                 /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P3_Size
                  * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                  */
  real_T VI_WorldSim_Sensor_VirtualCamera_P3[3];
                      /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P3
                       * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                       */
  real_T VI_WorldSim_Sensor_VirtualCamera_P4_Size[2];
                 /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P4_Size
                  * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                  */
  real_T VI_WorldSim_Sensor_VirtualCamera_P4[16];
                      /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P4
                       * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                       */
  real_T VI_WorldSim_Sensor_VirtualCamera_P5_Size[2];
                 /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P5_Size
                  * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                  */
  real_T VI_WorldSim_Sensor_VirtualCamera_P5;/* Expression: max_lanes
                                              * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                                              */
  real_T VI_WorldSim_Sensor_VirtualCamera_P6_Size[2];
                 /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P6_Size
                  * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                  */
  real_T VI_WorldSim_Sensor_VirtualCamera_P6;/* Expression: max_obstacles
                                              * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                                              */
  real_T VI_WorldSim_Sensor_VirtualCamera_P7_Size[2];
                 /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera_P7_Size
                  * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                  */
  real_T VI_WorldSim_Sensor_VirtualCamera_P7;/* Expression: worldsim_verbose
                                              * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera'
                                              */
  real_T Gain_Gain_j;                  /* Expression: 0.5
                                        * Referenced by: '<S331>/Gain'
                                        */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P1_Size[2];
                /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P1_Size
                 * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                 */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P1[9];
                     /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P1
                      * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                      */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P2_Size[2];
                /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P2_Size
                 * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                 */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P2;/* Expression: worldsim_endpoint_port
                                               * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                                               */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P3_Size[2];
                /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P3_Size
                 * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                 */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P3[3];
                     /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P3
                      * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                      */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P4_Size[2];
                /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P4_Size
                 * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                 */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P4[15];
                     /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P4
                      * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                      */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P5_Size[2];
                /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P5_Size
                 * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                 */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P5;/* Expression: max_lanes
                                               * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                                               */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P6_Size[2];
                /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P6_Size
                 * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                 */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P6;/* Expression: max_obstacles
                                               * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                                               */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P7_Size[2];
                /* Computed Parameter: VI_WorldSim_Sensor_VirtualCamera1_P7_Size
                 * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                 */
  real_T VI_WorldSim_Sensor_VirtualCamera1_P7;/* Expression: worldsim_verbose
                                               * Referenced by: '<S321>/VI_WorldSim_Sensor_VirtualCamera1'
                                               */
  real_T Gain2_Gain_f;                 /* Expression: -1
                                        * Referenced by: '<S329>/Gain2'
                                        */
  real_T Memory_InitialCondition_n;    /* Expression: 0
                                        * Referenced by: '<S321>/Memory'
                                        */
  real_T VI_WorldSim_State_Manager_P1_Size[2];
                        /* Computed Parameter: VI_WorldSim_State_Manager_P1_Size
                         * Referenced by: '<S321>/VI_WorldSim_State_Manager'
                         */
  real_T VI_WorldSim_State_Manager_P1[9];
                             /* Computed Parameter: VI_WorldSim_State_Manager_P1
                              * Referenced by: '<S321>/VI_WorldSim_State_Manager'
                              */
  real_T VI_WorldSim_State_Manager_P2_Size[2];
                        /* Computed Parameter: VI_WorldSim_State_Manager_P2_Size
                         * Referenced by: '<S321>/VI_WorldSim_State_Manager'
                         */
  real_T VI_WorldSim_State_Manager_P2; /* Expression: worldsim_endpoint_port
                                        * Referenced by: '<S321>/VI_WorldSim_State_Manager'
                                        */
  real_T VI_WorldSim_State_Manager_P3_Size[2];
                        /* Computed Parameter: VI_WorldSim_State_Manager_P3_Size
                         * Referenced by: '<S321>/VI_WorldSim_State_Manager'
                         */
  real_T VI_WorldSim_State_Manager_P3[3];
                             /* Computed Parameter: VI_WorldSim_State_Manager_P3
                              * Referenced by: '<S321>/VI_WorldSim_State_Manager'
                              */
  real_T VI_WorldSim_State_Manager_P4_Size[2];
                        /* Computed Parameter: VI_WorldSim_State_Manager_P4_Size
                         * Referenced by: '<S321>/VI_WorldSim_State_Manager'
                         */
  real_T VI_WorldSim_State_Manager_P4; /* Expression: worldsim_verbose
                                        * Referenced by: '<S321>/VI_WorldSim_State_Manager'
                                        */
  real_T Target_Distance_Saturation_LowerSat;/* Expression: 2
                                              * Referenced by: '<S15>/Target_Distance_Saturation'
                                              */
  real_T Constant_Value_n4;            /* Expression: 0
                                        * Referenced by: '<S35>/Constant'
                                        */
  real_T Tsamp_WtEt;                   /* Computed Parameter: Tsamp_WtEt
                                        * Referenced by: '<S163>/Tsamp'
                                        */
  real_T Gain3_Gain_j;                 /* Expression: 0.5
                                        * Referenced by: '<S250>/Gain3'
                                        */
  real_T TSamp_WtEt_b;                 /* Computed Parameter: TSamp_WtEt_b
                                        * Referenced by: '<S262>/TSamp'
                                        */
  real_T TSamp_WtEt_h;                 /* Computed Parameter: TSamp_WtEt_h
                                        * Referenced by: '<S263>/TSamp'
                                        */
  real_T Constant_Value_m5;            /* Expression: 0
                                        * Referenced by: '<S264>/Constant'
                                        */
  real_T Tsamp_WtEt_d;                 /* Computed Parameter: Tsamp_WtEt_d
                                        * Referenced by: '<S296>/Tsamp'
                                        */
  real_T Integrator_gainval_f;       /* Computed Parameter: Integrator_gainval_f
                                      * Referenced by: '<S301>/Integrator'
                                      */
  real_T sampletime_WtEt;              /* Computed Parameter: sampletime_WtEt
                                        * Referenced by: '<S266>/sample time'
                                        */
  real_T DelayInput2_InitialCondition; /* Expression: 0
                                        * Referenced by: '<S266>/Delay Input2'
                                        */
  real_T RateLimiter_IC;               /* Expression: 0
                                        * Referenced by: '<S250>/Rate Limiter'
                                        */
  real_T Constant_Value_ne;            /* Expression: 1
                                        * Referenced by: '<S221>/Constant'
                                        */
  real_T Constant1_Value_d;            /* Expression: 1
                                        * Referenced by: '<S239>/Constant1'
                                        */
  real_T Saturation_UpperSat_j;        /* Expression: 1.7
                                        * Referenced by: '<S239>/Saturation'
                                        */
  real_T Saturation_LowerSat_l;        /* Expression: 0.8
                                        * Referenced by: '<S239>/Saturation'
                                        */
  real_T Lane_Right_Edge_Y_Distance_Value;/* Expression: -1.5
                                           * Referenced by: '<S241>/Lane_Right_Edge_Y_Distance'
                                           */
  real_T TSamp_WtEt_f;                 /* Computed Parameter: TSamp_WtEt_f
                                        * Referenced by: '<S244>/TSamp'
                                        */
  real_T Saturation_UpperSat_i;        /* Expression: -1e-6
                                        * Referenced by: '<S241>/Saturation'
                                        */
  real_T Saturation_LowerSat_i;        /* Expression: -inf
                                        * Referenced by: '<S241>/Saturation'
                                        */
  real_T Gain2_Gain_n;                 /* Expression: -1
                                        * Referenced by: '<S241>/Gain2'
                                        */
  real_T Lane_Left_Edge_Y_Distance_Value;/* Expression: 1.5
                                          * Referenced by: '<S241>/Lane_Left_Edge_Y_Distance'
                                          */
  real_T TSamp_WtEt_a;                 /* Computed Parameter: TSamp_WtEt_a
                                        * Referenced by: '<S243>/TSamp'
                                        */
  real_T Saturation1_UpperSat_c;       /* Expression: -1e-6
                                        * Referenced by: '<S241>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_d;       /* Expression: -inf
                                        * Referenced by: '<S241>/Saturation1'
                                        */
  real_T Gain1_Gain_l;                 /* Expression: -1
                                        * Referenced by: '<S241>/Gain1'
                                        */
  real_T TSamp_WtEt_i;                 /* Computed Parameter: TSamp_WtEt_i
                                        * Referenced by: '<S242>/TSamp'
                                        */
  real_T Saturation_UpperSat_o;        /* Expression: -1e-6
                                        * Referenced by: '<S240>/Saturation'
                                        */
  real_T Saturation_LowerSat_j;        /* Expression: -inf
                                        * Referenced by: '<S240>/Saturation'
                                        */
  real_T Gain_Gain_nd;                 /* Expression: -1
                                        * Referenced by: '<S240>/Gain'
                                        */
  real_T Constant1_Value_i;            /* Expression: 0
                                        * Referenced by: '<S215>/Constant1'
                                        */
  real_T Constant2_Value_p;            /* Expression: 10
                                        * Referenced by: '<S215>/Constant2'
                                        */
  real_T Gain_Gain_g;                  /* Expression: 2
                                        * Referenced by: '<S231>/Gain'
                                        */
  real_T Delay_InitialCondition;       /* Expression: 0
                                        * Referenced by: '<S215>/Delay'
                                        */
  real_T Gain1_Gain_d;                 /* Expression: 100
                                        * Referenced by: '<S215>/Gain1'
                                        */
  real_T Saturation_UpperSat_e;        /* Expression: inf
                                        * Referenced by: '<S215>/Saturation'
                                        */
  real_T Saturation_LowerSat_ll;       /* Expression: 1e-6
                                        * Referenced by: '<S215>/Saturation'
                                        */
  boolean_T Constant_Value_b;          /* Computed Parameter: Constant_Value_b
                                        * Referenced by: '<S227>/Constant'
                                        */
  boolean_T Memory1_InitialCondition_l;
                               /* Computed Parameter: Memory1_InitialCondition_l
                                * Referenced by: '<S250>/Memory1'
                                */
  boolean_T Delay_InitialCondition_h;
                                 /* Computed Parameter: Delay_InitialCondition_h
                                  * Referenced by: '<S221>/Delay'
                                  */
  boolean_T Delay1_InitialCondition_b;
                                /* Computed Parameter: Delay1_InitialCondition_b
                                 * Referenced by: '<S221>/Delay1'
                                 */
  boolean_T Delay2_InitialCondition;
                                  /* Computed Parameter: Delay2_InitialCondition
                                   * Referenced by: '<S221>/Delay2'
                                   */
  int8_T Gain_Gain_c;                  /* Computed Parameter: Gain_Gain_c
                                        * Referenced by: '<S19>/Gain'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_auto_pilot_upl_T {
  const char_T *path;
  const char_T *modelName;
  struct SimStruct_tag * *childSfunctions;
  const char_T *errorStatus;
  SS_SimMode simMode;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;
  RTWSolverInfo *solverInfoPtr;
  void *sfcnInfo;

  /*
   * NonInlinedSFcns:
   * The following substructure contains information regarding
   * non-inlined s-functions used in the model.
   */
  struct {
    RTWSfcnInfo sfcnInfo;
    time_T *taskTimePtrs[5];
    SimStruct childSFunctions[3];
    SimStruct *childSFunctionPtrs[3];
    struct _ssBlkInfo2 blkInfo2[3];
    struct _ssSFcnModelMethods2 methods2[3];
    struct _ssSFcnModelMethods3 methods3[3];
    struct _ssSFcnModelMethods4 methods4[3];
    struct _ssStatesInfo2 statesInfo2[3];
    ssPeriodicStatesInfo periodicStatesInfo[3];
    struct _ssPortInfo2 inputOutputPortInfo2[3];
    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[8];
      struct _ssOutPortUnit outputPortUnits[8];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[8];
      int_T oDims1[2];
      int_T oDims2[2];
      int_T oDims4[2];
      int_T oDims6[2];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[5];
      struct _ssDWorkAuxRecord dWorkAux[5];
    } Sfcn0;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[8];
      struct _ssOutPortUnit outputPortUnits[8];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[8];
      int_T oDims1[2];
      int_T oDims2[2];
      int_T oDims4[2];
      int_T oDims6[2];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[5];
      struct _ssDWorkAuxRecord dWorkAux[5];
    } Sfcn1;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[4];
      struct _ssOutPortUnit outputPortUnits[4];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[4];
      int_T oDims3[2];
      uint_T attribs[4];
      mxArray *params[4];
      struct _ssDWorkRecord dWork[5];
      struct _ssDWorkAuxRecord dWorkAux[5];
    } Sfcn2;
  } NonInlinedSFcns;

  void *blockIO;
  const void *constBlockIO;
  void *defaultParam;
  ZCSigState *prevZCSigState;
  real_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  void *zcSignalValues;
  void *inputs;
  void *outputs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeX0[2];
  real_T odeF0[2];
  real_T odeX1START[2];
  real_T odeF1[2];
  real_T odeDELTA[2];
  real_T odeE[4*2];
  real_T odeFAC[2];
  real_T odeDFDX[2*2];
  real_T odeW[2*2];
  int_T odePIVOTS[2];
  real_T odeXTMP[2];
  real_T odeZTMP[2];
  ODE14X_IntgData intgData;
  void *dwork;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
  } DataMapInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
    uint32_T options;
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
    void *xpcData;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T stepSize1;
    uint32_T clockTick2;
    uint32_T clockTickH2;
    time_T stepSize2;
    uint32_T clockTick3;
    uint32_T clockTickH3;
    time_T stepSize3;
    uint32_T clockTick4;
    uint32_T clockTickH4;
    time_T stepSize4;
    struct {
      uint8_T TID[5];
    } TaskCounters;

    struct {
      boolean_T TID1_2;
      boolean_T TID1_3;
      boolean_T TID1_4;
    } RateInteraction;

    time_T tStart;
    time_T tFinal;
    time_T timeOfLastOutput;
    void *timingData;
    real_T *varNextHitTimesList;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    time_T *t;
    time_T sampleTimesArray[5];
    time_T offsetTimesArray[5];
    int_T sampleTimeTaskIDArray[5];
    int_T sampleHitArray[5];
    int_T perTaskSampleHitsArray[25];
    time_T tArray[5];
  } Timing;
};

/* Block parameters (default storage) */
extern P_auto_pilot_upl_T auto_pilot_upl_P;

/* Block signals (default storage) */
extern B_auto_pilot_upl_T auto_pilot_upl_B;

/* Continuous states (default storage) */
extern X_auto_pilot_upl_T auto_pilot_upl_X;

/* Block states (default storage) */
extern DW_auto_pilot_upl_T auto_pilot_upl_DW;

/* Zero-crossing (trigger) state */
extern PrevZCX_auto_pilot_upl_T auto_pilot_upl_PrevZCX;

/* External function called from main */
extern time_T rt_SimUpdateDiscreteEvents(
  int_T rtmNumSampTimes, void *rtmTimingData, int_T *rtmSampleHitPtr, int_T
  *rtmPerTaskSampleHits )
  ;

/* Model entry point functions */
extern void auto_pilot_upl_initialize(void);
extern void auto_pilot_upl_output0(void);
extern void auto_pilot_upl_update0(void);
extern void auto_pilot_upl_output2(void);
extern void auto_pilot_upl_update2(void);
extern void auto_pilot_upl_output3(void);
extern void auto_pilot_upl_update3(void);
extern void auto_pilot_upl_output4(void);
extern void auto_pilot_upl_update4(void);
extern void auto_pilot_upl_terminate(void);

/*====================*
 * External functions *
 *====================*/
extern auto_pilot_upl_rtModel *auto_pilot_upl(void);
extern void MdlInitializeSizes(void);
extern void MdlInitializeSampleTimes(void);
extern void MdlInitialize(void);
extern void MdlStart(void);
extern void MdlOutputs(int_T tid);
extern void MdlUpdate(int_T tid);
extern void MdlTerminate(void);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  auto_pilot_upl_GetCAPIStaticMap(void);

/* Real-time Model object */
extern RT_MODEL_auto_pilot_upl_T *const auto_pilot_upl_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'auto_pilot_upl'
 * '<S1>'   : 'auto_pilot_upl/ACC'
 * '<S2>'   : 'auto_pilot_upl/ADASMapping'
 * '<S3>'   : 'auto_pilot_upl/AEB'
 * '<S4>'   : 'auto_pilot_upl/AP'
 * '<S5>'   : 'auto_pilot_upl/INPUT'
 * '<S6>'   : 'auto_pilot_upl/OUTPUT'
 * '<S7>'   : 'auto_pilot_upl/SteeringButtonsMap'
 * '<S8>'   : 'auto_pilot_upl/ACC/ACC_Inputs'
 * '<S9>'   : 'auto_pilot_upl/ACC/ACC_Logic'
 * '<S10>'  : 'auto_pilot_upl/ACC/ACC_Outputs'
 * '<S11>'  : 'auto_pilot_upl/ACC/ACC_Inputs/ADAS_map'
 * '<S12>'  : 'auto_pilot_upl/ACC/ACC_Inputs/Compare To Constant'
 * '<S13>'  : 'auto_pilot_upl/ACC/ACC_Inputs/Detect Increase'
 * '<S14>'  : 'auto_pilot_upl/ACC/ACC_Inputs/ADAS_map/Detect Decrease'
 * '<S15>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller'
 * '<S16>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch'
 * '<S17>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition'
 * '<S18>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID'
 * '<S19>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_Speed_Distance_Gain'
 * '<S20>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Compare To Constant'
 * '<S21>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Compare To Constant1'
 * '<S22>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Compare To Zero'
 * '<S23>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Detect Increase'
 * '<S24>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Detect Increase1'
 * '<S25>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1'
 * '<S26>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order10'
 * '<S27>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order11'
 * '<S28>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order13'
 * '<S29>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order4'
 * '<S30>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order5'
 * '<S31>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order6'
 * '<S32>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order7'
 * '<S33>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order8'
 * '<S34>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Transfer Fcn First Order9'
 * '<S35>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID'
 * '<S36>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Anti-windup'
 * '<S37>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/D Gain'
 * '<S38>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Filter'
 * '<S39>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Filter ICs'
 * '<S40>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/I Gain'
 * '<S41>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Ideal P Gain'
 * '<S42>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Ideal P Gain Fdbk'
 * '<S43>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Integrator'
 * '<S44>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Integrator ICs'
 * '<S45>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/N Copy'
 * '<S46>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/N Gain'
 * '<S47>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/P Copy'
 * '<S48>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Parallel P Gain'
 * '<S49>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Reset Signal'
 * '<S50>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Saturation'
 * '<S51>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Saturation Fdbk'
 * '<S52>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Sum'
 * '<S53>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Sum Fdbk'
 * '<S54>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Tracking Mode'
 * '<S55>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Tracking Mode Sum'
 * '<S56>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Tsamp - Integral'
 * '<S57>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Tsamp - Ngain'
 * '<S58>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/postSat Signal'
 * '<S59>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/preSat Signal'
 * '<S60>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Anti-windup/Back Calculation'
 * '<S61>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/D Gain/Disabled'
 * '<S62>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Filter/Disabled'
 * '<S63>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Filter ICs/Disabled'
 * '<S64>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/I Gain/Internal Parameters'
 * '<S65>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Ideal P Gain/Passthrough'
 * '<S66>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Ideal P Gain Fdbk/Disabled'
 * '<S67>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Integrator/Discrete'
 * '<S68>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Integrator ICs/External IC'
 * '<S69>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/N Copy/Disabled wSignal Specification'
 * '<S70>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/N Gain/Disabled'
 * '<S71>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/P Copy/Disabled'
 * '<S72>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Parallel P Gain/Internal Parameters'
 * '<S73>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Reset Signal/External Reset'
 * '<S74>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Saturation/Enabled'
 * '<S75>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Saturation Fdbk/Disabled'
 * '<S76>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Sum/Sum_PI'
 * '<S77>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Sum Fdbk/Disabled'
 * '<S78>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Tracking Mode/Disabled'
 * '<S79>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Tracking Mode Sum/Passthrough'
 * '<S80>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Tsamp - Integral/Passthrough'
 * '<S81>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/Tsamp - Ngain/Passthrough'
 * '<S82>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/postSat Signal/Forward_Path'
 * '<S83>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_PID/preSat Signal/Forward_Path'
 * '<S84>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_Speed_Distance_Gain/Detect Increase'
 * '<S85>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/ACC_Speed_Distance_Gain/Detect Increase1'
 * '<S86>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Anti-windup'
 * '<S87>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/D Gain'
 * '<S88>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Filter'
 * '<S89>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Filter ICs'
 * '<S90>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/I Gain'
 * '<S91>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Ideal P Gain'
 * '<S92>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Ideal P Gain Fdbk'
 * '<S93>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Integrator'
 * '<S94>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Integrator ICs'
 * '<S95>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/N Copy'
 * '<S96>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/N Gain'
 * '<S97>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/P Copy'
 * '<S98>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Parallel P Gain'
 * '<S99>'  : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Reset Signal'
 * '<S100>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Saturation'
 * '<S101>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Saturation Fdbk'
 * '<S102>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Sum'
 * '<S103>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Sum Fdbk'
 * '<S104>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Tracking Mode'
 * '<S105>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Tracking Mode Sum'
 * '<S106>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Tsamp - Integral'
 * '<S107>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Tsamp - Ngain'
 * '<S108>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/postSat Signal'
 * '<S109>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/preSat Signal'
 * '<S110>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Anti-windup/Back Calculation'
 * '<S111>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/D Gain/Disabled'
 * '<S112>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Filter/Disabled'
 * '<S113>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Filter ICs/Disabled'
 * '<S114>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/I Gain/Internal Parameters'
 * '<S115>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Ideal P Gain/Passthrough'
 * '<S116>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Ideal P Gain Fdbk/Disabled'
 * '<S117>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Integrator/Discrete'
 * '<S118>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Integrator ICs/Internal IC'
 * '<S119>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/N Copy/Disabled wSignal Specification'
 * '<S120>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/N Gain/Disabled'
 * '<S121>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/P Copy/Disabled'
 * '<S122>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Parallel P Gain/Internal Parameters'
 * '<S123>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Reset Signal/External Reset'
 * '<S124>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Saturation/Enabled'
 * '<S125>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Saturation Fdbk/Disabled'
 * '<S126>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Sum/Sum_PI'
 * '<S127>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Sum Fdbk/Disabled'
 * '<S128>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Tracking Mode/Disabled'
 * '<S129>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Tracking Mode Sum/Passthrough'
 * '<S130>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Tsamp - Integral/Passthrough'
 * '<S131>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/Tsamp - Ngain/Passthrough'
 * '<S132>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/postSat Signal/Forward_Path'
 * '<S133>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/Discrete PID Controller1/preSat Signal/Forward_Path'
 * '<S134>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID'
 * '<S135>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Anti-windup'
 * '<S136>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/D Gain'
 * '<S137>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Filter'
 * '<S138>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Filter ICs'
 * '<S139>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/I Gain'
 * '<S140>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Ideal P Gain'
 * '<S141>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Ideal P Gain Fdbk'
 * '<S142>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Integrator'
 * '<S143>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Integrator ICs'
 * '<S144>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/N Copy'
 * '<S145>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/N Gain'
 * '<S146>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/P Copy'
 * '<S147>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Parallel P Gain'
 * '<S148>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Reset Signal'
 * '<S149>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Saturation'
 * '<S150>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Saturation Fdbk'
 * '<S151>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Sum'
 * '<S152>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Sum Fdbk'
 * '<S153>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Tracking Mode'
 * '<S154>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Tracking Mode Sum'
 * '<S155>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Tsamp - Integral'
 * '<S156>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Tsamp - Ngain'
 * '<S157>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/postSat Signal'
 * '<S158>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/preSat Signal'
 * '<S159>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Anti-windup/Back Calculation'
 * '<S160>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/D Gain/External Parameters'
 * '<S161>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Filter/Differentiator'
 * '<S162>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Filter/Differentiator/Tsamp'
 * '<S163>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Filter/Differentiator/Tsamp/Internal Ts'
 * '<S164>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Filter ICs/Internal IC - Differentiator'
 * '<S165>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/I Gain/External Parameters'
 * '<S166>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Ideal P Gain/Passthrough'
 * '<S167>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Ideal P Gain Fdbk/Disabled'
 * '<S168>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Integrator/Discrete'
 * '<S169>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Integrator ICs/Internal IC'
 * '<S170>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/N Copy/Disabled wSignal Specification'
 * '<S171>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/N Gain/Passthrough'
 * '<S172>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/P Copy/Disabled'
 * '<S173>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Parallel P Gain/External Parameters'
 * '<S174>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Reset Signal/External Reset'
 * '<S175>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Saturation/Enabled'
 * '<S176>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Saturation Fdbk/Disabled'
 * '<S177>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Sum/Sum_PID'
 * '<S178>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Sum Fdbk/Disabled'
 * '<S179>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Tracking Mode/Disabled'
 * '<S180>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Tracking Mode Sum/Passthrough'
 * '<S181>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Tsamp - Integral/Passthrough'
 * '<S182>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/Tsamp - Ngain/Passthrough'
 * '<S183>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/postSat Signal/Forward_Path'
 * '<S184>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Speed_Controller/tACC_PID/tACC_PID/preSat Signal/Forward_Path'
 * '<S185>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/ACC_Ready_Speed'
 * '<S186>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Constant'
 * '<S187>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Constant1'
 * '<S188>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Constant2'
 * '<S189>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Constant3'
 * '<S190>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Constant4'
 * '<S191>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Zero'
 * '<S192>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Compare To Zero3'
 * '<S193>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Detect Increase'
 * '<S194>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Detect Increase1'
 * '<S195>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Discrete Derivative'
 * '<S196>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Switch/Transfer Fcn First Order'
 * '<S197>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_ClosestTargetDistance'
 * '<S198>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_ClosestTargetId'
 * '<S199>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_InCurvedLane_mux'
 * '<S200>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_InStraightLane_mux'
 * '<S201>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_LateralDistance_mux'
 * '<S202>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_LongitudinalDistance_mux'
 * '<S203>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_ClosestTargetId/Compare To Constant'
 * '<S204>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_ClosestTargetId/Compare To Constant1'
 * '<S205>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_ClosestTargetId/Compare To Constant2'
 * '<S206>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_ClosestTargetId/Compare To Constant3'
 * '<S207>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_InCurvedLane_mux/MATLAB Function'
 * '<S208>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_InCurvedLane_mux/Wrap To Zero'
 * '<S209>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_InCurvedLane_mux/Wrap To Zero1'
 * '<S210>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_InStraightLane_mux/Compare_to_Lane_Width_div2'
 * '<S211>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_LateralDistance_mux/Target_Lateral_Position'
 * '<S212>' : 'auto_pilot_upl/ACC/ACC_Logic/ACC_Target_Acquisition/SensorTargets_300000_LongitudinalDistance_mux/Target_Longitudinal_Position'
 * '<S213>' : 'auto_pilot_upl/ACC/ACC_Outputs/Compare To Zero'
 * '<S214>' : 'auto_pilot_upl/AEB/AEB_Inputs'
 * '<S215>' : 'auto_pilot_upl/AEB/AEB_Logic'
 * '<S216>' : 'auto_pilot_upl/AEB/AEB_Outputs'
 * '<S217>' : 'auto_pilot_upl/AEB/AEB_Inputs/MATLAB Function'
 * '<S218>' : 'auto_pilot_upl/AEB/AEB_Inputs/MATLAB Function1'
 * '<S219>' : 'auto_pilot_upl/AEB/AEB_Logic/AEB_Approaching_Speed_Threshold'
 * '<S220>' : 'auto_pilot_upl/AEB/AEB_Logic/AEB_Brake_id '
 * '<S221>' : 'auto_pilot_upl/AEB/AEB_Logic/AEB_Trigger'
 * '<S222>' : 'auto_pilot_upl/AEB/AEB_Logic/Compare To AEB_Distance_To_Collision_Brake'
 * '<S223>' : 'auto_pilot_upl/AEB/AEB_Logic/Compare To Constant'
 * '<S224>' : 'auto_pilot_upl/AEB/AEB_Logic/Compare To Constant1'
 * '<S225>' : 'auto_pilot_upl/AEB/AEB_Logic/Compare To Lane_Width//2'
 * '<S226>' : 'auto_pilot_upl/AEB/AEB_Logic/Compare To Zero'
 * '<S227>' : 'auto_pilot_upl/AEB/AEB_Logic/Compare To Zero1'
 * '<S228>' : 'auto_pilot_upl/AEB/AEB_Logic/Compare To Zero2'
 * '<S229>' : 'auto_pilot_upl/AEB/AEB_Logic/Compare To Zero3'
 * '<S230>' : 'auto_pilot_upl/AEB/AEB_Logic/Detect Change'
 * '<S231>' : 'auto_pilot_upl/AEB/AEB_Logic/Distance_To_Collision_computation'
 * '<S232>' : 'auto_pilot_upl/AEB/AEB_Logic/MATLAB Function'
 * '<S233>' : 'auto_pilot_upl/AEB/AEB_Logic/Target_XY_Distance'
 * '<S234>' : 'auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision'
 * '<S235>' : 'auto_pilot_upl/AEB/AEB_Logic/derivation_speed'
 * '<S236>' : 'auto_pilot_upl/AEB/AEB_Logic/AEB_Trigger/AEB_Max_Speed'
 * '<S237>' : 'auto_pilot_upl/AEB/AEB_Logic/AEB_Trigger/AEB_Steer_Max'
 * '<S238>' : 'auto_pilot_upl/AEB/AEB_Logic/AEB_Trigger/Compare To Pedestrian Type'
 * '<S239>' : 'auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Collision_Identifier_mux   '
 * '<S240>' : 'auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_X_TimeToCollision_mux'
 * '<S241>' : 'auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux'
 * '<S242>' : 'auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_X_TimeToCollision_mux/Discrete Derivative'
 * '<S243>' : 'auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Discrete Derivative1'
 * '<S244>' : 'auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Discrete Derivative2'
 * '<S245>' : 'auto_pilot_upl/AEB/AEB_Logic/Target_XY_TimeToCollision/Target_Y_TimeToCollision_mux/Discrete Derivative3'
 * '<S246>' : 'auto_pilot_upl/AEB/AEB_Logic/derivation_speed/Discrete Derivative'
 * '<S247>' : 'auto_pilot_upl/AEB/AEB_Outputs/AEB_Max_Speed'
 * '<S248>' : 'auto_pilot_upl/AEB/AEB_Outputs/Compare To Zero'
 * '<S249>' : 'auto_pilot_upl/AP/AP_Inputs'
 * '<S250>' : 'auto_pilot_upl/AP/AP_Logic'
 * '<S251>' : 'auto_pilot_upl/AP/AP_Outputs'
 * '<S252>' : 'auto_pilot_upl/AP/AP_Logic/Compare To Constant'
 * '<S253>' : 'auto_pilot_upl/AP/AP_Logic/Compare To Constant1'
 * '<S254>' : 'auto_pilot_upl/AP/AP_Logic/Compare To Constant2'
 * '<S255>' : 'auto_pilot_upl/AP/AP_Logic/Compare To Constant3'
 * '<S256>' : 'auto_pilot_upl/AP/AP_Logic/Compare To Constant4'
 * '<S257>' : 'auto_pilot_upl/AP/AP_Logic/Compare To Constant5'
 * '<S258>' : 'auto_pilot_upl/AP/AP_Logic/Compare To Constant6'
 * '<S259>' : 'auto_pilot_upl/AP/AP_Logic/Compare To Constant8'
 * '<S260>' : 'auto_pilot_upl/AP/AP_Logic/Compare To Constant9'
 * '<S261>' : 'auto_pilot_upl/AP/AP_Logic/Compare To Zero'
 * '<S262>' : 'auto_pilot_upl/AP/AP_Logic/Discrete Derivative'
 * '<S263>' : 'auto_pilot_upl/AP/AP_Logic/Discrete Derivative1'
 * '<S264>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2'
 * '<S265>' : 'auto_pilot_upl/AP/AP_Logic/MATLAB Function'
 * '<S266>' : 'auto_pilot_upl/AP/AP_Logic/Rate Limiter Dynamic'
 * '<S267>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2'
 * '<S268>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Anti-windup'
 * '<S269>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/D Gain'
 * '<S270>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Filter'
 * '<S271>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Filter ICs'
 * '<S272>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/I Gain'
 * '<S273>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Ideal P Gain'
 * '<S274>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Ideal P Gain Fdbk'
 * '<S275>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Integrator'
 * '<S276>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Integrator ICs'
 * '<S277>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/N Copy'
 * '<S278>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/N Gain'
 * '<S279>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/P Copy'
 * '<S280>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Parallel P Gain'
 * '<S281>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Reset Signal'
 * '<S282>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Saturation'
 * '<S283>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Saturation Fdbk'
 * '<S284>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Sum'
 * '<S285>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Sum Fdbk'
 * '<S286>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Tracking Mode'
 * '<S287>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Tracking Mode Sum'
 * '<S288>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Tsamp - Integral'
 * '<S289>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Tsamp - Ngain'
 * '<S290>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/postSat Signal'
 * '<S291>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/preSat Signal'
 * '<S292>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Anti-windup/Passthrough'
 * '<S293>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/D Gain/External Parameters'
 * '<S294>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Filter/Differentiator'
 * '<S295>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Filter/Differentiator/Tsamp'
 * '<S296>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Filter/Differentiator/Tsamp/Internal Ts'
 * '<S297>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Filter ICs/External IC'
 * '<S298>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/I Gain/External Parameters'
 * '<S299>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Ideal P Gain/Passthrough'
 * '<S300>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Ideal P Gain Fdbk/Disabled'
 * '<S301>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Integrator/Discrete'
 * '<S302>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Integrator ICs/External IC'
 * '<S303>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/N Copy/Disabled wSignal Specification'
 * '<S304>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/N Gain/Passthrough'
 * '<S305>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/P Copy/Disabled'
 * '<S306>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Parallel P Gain/External Parameters'
 * '<S307>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Reset Signal/External Reset'
 * '<S308>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Saturation/Passthrough'
 * '<S309>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Saturation Fdbk/Disabled'
 * '<S310>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Sum/Sum_PID'
 * '<S311>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Sum Fdbk/Disabled'
 * '<S312>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Tracking Mode/Disabled'
 * '<S313>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Tracking Mode Sum/Passthrough'
 * '<S314>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Tsamp - Integral/Passthrough'
 * '<S315>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/Tsamp - Ngain/Passthrough'
 * '<S316>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/postSat Signal/Forward_Path'
 * '<S317>' : 'auto_pilot_upl/AP/AP_Logic/Discrete PID Controller2/Discrete PID Controller2/preSat Signal/Forward_Path'
 * '<S318>' : 'auto_pilot_upl/AP/AP_Logic/Rate Limiter Dynamic/Saturation Dynamic'
 * '<S319>' : 'auto_pilot_upl/INPUT/Inputs for CRT'
 * '<S320>' : 'auto_pilot_upl/OUTPUT/VI-CarRealTime_Outputs'
 * '<S321>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs'
 * '<S322>' : 'auto_pilot_upl/OUTPUT/rough data reporting'
 * '<S323>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/MATLAB Function'
 * '<S324>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Radar_selection'
 * '<S325>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem'
 * '<S326>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/manipulation_of_objects'
 * '<S327>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/manipulation_of_objects1'
 * '<S328>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/bsd setection from ostacle recognition'
 * '<S329>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition'
 * '<S330>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/multiagent radar  SimpleRadar_... are single double representing id, yaw, range, power_db, range_rate, yaw_rate, status'
 * '<S331>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/obstacle detection '
 * '<S332>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/bsd setection from ostacle recognition/Compare To Constant'
 * '<S333>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/bsd setection from ostacle recognition/MATLAB Function3'
 * '<S334>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/derivation_speed'
 * '<S335>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/lane marking acquisition/derivation_speed/Discrete Derivative'
 * '<S336>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/multiagent radar  SimpleRadar_... are single double representing id, yaw, range, power_db, range_rate, yaw_rate, status/MATLAB Function1'
 * '<S337>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/obstacle detection /MATLAB Function'
 * '<S338>' : 'auto_pilot_upl/OUTPUT/WorldSim_Sensor_Outputs/Subsystem/obstacle detection /MATLAB Function2'
 * '<S339>' : 'auto_pilot_upl/OUTPUT/rough data reporting/Compare To Constant'
 * '<S340>' : 'auto_pilot_upl/OUTPUT/rough data reporting/Compare To Constant1'
 * '<S341>' : 'auto_pilot_upl/OUTPUT/rough data reporting/Compare To Constant2'
 * '<S342>' : 'auto_pilot_upl/SteeringButtonsMap/Compare To Constant'
 * '<S343>' : 'auto_pilot_upl/SteeringButtonsMap/Compare To Constant1'
 * '<S344>' : 'auto_pilot_upl/SteeringButtonsMap/Compare To Constant2'
 * '<S345>' : 'auto_pilot_upl/SteeringButtonsMap/gear_change_max_speed_down'
 * '<S346>' : 'auto_pilot_upl/SteeringButtonsMap/gear_change_max_speed_up'
 * '<S347>' : 'auto_pilot_upl/SteeringButtonsMap/shift_paddle_threshold'
 * '<S348>' : 'auto_pilot_upl/SteeringButtonsMap/shift_paddle_threshold1'
 */
#endif                                 /* RTW_HEADER_auto_pilot_upl_h_ */
