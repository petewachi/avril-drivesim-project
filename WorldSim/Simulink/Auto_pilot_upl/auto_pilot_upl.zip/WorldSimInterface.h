// @File      : WorldSimInterface.h
// @Contact   : info@vi-grade.com
// @License   : PROPRIETARY/CONFIDENTIAL (https://www.vi-grade.com/license.txt)
// @Copyright : (c) 2006-2023, VI-grade GmbH, Darmstadt, Germany, All Rights Reserved
// ----------------------------------------------------------------------------------
#ifndef WORLDSIM_LIB_H
#define WORLDSIM_LIB_H

#ifndef PUBLIC
#ifdef __cplusplus
#define PUBLIC extern "C"
#else
#define PUBLIC
#endif
#endif

#ifndef EXPORT
#ifdef WIN32
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif
#endif

#define WORLDSIM_UPDATE_FREQUENCY 100.0
#define VIRTUAL_CAMERA_OBSTACLES_DATA 10
#define MAX_LANE_POINTS 20
#define CUBIC_COEFFICIENTS 4
#define RADAR_OBSTACLES_DATA 7
#define LIDAR_OBSTACLES_DATA 4
#define ACTOR_STATES 3

#include <stdint.h>

#define MAX_ENDPOINT_LENGTH 128

// Log Interface
PUBLIC EXPORT void sensorLog(char* msg, int severity);

// Sensor Receiver
PUBLIC EXPORT void* sensorReceiverCreate(const char* endpointIp, const int endpointPort, const char *car_name, int& updated, const char *trigger_name);
PUBLIC EXPORT void sensorReceiverDestructor(void* pointer);

// Controller
PUBLIC EXPORT void playWorldSimScenario(void *pointer, const char* endpointIp, int endpointPort, char* controlEndpoint);
PUBLIC EXPORT void *createControllerSocket(const char *controlEndpoint);
PUBLIC EXPORT bool sendSimAdvanceRequest(void* socket, bool verbose, double new_time, double *y0);
PUBLIC EXPORT void unloadScenario(const char *endpointIp, const int endpointPort);
PUBLIC EXPORT bool reloadScenario(void* pointer);
PUBLIC EXPORT bool resetScenario(const char *endpointIp, const int endpointPort);
PUBLIC EXPORT void closeControllerSocket(void *socket);

// Vehicle Sender
PUBLIC EXPORT void initVehicleSender(void* pointer, const char *endpointIp, const int endpointPort, char *actuationEndpoint, const char *car_name, bool ai_controlled, bool snap_to_gnd, double* wheelbase);
PUBLIC EXPORT void* createActuationSocket(const char *actuationEndpoint);
PUBLIC EXPORT void sendVehicleData(void* socket,
                                   double* inputVec,
                                   double* lightsVec,
                                   bool verbose,
                                   double t_now,
                                   double t_zero,
                                   double wheelbase,
                                   unsigned long int counter);
PUBLIC EXPORT void sendKinematicVehicleData(void* socket,
                                            double* inputVec,
                                            bool verbose,
                                            double t_now,
                                            double t_zero,
                                            double wheelbase,
                                            unsigned long int counter);
PUBLIC EXPORT void closeActuationSocket(void* socket);

// State Manager
PUBLIC EXPORT bool buildStateManager(void* pointer, const char *car_name, bool verbose, bool mode, double& frequency);
PUBLIC EXPORT void getStateManagerData(void* pointer,
                                       bool verbose,
                                       double* y0,
                                       double* y1,
                                       double* y2,
                                       double* y3,
                                       double tick_length,
                                       double seq_no,
                                       double& seq_no_old,
                                       double sim_time);

// Vehicle Intent Manager
PUBLIC EXPORT bool buildVehicleIntentManager(void* pointer, const char *car_name, bool verbose, bool mode);
PUBLIC EXPORT void getVehicleIntentManagerData(void* pointer,
                                       bool verbose,
                                       double* y0,
                                       double* y1,
                                       double tick_length,
                                       double seq_no,
                                       double& seq_no_old,
                                       double sim_time);

// Ultrasonic Sensor
PUBLIC EXPORT bool buildUltrasonicSensor(void* pointer, const char *sensor_name, bool verbose, bool mode);
PUBLIC EXPORT bool getUltrasonicUpdateRate(void* pointer, const char *sensor_name, int& rate);
PUBLIC EXPORT void getUltrasonicData(void* pointer, 
                                    bool verbose, 
                                    double* y0, 
                                    double* y1, 
                                    double* y2, 
                                    double tick_length, 
                                    double seq_no, 
                                    double& seq_no_old, 
                                    double sim_time);


// Virtual Camera
PUBLIC EXPORT bool buildVirtualCameraSensor(void* pointer, const char *sensor_name, bool verbose, bool mode);
PUBLIC EXPORT bool getVirtualCameraUpdateRate(void* pointer, const char *sensor_name, int& rate);
PUBLIC EXPORT int getVirtualCameraMsg(void* pointer, void*& msg, double tick_length, double seq_no, double& seq_no_old, double sim_time);
PUBLIC EXPORT void getVirtualCameraData(void* pointer,
                                        void* msg,
                                        bool verbose,
                                        double* y0,
                                        double* y1,
                                        double* y2,
                                        double* y3,
                                        double* y4,
                                        double* y5,
                                        double* y6,
                                        double* y7,
                                        int max_obstacles,
                                        int max_lanes,
                                        int msg_size);


// LiDAR
PUBLIC EXPORT bool buildLidarSensor(void* pointer, const char *sensor_name, bool verbose, bool mode);
PUBLIC EXPORT bool getLidarUpdateRate(void* pointer, const char *sensor_name, int& rate);
PUBLIC EXPORT int getLidarMsg(void* pointer, void*& msg, double tick_length, double seq_no, double& seq_no_old, double sim_time);
PUBLIC EXPORT void getLidarData(void* pointer, void* msg, bool verbose, double* y0, double* y1, double* y2, int max_size, int msg_size);


// Radar
PUBLIC EXPORT bool buildRadarSensor(void* pointer, const char *sensor_name, bool verbose, bool mode);
PUBLIC EXPORT bool getRadarUpdateRate(void* pointer, const char *sensor_name, int& rate);

PUBLIC EXPORT void getRadarData(void* pointer,
                                bool verbose,
                                double* y0,
                                double* y1,
                                double* y2,
                                int max_size,
                                double tick_length,
                                double seq_no,
                                double& seq_no_old,
                                double sim_time);


// Camera
PUBLIC EXPORT bool buildCameraSensor(void* pointer, const char *sensor_name, bool verbose, bool mode);
PUBLIC EXPORT bool getCameraInfo(void* pointer, const char *sensor_name, double& width, double& height, char * encoding);
PUBLIC EXPORT bool getCameraUpdateRate(void* pointer, const char *sensor_name, int& rate);
PUBLIC EXPORT void getCameraData(void* pointer,
                                 bool verbose,
                                 uint8_t* y0,
                                 uint8_t* y1,
                                 uint8_t* y2,
                                 double* y3,
                                 double tick_length,
                                 double seq_no,
                                 double& seq_no_old,
                                 double sim_time);


// DepthCamera
PUBLIC EXPORT bool buildDepthCameraSensor(void *pointer, const char *sensor_name, bool verbose, bool mode);
PUBLIC EXPORT bool getDepthCameraInfo(void *pointer, const char *sensor_name, double &width, double &height/* , std::string& encoding */);
PUBLIC EXPORT bool getDepthCameraUpdateRate(void *pointer, const char *sensor_name, int &rate, double& max_depth);
PUBLIC EXPORT void getDepthCameraData(void *pointer, 
                                      bool verbose, 
                                      uint8_t *y0, 
                                      uint8_t *y1, 
                                      uint8_t *y2, 
                                      double *y3, 
                                      double tick_length, 
                                      double seq_no, 
                                      double &seq_no_old, 
                                      double sim_time,
                                      double max_depth);


// Semantic Camera
PUBLIC EXPORT bool buildSemanticCameraSensor(void* pointer, const char *sensor_name, bool verbose, bool mode);
PUBLIC EXPORT bool getSemanticCameraInfo(void* pointer, const char *sensor_name, double& width, double& height);
PUBLIC EXPORT bool getSemanticCameraUpdateRate(void* pointer, const char *sensor_name, int& rate);
PUBLIC EXPORT void getSemanticCameraData(void* pointer,
                                         bool verbose,
                                         uint8_t* y0,
                                         uint8_t* y1,
                                         uint8_t* y2,
                                         double* y3,
                                         double tick_length,
                                         double seq_no,
                                         double& seq_no_old,
                                         double sim_time);


// Laserscan
PUBLIC EXPORT bool buildLaserscanSensor(void* pointer, const char *sensor_name, bool verbose, bool mode);
PUBLIC EXPORT bool getLaserscanUpdateRate(void* pointer, const char *sensor_name, int& rate);
PUBLIC EXPORT int getLaserscanMsg(void* pointer, void*& msg, double tick_length, double seq_no, double& seq_no_old, double sim_time);
PUBLIC EXPORT void getLaserscanData(void* pointer, void* msg, bool verbose, double* y0, double* y1, double* y2, int max_size, int msg_size);

// Trigger Manager
PUBLIC EXPORT bool buildTriggerManager(void* pointer, const char* trigger_name, const char *car_name, bool verbose, bool mode, double& frequency);
PUBLIC EXPORT void getTriggerManagerData(void* pointer,
                                       bool verbose,
                                       double* y0,
                                       double* y1,
                                       double tick_length,
                                       double seq_no,
                                       double& seq_no_old,
                                       double sim_time);

PUBLIC EXPORT bool buildWeatherEnvManager(void* pointer, const char* trigger_name, const char *car_name, bool verbose, bool mode, double& frequency);
PUBLIC EXPORT void getWeatherEnvManagerData(void* pointer,
                                            bool verbose,
                                            double* y0,
                                            double* y1,
                                            double* y2,
                                            double* y3,
                                            double* y4,
                                            //double in0,
                                            //double in1,
                                            //double in2,
                                            //double in3,
                                            //double in4,
                                            //double en0,
                                            //double en1,
                                            //double en2,
                                            //double en3,
                                            //double en4,
                                            double tick_length,
                                            double seq_no,
                                            double& seq_no_old,
                                            double sim_time);

// utility to inherit settings from drivesim
PUBLIC EXPORT void retrieveDriveSimEndPoint(char *ip, int& port);

// get worldsim version identification
PUBLIC EXPORT void getWorldSimVersion(char *version, char*revision, char*date, char*hostname, char*url);


#endif  // WORLDSIM_LIB_H
